<?php
/**
 * Publish the search and sharing details a Pagecraft page carries.
 *
 * Cloud publishing writes the page title, description, favicon and social image into the
 * page head. Pages imported into WordPress keep those fields in their Pagecraft document,
 * so the theme outputs the same tags. A dedicated SEO plugin stays in charge when one is
 * active, and the theme never needs Builder for this.
 *
 * @package Pagecraft
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether a dedicated SEO plugin owns the document title and meta tags.
 */
function pagecraft_theme_seo_plugin_active(): bool {
	foreach ( array( 'WPSEO_VERSION', 'RANK_MATH_VERSION', 'AIOSEO_VERSION', 'SEOPRESS_VERSION', 'THE_SEO_FRAMEWORK_VERSION' ) as $constant ) {
		if ( defined( $constant ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Whether the theme should print Pagecraft page SEO tags on this request.
 */
function pagecraft_theme_outputs_page_seo(): bool {
	return (bool) apply_filters( 'pagecraft_theme_output_page_seo', ! pagecraft_theme_seo_plugin_active() );
}

/**
 * Resolve a stored Pagecraft media reference to a public http(s) URL.
 *
 * @param mixed $value Absolute URL or asset:<attachment id> reference.
 */
function pagecraft_theme_seo_url( $value ): string {
	if ( ! is_string( $value ) ) {
		return '';
	}
	$value = trim( $value );
	if ( 1 === preg_match( '/^asset:(\d+)$/', $value, $match ) ) {
		$value = (string) wp_get_attachment_url( (int) $match[1] );
	}
	$scheme = strtolower( (string) wp_parse_url( $value, PHP_URL_SCHEME ) );
	if ( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
		return '';
	}
	return esc_url_raw( $value );
}

/**
 * Read the SEO fields stored with a managed page's Pagecraft document.
 *
 * @return array{title:string,description:string,image:string,favicon:string}
 */
function pagecraft_theme_page_seo( ?int $post_id = null ): array {
	$empty   = array(
		'title'       => '',
		'description' => '',
		'image'       => '',
		'favicon'     => '',
	);
	$post_id = $post_id ?? (int) get_queried_object_id();
	if ( ! is_singular( 'page' ) || $post_id <= 0 || post_password_required( $post_id ) || ! pagecraft_theme_is_managed_page( $post_id ) ) {
		return $empty;
	}
	$document = json_decode( (string) get_post_meta( $post_id, '_pagecraft_document', true ), true );
	if ( ! is_array( $document ) ) {
		return $empty;
	}
	$page = ( isset( $document['pages'][0] ) && is_array( $document['pages'][0] ) ) ? $document['pages'][0] : array();
	$meta = ( isset( $document['meta'] ) && is_array( $document['meta'] ) ) ? $document['meta'] : array();
	$text = static function ( $value ): string {
		return is_string( $value ) ? trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( $value ) ) ) : '';
	};

	$image = pagecraft_theme_seo_url( $page['ogImage'] ?? '' );
	return array(
		'title'       => $text( $page['title'] ?? '' ),
		'description' => $text( $page['desc'] ?? '' ),
		'image'       => '' !== $image ? $image : pagecraft_theme_seo_url( $meta['ogImage'] ?? '' ),
		'favicon'     => pagecraft_theme_seo_url( $meta['favicon'] ?? '' ),
	);
}

/**
 * Use the Pagecraft page title as the document title, as Cloud publishing does.
 *
 * @param string $title Title chosen so far; empty lets WordPress build its default.
 */
function pagecraft_theme_document_title( string $title ): string {
	if ( '' !== $title || ! pagecraft_theme_outputs_page_seo() ) {
		return $title;
	}
	$seo = pagecraft_theme_page_seo();
	return '' !== $seo['title'] ? $seo['title'] : $title;
}
add_filter( 'pre_get_document_title', 'pagecraft_theme_document_title', 10 );

/**
 * Print the description, favicon and Open Graph tags for a managed page.
 */
function pagecraft_theme_page_seo_tags(): void {
	if ( ! pagecraft_theme_outputs_page_seo() ) {
		return;
	}
	$post_id = (int) get_queried_object_id();
	$seo     = pagecraft_theme_page_seo( $post_id );
	if ( array( '', '', '', '' ) === array_values( $seo ) ) {
		return;
	}
	$title     = '' !== $seo['title'] ? $seo['title'] : wp_get_document_title();
	$canonical = (string) wp_get_canonical_url( $post_id );

	if ( '' !== $seo['description'] ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $seo['description'] ) );
	}
	if ( '' !== $seo['favicon'] && ! has_site_icon() ) {
		printf( '<link rel="icon" href="%s">' . "\n", esc_url( $seo['favicon'] ) );
	}
	echo '<meta property="og:type" content="website">' . "\n";
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	if ( '' !== $seo['description'] ) {
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $seo['description'] ) );
	}
	if ( '' !== $canonical ) {
		printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $canonical ) );
	}
	if ( '' !== $seo['image'] ) {
		printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $seo['image'] ) );
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	}
}
add_action( 'wp_head', 'pagecraft_theme_page_seo_tags', 5 );
