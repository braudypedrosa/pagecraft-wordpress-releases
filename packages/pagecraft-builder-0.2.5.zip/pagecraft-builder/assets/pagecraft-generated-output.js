const keyOf = item => `${item.type}:${item.id}`;
const sameCompiler = (left, right) => ['editorVersion', 'schemaVersion', 'rendererVersion', 'rendererRevision']
  .every(key => left?.[key] === right?.[key]);
const reloadRequired = message => Object.assign(new Error(message), { code: 'reload_required' });

/** Sequential maintenance. Opening Settings only reads; update() is explicit. */
export function createOutputUpdater({ request, compile, dispose = () => {}, onChange = () => {} }) {
  const state = { phase: 'idle', items: [], results: new Map(), compiler: null, error: '', completed: 0, total: 0, stopped: false };
  let stopRequested = false;
  const emit = () => onChange({ ...state, items: [...state.items], results: new Map(state.results) });
  const scan = async () => {
    const items = [];
    const cursors = new Set();
    let after = 0;
    let compiler = null;
    do {
      if (cursors.has(after)) throw new Error('The site output check did not finish. Check again.');
      cursors.add(after);
      const page = await request(`/generated-output/stale?after=${after}&limit=50`);
      if (!Array.isArray(page.items) || !page.compiler) throw new Error('WordPress returned an incomplete site output check.');
      if (compiler && !sameCompiler(compiler, page.compiler)) throw new Error('Pagecraft was upgraded during this check. Reload and retry.');
      compiler = page.compiler;
      for (const item of page.items) {
        if (!['page', 'global'].includes(item.type) || !Number.isSafeInteger(item.id) || item.id < 1) {
          throw new Error('WordPress returned an invalid site output item.');
        }
        if (item.stale) items.push(item);
      }
      if (page.nextAfter !== null && (!Number.isSafeInteger(page.nextAfter) || page.nextAfter <= after)) {
        throw new Error('The site output check did not finish. Check again.');
      }
      after = page.nextAfter;
    } while (after !== null);
    state.items = items;
    state.compiler = compiler;
  };
  const check = async () => {
    if (state.phase === 'checking' || state.phase === 'updating') return;
    state.phase = 'checking'; state.error = ''; state.stopped = false; state.results.clear(); emit();
    try { await scan(); } catch (error) { state.error = error.message || 'Could not check site output.'; }
    state.phase = 'idle'; emit();
  };
  const update = async () => {
    if (state.phase !== 'idle' || state.error || !state.items.length) return;
    const queue = [...state.items];
    const compiler = state.compiler;
    state.phase = 'updating'; state.error = ''; state.results.clear();
    state.completed = 0; state.total = queue.length; state.stopped = false; stopRequested = false; emit();
    try {
      for (const item of queue) {
        if (stopRequested) break;
        const key = keyOf(item);
        state.results.set(key, { ...item, status: 'updating', error: '' }); emit();
        try {
          const source = await request(`/generated-output/source/${item.type}/${item.id}`);
          if (source.id !== item.id || source.type !== item.type || !sameCompiler(compiler, source.compiler)) {
            throw reloadRequired('Pagecraft changed during this update. Reload and retry.');
          }
          if (!source.render?.document || !source.render.pageId || !source.documentSha256 || !source.documentVersion
            || !source.renderContextSha256) {
            throw new Error('The editable source could not be loaded. Check again.');
          }
          const { document, ...options } = source.render;
          const compiled = await compile(document, options);
          if (compiled?.format !== 'pagecraft.wordpress-compile.v1' || compiled.pageId !== source.render.pageId
            || compiled.compiler?.format !== 'pagecraft.editor-contract.v1'
            || !sameCompiler(compiler, compiled.compiler)) {
            throw reloadRequired('The Pagecraft compiler is out of date. Reload and retry.');
          }
          const saved = await request('/generated-output/recompile', {
            method: 'POST',
            body: {
              type: item.type, id: item.id,
              expected: { documentVersion: source.documentVersion, documentSha256: source.documentSha256,
                renderContextSha256: source.renderContextSha256 },
              compiler: { editorVersion: compiled.compiler.editorVersion, rendererRevision: compiled.compiler.rendererRevision },
              compiled
            }
          });
          if (saved.id !== item.id || saved.type !== item.type
            || saved.documentVersion !== source.documentVersion || saved.documentSha256 !== source.documentSha256
            || saved.renderContextSha256 !== source.renderContextSha256) {
            throw new Error('WordPress could not confirm this update. Check again before retrying.');
          }
          state.results.set(key, { ...item, status: 'updated', error: '' });
        } catch (error) {
          state.results.set(key, { ...item, status: 'failed', error: error.message || 'Could not update this item.' });
          if (error.code === 'reload_required') { state.error = error.message; stopRequested = true; }
        }
        state.completed++; emit();
      }
      state.stopped = stopRequested;
      // Verify persisted provenance. A local success count is not completion proof.
      await scan();
      for (const item of state.items) {
        const result = state.results.get(keyOf(item));
        if (result?.status === 'updated') state.results.set(keyOf(item), {
          ...item, status: 'failed', error: 'This item still needs updating. Check again before retrying.'
        });
      }
    } catch (error) {
      state.error = error.message || 'Could not verify updated site output. Check again.';
    } finally {
      dispose(); state.phase = 'idle'; emit();
    }
  };
  return { check, update, stop() { if (!stopRequested) { stopRequested = true; emit(); } } };
}

export function mountOutputUpdater(root, config) {
  const status = root.querySelector('[data-output-status]');
  const list = root.querySelector('[data-output-list]');
  const check = root.querySelector('[data-output-check]');
  const update = root.querySelector('[data-output-update]');
  const stop = root.querySelector('[data-output-stop]');
  const labels = config.labels || {};
  const label = (key, fallback, count) => (labels[key] || fallback).replace('%d', String(count ?? ''));
  let compilerModule;
  const request = async (path, options = {}) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);
    let response;
    try {
      response = await fetch(config.restUrl + path, {
        method: options.method || 'GET', credentials: 'same-origin', signal: controller.signal,
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce },
        ...(options.body ? { body: JSON.stringify(options.body) } : {})
      });
      const body = await response.json().catch(() => null);
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) throw reloadRequired(label('session', 'Your session expired or access changed. Reload and sign in again.'));
        if (response.status === 409 && body?.reloadRequired) throw reloadRequired(label('upgraded', 'Pagecraft was upgraded. Reload this screen before updating.'));
        if (response.status === 409) throw new Error(label('conflict', 'This item changed while updating. Check again and retry.'));
        throw new Error(body?.message || label('requestFailed', 'WordPress could not complete this request. Check again.'));
      }
      if (!body || typeof body !== 'object') throw new Error(label('requestFailed', 'WordPress could not complete this request. Check again.'));
      return body;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error(label('timeout', 'The request timed out. Check again before retrying.'));
      if (!response) throw new Error(label('offline', 'Could not reach WordPress. Check your connection, then check again.'));
      throw error;
    } finally { clearTimeout(timeout); }
  };
  const updater = createOutputUpdater({
    request,
    compile: async (document, options) => {
      compilerModule ||= await import(config.compilerUrl);
      return compilerModule.compile(document, options);
    },
    dispose: () => compilerModule?.dispose(),
    onChange(state) {
      const busy = state.phase !== 'idle';
      root.setAttribute('aria-busy', String(busy));
      check.disabled = busy;
      update.disabled = busy || !!state.error || !state.items.length;
      update.hidden = state.phase !== 'updating' && !state.items.length;
      stop.hidden = state.phase !== 'updating';
      stop.disabled = state.stopped;
      const failed = [...state.results.values()].filter(item => item.status === 'failed').length;
      if (state.error) status.textContent = state.error;
      else if (state.phase === 'checking') status.textContent = label('checking', 'Checking site output…');
      else if (state.phase === 'updating') status.textContent = label('updating', 'Updating %d', `${Math.min(state.completed + 1, state.total)} / ${state.total}`);
      else if (state.stopped) status.textContent = label('stopped', 'Update stopped. %d items still need updating.', state.items.length);
      else if (failed) status.textContent = label('failed', '%d items need attention. Retry after resolving the errors below.', failed);
      else if (state.items.length) status.textContent = label('remaining', '%d pages and templates need updating.', state.items.length);
      else status.textContent = label('current', 'Site output is up to date.');
      status.classList.toggle('is-error', !!state.error || failed > 0);
      const rows = new Map(state.items.map(item => [keyOf(item), { ...item, status: 'pending' }]));
      for (const [key, result] of state.results) rows.set(key, result);
      list.replaceChildren();
      for (const item of rows.values()) {
        const row = document.createElement('li');
        const title = document.createElement('strong');
        const type = document.createElement('span');
        const result = document.createElement('span');
        title.textContent = item.title || label('untitled', 'Untitled');
        type.textContent = item.type === 'page' ? label('page', 'Page') : label('template', 'Template');
        result.textContent = item.error || label(item.status, ({ updated: 'Updated', updating: 'Updating…', pending: 'Update available', failed: 'Needs attention' })[item.status]);
        result.className = item.status === 'failed' ? 'is-error' : '';
        row.append(title, type, result); list.append(row);
      }
      list.hidden = !rows.size;
    }
  });
  check.addEventListener('click', () => void updater.check());
  update.addEventListener('click', () => void updater.update());
  stop.addEventListener('click', () => { updater.stop(); stop.disabled = true; });
  window.addEventListener('pagehide', () => compilerModule?.dispose(), { once: true });
  void updater.check();
  return updater;
}
