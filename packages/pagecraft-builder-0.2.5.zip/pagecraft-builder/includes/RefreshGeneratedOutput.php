<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Explicitly refreshes derived HTML/CSS without changing the editable document. */
final class RefreshGeneratedOutput
{
    public const MAX_BATCH = 100;
    public const COMPILE_FORMAT = 'pagecraft.wordpress-compile.v1';

    private CompilerContract $compiler;

    public function __construct(?CompilerContract $compiler = null)
    {
        $this->compiler = $compiler ?? CompilerContract::current();
    }

    /**
     * @return array{
     *   compiler:array{editorVersion:string,schemaVersion:int,rendererVersion:string,rendererRevision:string},
     *   items:list<array<string,mixed>>,
     *   nextAfter:?int
     * }
     */
    public function stale(int $after = 0, int $limit = 50): array
    {
        $this->assertManager();
        $after = max(0, $after);
        $limit = min(self::MAX_BATCH, max(1, $limit));
        $posts = get_posts([
            'post_type' => ['page', GlobalElement::POST_TYPE],
            'post_status' => ['draft', 'publish', 'private', 'pending', 'future'],
            'posts_per_page' => -1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);
        usort($posts, static fn (\WP_Post $left, \WP_Post $right): int => $left->ID <=> $right->ID);

        $items = [];
        foreach ($posts as $post) {
            $postId = (int) $post->ID;
            if ($postId <= $after || !current_user_can('edit_post', $postId)) {
                continue;
            }
            $type = $post->post_type === GlobalElement::POST_TYPE ? 'global' : 'page';
            $documentKey = $type === 'global' ? GlobalElement::DOCUMENT : ManagedPage::DOCUMENT;
            $raw = get_post_meta($postId, $documentKey, true);
            if (!is_string($raw) || $raw === '') {
                continue;
            }
            try {
                $items[] = $this->manifestItem($post, $type, $raw);
            } catch (\Throwable $error) {
                $items[] = $this->manifestErrorItem($post, $type, $raw, $error);
            }
            if (count($items) > $limit) {
                break;
            }
        }
        $nextAfter = null;
        if (count($items) > $limit) {
            array_pop($items);
            $last = end($items);
            $nextAfter = is_array($last) ? (int) $last['id'] : null;
        }
        return [
            'compiler' => $this->compiler->payload(),
            'items' => $items,
            'nextAfter' => $nextAfter,
        ];
    }

    /** @return array<string,mixed> */
    public function source(string $type, int $postId): array
    {
        $this->assertManager();
        $this->assertTarget($type, $postId);
        $documentKey = $type === 'global' ? GlobalElement::DOCUMENT : ManagedPage::DOCUMENT;
        $versionKey = $type === 'global' ? GlobalElement::DOCUMENT_VERSION : ManagedPage::DOCUMENT_VERSION;
        $raw = get_post_meta($postId, $documentKey, true);
        if (!is_string($raw) || $raw === '') {
            throw new PackageException('The Pagecraft source document is missing.');
        }
        if (strlen($raw) > PageEditor::MAX_DOCUMENT_BYTES) {
            throw new PackageException('The stored Pagecraft document exceeds the WordPress editor limit.');
        }
        try {
            $document = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new PackageException('The stored Pagecraft document is invalid: ' . $error->getMessage());
        }
        if (!is_array($document)) {
            throw new PackageException('The stored Pagecraft document is not an object.');
        }
        $render = $this->renderContext($postId, $type, $document);
        $renderContextSha256 = $this->renderContextSha256($render);
        return [
            'type' => $type,
            'id' => $postId,
            'document' => $document,
            'documentVersion' => max(1, (int) get_post_meta($postId, $versionKey, true)),
            'documentSha256' => hash('sha256', $raw),
            'renderContextSha256' => $renderContextSha256,
            'compiler' => $this->compiler->payload(),
            'render' => $render,
        ];
    }

    /** @param array<string,mixed> $document */
    public function contextSha256(int $postId, string $type, array $document): string
    {
        return $this->renderContextSha256($this->renderContext($postId, $type, $document));
    }

    /**
     * @param array<string,mixed> $input
     * @return array<string,mixed>
     */
    public function recompile(array $input): array
    {
        $this->assertManager();
        $type = $input['type'] ?? null;
        $postId = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
        if (!is_string($type) || !in_array($type, ['page', 'global'], true)
            || $postId === false || $postId <= 0) {
            throw new PackageException('The generated-output target is invalid.');
        }
        $this->assertTarget($type, $postId);
        $expected = $input['expected'] ?? null;
        $requestedCompiler = $input['compiler'] ?? null;
        $compiled = $input['compiled'] ?? null;
        if (!is_array($expected) || !is_array($requestedCompiler) || !is_array($compiled)) {
            throw new PackageException('The generated-output refresh payload is incomplete.');
        }
        $compilerKeys = array_keys($requestedCompiler);
        sort($compilerKeys);
        if ($compilerKeys !== ['editorVersion', 'rendererRevision']) {
            throw new PackageException('The generated-output compiler identity has an unsupported shape.');
        }
        $expectedVersion = filter_var($expected['documentVersion'] ?? null, FILTER_VALIDATE_INT);
        $expectedHash = $expected['documentSha256'] ?? null;
        $expectedContextHash = $expected['renderContextSha256'] ?? null;
        if ($expectedVersion === false || $expectedVersion <= 0 || !is_string($expectedHash)
            || preg_match('/^[a-f0-9]{64}$/D', $expectedHash) !== 1
            || !is_string($expectedContextHash)
            || preg_match('/^[a-f0-9]{64}$/D', $expectedContextHash) !== 1) {
            throw new PackageException('The expected Pagecraft document or render-context identity is invalid.');
        }
        if (($requestedCompiler['editorVersion'] ?? null) !== $this->compiler->editorVersion
            || ($requestedCompiler['rendererRevision'] ?? null) !== $this->compiler->rendererRevision) {
            throw new CompilerContractConflict($this->compiler->sealedPayload());
        }

        return EditorWriteLock::run($postId, fn (): array => $this->recompileLocked(
            $type,
            $postId,
            $expectedVersion,
            $expectedHash,
            $expectedContextHash,
            $compiled
        ));
    }

    /** @param array<string,mixed> $compiled @return array<string,mixed> */
    private function recompileLocked(
        string $type,
        int $postId,
        int $expectedVersion,
        string $expectedHash,
        string $expectedContextHash,
        array $compiled
    ): array {
        $documentKey = $type === 'global' ? GlobalElement::DOCUMENT : ManagedPage::DOCUMENT;
        $versionKey = $type === 'global' ? GlobalElement::DOCUMENT_VERSION : ManagedPage::DOCUMENT_VERSION;
        $raw = get_post_meta($postId, $documentKey, true);
        $currentVersion = max(1, (int) get_post_meta($postId, $versionKey, true));
        $currentHash = is_string($raw) && $raw !== '' ? hash('sha256', $raw) : '';
        if (!is_string($raw) || $raw === '') {
            throw new PackageException('The Pagecraft source document is missing.');
        }
        if (strlen($raw) > PageEditor::MAX_DOCUMENT_BYTES) {
            throw new PackageException('The stored Pagecraft document exceeds the WordPress editor limit.');
        }
        if ($currentVersion !== $expectedVersion || !hash_equals($currentHash, $expectedHash)) {
            throw new GeneratedOutputConflict($currentVersion, $currentHash);
        }
        try {
            $document = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new PackageException('The stored Pagecraft document is invalid: ' . $error->getMessage());
        }
        $schemaVersion = is_array($document)
            ? filter_var($document['schemaVersion'] ?? $document['v'] ?? null, FILTER_VALIDATE_INT)
            : false;
        if ($schemaVersion === false || $schemaVersion <= 0 || $schemaVersion > $this->compiler->schemaVersion) {
            throw new PackageException('The stored Pagecraft document schema is unsupported by this sealed compiler.');
        }

        $render = $this->renderContext($postId, $type, $document);
        $currentContextHash = $this->renderContextSha256($render);
        if (!hash_equals($currentContextHash, $expectedContextHash)) {
            throw new GeneratedOutputConflict($currentVersion, $currentHash, $currentContextHash);
        }
        $targetPageId = (string) $render['pageId'];
        if (($compiled['format'] ?? null) !== self::COMPILE_FORMAT
            || ($compiled['pageId'] ?? null) !== $targetPageId) {
            throw new PackageException('The compiled output does not match the requested Pagecraft render target.');
        }

        $compiledCompiler = $compiled['compiler'] ?? null;
        if (!is_array($compiledCompiler) || !$this->compiler->matchesSealedPayload($compiledCompiler)) {
            throw new CompilerContractConflict($this->compiler->sealedPayload());
        }

        $html = $this->boundedString($compiled['html'] ?? null, PageEditor::MAX_HTML_BYTES, 'compiled output');
        $globalCss = FallbackCompiler::safeCssSource(
            $this->boundedString($compiled['globalCss'] ?? '', GeneratedAssetStore::MAX_CSS_BYTES, 'global stylesheet', true)
        );
        $pageCss = FallbackCompiler::safeCssSource(
            $this->boundedString($compiled['pageCss'] ?? '', GeneratedAssetStore::MAX_CSS_BYTES, 'page stylesheet', true)
        );
        $content = FallbackCompiler::contentFromHtml($html);
        $assets = new GeneratedAssetStore();
        $globalAsset = null;
        $pageAsset = null;
        if ($type === 'global') {
            $globalCss = trim(implode("\n", array_filter(
                [$globalCss, $pageCss],
                static fn (string $part): bool => $part !== ''
            )));
            if (strlen($globalCss) > GeneratedAssetStore::MAX_CSS_BYTES) {
                throw new PackageException('The combined global stylesheet exceeds the WordPress editor limit.');
            }
            $pageCss = '';
            $globalAsset = $globalCss !== '' ? $assets->writeCss('global', $globalCss) : null;
        } else {
            $globalAsset = $globalCss !== '' ? $assets->writeCss('global', $globalCss) : null;
            $pageAsset = $pageCss !== '' ? $assets->writeCss('page', $pageCss) : null;
        }
        $runtimeAsset = FallbackCompiler::needsRuntime($content) ? $assets->writeRuntime() : null;
        $metadata = $this->compiler->provenance($raw);
        $metadata[ManagedPage::COMPILER_RENDER_CONTEXT_SHA256] = $currentContextHash;
        $metadata[$type === 'global' ? GlobalElement::RENDERER_VERSION : ManagedPage::RENDERER_VERSION]
            = $this->compiler->rendererVersion;
        if ($type === 'global') {
            $metadata += [
                GlobalElement::COMPILED_HASH => hash('sha256', $content),
                GlobalElement::CSS_PATH => $globalAsset['path'] ?? '',
                GlobalElement::CSS_HASH => $globalAsset['hash'] ?? '',
                GlobalElement::RUNTIME_PATH => $runtimeAsset['path'] ?? '',
                GlobalElement::RUNTIME_HASH => $runtimeAsset['hash'] ?? '',
            ];
        } else {
            $metadata += [
                ManagedPage::COMPILED_HASH => hash('sha256', $content),
                ManagedPage::COMPILED_CSS => implode("\n", array_filter([$globalCss, $pageCss])),
                ManagedPage::GLOBAL_CSS_PATH => $globalAsset['path'] ?? '',
                ManagedPage::GLOBAL_CSS_HASH => $globalAsset['hash'] ?? '',
                ManagedPage::PAGE_CSS_PATH => $pageAsset['path'] ?? '',
                ManagedPage::PAGE_CSS_HASH => $pageAsset['hash'] ?? '',
                ManagedPage::RUNTIME_PATH => $runtimeAsset['path'] ?? '',
                ManagedPage::RUNTIME_HASH => $runtimeAsset['hash'] ?? '',
            ];
        }

        $checkpoint = $this->mutationCheckpoint($postId, array_keys($metadata));
        $revisionId = $this->createSafetyRevision($postId, $type);
        try {
            $updated = wp_update_post(['ID' => $postId, 'post_content' => wp_slash($content)], true);
            if (is_wp_error($updated)) {
                throw new PackageException(
                    'WordPress could not refresh the Pagecraft generated output: ' . $updated->get_error_message()
                );
            }
            $persisted = get_post($postId);
            if (!$persisted instanceof \WP_Post || (string) $persisted->post_content !== $content) {
                throw new PackageException('WordPress did not persist the refreshed Pagecraft generated HTML.');
            }
            $this->persistMetadata($postId, $metadata);
        } catch (\Throwable $error) {
            try {
                $this->restoreCheckpoint($postId, $checkpoint);
            } catch (\Throwable $recoveryError) {
                throw new PackageException(
                    'WordPress could not refresh Pagecraft generated output and automatic recovery failed: '
                    . $recoveryError->getMessage()
                );
            }
            throw new PackageException(
                'WordPress could not refresh Pagecraft generated output. The previous output was restored: '
                . $error->getMessage()
            );
        }
        return [
            'type' => $type,
            'id' => $postId,
            'documentVersion' => $currentVersion,
            'documentSha256' => $currentHash,
            'renderContextSha256' => $currentContextHash,
            'revisionId' => $revisionId,
            'compiler' => $this->compiler->payload(),
            'assets' => [
                'globalCss' => $globalAsset,
                'pageCss' => $pageAsset,
                'runtime' => $runtimeAsset,
            ],
            'compiledHash' => hash('sha256', $content),
        ];
    }

    /** @return array<string,mixed> */
    private function manifestItem(\WP_Post $post, string $type, string $documentJson): array
    {
        $postId = (int) $post->ID;
        $versionKey = $type === 'global' ? GlobalElement::DOCUMENT_VERSION : ManagedPage::DOCUMENT_VERSION;
        $editorVersion = (string) get_post_meta($postId, ManagedPage::COMPILER_EDITOR_VERSION, true);
        $rendererVersion = (string) get_post_meta(
            $postId,
            $type === 'global' ? GlobalElement::RENDERER_VERSION : ManagedPage::RENDERER_VERSION,
            true
        );
        $rendererRevision = (string) get_post_meta($postId, ManagedPage::COMPILER_RENDERER_REVISION, true);
        $documentHash = (string) get_post_meta($postId, ManagedPage::COMPILER_DOCUMENT_SHA256, true);
        $contextHash = (string) get_post_meta($postId, ManagedPage::COMPILER_RENDER_CONTEXT_SHA256, true);
        $compiledAt = (string) get_post_meta($postId, ManagedPage::COMPILED_AT, true);
        $reasons = [];
        if ($editorVersion === '' || $rendererVersion === '' || $rendererRevision === ''
            || $documentHash === '' || $contextHash === '' || $compiledAt === '') {
            $reasons[] = 'missing-provenance';
        }
        if ($editorVersion !== '' && $editorVersion !== $this->compiler->editorVersion) {
            $reasons[] = 'editor-version';
        }
        if (($rendererVersion !== '' && $rendererVersion !== $this->compiler->rendererVersion)
            || ($rendererRevision !== '' && $rendererRevision !== $this->compiler->rendererRevision)) {
            $reasons[] = 'renderer-revision';
        }
        $currentHash = hash('sha256', $documentJson);
        if ($documentHash !== '' && !hash_equals($currentHash, $documentHash)) {
            $reasons[] = 'document-hash';
        }
        try {
            $document = json_decode($documentJson, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new PackageException('The stored Pagecraft document is invalid: ' . $error->getMessage());
        }
        if (!is_array($document)) {
            throw new PackageException('The stored Pagecraft document is not an object.');
        }
        $currentContextHash = $this->contextSha256($postId, $type, $document);
        if ($contextHash !== '' && !hash_equals($currentContextHash, $contextHash)) {
            $reasons[] = 'render-context';
        }
        return [
            'type' => $type,
            'id' => $postId,
            'title' => get_the_title($post),
            'documentVersion' => max(1, (int) get_post_meta($postId, $versionKey, true)),
            'documentSha256' => $currentHash,
            'renderContextSha256' => $currentContextHash,
            'compiled' => [
                'editorVersion' => $editorVersion,
                'rendererRevision' => $rendererRevision,
                'documentSha256' => $documentHash,
                'renderContextSha256' => $contextHash,
            ],
            'stale' => $reasons !== [],
            'reasons' => $reasons,
        ];
    }

    /** @return array<string,mixed> */
    private function manifestErrorItem(
        \WP_Post $post,
        string $type,
        string $documentJson,
        \Throwable $error
    ): array {
        $postId = (int) $post->ID;
        $versionKey = $type === 'global' ? GlobalElement::DOCUMENT_VERSION : ManagedPage::DOCUMENT_VERSION;
        return [
            'type' => $type,
            'id' => $postId,
            'title' => get_the_title($post),
            'documentVersion' => max(1, (int) get_post_meta($postId, $versionKey, true)),
            'documentSha256' => hash('sha256', $documentJson),
            'renderContextSha256' => null,
            'compiled' => [
                'editorVersion' => (string) get_post_meta($postId, ManagedPage::COMPILER_EDITOR_VERSION, true),
                'rendererRevision' => (string) get_post_meta(
                    $postId,
                    ManagedPage::COMPILER_RENDERER_REVISION,
                    true
                ),
                'documentSha256' => (string) get_post_meta(
                    $postId,
                    ManagedPage::COMPILER_DOCUMENT_SHA256,
                    true
                ),
                'renderContextSha256' => (string) get_post_meta(
                    $postId,
                    ManagedPage::COMPILER_RENDER_CONTEXT_SHA256,
                    true
                ),
            ],
            'stale' => true,
            'reasons' => ['context-error'],
            'error' => $error->getMessage(),
        ];
    }

    private function createSafetyRevision(int $postId, string $type): int
    {
        $postType = $type === 'global' ? GlobalElement::POST_TYPE : 'page';
        if (!post_type_supports($postType, 'revisions') || !wp_revisions_enabled(get_post($postId))) {
            throw new PackageException('WordPress revisions must be enabled before refreshing Pagecraft generated output.');
        }
        $saved = wp_save_post_revision($postId);
        if (is_wp_error($saved)) {
            throw new PackageException('WordPress could not create the generated-output safety revision: ' . $saved->get_error_message());
        }
        if (is_int($saved) && $saved > 0 && $this->revisionMatchesCurrent($postId, $saved, $type)) {
            return $saved;
        }
        foreach (wp_get_post_revisions($postId, [
            'posts_per_page' => 1,
            'order' => 'DESC',
            'orderby' => 'date ID',
            'check_enabled' => false,
        ]) as $revision) {
            $revisionId = (int) ($revision->ID ?? 0);
            if ($revisionId > 0 && $this->revisionMatchesCurrent($postId, $revisionId, $type)) {
                return $revisionId;
            }
        }
        throw new PackageException('WordPress did not create or retain an exact Pagecraft safety revision. Nothing was changed.');
    }

    private function revisionMatchesCurrent(int $postId, int $revisionId, string $type): bool
    {
        $post = get_post($postId);
        $revision = get_post($revisionId);
        if (!$post instanceof \WP_Post || !$revision instanceof \WP_Post
            || (string) $revision->post_content !== (string) $post->post_content) {
            return false;
        }
        $keys = $type === 'global' ? GlobalElement::keys() : ManagedPage::keys();
        foreach ($keys as $key) {
            if ((string) get_post_meta($revisionId, $key, true) !== (string) get_post_meta($postId, $key, true)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param list<string> $keys
     * @return array{content:string,metadata:array<string,array{exists:bool,value:string}>}
     */
    private function mutationCheckpoint(int $postId, array $keys): array
    {
        $post = get_post($postId);
        if (!$post instanceof \WP_Post) {
            throw new PackageException('The Pagecraft generated-output target disappeared before it could be refreshed.');
        }
        $metadata = [];
        foreach ($keys as $key) {
            $metadata[$key] = [
                'exists' => metadata_exists('post', $postId, $key),
                'value' => (string) get_post_meta($postId, $key, true),
            ];
        }
        return ['content' => (string) $post->post_content, 'metadata' => $metadata];
    }

    /** @param array<string,string> $metadata */
    private function persistMetadata(int $postId, array $metadata): void
    {
        foreach ($metadata as $key => $value) {
            update_post_meta($postId, $key, wp_slash($value));
            if ((string) get_post_meta($postId, $key, true) !== $value) {
                throw new PackageException('WordPress did not persist generated-output metadata: ' . $key . '.');
            }
        }
    }

    /** @param array{content:string,metadata:array<string,array{exists:bool,value:string}>} $checkpoint */
    private function restoreCheckpoint(int $postId, array $checkpoint): void
    {
        $restored = wp_update_post([
            'ID' => $postId,
            'post_content' => wp_slash($checkpoint['content']),
        ], true);
        if (is_wp_error($restored)) {
            throw new PackageException('WordPress could not restore the previous generated HTML.');
        }
        $post = get_post($postId);
        if (!$post instanceof \WP_Post || (string) $post->post_content !== $checkpoint['content']) {
            throw new PackageException('WordPress did not retain the restored generated HTML.');
        }
        foreach ($checkpoint['metadata'] as $key => $before) {
            if ($before['exists']) {
                update_post_meta($postId, $key, wp_slash($before['value']));
                if (!metadata_exists('post', $postId, $key)
                    || (string) get_post_meta($postId, $key, true) !== $before['value']) {
                    throw new PackageException('WordPress did not restore generated-output metadata: ' . $key . '.');
                }
                continue;
            }
            delete_post_meta($postId, $key);
            if (metadata_exists('post', $postId, $key)) {
                throw new PackageException('WordPress did not remove partial generated-output metadata: ' . $key . '.');
            }
        }
    }

    private function assertManager(): void
    {
        if (!current_user_can(Capabilities::MANAGE) || !current_user_can('edit_theme_options')) {
            throw new PackageException('You are not allowed to maintain Pagecraft generated output.');
        }
    }

    private function assertTarget(string $type, int $postId): void
    {
        if (!in_array($type, ['page', 'global'], true) || $postId <= 0) {
            throw new PackageException('The generated-output target is invalid.');
        }
        $expectedType = $type === 'global' ? GlobalElement::POST_TYPE : 'page';
        if (get_post_type($postId) !== $expectedType || !current_user_can('edit_post', $postId)) {
            throw new PackageException('You are not allowed to refresh this Pagecraft generated output.');
        }
    }

    /**
     * @param array<string,mixed> $document
     * @return array{
     *   document:array<string,mixed>,
     *   pageId:string,
     *   assets:array<int,array{id:string,name:string,mimeType:string,url:string,size:int,width:int,height:int}>,
     *   wordpressContent:array<string,string>,
     *   design:array<string,mixed>
     * }
     */
    private function renderContext(int $postId, string $type, array $document): array
    {
        $renderDocument = (new NativeMenu())->hydrateDocument($document);
        if ($type === 'page') {
            $renderDocument = FallbackCompiler::remapProjectDocumentLinks(
                $renderDocument,
                CurrentPageRoute::routes($postId, $document)
            );
        }
        $design = DocumentJson::design((new DesignSettings())->read());
        return [
            'document' => DocumentJson::document($renderDocument),
            'pageId' => $this->targetPageId($postId, $type, $document),
            'assets' => $this->referencedAssets($postId, $document, $renderDocument, $design),
            'wordpressContent' => $this->wordpressContent($document, $renderDocument),
            'design' => $design,
        ];
    }

    /** @param array<string,mixed> $render */
    private function renderContextSha256(array $render): string
    {
        return hash('sha256', CanonicalJson::encode($render));
    }

    /** @param array<string,mixed> $document */
    private function targetPageId(int $postId, string $type, array $document): string
    {
        return CurrentPageRoute::targetPageId($postId, $type, $document);
    }

    /**
     * @param array<string,mixed> $document
     * @param array<string,mixed> $renderDocument
     * @param array<string,mixed> $design
     * @return array<int,array{id:string,name:string,mimeType:string,url:string,size:int,width:int,height:int}>
     */
    private function referencedAssets(
        int $postId,
        array $document,
        array $renderDocument,
        array $design
    ): array {
        $required = [];
        foreach ($this->strings([$document, $renderDocument, $design]) as $value) {
            if (!preg_match_all('/(?<![A-Za-z0-9._:-])asset:([1-9][0-9]*)(?:@[0-9]+)?(?![A-Za-z0-9._:-])/', $value, $matches)) {
                continue;
            }
            foreach ($matches[1] as $attachmentId) {
                $required[(int) $attachmentId] = true;
            }
        }
        $referenced = $required;
        $stored = get_post_meta($postId, ManagedPage::MEDIA_ATTACHMENTS, true);
        $storedIds = is_string($stored) && $stored !== '' ? json_decode($stored, true) : [];
        foreach (is_array($storedIds) ? $storedIds : [] as $attachmentId) {
            if ((is_int($attachmentId) || is_string($attachmentId))
                && preg_match('/^[1-9][0-9]*$/D', (string) $attachmentId)) {
                $referenced[(int) $attachmentId] = true;
            }
        }
        ksort($referenced, SORT_NUMERIC);
        $assets = [];
        foreach (array_keys($referenced) as $attachmentId) {
            $post = get_post((int) $attachmentId);
            $mimeType = $post instanceof \WP_Post ? (string) $post->post_mime_type : '';
            $url = $post instanceof \WP_Post ? wp_get_attachment_url((int) $attachmentId) : false;
            $valid = $post instanceof \WP_Post
                && $post->post_type === 'attachment'
                && str_starts_with($mimeType, 'image/')
                && current_user_can('read_post', (int) $attachmentId)
                && is_string($url)
                && $url !== '';
            if (!$valid) {
                if (isset($required[(int) $attachmentId])) {
                    throw new PackageException('A referenced WordPress media item is missing or unavailable.');
                }
                continue;
            }
            $metadata = wp_get_attachment_metadata((int) $attachmentId);
            $file = get_attached_file((int) $attachmentId);
            $assets[$attachmentId] = [
                'id' => (string) $attachmentId,
                'name' => get_the_title($post),
                'mimeType' => $mimeType,
                'url' => esc_url_raw($url),
                'size' => is_string($file) && is_file($file) ? (int) filesize($file) : 0,
                'width' => is_array($metadata) ? (int) ($metadata['width'] ?? 0) : 0,
                'height' => is_array($metadata) ? (int) ($metadata['height'] ?? 0) : 0,
            ];
        }
        return $assets;
    }

    /**
     * @param array<string,mixed> $document
     * @param array<string,mixed> $renderDocument
     * @return array<string,string>
     */
    private function wordpressContent(array $document, array $renderDocument): array
    {
        $references = [];
        foreach ($this->strings([$document, $renderDocument]) as $value) {
            $parsed = $this->parseWordPressReference($value);
            if ($parsed !== null) {
                $references[$parsed['token']] = $parsed;
                continue;
            }
            $parsed = $this->parseWordPressToken($value);
            if ($parsed !== null) {
                $references[$parsed['token']] = $parsed;
            }
        }
        if ($references === []) {
            return [];
        }
        $home = home_url('/');
        $homeParts = wp_parse_url($home);
        if (!is_array($homeParts) || !is_string($homeParts['scheme'] ?? null)
            || !is_string($homeParts['host'] ?? null)) {
            return [];
        }
        $origin = $homeParts['scheme'] . '://' . $homeParts['host']
            . (isset($homeParts['port']) ? ':' . (int) $homeParts['port'] : '');
        $targetPath = '/' . trim((string) ($homeParts['path'] ?? '/'), '/');
        if ($targetPath !== '/') {
            $targetPath = rtrim($targetPath, '/');
        }
        $routes = [];
        $posts = get_posts([
            'post_type' => ['page', 'post'],
            'post_status' => ['draft', 'pending', 'publish', 'private'],
            'posts_per_page' => -1,
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);
        foreach ($posts as $post) {
            if (!$post instanceof \WP_Post || !in_array($post->post_type, ['page', 'post'], true)
                || !current_user_can('read_post', $post->ID)) {
                continue;
            }
            $url = get_permalink($post);
            $parts = is_string($url) ? wp_parse_url($url) : false;
            if (!is_array($parts) || isset($parts['user']) || isset($parts['pass'])
                || isset($parts['query']) || isset($parts['fragment'])) {
                continue;
            }
            $postOrigin = (string) ($parts['scheme'] ?? '') . '://' . (string) ($parts['host'] ?? '')
                . (isset($parts['port']) ? ':' . (int) $parts['port'] : '');
            $path = (string) ($parts['path'] ?? '');
            if ($postOrigin !== $origin || ($targetPath !== '/' && $path !== $targetPath
                && !str_starts_with($path, $targetPath . '/'))) {
                continue;
            }
            $fullPath = $this->normalizeWordPressPath($path);
            $relativePath = $targetPath === '/'
                ? $fullPath
                : $this->normalizeWordPressPath(substr($path, strlen($targetPath)) ?: '/');
            foreach (array_filter([$fullPath, $relativePath]) as $candidate) {
                $routes[$post->post_type . '|' . $candidate] ??= esc_url_raw($url);
            }
        }
        $resolved = [];
        foreach ($references as $token => $reference) {
            $url = $routes[$reference['objectType'] . '|' . $reference['path']] ?? '';
            if ($url !== '') {
                $resolved[$token] = $url;
            }
        }
        ksort($resolved);
        return $resolved;
    }

    /** @return array{objectType:string,path:string,token:string}|null */
    private function parseWordPressReference(string $value): ?array
    {
        if (!preg_match('/^pagecraft:wordpress-content:(page|post):([A-Za-z0-9_-]+)$/D', trim($value), $match)) {
            return null;
        }
        return $this->parsedWordPressTarget($match[1], $match[2]);
    }

    /** @return array{objectType:string,path:string,token:string}|null */
    private function parseWordPressToken(string $value): ?array
    {
        if (!preg_match('/^%%PAGECRAFT_WP_CONTENT:(page|post):([A-Za-z0-9_-]+)%%$/D', trim($value), $match)) {
            return null;
        }
        return $this->parsedWordPressTarget($match[1], $match[2]);
    }

    /** @return array{objectType:string,path:string,token:string}|null */
    private function parsedWordPressTarget(string $objectType, string $encoded): ?array
    {
        $base64 = strtr($encoded, '-_', '+/');
        $remainder = strlen($base64) % 4;
        if ($remainder > 0) {
            $base64 .= str_repeat('=', 4 - $remainder);
        }
        $path = base64_decode($base64, true);
        $normalized = is_string($path) ? $this->normalizeWordPressPath($path) : null;
        $canonical = is_string($path) ? rtrim(strtr(base64_encode($path), '+/', '-_'), '=') : '';
        if ($normalized === null || $path !== $normalized || $encoded !== $canonical) {
            return null;
        }
        return [
            'objectType' => $objectType,
            'path' => $path,
            'token' => '%%PAGECRAFT_WP_CONTENT:' . $objectType . ':' . $encoded . '%%',
        ];
    }

    private function normalizeWordPressPath(string $value): ?string
    {
        $path = trim($value);
        if ($path === '' || strlen($path) > 2048 || preg_match('//u', $path) !== 1
            || preg_match('/[?#\\\\\x00-\x1f\x7f]/', $path)) {
            return null;
        }
        $path = '/' . ltrim($path, '/');
        $path = preg_replace('#/{2,}#', '/', $path);
        if (!is_string($path)) {
            return null;
        }
        if ($path !== '/' && !preg_match('/\.[^\/]+\/?$/', $path) && !str_ends_with($path, '/')) {
            $path .= '/';
        }
        return $path;
    }

    /** @return list<string> */
    private function strings(mixed $value): array
    {
        $strings = [];
        $visit = static function (mixed $item) use (&$visit, &$strings): void {
            if (is_string($item)) {
                $strings[] = $item;
                return;
            }
            if (is_array($item) || is_object($item)) {
                foreach ((array) $item as $child) {
                    $visit($child);
                }
            }
        };
        $visit($value);
        return $strings;
    }

    private function boundedString(mixed $value, int $limit, string $label, bool $allowEmpty = false): string
    {
        if (!is_string($value) || (!$allowEmpty && $value === '')) {
            throw new PackageException('The ' . $label . ' payload is missing.');
        }
        if (strlen($value) > $limit) {
            throw new PackageException('The ' . $label . ' exceeds the WordPress editor limit.');
        }
        return $value;
    }
}
