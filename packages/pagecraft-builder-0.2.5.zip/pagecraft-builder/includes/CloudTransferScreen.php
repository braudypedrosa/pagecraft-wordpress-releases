<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Server-rendered steps: choosing or reviewing never changes WordPress content. */
final class CloudTransferScreen
{
    /** Where the person is in the transfer: 0 Connect, 1 Choose, 2 Review, 3 Replace. */
    public static function steps(int $current): void
    {
        echo '<div class="pagecraft-toolbar"><ol class="pagecraft-steps" aria-label="' . esc_attr__('Progress', 'pagecraft-builder') . '">';
        foreach ([
            __('Connect', 'pagecraft-builder'),
            __('Choose', 'pagecraft-builder'),
            __('Review', 'pagecraft-builder'),
            __('Replace', 'pagecraft-builder'),
        ] as $index => $label) {
            echo '<li class="' . ($index === $current ? 'is-current' : ($index < $current ? 'is-done' : '')) . '"'
                . ($index === $current ? ' aria-current="step"' : '') . '>' . esc_html($label)
                . ($index < $current ? '<span class="screen-reader-text"> ' . esc_html__('(done)', 'pagecraft-builder') . '</span>' : '') . '</li>';
        }
        echo '</ol></div>';
    }

    public function render(CloudImport $cloud): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET navigation is read-only.
        $projects = $cloud->projects();
        $selected = sanitize_text_field(wp_unslash((string) ($_GET['project'] ?? '')));
        $scope = sanitize_key((string) ($_GET['scope'] ?? ''));
        $source = sanitize_text_field(wp_unslash((string) ($_GET['source_page'] ?? '')));
        $destination = absint($_GET['destination'] ?? 0);
        $review = isset($_GET['review']);
        // phpcs:enable
        if ($projects === []) {
            self::steps(1);
            echo '<div class="pagecraft-empty"><strong>' . esc_html__('No Cloud projects are available for this account yet.', 'pagecraft-builder') . '</strong></div>';
            return;
        }
        $project = current(array_filter($projects, static fn (array $p): bool => (string) $p['id'] === $selected));
        if (!$review || !is_array($project) || !in_array($scope, ['site', 'page'], true)) {
            // After a replacement the person lands back here, with the result shown as a toast.
            $this->choose($projects, $selected, $scope);
            return;
        }
        $pages = $scope === 'page' ? $cloud->pages($selected) : [];
        $sourcePage = current(array_filter($pages, static fn (array $p): bool => (string) $p['id'] === $source));
        $targets = array_values(array_filter(CloudReplacement::destinations(), static fn (\WP_Post $p): bool => current_user_can('edit_post', $p->ID)));
        $target = current(array_filter($targets, static fn (\WP_Post $p): bool => $p->ID === $destination));
        $back = add_query_arg(['page' => 'pagecraft-connect', 'project' => $selected, 'scope' => $scope], admin_url('admin.php'));
        $backLink = '<a class="button" href="' . esc_url($back) . '">' . esc_html__('Change project or scope', 'pagecraft-builder') . '</a>';
        if ($scope === 'page' && (!is_array($sourcePage) || !$target)) {
            self::steps(1);
            echo '<div class="pagecraft-split"><div class="pagecraft-split__main"><section class="pagecraft-pad"><h2>'
                . esc_html__('Choose the source and destination', 'pagecraft-builder') . '</h2>'
                . '<form class="pagecraft-cloud-transfer" method="get" action="' . esc_url(admin_url('admin.php')) . '">'
                . '<input type="hidden" name="page" value="pagecraft-connect"><input type="hidden" name="scope" value="page">'
                . '<input type="hidden" name="review" value="1"><input type="hidden" name="project" value="' . esc_attr($selected) . '">'
                . '<div class="pagecraft-pair"><div><label for="pc-source-page">' . esc_html__('Page from Cloud', 'pagecraft-builder') . '</label>'
                . '<select id="pc-source-page" name="source_page" required><option value="">' . esc_html__('Choose a Cloud page', 'pagecraft-builder') . '</option>';
            foreach ($pages as $page) {
                echo '<option value="' . esc_attr((string) $page['id']) . '">' . esc_html((string) ($page['name'] ?? $page['title'] ?? $page['id'])) . '</option>';
            }
            echo '</select></div><div><label for="pc-destination">' . esc_html__('WordPress page to replace', 'pagecraft-builder')
                . '</label><select id="pc-destination" name="destination" required><option value="">'
                . esc_html__('Choose a WordPress page', 'pagecraft-builder') . '</option>';
            foreach ($targets as $post) {
                echo '<option value="' . esc_attr((string) $post->ID) . '">' . esc_html($post->post_title . ' · ' . $post->post_status . ' · #' . $post->ID) . '</option>';
            }
            echo '</select></div></div><div class="pagecraft-cloud__actions"><button class="button button-primary">' . esc_html__('Review replacement', 'pagecraft-builder') . '</button>';
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts above.
            echo $backLink;
            echo '</div></form></section></div>';
            $this->summary([
                __('Cloud project', 'pagecraft-builder') => (string) $project['name'],
                __('Scope', 'pagecraft-builder') => __('One page', 'pagecraft-builder'),
            ]);
            echo '</div>';
            return;
        }
        self::steps(2);
        $heading = $scope === 'site' ? sprintf('Replace this site with %s', $project['name'])
            : sprintf('Replace WordPress page “%s”', $target->post_title);
        echo '<div class="pagecraft-split"><div class="pagecraft-split__main"><section class="pagecraft-pad pagecraft-pad--tight"><h2>'
            . esc_html__('Review replacement', 'pagecraft-builder') . '</h2><h3>' . esc_html($heading) . '</h3>';
        if ($scope === 'page') {
            echo '<p>' . esc_html(sprintf('From Cloud: %s / %s', $project['name'], $sourcePage['name'] ?? $sourcePage['title'] ?? $source))
                . '<br>' . esc_html(sprintf('Destination: %s (WordPress page #%d)', get_permalink($target->ID), $target->ID)) . '</p>';
        }
        echo '</section><div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-cloud-transfer__impact"><thead><tr><th scope="col">'
            . esc_html__('Effect', 'pagecraft-builder') . '</th><th scope="col">' . esc_html__('What happens', 'pagecraft-builder') . '</th></tr></thead><tbody>';
        $replacedLabel = __('Replaced', 'pagecraft-builder');
        $keptLabel = __('Kept', 'pagecraft-builder');
        $effects = $scope === 'site' ? [
            ['change', __('Published', 'pagecraft-builder'), sprintf('%d Cloud pages will be published as this site’s page collection.', (int) $project['pageCount'])],
            ['change', __('Archived', 'pagecraft-builder'), 'Existing pages outside the incoming collection will be archived, not permanently deleted.'],
            ['change', $replacedLabel, 'Pagecraft navigation, homepage, header and footer will be replaced.'],
            ['keep', $keptLabel, 'Posts, products, users, plugins and unrelated media will be preserved.'],
        ] : [
            ['change', $replacedLabel, 'All content and Pagecraft styling on the destination page will be replaced.'],
            ['keep', $keptLabel, 'Its WordPress URL, title and publication status will stay the same.'],
            ['note', __('Scope', 'pagecraft-builder'), 'The Cloud header and footer will apply to this page only. Other pages and menus will not change.'],
            ['note', __('Check after', 'pagecraft-builder'), 'Other Cloud pages are not imported. Review links to them after replacement.'],
        ];
        $effects[] = ['note', __('Recovery', 'pagecraft-builder'), __('Recovery data will be retained in WordPress. Recovery currently requires an administrator; there is no one-click undo.', 'pagecraft-builder')];
        foreach ($effects as [$kind, $label, $effect]) {
            echo '<tr><th scope="row" class="pagecraft-effect pagecraft-effect--' . esc_attr($kind) . '">' . esc_html($label) . '</th><td>' . esc_html($effect) . '</td></tr>';
        }
        echo '</tbody></table></div><form class="pagecraft-cloud-transfer pagecraft-confirm" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-pagecraft-working="'
            . esc_attr__('Replacing… This can take up to a minute. Keep this tab open.', 'pagecraft-builder') . '">';
        wp_nonce_field('pagecraft_cloud_import_' . $selected);
        foreach (['action' => 'pagecraft_cloud_import', 'project' => $selected, 'scope' => $scope,
            'source_page' => $source, 'destination' => (string) $destination,
            'destination_state' => CloudReplacement::fingerprint($scope, $destination),
            'source_version' => (string) ($project['sourceVersion'] ?? 0)] as $key => $value) {
            echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        echo '<label class="pagecraft-cloud-import__choice"><input type="checkbox" name="confirm_replace" value="1" required><span>'
            . esc_html__('I understand that this replaces WordPress content, including local edits.', 'pagecraft-builder')
            . '</span></label>';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts above.
        echo $backLink;
        echo '<button class="button button-primary pagecraft-button--danger">' . esc_html($scope === 'site' ? 'Replace site' : 'Replace page')
            . '</button></form></div>';
        $this->summary($scope === 'site' ? [
            __('Cloud project', 'pagecraft-builder') => (string) $project['name'],
            __('Scope', 'pagecraft-builder') => __('Whole site', 'pagecraft-builder'),
            __('Pages', 'pagecraft-builder') => (string) (int) $project['pageCount'],
        ] : [
            __('Cloud project', 'pagecraft-builder') => (string) $project['name'],
            __('Scope', 'pagecraft-builder') => __('One page', 'pagecraft-builder'),
            __('From Cloud', 'pagecraft-builder') => (string) ($sourcePage['name'] ?? $sourcePage['title'] ?? $source),
            __('Replaces', 'pagecraft-builder') => (string) $target->post_title,
        ]);
        echo '</div>';
    }

    /**
     * The first step: the project list is the picker, then the scope, then one button.
     *
     * @param array<int, array<string, mixed>> $projects
     */
    private function choose(array $projects, string $selected, string $scope): void
    {
        $current = self::projectOnThisSite();
        echo '<form class="pagecraft-pick" method="get" action="' . esc_url(admin_url('admin.php')) . '">'
            . '<input type="hidden" name="page" value="pagecraft-connect">'
            . '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-pick__projects"><tbody>'
            . '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="4">' . esc_html__('1 · Choose a project', 'pagecraft-builder')
            . '<span class="pagecraft-table__band-note">' . esc_html(sprintf(
                /* translators: %d: number of Cloud projects */
                _n('%d project', '%d projects', count($projects), 'pagecraft-builder'),
                count($projects)
            )) . '</span></th></tr>';
        foreach (array_values($projects) as $index => $item) {
            $id = (string) $item['id'];
            $field = 'pc-project-' . $index;
            echo '<tr class="pagecraft-pick__row' . ($id === $selected ? ' is-selected' : '') . '"><td class="pagecraft-pick__radio">'
                . '<input type="radio" id="' . esc_attr($field) . '" name="project" value="' . esc_attr($id) . '" required'
                . checked($selected, $id, false) . '></td><th scope="row"><label for="' . esc_attr($field) . '">'
                . esc_html((string) $item['name']) . '</label></th><td class="pagecraft-pick__count">' . esc_html(sprintf(
                    /* translators: %d: number of pages */
                    _n('%d page', '%d pages', (int) $item['pageCount'], 'pagecraft-builder'),
                    (int) $item['pageCount']
                )) . '</td><td class="pagecraft-pick__note">'
                . ($current !== '' && $current === $id ? esc_html__('On this site now', 'pagecraft-builder') : '') . '</td></tr>';
        }
        echo '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="4">' . esc_html__('2 · What to replace', 'pagecraft-builder') . '</th></tr>'
            . '</tbody></table></div><fieldset class="pagecraft-pick__scope"><legend class="screen-reader-text">'
            . esc_html__('What to replace', 'pagecraft-builder') . '</legend>';
        foreach ([
            'site' => [__('The whole site', 'pagecraft-builder'), __('Pages, navigation, homepage and Pagecraft site design.', 'pagecraft-builder')],
            'page' => [__('One page', 'pagecraft-builder'), __('Keeps its URL. Other pages are left alone.', 'pagecraft-builder')],
        ] as $value => [$title, $description]) {
            echo '<label class="pagecraft-cloud-import__choice"><input type="radio" name="scope" value="' . esc_attr($value)
                . '" required' . checked($scope, $value, false) . '><span><strong>' . esc_html($title)
                . '</strong><small>' . esc_html($description) . '</small></span></label>';
        }
        echo '</fieldset><div class="pagecraft-pick__foot"><p>' . esc_html__('Nothing changes until you confirm on the next step.', 'pagecraft-builder')
            . '</p><button class="button button-primary" name="review" value="1">' . esc_html__('Review replacement', 'pagecraft-builder')
            . '</button></div></form>';
    }

    /** The Cloud project the homepage came from, or an empty string when it did not come from Cloud. */
    private static function projectOnThisSite(): string
    {
        $front = (int) get_option('page_on_front');
        return $front > 0 ? (string) get_post_meta($front, ManagedPage::SOURCE_PROJECT_ID, true) : '';
    }

    /** @param array<string,string> $facts */
    private function summary(array $facts): void
    {
        echo '<aside class="pagecraft-split__side"><h2>' . esc_html__('This replacement', 'pagecraft-builder') . '</h2><dl class="pagecraft-side-facts">';
        foreach ($facts as $label => $value) {
            echo '<dt>' . esc_html($label) . '</dt><dd>' . esc_html($value) . '</dd>';
        }
        echo '</dl></aside>';
    }
}
