<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class RestController
{
    public const NAMESPACE = 'pagecraft/v1';

    public function register(): void
    {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes(): void
    {
        register_rest_route(self::NAMESPACE, '/session', [
            'methods' => 'GET',
            'callback' => [$this, 'session'],
            'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT),
        ]);
        register_rest_route(self::NAMESPACE, '/pages', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'pages'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT),
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'createPage'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT)
                    && current_user_can('edit_pages'),
            ],
        ]);
        register_rest_route(self::NAMESPACE, '/pages/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'page'],
                'permission_callback' => [$this, 'canEditPage'],
            ],
            [
                'methods' => 'PATCH',
                'callback' => [$this, 'updatePage'],
                'permission_callback' => [$this, 'canEditPage'],
            ],
        ]);
        register_rest_route(self::NAMESPACE, '/pages/(?P<id>\d+)/document', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'document'],
                'permission_callback' => [$this, 'canEditPage'],
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'saveDocument'],
                'permission_callback' => [$this, 'canEditPage'],
            ],
        ]);
        register_rest_route(self::NAMESPACE, '/pages/(?P<id>\d+)/revisions', [
            'methods' => 'GET',
            'callback' => [$this, 'revisions'],
            'permission_callback' => [$this, 'canEditPage'],
        ]);
        register_rest_route(self::NAMESPACE, '/pages/(?P<id>\d+)/revisions/(?P<version>\d+)/restore', [
            'methods' => 'POST',
            'callback' => [$this, 'restore'],
            'permission_callback' => [$this, 'canEditPage'],
        ]);
        register_rest_route(self::NAMESPACE, '/globals/(?P<id>\d+)/document', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'globalDocument'],
                'permission_callback' => [$this, 'canEditGlobal'],
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'saveGlobalDocument'],
                'permission_callback' => [$this, 'canEditGlobal'],
            ],
        ]);
        register_rest_route(self::NAMESPACE, '/globals/(?P<id>\d+)/revisions', [
            'methods' => 'GET',
            'callback' => [$this, 'globalRevisions'],
            'permission_callback' => [$this, 'canEditGlobal'],
        ]);
        register_rest_route(self::NAMESPACE, '/globals/(?P<id>\d+)/revisions/(?P<version>\d+)/restore', [
            'methods' => 'POST',
            'callback' => [$this, 'restoreGlobal'],
            'permission_callback' => [$this, 'canEditGlobal'],
        ]);
        register_rest_route(self::NAMESPACE, '/media', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'media'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT),
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'uploadMedia'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT)
                    && current_user_can('upload_files'),
            ],
        ]);
        register_rest_route(self::NAMESPACE, '/media/(?P<id>\d+)', [
            'methods' => 'DELETE',
            'callback' => [$this, 'deleteMedia'],
            'permission_callback' => static fn (\WP_REST_Request $request): bool => current_user_can(Capabilities::EDIT)
                && current_user_can('delete_post', (int) $request['id']),
        ]);
        register_rest_route(self::NAMESPACE, '/menus', [
            'methods' => 'GET',
            'callback' => [$this, 'menus'],
            'permission_callback' => static fn (): bool => current_user_can(Capabilities::MANAGE)
                && current_user_can('edit_theme_options'),
        ]);
        register_rest_route(self::NAMESPACE, '/menus/(?P<id>\d+)', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'menu'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::MANAGE)
                    && current_user_can('edit_theme_options'),
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'saveMenu'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::MANAGE)
                    && current_user_can('edit_theme_options'),
            ],
        ]);
        register_rest_route(self::NAMESPACE, '/settings', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'settings'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT),
            ],
            [
                'methods' => 'PUT',
                'callback' => [$this, 'saveSettings'],
                'permission_callback' => static fn (): bool => current_user_can(Capabilities::MANAGE)
                    && current_user_can('edit_theme_options'),
            ],
        ]);
        register_rest_route(self::NAMESPACE, '/generated-output/stale', [
            'methods' => 'GET',
            'callback' => [$this, 'staleGeneratedOutput'],
            'permission_callback' => static fn (): bool => current_user_can(Capabilities::MANAGE)
                && current_user_can('edit_theme_options'),
        ]);
        register_rest_route(self::NAMESPACE, '/generated-output/source/(?P<type>page|global)/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'generatedOutputSource'],
            'permission_callback' => [$this, 'canMaintainGeneratedOutputTarget'],
        ]);
        register_rest_route(self::NAMESPACE, '/generated-output/recompile', [
            'methods' => 'POST',
            'callback' => [$this, 'recompileGeneratedOutput'],
            'permission_callback' => static fn (): bool => current_user_can(Capabilities::MANAGE)
                && current_user_can('edit_theme_options'),
        ]);
        register_rest_route(self::NAMESPACE, '/content/sources', [
            'methods' => 'GET',
            'callback' => [$this, 'contentSources'],
            'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT),
        ]);
        register_rest_route(self::NAMESPACE, '/content/(?P<source>[a-zA-Z0-9_-]+)', [
            'methods' => 'GET',
            'callback' => [$this, 'contentItems'],
            'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT),
        ]);
        register_rest_route(self::NAMESPACE, '/content/(?P<source>[a-zA-Z0-9_-]+)/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'contentItem'],
            'permission_callback' => static fn (): bool => current_user_can(Capabilities::EDIT),
        ]);
    }

    public function canEditPage(\WP_REST_Request $request): bool
    {
        return current_user_can(Capabilities::EDIT)
            && current_user_can('edit_post', (int) $request['id'])
            && get_post_type((int) $request['id']) === 'page';
    }

    public function canEditGlobal(\WP_REST_Request $request): bool
    {
        return current_user_can(Capabilities::MANAGE)
            && current_user_can('edit_post', (int) $request['id'])
            && get_post_type((int) $request['id']) === GlobalElement::POST_TYPE;
    }

    public function canMaintainGeneratedOutputTarget(\WP_REST_Request $request): bool
    {
        $type = (string) $request['type'];
        $postId = (int) $request['id'];
        $expectedType = $type === 'global' ? GlobalElement::POST_TYPE : 'page';
        return in_array($type, ['page', 'global'], true)
            && current_user_can(Capabilities::MANAGE)
            && current_user_can('edit_theme_options')
            && current_user_can('edit_post', $postId)
            && get_post_type($postId) === $expectedType;
    }

    public function session(): \WP_REST_Response
    {
        $user = wp_get_current_user();
        $capabilities = ['edit_document', 'edit_structure', 'restore_revisions'];
        if (current_user_can('edit_pages')) {
            $capabilities[] = 'manage_pages';
        }
        if (current_user_can('upload_files')) {
            $capabilities[] = 'upload_media';
        }
        if (current_user_can(Capabilities::MANAGE) && current_user_can('edit_theme_options')) {
            $capabilities[] = 'manage_menus';
            $capabilities[] = 'manage_settings';
        }
        return new \WP_REST_Response([
            'authenticated' => $user->exists(),
            'userId' => (string) $user->ID,
            'displayName' => (string) $user->display_name,
            'capabilities' => $capabilities,
        ]);
    }

    public function pages(): \WP_REST_Response
    {
        $posts = get_posts([
            'post_type' => 'page',
            'post_status' => ['draft', 'publish', 'private'],
            'posts_per_page' => 200,
            'orderby' => ['menu_order' => 'ASC', 'title' => 'ASC'],
        ]);
        $posts = array_values(array_filter($posts, static fn (\WP_Post $post): bool =>
            $post->post_status === 'publish' || current_user_can('read_post', $post->ID)));
        return new \WP_REST_Response(array_map([$this, 'pagePayload'], $posts));
    }

    public function page(\WP_REST_Request $request): \WP_REST_Response
    {
        return new \WP_REST_Response($this->pagePayload(get_post((int) $request['id'])));
    }

    public function createPage(\WP_REST_Request $request): \WP_REST_Response
    {
        $input = $request->get_json_params();
        $status = $this->status((string) ($input['status'] ?? 'draft'));
        if (in_array($status, ['publish', 'private'], true) && !current_user_can('publish_pages')) {
            return new \WP_REST_Response(['error' => __('You are not allowed to publish pages.', 'pagecraft-builder')], 403);
        }
        $id = wp_insert_post([
            'post_type' => 'page',
            'post_status' => $status,
            'post_title' => sanitize_text_field((string) ($input['title'] ?? __('Untitled page', 'pagecraft-builder'))),
            'post_name' => sanitize_title((string) ($input['slug'] ?? '')),
            'post_parent' => max(0, (int) ($input['parentId'] ?? 0)),
        ], true);
        if (is_wp_error($id)) {
            return new \WP_REST_Response(['error' => $id->get_error_message()], 400);
        }
        return new \WP_REST_Response($this->pagePayload(get_post((int) $id)), 201);
    }

    public function updatePage(\WP_REST_Request $request): \WP_REST_Response
    {
        $input = $request->get_json_params();
        $update = ['ID' => (int) $request['id']];
        if (array_key_exists('title', $input)) {
            $update['post_title'] = sanitize_text_field((string) $input['title']);
        }
        if (array_key_exists('slug', $input)) {
            $update['post_name'] = sanitize_title((string) $input['slug']);
        }
        if (array_key_exists('status', $input)) {
            $update['post_status'] = $this->status((string) $input['status']);
            if (in_array($update['post_status'], ['publish', 'private'], true) && !current_user_can('publish_pages')) {
                return new \WP_REST_Response(['error' => __('You are not allowed to publish pages.', 'pagecraft-builder')], 403);
            }
        }
        if (array_key_exists('parentId', $input)) {
            $update['post_parent'] = max(0, (int) $input['parentId']);
        }
        $id = wp_update_post($update, true);
        if (is_wp_error($id)) {
            return new \WP_REST_Response(['error' => $id->get_error_message()], 400);
        }
        return new \WP_REST_Response($this->pagePayload(get_post((int) $id)));
    }

    public function document(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(function () use ($request): array {
            $loaded = (new PageEditor())->load((int) $request['id']);
            if (is_array($loaded['document'])) {
                $loaded['document'] = (new NativeMenu())->hydrateDocument($loaded['document']);
            }
            return $loaded;
        });
    }

    public function saveDocument(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(function () use ($request): array {
            $input = $request->get_json_params();
            return (new PageEditor())->save((int) $request['id'], $input);
        });
    }

    public function revisions(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(static fn (): array => (new PageEditor())->revisions((int) $request['id']));
    }

    public function restore(\WP_REST_Request $request): \WP_REST_Response
    {
        $input = $request->get_json_params();
        return $this->editorResponse(static fn (): array => (new PageEditor())->restore(
            (int) $request['id'],
            (int) $request['version'],
            (int) ($input['currentVersion'] ?? -1)
        ));
    }

    public function globalDocument(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(static fn (): array => (new GlobalElementEditor())->load((int) $request['id']));
    }

    public function saveGlobalDocument(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(function () use ($request): array {
            $input = $request->get_json_params();
            return (new GlobalElementEditor())->save((int) $request['id'], $input);
        });
    }

    public function globalRevisions(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(static fn (): array => (new GlobalElementEditor())->revisions((int) $request['id']));
    }

    public function restoreGlobal(\WP_REST_Request $request): \WP_REST_Response
    {
        $input = $request->get_json_params();
        return $this->editorResponse(static fn (): array => (new GlobalElementEditor())->restore(
            (int) $request['id'],
            (int) $request['version'],
            (int) ($input['currentVersion'] ?? -1)
        ));
    }

    public function media(): \WP_REST_Response
    {
        $attachments = $this->mediaAttachments();
        $attachmentIds = array_map(
            static fn (\WP_Post $attachment): int => $attachment->ID,
            $attachments
        );
        $usage = MediaLibrary::usageMap($attachmentIds);
        $payload = [];
        foreach ($attachments as $attachment) {
            $attachmentId = $attachment->ID;
            $payload[] = $this->mediaPayload($attachment, $usage[$attachmentId] ?? null);
        }
        return new \WP_REST_Response($payload);
    }

    /** @return list<\WP_Post> */
    private function mediaAttachments(): array
    {
        $batchSize = 200;
        $page = 1;
        $attachments = [];
        $seen = [];
        do {
            $batch = get_posts([
                'post_type' => 'attachment',
                'post_status' => 'inherit',
                'post_mime_type' => 'image',
                'posts_per_page' => $batchSize,
                'paged' => $page,
                'orderby' => 'date',
                'order' => 'DESC',
            ]);
            $added = 0;
            foreach ($batch as $attachment) {
                if (!$attachment instanceof \WP_Post || isset($seen[$attachment->ID])) continue;
                $seen[$attachment->ID] = true;
                $attachments[] = $attachment;
                $added++;
            }
            $page++;
        } while (count($batch) === $batchSize && $added > 0);
        return $attachments;
    }

    public function uploadMedia(): \WP_REST_Response
    {
        // REST authentication verifies the nonce; validation must inspect the untouched temporary file.
        // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $error = MediaUpload::error(is_array($_FILES['file'] ?? null) ? $_FILES['file'] : []);
        if ($error !== null) {
            return new \WP_REST_Response(['error' => $error], 400);
        }
        if (!function_exists('media_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $id = media_handle_upload('file', 0, [], ['test_form' => false]);
        if (is_wp_error($id)) {
            return new \WP_REST_Response(['error' => $id->get_error_message()], 400);
        }
        return new \WP_REST_Response($this->mediaPayload(get_post((int) $id)), 201);
    }

    public function deleteMedia(\WP_REST_Request $request): \WP_REST_Response
    {
        $id = (int) $request['id'];
        if (get_post_type($id) !== 'attachment') {
            return new \WP_REST_Response(['error' => __('WordPress could not delete that media item.', 'pagecraft-builder')], 400);
        }
        $usage = MediaLibrary::usage($id);
        if (!$usage['canDelete']) {
            return $this->mediaInUseResponse($usage);
        }
        if (!wp_delete_attachment($id, true)) {
            $usage = MediaLibrary::usage($id);
            if (!$usage['canDelete']) return $this->mediaInUseResponse($usage);
            return new \WP_REST_Response(['error' => __('WordPress could not delete that media item.', 'pagecraft-builder')], 400);
        }
        return new \WP_REST_Response(['removed' => (string) $id]);
    }

    public function menus(): \WP_REST_Response
    {
        return $this->menuResponse(static fn (): array => (new NativeMenu())->list());
    }

    public function menu(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->menuResponse(static fn (): array => (new NativeMenu())->get((int) $request['id']));
    }

    public function saveMenu(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->menuResponse(static fn (): array => (new NativeMenu())->save(
            (int) $request['id'],
            $request->get_json_params()
        ));
    }

    public function settings(): \WP_REST_Response
    {
        $theme = wp_get_theme();
        $settings = new DesignSettings();
        $design = $settings->read();
        try {
            $designUsage = $settings->designUsage();
            foreach ($designUsage['counts'] as $kind => $counts) {
                $designUsage['counts'][$kind] = (object) $counts;
            }
            // Preview 25 and older editor HTML reads this compatibility field.
            $classUsage = ['known' => true, 'counts' => $designUsage['counts']['classes']];
        } catch (PackageException) {
            // The editor must fail closed when every persisted document cannot be checked.
            $classUsage = ['known' => false, 'counts' => (object) []];
            $designUsage = [
                'known' => false,
                'counts' => [
                    'classes' => (object) [],
                    'colors' => (object) [],
                    'textStyles' => (object) [],
                ],
            ];
        }
        return new \WP_REST_Response([
            'theme' => (string) $theme->get_stylesheet(),
            'editor' => true,
            'wordpressVersion' => (string) get_bloginfo('version'),
            'design' => DocumentJson::design($design),
            /* Derive the version from the exact design returned above. If a concurrent writer
             * changes the stylesheet between these reads, the hybrid version cannot match its
             * completed state and the client's later conditional write safely conflicts. */
            'designVersion' => $settings->version($design),
            'classUsage' => $classUsage,
            'designUsage' => $designUsage,
        ]);
    }

    public function saveSettings(\WP_REST_Request $request): \WP_REST_Response
    {
        try {
            $saved = (new DesignSettings())->save($request->get_json_params());
            return new \WP_REST_Response([
                'editor' => true,
                'design' => DocumentJson::design($saved['design']),
                'globalCss' => $saved['globalCss'],
                'designVersion' => $saved['designVersion'],
            ]);
        } catch (DesignSettingsConflict $error) {
            return new \WP_REST_Response([
                'code' => 'pagecraft_design_conflict',
                'error' => $error->getMessage(),
                'designVersion' => $error->currentVersion,
            ], 409);
        } catch (EditorBusy $error) {
            return new \WP_REST_Response(['error' => $error->getMessage(), 'retryable' => true], 409);
        } catch (PackageException $error) {
            return new \WP_REST_Response(['error' => $error->getMessage()], 422);
        }
    }

    public function staleGeneratedOutput(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(static fn (): array => (new RefreshGeneratedOutput())->stale(
            max(0, (int) ($request->get_param('after') ?? 0)),
            min(RefreshGeneratedOutput::MAX_BATCH, max(1, (int) ($request->get_param('limit') ?? 50)))
        ));
    }

    public function generatedOutputSource(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(static fn (): array => (new RefreshGeneratedOutput())->source(
            (string) $request['type'],
            (int) $request['id']
        ));
    }

    public function recompileGeneratedOutput(\WP_REST_Request $request): \WP_REST_Response
    {
        return $this->editorResponse(static fn (): array => (new RefreshGeneratedOutput())->recompile(
            $request->get_json_params()
        ));
    }

    public function contentSources(): \WP_REST_Response
    {
        $sources = [];
        foreach (get_post_types(['show_in_rest' => true], 'objects') as $type) {
            if (!$type instanceof \WP_Post_Type || !$this->contentType($type->name)) {
                continue;
            }
            $sources[] = [
                'id' => (string) $type->name,
                'label' => (string) $type->labels->name,
                'restBase' => (string) ($type->rest_base ?: $type->name),
            ];
        }
        return new \WP_REST_Response($sources);
    }

    public function contentItems(\WP_REST_Request $request): \WP_REST_Response
    {
        $source = sanitize_key((string) $request['source']);
        if (!$this->contentType($source)) {
            return new \WP_REST_Response(['error' => __('That WordPress content type is unavailable.', 'pagecraft-builder')], 404);
        }
        $posts = get_posts([
            'post_type' => $source,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'posts_per_page' => min(100, max(1, (int) ($request->get_param('per_page') ?: 50))),
            'paged' => max(1, (int) ($request->get_param('page') ?: 1)),
            's' => sanitize_text_field((string) ($request->get_param('search') ?: '')),
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);
        $posts = array_values(array_filter($posts, static fn (\WP_Post $post): bool => current_user_can('read_post', $post->ID)));
        return new \WP_REST_Response(array_map([$this, 'contentPayload'], $posts));
    }

    public function contentItem(\WP_REST_Request $request): \WP_REST_Response
    {
        $source = sanitize_key((string) $request['source']);
        $post = get_post((int) $request['id']);
        if (!$this->contentType($source) || !$post || $post->post_type !== $source
            || !current_user_can('read_post', $post->ID)) {
            return new \WP_REST_Response(['error' => __('That WordPress content item is unavailable.', 'pagecraft-builder')], 404);
        }
        return new \WP_REST_Response($this->contentPayload($post));
    }

    /** @return array<string,mixed> */
    private function pagePayload(?\WP_Post $post): array
    {
        if (!$post || $post->post_type !== 'page') {
            return [];
        }
        return [
            'id' => (string) $post->ID,
            'title' => get_the_title($post),
            'slug' => (string) $post->post_name,
            'status' => in_array($post->post_status, ['draft', 'publish', 'private', 'trash'], true)
                ? $post->post_status : 'draft',
            'url' => get_permalink($post),
            'parentId' => $post->post_parent > 0 ? (string) $post->post_parent : null,
            'modifiedAt' => get_post_modified_time('c', true, $post),
        ];
    }

    /** @return array<string,mixed> */
    private function mediaPayload(?\WP_Post $post, ?array $usage = null): array
    {
        if (!$post || $post->post_type !== 'attachment') {
            return [];
        }
        $metadata = wp_get_attachment_metadata($post->ID);
        $file = get_attached_file($post->ID);
        $usage ??= MediaLibrary::usage((int) $post->ID);
        return array_merge([
            'id' => (string) $post->ID,
            'name' => get_the_title($post),
            'mimeType' => (string) $post->post_mime_type,
            'url' => (string) wp_get_attachment_url($post->ID),
            'size' => is_string($file) && is_file($file) ? (int) filesize($file) : 0,
            'width' => is_array($metadata) ? (int) ($metadata['width'] ?? 0) : 0,
            'height' => is_array($metadata) ? (int) ($metadata['height'] ?? 0) : 0,
            'usageKnown' => true,
        ], $usage);
    }

    /** @param array{usageCount:int,canDelete:bool,usedBy:list<array<string,mixed>>} $usage */
    private function mediaInUseResponse(array $usage): \WP_REST_Response
    {
        return new \WP_REST_Response(array_merge([
            'code' => 'pagecraft_media_in_use',
            'error' => __('This image is used by WordPress content and cannot be deleted.', 'pagecraft-builder'),
            'usageKnown' => true,
        ], $usage), 409);
    }

    private function contentType(string $name): ?\WP_Post_Type
    {
        $type = get_post_type_object($name);
        if (!$type instanceof \WP_Post_Type || !$type->show_in_rest || $name === 'attachment'
            || $name === GlobalElement::POST_TYPE || (!$type->publicly_queryable && !$type->show_ui)) {
            return null;
        }
        return $type;
    }

    /** @return array<string,mixed> */
    private function contentPayload(\WP_Post $post): array
    {
        $excerpt = trim((string) $post->post_excerpt);
        if ($excerpt === '') {
            $excerpt = wp_trim_words(wp_strip_all_tags(strip_shortcodes((string) $post->post_content)), 55);
        }
        return [
            'id' => (string) $post->ID,
            'source' => (string) $post->post_type,
            'title' => get_the_title($post),
            'slug' => (string) $post->post_name,
            'status' => (string) $post->post_status,
            'url' => (string) get_permalink($post),
            'modifiedAt' => (string) get_post_modified_time('c', true, $post),
            'excerpt' => $excerpt,
        ];
    }

    private function status(string $status): string
    {
        return in_array($status, ['draft', 'publish', 'private', 'trash'], true) ? $status : 'draft';
    }

    /** @param callable():array<mixed> $operation */
    private function editorResponse(callable $operation): \WP_REST_Response
    {
        try {
            $result = $operation();
            if (isset($result['document']) && is_array($result['document'])) {
                $result['document'] = DocumentJson::document($result['document']);
            }
            return new \WP_REST_Response($result);
        } catch (EditorConflict $error) {
            return new \WP_REST_Response([
                'error' => $error->getMessage(),
                'conflict' => ['mine' => $error->mine, 'theirs' => $error->theirs],
            ], 409);
        } catch (GeneratedOutputConflict $error) {
            return new \WP_REST_Response([
                'error' => $error->getMessage(),
                'current' => [
                    'documentVersion' => $error->currentVersion,
                    'documentSha256' => $error->currentDocumentSha256,
                    'renderContextSha256' => $error->currentRenderContextSha256,
                ],
            ], 409);
        } catch (CompilerContractConflict $error) {
            return new \WP_REST_Response([
                'error' => $error->getMessage(),
                'reloadRequired' => true,
                'compiler' => $error->current,
            ], 409);
        } catch (EditorBusy $error) {
            return new \WP_REST_Response(['error' => $error->getMessage(), 'retryable' => true], 409);
        } catch (PackageException $error) {
            return new \WP_REST_Response(['error' => $error->getMessage()], 400);
        }
    }

    /** @param callable():array<mixed> $operation */
    private function menuResponse(callable $operation): \WP_REST_Response
    {
        try {
            return new \WP_REST_Response($operation());
        } catch (PackageException $error) {
            return new \WP_REST_Response(['error' => $error->getMessage()], 400);
        }
    }
}
