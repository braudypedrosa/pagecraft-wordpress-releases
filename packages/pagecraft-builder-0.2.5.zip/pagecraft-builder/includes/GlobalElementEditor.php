<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Persists a global element through the same portable document boundary used by pages.
 * The workbench edits the global region as its only canvas; the Theme owns the outer
 * header/footer landmark at render time.
 */
final class GlobalElementEditor
{
    /** @return array{document:?array<string,mixed>,version:int} */
    public function load(int $postId): array
    {
        $post = $this->assertEditable($postId);
        $raw = get_post_meta($postId, GlobalElement::DOCUMENT, true);
        if (!is_string($raw) || $raw === '') {
            return ['document' => null, 'version' => 0];
        }
        try {
            $document = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new PackageException('The stored Pagecraft global document is invalid: ' . $error->getMessage());
        }
        if (!is_array($document)) {
            throw new PackageException('The stored Pagecraft global document is not an object.');
        }
        if (!isset($document['schemaVersion'])) {
            $document = self::documentFromRegion(
                [(string) get_post_meta($postId, GlobalElement::KIND, true) => $document],
                (string) get_post_meta($postId, GlobalElement::KIND, true),
                get_the_title($post)
            );
        }
        $document = (new NativeMenu())->hydrateDocument($document);
        return [
            'document' => $document,
            'version' => max(1, (int) get_post_meta($postId, GlobalElement::DOCUMENT_VERSION, true)),
        ];
    }

    /** @param array<string,mixed> $input @return array{version:int,revisionId:?int} */
    public function save(int $postId, array $input): array
    {
        $this->assertEditable($postId);
        return EditorWriteLock::runExclusiveSourceWrite([$postId], function () use ($postId, $input): array {
            $this->assertSaveIdentity($postId, $input);
            $prepared = $this->prepareSave($postId, $input);
            $document = $prepared['document'];
            $save = fn (): array => $this->saveLocked($postId, $prepared);
            return (new NativeMenu())->synchronizeAndRun($document, $save);
        });
    }

    /** @param array<string,mixed> $input */
    private function assertSaveIdentity(int $postId, array $input): void
    {
        $hasDocument = (string) get_post_meta($postId, GlobalElement::DOCUMENT, true) !== '';
        $currentVersion = $hasDocument
            ? max(1, (int) get_post_meta($postId, GlobalElement::DOCUMENT_VERSION, true))
            : 0;
        $clientVersion = filter_var($input['version'] ?? null, FILTER_VALIDATE_INT);
        if ($clientVersion === false || $clientVersion !== $currentVersion) {
            throw new EditorConflict($clientVersion === false ? -1 : (int) $clientVersion, $currentVersion);
        }
        $compiled = $input['compiled'] ?? null;
        if (!is_array($compiled)) {
            throw new PackageException('The compiled WordPress fallback is missing.');
        }
        if (array_key_exists('compiler', $compiled)) {
            $compiler = CompilerContract::current();
            if (!is_array($compiled['compiler']) || !$compiler->matchesSealedPayload($compiled['compiler'])) {
                throw new CompilerContractConflict($compiler->sealedPayload());
            }
        }
    }

    /**
     * @param array<string,mixed> $input
     * @return array{
     *   hasDocument:bool,
     *   currentVersion:int,
     *   document:array<string,mixed>,
     *   schemaVersion:int,
     *   documentJson:string,
     *   mediaAttachments:string,
     *   compiler:?CompilerContract,
     *   css:string,
     *   content:string
     * }
     */
    private function prepareSave(int $postId, array $input): array
    {
        $hasDocument = (string) get_post_meta($postId, GlobalElement::DOCUMENT, true) !== '';
        $currentVersion = (int) $input['version'];
        $document = $input['document'] ?? $input['doc'] ?? null;
        if (!is_array($document)) {
            throw new PackageException('The Pagecraft global document payload is missing.');
        }
        $schemaVersion = filter_var($document['schemaVersion'] ?? $document['v'] ?? null, FILTER_VALIDATE_INT);
        if ($schemaVersion === false || $schemaVersion <= 0) {
            throw new PackageException('The Pagecraft global document has no valid schema version.');
        }
        if ($schemaVersion > PageEditor::SCHEMA_VERSION) {
            throw new PackageException(
                'This global element uses Pagecraft schema ' . $schemaVersion . ', but this Builder supports schema '
                . PageEditor::SCHEMA_VERSION . '. Upgrade Pagecraft Builder before saving.'
            );
        }
        $documentJson = DocumentJson::encode($document);
        if (strlen($documentJson) > PageEditor::MAX_DOCUMENT_BYTES) {
            throw new PackageException('The Pagecraft global document exceeds the WordPress editor limit.');
        }
        $mediaAttachments = MediaLibrary::attachmentIdsJsonForDocument($document);
        $compiled = $input['compiled'] ?? null;
        if (!is_array($compiled)) {
            throw new PackageException('The compiled WordPress fallback is missing.');
        }
        $compiler = null;
        if (array_key_exists('compiler', $compiled)) {
            $compiler = CompilerContract::current();
            if ($schemaVersion > $compiler->schemaVersion) {
                throw new PackageException('The sealed Pagecraft compiler cannot compile this global document schema.');
            }
        }
        $html = $this->boundedString($compiled['html'] ?? null, PageEditor::MAX_HTML_BYTES, 'compiled global element');
        $cssParts = [];
        foreach (['globalCss', 'pageCss'] as $key) {
            $cssParts[] = FallbackCompiler::safeCssSource(
                $this->boundedString($compiled[$key] ?? '', GeneratedAssetStore::MAX_CSS_BYTES, 'global stylesheet', true)
            );
        }
        $css = trim(implode("\n", array_filter($cssParts, static fn (string $part): bool => $part !== '')));
        if (strlen($css) > GeneratedAssetStore::MAX_CSS_BYTES) {
            throw new PackageException('The combined global stylesheet exceeds the WordPress editor limit.');
        }
        $content = FallbackCompiler::contentFromHtml($html);
        return [
            'hasDocument' => $hasDocument,
            'currentVersion' => $currentVersion,
            'document' => $document,
            'schemaVersion' => $schemaVersion,
            'documentJson' => $documentJson,
            'mediaAttachments' => $mediaAttachments,
            'compiler' => $compiler,
            'css' => $css,
            'content' => $content,
        ];
    }

    /**
     * @param array{
     *   hasDocument:bool,
     *   currentVersion:int,
     *   document:array<string,mixed>,
     *   schemaVersion:int,
     *   documentJson:string,
     *   mediaAttachments:string,
     *   compiler:?CompilerContract,
     *   css:string,
     *   content:string
     * } $prepared
     * @return array{version:int,revisionId:?int}
     */
    private function saveLocked(int $postId, array $prepared): array
    {
        $this->assertEditable($postId);
        $hasDocument = $prepared['hasDocument'];
        $currentVersion = $prepared['currentVersion'];
        $document = $prepared['document'];
        $schemaVersion = $prepared['schemaVersion'];
        $documentJson = $prepared['documentJson'];
        $mediaAttachments = $prepared['mediaAttachments'];
        $compiler = $prepared['compiler'];
        $css = $prepared['css'];
        $content = $prepared['content'];
        $renderContextSha256 = $compiler !== null
            ? (new RefreshGeneratedOutput($compiler))->contextSha256($postId, 'global', $document)
            : '';
        $assets = new GeneratedAssetStore();
        $cssAsset = $css !== '' ? $assets->writeCss('global', $css) : null;
        $runtimeAsset = FallbackCompiler::needsRuntime($content) ? $assets->writeRuntime() : null;

        $revisionId = null;
        if ($hasDocument) {
            $revision = wp_save_post_revision($postId);
            if (is_wp_error($revision)) {
                throw new PackageException('WordPress could not create the global-element safety revision: ' . $revision->get_error_message());
            }
            if (is_int($revision) && $revision > 0) {
                $revisionId = $revision;
            }
        }
        $updated = wp_update_post(['ID' => $postId, 'post_content' => wp_slash($content)], true);
        if (is_wp_error($updated)) {
            throw new PackageException('WordPress could not save the Pagecraft global element: ' . $updated->get_error_message());
        }

        $nextVersion = $currentVersion + 1;
        $metadata = [
            GlobalElement::DOCUMENT => $documentJson,
            GlobalElement::MEDIA_ATTACHMENTS => $mediaAttachments,
            GlobalElement::DOCUMENT_VERSION => (string) $nextVersion,
            GlobalElement::SCHEMA_VERSION => (string) $schemaVersion,
            GlobalElement::RENDERER_VERSION => $compiler !== null
                ? $compiler->rendererVersion
                : PAGECRAFT_BUILDER_VERSION,
            GlobalElement::COMPILED_HASH => hash('sha256', $content),
            GlobalElement::CSS_PATH => $cssAsset['path'] ?? '',
            GlobalElement::CSS_HASH => $cssAsset['hash'] ?? '',
            GlobalElement::RUNTIME_PATH => $runtimeAsset['path'] ?? '',
            GlobalElement::RUNTIME_HASH => $runtimeAsset['hash'] ?? '',
            GlobalElement::UPDATED_AT => gmdate('c'),
            GlobalElement::COMPILER_EDITOR_VERSION => '',
            GlobalElement::COMPILER_RENDERER_REVISION => '',
            GlobalElement::COMPILER_DOCUMENT_SHA256 => '',
            GlobalElement::COMPILER_RENDER_CONTEXT_SHA256 => '',
            GlobalElement::COMPILED_AT => '',
        ];
        if ($compiler !== null) {
            $metadata = array_replace($metadata, $compiler->provenance($documentJson));
            $metadata[GlobalElement::COMPILER_RENDER_CONTEXT_SHA256] = $renderContextSha256;
        }
        foreach ($metadata as $key => $value) {
            update_post_meta($postId, $key, wp_slash($value));
        }
        return ['version' => $nextVersion, 'revisionId' => $revisionId];
    }

    /** @return list<array{id:string,version:int,createdAt:string,author:array{id:string,name:string},current:bool}> */
    public function revisions(int $postId): array
    {
        $loaded = $this->load($postId);
        $rows = [];
        $snapshots = new EditorRevisionSnapshots(
            GlobalElement::DOCUMENT,
            GlobalElement::DOCUMENT_VERSION,
            GlobalElement::COMPILED_HASH
        );
        $selection = $snapshots->selectForPost($postId, $loaded['version']);
        foreach ($selection['snapshots'] as $revision) {
            $id = (int) $revision->ID;
            $author = get_userdata((int) $revision->post_author);
            $rows[] = [
                'id' => (string) $id,
                'version' => max(1, (int) get_post_meta($id, GlobalElement::DOCUMENT_VERSION, true)),
                'createdAt' => get_post_time('c', true, $revision),
                'author' => [
                    'id' => (string) ($author->ID ?? ''),
                    'name' => (string) ($author->display_name ?? __('WordPress user', 'pagecraft-builder')),
                ],
                'current' => false,
            ];
        }
        array_unshift($rows, [
            'id' => 'current',
            'version' => $loaded['version'],
            'createdAt' => get_post_modified_time('c', true, $postId),
            'author' => [
                'id' => '',
                'name' => $selection['hasUnverifiedHistory']
                    ? __('Current draft · Some older versions cannot be safely restored here', 'pagecraft-builder')
                    : __('Current WordPress draft', 'pagecraft-builder'),
            ],
            'current' => true,
        ]);
        return $rows;
    }

    /** @return array{document:array<string,mixed>,version:int} */
    public function restore(int $postId, int $revisionVersion, int $currentVersion): array
    {
        $this->assertEditable($postId);
        return EditorWriteLock::runExclusiveSourceWrite(
            [$postId],
            fn (): array => $this->restoreLocked($postId, $revisionVersion, $currentVersion)
        );
    }

    private function restoreLocked(int $postId, int $revisionVersion, int $currentVersion): array
    {
        $loaded = $this->load($postId);
        if ($loaded['version'] !== $currentVersion) {
            throw new EditorConflict($currentVersion, $loaded['version']);
        }
        $matched = (new EditorRevisionSnapshots(
            GlobalElement::DOCUMENT,
            GlobalElement::DOCUMENT_VERSION,
            GlobalElement::COMPILED_HASH
        ))->forVersion($postId, $loaded['version'], $revisionVersion);
        if (!$matched instanceof \WP_Post) {
            throw new PackageException('That Pagecraft global version has no verified WordPress revision and cannot be restored.');
        }
        $safety = wp_save_post_revision($postId);
        if (is_wp_error($safety)) {
            throw new PackageException('WordPress could not protect the current global element before restoring it.');
        }
        $updated = wp_update_post(['ID' => $postId, 'post_content' => wp_slash((string) $matched->post_content)], true);
        if (is_wp_error($updated)) {
            throw new PackageException('WordPress could not restore the selected global-element revision.');
        }
        foreach (GlobalElement::keys() as $key) {
            if ($key === GlobalElement::DOCUMENT_VERSION) {
                continue;
            }
            $value = get_post_meta((int) $matched->ID, $key, true);
            if (is_string($value)) {
                update_post_meta($postId, $key, wp_slash($value));
            }
        }
        $nextVersion = $currentVersion + 1;
        update_post_meta($postId, GlobalElement::DOCUMENT_VERSION, (string) $nextVersion);
        $restored = $this->load($postId);
        if (!is_array($restored['document'])) {
            throw new PackageException('The selected revision has no Pagecraft global document.');
        }
        update_post_meta(
            $postId,
            GlobalElement::MEDIA_ATTACHMENTS,
            wp_slash(MediaLibrary::attachmentIdsJsonForDocument($restored['document']))
        );
        return ['document' => $restored['document'], 'version' => $nextVersion];
    }

    /** @param array<string,mixed> $source @return array<string,mixed> */
    public static function documentFromRegion(array $source, string $kind, string $title): array
    {
        GlobalElement::assertKind($kind);
        $region = $source[$kind] ?? [];
        if (!is_array($region)) {
            $region = [];
        }
        $meta = isset($source['meta']) && is_array($source['meta']) ? $source['meta'] : [];
        $meta += [
            'name' => $title,
            'maxWidth' => '1200px',
            'font' => "'Manrope',system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif",
            'headFont' => "'Manrope',system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif",
            'size' => '16px',
            'css' => '',
            'headHtml' => '',
            'lang' => 'en',
            'baseUrl' => '',
            'ogImage' => '',
            'favicon' => '',
            'blocks' => [],
            'tokens' => ['classes' => [], 'colors' => [], 'text' => []],
            'collections' => [],
        ];
        $page = isset($source['pages'][0]) && is_array($source['pages'][0]) ? $source['pages'][0] : [];
        $page = array_merge($page, [
            'id' => 'wordpress-global-' . $kind,
            'name' => $title,
            'slug' => 'global-' . $kind,
            'title' => $title,
            'desc' => '',
            'ogImage' => '',
            'tree' => array_values($region),
        ]);
        return [
            'schemaVersion' => (int) ($source['schemaVersion'] ?? PageEditor::SCHEMA_VERSION),
            'meta' => $meta,
            'header' => [],
            'footer' => [],
            'pages' => [$page],
        ];
    }

    private function assertEditable(int $postId): \WP_Post
    {
        $post = get_post($postId);
        $kind = (string) get_post_meta($postId, GlobalElement::KIND, true);
        if (!$post instanceof \WP_Post || $post->post_type !== GlobalElement::POST_TYPE
            || !current_user_can(Capabilities::MANAGE) || !current_user_can('edit_post', $postId)) {
            throw new PackageException('You are not allowed to edit this Pagecraft global element.');
        }
        GlobalElement::assertKind($kind);
        return $post;
    }

    private function boundedString(mixed $value, int $limit, string $label, bool $allowEmpty = false): string
    {
        if (!is_string($value) || (!$allowEmpty && $value === '')) {
            throw new PackageException('The ' . $label . ' payload is missing.');
        }
        if (strlen($value) > $limit) {
            throw new PackageException('The ' . $label . ' exceeds the WordPress editor limit.');
        }
        return $value;
    }
}
