<?php
/**
 * Public document boundary for a resolved Pagecraft Theme Builder template.
 * WordPress owns the query and content; Pagecraft owns visual composition.
 *
 * @package Pagecraft
 */

$pagecraft_template_id = pagecraft_theme_document_template_post_id();
if ( $pagecraft_template_id <= 0 ) {
	return;
}

get_header();
$pagecraft_template_content = (string) get_post_field( 'post_content', $pagecraft_template_id );
?>
<main id="pagecraft-main" class="pagecraft-main pagecraft-theme-template" data-pagecraft-template="<?php echo esc_attr( (string) $pagecraft_template_id ); ?>">
	<?php
	$pagecraft_template_content = (string) apply_filters( 'pagecraft_theme_template_content', $pagecraft_template_content, 'template', $pagecraft_template_id );
	echo pagecraft_theme_bind_dynamic_content( $pagecraft_template_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- compiled template and native WP fields are sanitized at their ownership boundaries.
	?>
</main>
<?php
get_footer();
