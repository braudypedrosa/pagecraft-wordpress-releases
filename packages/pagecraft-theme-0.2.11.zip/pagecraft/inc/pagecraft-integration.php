<?php
/**
 * Safe integration boundary between the theme and Pagecraft Builder.
 *
 * @package Pagecraft
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether the current native WordPress page carries a Pagecraft document.
 */
function pagecraft_theme_is_managed_page( ?int $post_id = null ): bool {
	$resolved = $post_id ?? (int) get_queried_object_id();
	if ( $resolved <= 0 || 'page' !== get_post_type( $resolved ) ) {
		return false;
	}

	if ( function_exists( 'pagecraft_builder_is_managed_page' ) ) {
		return pagecraft_builder_is_managed_page( $resolved );
	}

	return '' !== get_post_meta( $resolved, '_pagecraft_document', true );
}

/** Render compiled native markup without adding paragraphs inside layout grids. */
function pagecraft_theme_native_image_loading(): bool {
	return false;
}

function pagecraft_theme_managed_content(): void {
	$priority = has_filter( 'the_content', 'wpautop' );
	if ( false !== $priority ) {
		remove_filter( 'the_content', 'wpautop', $priority );
	}
	// Native markup already expresses the author's lazy/eager choice. Do not
	// inject lazy loading into an image exported without the lazy attribute.
	add_filter( 'wp_lazy_loading_enabled', 'pagecraft_theme_native_image_loading' );
	try {
		the_content();
	} finally {
		remove_filter( 'wp_lazy_loading_enabled', 'pagecraft_theme_native_image_loading', 10 );
		if ( false !== $priority ) {
			add_filter( 'the_content', 'wpautop', $priority );
		}
	}
}

/**
 * Keep saved Theme Builder records queryable if Builder is temporarily inactive.
 * The plugin remains the owner of editing, capabilities, metadata and revisions.
 */
function pagecraft_theme_register_template_storage(): void {
	if ( post_type_exists( 'pagecraft_global' ) || class_exists( '\\Pagecraft\\Builder\\GlobalElement' ) ) {
		return;
	}
	register_post_type(
		'pagecraft_global',
		array(
			'public'       => false,
			'show_ui'      => false,
			'show_in_rest' => false,
			'rewrite'      => false,
			'query_var'    => false,
			'supports'     => array( 'title', 'revisions', 'custom-fields' ),
		)
	);
}
add_action( 'init', 'pagecraft_theme_register_template_storage', 1 );

/** Determine whether Pagecraft owns the visual document on the current route. */
function pagecraft_theme_is_managed_route(): bool {
	return pagecraft_theme_is_managed_page() || pagecraft_theme_document_template_post_id() > 0;
}

/**
 * Scope fallback presentation so it cannot impose a design on managed routes.
 *
 * @param string[] $classes Existing body classes.
 * @return string[]
 */
function pagecraft_theme_body_classes( array $classes ): array {
	$classes[] = pagecraft_theme_is_managed_route()
		? 'pagecraft-theme-managed'
		: 'pagecraft-theme-fallback';

	return array_values( array_unique( $classes ) );
}
add_filter( 'body_class', 'pagecraft_theme_body_classes', 20 );

/**
 * Resolve one of the two revision-backed global element posts without requiring the plugin.
 */
function pagecraft_theme_global_post_id( string $kind ): int {
	if ( ! in_array( $kind, array( 'header', 'footer' ), true ) ) {
		return 0;
	}
	$page_id = (int) get_queried_object_id();
	$mode_key = '_pagecraft_' . $kind . '_mode';
	$id_key = '_pagecraft_' . $kind . '_id';
	$mode = 'page' === get_post_type( $page_id ) ? (string) get_post_meta( $page_id, $mode_key, true ) : 'inherit';
	if ( 'none' === $mode ) {
		return 0;
	}
	if ( 'selected' === $mode ) {
		$selected = (int) get_post_meta( $page_id, $id_key, true );
		if ( pagecraft_theme_valid_global_post( $selected, $kind ) ) {
			return $selected;
		}
	}
	$conditional = pagecraft_theme_resolve_template( array( $kind ) );
	if ( pagecraft_theme_valid_global_post( $conditional, $kind ) ) {
		return $conditional;
	}
	$default = (int) get_option( 'pagecraft_default_' . $kind . '_id', 0 );
	if ( pagecraft_theme_valid_global_post( $default, $kind ) ) {
		return $default;
	}
	$post = get_page_by_path( 'pagecraft-' . $kind, OBJECT, 'pagecraft_global' );
	return is_object( $post ) ? (int) $post->ID : 0;
}

/** @return string[] */
function pagecraft_theme_document_template_kinds(): array {
	if ( is_404() ) {
		return array( 'not_found' );
	}
	if ( is_search() ) {
		return array( 'search' );
	}
	if ( is_archive() || is_home() ) {
		return array( 'archive' );
	}
	if ( is_singular( 'page' ) ) {
		if ( pagecraft_theme_is_managed_page() ) {
			return array();
		}
		return array( 'single_page' );
	}
	if ( is_singular() ) {
		return array( 'single_post' );
	}
	return array();
}

/** Resolve the Pagecraft document template for the current public route. */
function pagecraft_theme_document_template_post_id(): int {
	if ( is_singular( 'page' ) && '1' === (string) get_post_meta( get_queried_object_id(), '_pagecraft_use_page_document', true ) ) {
		return 0;
	}
	$kinds = pagecraft_theme_document_template_kinds();
	return array() === $kinds ? 0 : pagecraft_theme_resolve_template( $kinds );
}

/** @return array<string,mixed> */
function pagecraft_theme_condition_context(): array {
	$object    = get_queried_object();
	$post_type = '';
	$taxonomy  = '';
	$term_id   = 0;
	if ( $object instanceof WP_Post ) {
		$post_type = (string) $object->post_type;
	} elseif ( $object instanceof WP_Term ) {
		$taxonomy = (string) $object->taxonomy;
		$term_id  = (int) $object->term_id;
	}
	if ( '' === $post_type && is_post_type_archive() ) {
		$queried   = get_query_var( 'post_type' );
		$post_type = is_array( $queried ) ? (string) reset( $queried ) : (string) $queried;
	}
	return array(
		'is_singular'          => is_singular(),
		'post_id'              => is_singular() ? (int) get_queried_object_id() : 0,
		'post_type'            => $post_type,
		'is_archive'           => is_archive() || is_home(),
		'is_post_type_archive' => is_post_type_archive(),
		'is_taxonomy'          => is_category() || is_tag() || is_tax(),
		'taxonomy'             => $taxonomy,
		'term_id'              => $term_id,
		'is_search'            => is_search(),
		'is_404'               => is_404(),
	);
}

/** @param string[] $kinds */
function pagecraft_theme_resolve_template( array $kinds ): int {
	$context         = pagecraft_theme_condition_context();
	$winner          = 0;
	$winner_score    = -1;
	$winner_priority = PHP_INT_MIN;
	$posts           = get_posts(
		array(
			'post_type'      => 'pagecraft_global',
			'post_status'    => 'publish',
			'posts_per_page' => 200,
			'orderby'        => array( 'modified' => 'DESC', 'ID' => 'DESC' ),
		)
	);
	foreach ( $posts as $post ) {
		$post_id = is_object( $post ) ? (int) $post->ID : (int) $post;
		$kind    = (string) get_post_meta( $post_id, '_pagecraft_global_kind', true );
		if ( ! in_array( $kind, $kinds, true ) ) {
			continue;
		}
		$stored_rules = (string) get_post_meta( $post_id, '_pagecraft_template_conditions', true );
		if ( '' === $stored_rules && in_array( $kind, array( 'header', 'footer' ), true ) ) {
			continue;
		}
		$rules = pagecraft_theme_normalize_conditions( $stored_rules, $kind );
		$score = pagecraft_theme_condition_score( $rules, $context );
		$priority = (int) get_post_meta( $post_id, '_pagecraft_template_priority', true );
		if ( $score > $winner_score || ( $score === $winner_score && $priority > $winner_priority )
			|| ( $score === $winner_score && $priority === $winner_priority && $post_id > $winner ) ) {
			$winner          = $post_id;
			$winner_score    = $score;
			$winner_priority = $priority;
		}
	}
	return $winner_score >= 0 ? $winner : 0;
}

/** @return array<int,array{action:string,type:string,value:string}> */
function pagecraft_theme_normalize_conditions( string $json, string $kind ): array {
	$decoded = json_decode( $json, true );
	if ( ! is_array( $decoded ) ) {
		$type    = in_array( $kind, array( 'header', 'footer' ), true ) ? 'site' : $kind;
		$decoded = array( array( 'action' => 'include', 'type' => $type, 'value' => '' ) );
		if ( 'single_page' === $kind || 'single_post' === $kind ) {
			$decoded[0] = array(
				'action' => 'include',
				'type'   => 'post_type',
				'value'  => 'single_page' === $kind ? 'page' : 'post',
			);
		}
	}
	$allowed = array( 'site', 'singular', 'post_type', 'post', 'archive', 'post_type_archive', 'taxonomy', 'term', 'search', 'not_found' );
	$rules   = array();
	foreach ( $decoded as $rule ) {
		if ( ! is_array( $rule ) ) {
			continue;
		}
		$action = strtolower( trim( (string) ( $rule['action'] ?? 'include' ) ) );
		$type   = strtolower( trim( (string) ( $rule['type'] ?? '' ) ) );
		$value  = preg_replace( '/[^A-Za-z0-9_:\-]/', '', trim( (string) ( $rule['value'] ?? '' ) ) );
		if ( ! in_array( $action, array( 'include', 'exclude' ), true ) || ! in_array( $type, $allowed, true ) ) {
			continue;
		}
		$rules[] = array( 'action' => $action, 'type' => $type, 'value' => (string) $value );
	}
	return $rules;
}

/** @param array<int,array{action:string,type:string,value:string}> $rules @param array<string,mixed> $context */
function pagecraft_theme_condition_score( array $rules, array $context ): int {
	$best = -1;
	foreach ( $rules as $rule ) {
		if ( ! pagecraft_theme_condition_matches( $rule, $context ) ) {
			continue;
		}
		if ( 'exclude' === $rule['action'] ) {
			return -1;
		}
		$best = max( $best, pagecraft_theme_condition_specificity( $rule['type'] ) );
	}
	return $best;
}

/** @param array{action:string,type:string,value:string} $rule @param array<string,mixed> $context */
function pagecraft_theme_condition_matches( array $rule, array $context ): bool {
	$value = $rule['value'];
	switch ( $rule['type'] ) {
		case 'site': return true;
		case 'singular': return (bool) ( $context['is_singular'] ?? false );
		case 'post_type': return (bool) ( $context['is_singular'] ?? false ) && $value === (string) ( $context['post_type'] ?? '' );
		case 'post': return (bool) ( $context['is_singular'] ?? false ) && (int) $value === (int) ( $context['post_id'] ?? 0 );
		case 'archive': return (bool) ( $context['is_archive'] ?? false );
		case 'post_type_archive': return (bool) ( $context['is_post_type_archive'] ?? false ) && $value === (string) ( $context['post_type'] ?? '' );
		case 'taxonomy': return (bool) ( $context['is_taxonomy'] ?? false ) && $value === (string) ( $context['taxonomy'] ?? '' );
		case 'term':
			list( $taxonomy, $term_id ) = array_pad( explode( ':', $value, 2 ), 2, '' );
			return (bool) ( $context['is_taxonomy'] ?? false ) && $taxonomy === (string) ( $context['taxonomy'] ?? '' )
				&& (int) $term_id === (int) ( $context['term_id'] ?? 0 );
		case 'search': return (bool) ( $context['is_search'] ?? false );
		case 'not_found': return (bool) ( $context['is_404'] ?? false );
		default: return false;
	}
}

function pagecraft_theme_condition_specificity( string $type ): int {
	if ( in_array( $type, array( 'post', 'term', 'search', 'not_found' ), true ) ) return 500;
	if ( in_array( $type, array( 'post_type', 'post_type_archive', 'taxonomy' ), true ) ) return 400;
	if ( in_array( $type, array( 'singular', 'archive' ), true ) ) return 300;
	return 'site' === $type ? 100 : 0;
}

/**
 * Validate a stored global assignment without relying on Builder being active.
 */
function pagecraft_theme_valid_global_post( int $post_id, string $kind ): bool {
	return $post_id > 0
		&& 'pagecraft_global' === get_post_type( $post_id )
		&& 'publish' === get_post_status( $post_id )
		&& hash_equals( $kind, (string) get_post_meta( $post_id, '_pagecraft_global_kind', true ) );
}

/** Remove the page-only identity from a canonical stored global wrapper. */
function pagecraft_theme_normalize_global_wrapper( string $content ): string {
	$normalized = preg_replace_callback(
		'/\A(\s*<div(?:(?:\s+[^\s=\/>]+(?:\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s"\'=<>`]+))?))*\s*>)/i',
		static function ( array $match ): string {
			$opening = $match[1];
			preg_match_all(
				'/\s+([^\s=\/>]+)(?:\s*=\s*("[^"]*"|\'[^\']*\'|[^\s"\'=<>`]+))?/',
				$opening,
				$attributes,
				PREG_SET_ORDER | PREG_OFFSET_CAPTURE
			);
			$class_value = '';
			$id_attribute = null;
			foreach ( $attributes as $attribute ) {
				$name = strtolower( $attribute[1][0] );
				$value = $attribute[2][0] ?? '';
				if ( strlen( $value ) >= 2 && ( '"' === $value[0] || "'" === $value[0] ) ) {
					$value = substr( $value, 1, -1 );
				}
				if ( 'class' === $name ) {
					$class_value = $value;
				} elseif ( 'id' === $name && 'pagecraft-main' === $value ) {
					$id_attribute = $attribute[0];
				}
			}
			if ( ! preg_match( '/(?:^|\s)pagecraft-main(?:\s|$)/', $class_value ) || null === $id_attribute ) {
				return $opening;
			}
			// A global lives inside the Theme's header/footer landmark; only the page body owns this identity.
			return substr_replace(
				$opening,
				'',
				$id_attribute[1],
				strlen( $id_attribute[0] )
			);
		},
		$content,
		1
	);
	return is_string( $normalized ) ? $normalized : $content;
}

/** Render a stored global region through an explicit landmark. */
function pagecraft_theme_render_global( string $kind ): bool {
	$post_id = pagecraft_theme_global_post_id( $kind );
	if ( $post_id <= 0 ) {
		return false;
	}
	$content = get_post_field( 'post_content', $post_id );
	if ( ! is_string( $content ) || '' === trim( $content ) ) {
		return false;
	}
	$content = pagecraft_theme_normalize_global_wrapper( $content );
	$content = pagecraft_theme_bind_native_menus( $content, $kind );
	/** Lets Pagecraft Builder upgrade forms in a global; without Builder the markup stays as saved. */
	$content = (string) apply_filters( 'pagecraft_theme_global_content', $content, $kind, $post_id );
	$tag = 'header' === $kind ? 'header' : 'footer';
	printf(
		'<%1$s class="pagecraft-global pagecraft-global-%2$s" data-pagecraft-global="%2$s">%3$s</%1$s>',
		esc_attr( $tag ),
		esc_attr( $kind ),
		$content // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized before persistence.
	);
	return true;
}

/**
 * Keep page-backed menu items dynamic while preserving an imported Pagecraft anchor.
 *
 * @param object $item WordPress menu item.
 * @return object
 */
function pagecraft_theme_menu_item_anchor( object $item ): object {
	if ( ! isset( $item->ID, $item->url ) || 'post_type' !== ( $item->type ?? '' ) ) {
		return $item;
	}
	$anchor = sanitize_title( (string) get_post_meta( (int) $item->ID, '_pagecraft_menu_anchor', true ) );
	if ( '' !== $anchor ) {
		$item->url = strtok( (string) $item->url, '#' ) . '#' . $anchor;
	}
	return $item;
}
add_filter( 'wp_setup_nav_menu_item', 'pagecraft_theme_menu_item_anchor', 20 );

/**
 * Replace a compiled Pagecraft menu list with the native menu assigned to its stable location.
 * Pagecraft keeps the surrounding nav, toggle, classes and generated CSS; WordPress supplies
 * the current menu items and URLs.
 */
function pagecraft_theme_bind_native_menus( string $content, string $kind ): string {
	$locations = get_nav_menu_locations();
	$seen = 0;
	$bound = preg_replace_callback(
		'#<nav\b([^>]*)\bdata-nav\b([^>]*)>([\s\S]*?)</nav>#i',
		static function ( array $match ) use ( $kind, $locations, &$seen ): string {
			$attributes = $match[1] . ' data-nav' . $match[2];
			$location = '';
			if ( preg_match( '/\bdata-pagecraft-menu-location=(?:"([a-z0-9_-]+)"|\'([a-z0-9_-]+)\')/i', $attributes, $declared ) ) {
				$location = (string) ( $declared[1] ?: $declared[2] );
			} elseif ( 'header' === $kind ) {
				$location = 0 === $seen ? 'primary' : 'utility';
			} elseif ( 0 === $seen ) {
				$location = 'footer';
			}
			$seen++;
			$menu_id = (int) ( $locations[ $location ] ?? 0 );
			if ( $menu_id <= 0 ) {
				return $match[0];
			}
			if ( ! str_contains( $attributes, 'data-pagecraft-menu-location=' ) ) {
				$attributes .= ' data-pagecraft-menu-location="' . esc_attr( $location ) . '"';
			}
			$toggle = '';
			if ( preg_match( '#<button\b[^>]*\bdata-nav-t\b[^>]*>[\s\S]*?</button>#i', $match[3], $button ) ) {
				$toggle = $button[0];
			}
			$list_id = 'pagecraft-native-menu-' . $menu_id;
			if ( preg_match( '/<ul\b[^>]*\bid=(?:"([^"]+)"|\'([^\']+)\')/i', $match[3], $list ) ) {
				$list_id = sanitize_html_class( (string) ( $list[1] ?: $list[2] ), $list_id );
			}
			$menu = wp_nav_menu(
				array(
					'menu'        => $menu_id,
						'container'   => '',
					'depth'       => 0,
					'fallback_cb' => false,
					'echo'        => false,
					'items_wrap'  => '<ul id="' . esc_attr( $list_id ) . '" class="pagecraft-nav-list" data-nav-l>%3$s</ul>',
				)
			);
			if ( ! is_string( $menu ) || '' === trim( $menu ) ) {
				return $match[0];
			}
			return '<nav' . $attributes . '>' . $toggle . $menu . '</nav>';
		},
		$content
	);
	return is_string( $bound ) ? $bound : $content;
}

/**
 * Convert a persisted upload-relative descriptor to a same-site URL.
 */
function pagecraft_theme_generated_asset_url( string $path, string $hash, string $extension ): string {
	if ( ! preg_match( '#^pagecraft/(?:global|page|runtime)-([a-f0-9]{64})\.(css|js)$#', $path, $match )
		|| ! hash_equals( $match[1], $hash ) || $match[2] !== $extension ) {
		return '';
	}
	$uploads = wp_upload_dir();
	if ( ! empty( $uploads['error'] ) ) {
		return '';
	}
	$file = trailingslashit( $uploads['basedir'] ) . $path;
	if ( ! is_file( $file ) || ! is_readable( $file ) ) {
		return '';
	}
	return trailingslashit( $uploads['baseurl'] ) . $path;
}

/**
 * Resolve the one interaction runtime shared by every Pagecraft fragment on the request.
 *
 * The active compatible Builder owns runtime compatibility for the whole document. When
 * it is unavailable, the newest saved fragment cannot be inferred from content hashes,
 * so the theme uses the closest persisted fallback in page, template, header, footer order.
 *
 * @param int[] $post_ids Persisted runtime candidates in fallback priority order.
 * @return array{hash:string,url:string}|null
 */
function pagecraft_theme_generated_runtime( array $post_ids ): ?array {
	$fallback = null;
	foreach ( array_unique( array_filter( $post_ids ) ) as $post_id ) {
		$runtime_path = (string) get_post_meta( (int) $post_id, '_pagecraft_runtime_path', true );
		$runtime_hash = (string) get_post_meta( (int) $post_id, '_pagecraft_runtime_hash', true );
		$runtime_url  = pagecraft_theme_generated_asset_url( $runtime_path, $runtime_hash, 'js' );
		if ( '' !== $runtime_url ) {
			$fallback = array( 'hash' => $runtime_hash, 'url' => $runtime_url );
			break;
		}
	}
	if ( null === $fallback || did_action( 'pagecraft_builder_loaded' ) <= 0
		|| ! defined( 'PAGECRAFT_BUILDER_DIR' ) || ! defined( 'PAGECRAFT_BUILDER_URL' ) ) {
		return $fallback;
	}

	$file = trailingslashit( (string) PAGECRAFT_BUILDER_DIR ) . 'assets/pagecraft-runtime.js';
	if ( ! is_file( $file ) || ! is_readable( $file ) ) {
		return $fallback;
	}
	$bytes = filesize( $file );
	if ( ! is_int( $bytes ) || $bytes <= 0 || $bytes > 2 * 1024 * 1024 ) {
		return $fallback;
	}
	$hash = hash_file( 'sha256', $file );
	if ( ! is_string( $hash ) || ! preg_match( '/^[a-f0-9]{64}$/', $hash ) ) {
		return $fallback;
	}

	return array(
		'hash' => $hash,
		'url'  => trailingslashit( (string) PAGECRAFT_BUILDER_URL ) . 'assets/pagecraft-runtime.js',
	);
}

/**
 * Load immutable styles and one compatible interaction runtime for the active document.
 */
function pagecraft_theme_enqueue_generated_assets(): void {
	$global_ids = array_filter(
		array( pagecraft_theme_global_post_id( 'header' ), pagecraft_theme_global_post_id( 'footer' ) )
	);
	$template_id = pagecraft_theme_document_template_post_id();
	$page_id = pagecraft_theme_is_managed_page() ? (int) get_queried_object_id() : 0;
	$styles = array();
	$remember_style = static function ( int $post_id, string $prefix ) use ( &$styles ): void {
		if ( $post_id <= 0 ) {
			return;
		}
		$path = (string) get_post_meta( $post_id, $prefix . '_path', true );
		$hash = (string) get_post_meta( $post_id, $prefix . '_hash', true );
		$url = pagecraft_theme_generated_asset_url( $path, $hash, 'css' );
		if ( '' !== $url ) {
			unset( $styles[ $hash ] );
			$styles[ $hash ] = $url;
		}
	};
	/* Project foundation first, active global presentation second, page-only rules last. */
	$remember_style( $page_id, '_pagecraft_global_css' );
	foreach ( array_unique( $global_ids ) as $post_id ) {
		$remember_style( $post_id, '_pagecraft_global_css' );
	}
	$remember_style( $template_id, '_pagecraft_global_css' );
	/* WordPress-owned design settings outrank foundations captured in older globals.
	 * This asset contains foundation/tokens only, never header/footer node rules. */
	$design_asset = get_option( 'pagecraft_design_stylesheet_v1', array() );
	if ( is_array( $design_asset ) && ( $page_id || $template_id || $global_ids ) ) {
		$design_hash = (string) ( $design_asset['hash'] ?? '' );
		$design_url = pagecraft_theme_generated_asset_url( (string) ( $design_asset['path'] ?? '' ), $design_hash, 'css' );
		if ( '' !== $design_url ) {
			unset( $styles[ $design_hash ] );
			$styles[ $design_hash ] = $design_url;
		}
	}
	/* Each template's own rules come after every foundation, so no foundation can reset them.
	 * A template compiled before this split has no such file and loads as it did before. */
	foreach ( array_unique( $global_ids ) as $post_id ) {
		$remember_style( $post_id, '_pagecraft_page_css' );
	}
	$remember_style( $template_id, '_pagecraft_page_css' );
	$remember_style( $page_id, '_pagecraft_page_css' );

	$runtime = pagecraft_theme_generated_runtime(
		array_merge( array( $page_id, $template_id ), $global_ids )
	);
	foreach ( $styles as $hash => $url ) {
		wp_enqueue_style( 'pagecraft-generated-' . substr( $hash, 0, 12 ), $url, array(), substr( $hash, 0, 12 ) );
	}
	if ( null !== $runtime ) {
		wp_enqueue_script(
			'pagecraft-runtime-' . substr( $runtime['hash'], 0, 12 ),
			$runtime['url'],
			array(),
			substr( $runtime['hash'], 0, 12 ),
			array( 'in_footer' => true, 'strategy' => 'defer' )
		);
	}

	/* Backward compatibility for v1 page packages created before split asset files existed. */
	if ( pagecraft_theme_is_managed_page() && array() === $styles ) {
		$post_id = (int) get_queried_object_id();
		$css = get_post_meta( $post_id, '_pagecraft_compiled_css', true );
		if ( is_string( $css ) && '' !== trim( $css ) ) {
			$handle = 'pagecraft-managed-legacy';
			wp_register_style( $handle, false, array(), substr( hash( 'sha256', $css ), 0, 12 ) );
			wp_enqueue_style( $handle );
			wp_add_inline_style( $handle, $css );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'pagecraft_theme_enqueue_generated_assets', 20 );

/** Route supported WordPress requests through the matching Pagecraft document. */
function pagecraft_theme_template_include( string $template ): string {
	$template_id = pagecraft_theme_document_template_post_id();
	if ( $template_id <= 0 || '' === trim( (string) get_post_field( 'post_content', $template_id ) ) ) {
		return $template;
	}
	$pagecraft = PAGECRAFT_THEME_DIR . '/pagecraft-template.php';
	return is_readable( $pagecraft ) ? $pagecraft : $template;
}
add_filter( 'template_include', 'pagecraft_theme_template_include', 99 );

/** Replace declarative WordPress fields after Pagecraft has compiled its visual document. */
function pagecraft_theme_bind_dynamic_content( string $content ): string {
	$post_id = is_singular() ? (int) get_queried_object_id() : 0;
	$post    = $post_id > 0 ? get_post( $post_id ) : null;
	$values  = array(
		'{{wp.site.title}}'          => static fn(): string => esc_html( get_bloginfo( 'name' ) ),
		'{{wp.site.description}}'    => static fn(): string => esc_html( get_bloginfo( 'description' ) ),
		'{{wp.site.home_url}}'       => static fn(): string => esc_url( home_url( '/' ) ),
		'{{wp.post.title}}'          => static fn(): string => $post ? esc_html( get_the_title( $post ) ) : '',
		'{{wp.post.content}}'        => static fn(): string => $post ? apply_filters( 'the_content', get_the_content( null, false, $post ) ) : '',
		'{{wp.post.excerpt}}'        => static fn(): string => $post ? wp_kses_post( get_the_excerpt( $post ) ) : '',
		'{{wp.post.featured_image}}' => static fn(): string => $post && has_post_thumbnail( $post )
			? get_the_post_thumbnail( $post, 'large', array( 'loading' => 'eager' ) ) : '',
		'{{wp.post.author}}'         => static fn(): string => $post ? esc_html( get_the_author_meta( 'display_name', (int) $post->post_author ) ) : '',
		'{{wp.post.date}}'           => static fn(): string => $post ? esc_html( get_the_date( '', $post ) ) : '',
		'{{wp.archive.title}}'       => static fn(): string => wp_kses_post( get_the_archive_title() ),
		'{{wp.archive.description}}' => static fn(): string => wp_kses_post( get_the_archive_description() ),
		'{{wp.search.query}}'        => static fn(): string => esc_html( get_search_query() ),
		'{{wp.query.loop}}'          => static fn(): string => pagecraft_theme_query_loop(),
		'{{wp.pagination}}'          => static fn(): string => pagecraft_theme_query_pagination(),
	);
	foreach ( $values as $token => $resolve ) {
		if ( str_contains( $content, $token ) ) {
			$content = str_replace( $token, $resolve(), $content );
		}
	}
	return $content;
}

/** Render the current main query using the theme's accessible native cards. */
function pagecraft_theme_query_loop(): string {
	ob_start();
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', is_search() ? 'search' : get_post_type() );
		}
	} else {
		get_template_part( 'template-parts/content', 'none' );
	}
	$rendered = (string) ob_get_clean();
	rewind_posts();
	return $rendered;
}

/** Return pagination markup without making the template responsible for WP query state. */
function pagecraft_theme_query_pagination(): string {
	$pagination = get_the_posts_pagination(
		array(
			'mid_size'  => 1,
			'prev_text' => __( 'Previous', 'pagecraft' ),
			'next_text' => __( 'Next', 'pagecraft' ),
		)
	);
	return is_string( $pagination ) ? $pagination : '';
}
