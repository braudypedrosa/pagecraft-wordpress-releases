<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Server-rendered steps: choosing or reviewing never changes WordPress content. */
final class CloudTransferScreen
{
    public function render(CloudImport $cloud): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET navigation is read-only.
        $projects = $cloud->projects();
        $selected = sanitize_text_field(wp_unslash((string) ($_GET['project'] ?? '')));
        $scope = sanitize_key((string) ($_GET['scope'] ?? ''));
        $source = sanitize_text_field(wp_unslash((string) ($_GET['source_page'] ?? '')));
        $destination = absint($_GET['destination'] ?? 0);
        $review = isset($_GET['review']);
        $undo = absint($_GET['undo'] ?? 0);
        // phpcs:enable
        $latest = CloudRecovery::latest();
        if ($undo > 0 && $latest !== null && $latest['id'] === $undo) {
            $this->reviewUndo($latest);
            return;
        }
        if ($projects === []) {
            echo '<div class="pagecraft-pick"><div class="pagecraft-pick__band"><h2>' . esc_html__('No Cloud projects yet', 'pagecraft-builder')
                . '</h2></div><p class="pagecraft-pick__text">'
                . esc_html__('Projects in your Pagecraft account appear here. Create one in Pagecraft, then check again.', 'pagecraft-builder')
                . '</p><div class="pagecraft-pick__foot"><div class="pagecraft-pick__actions"><a class="button" href="'
                . esc_url(admin_url('admin.php?page=pagecraft-connect')) . '">' . esc_html__('Check again', 'pagecraft-builder')
                . '</a><a class="button button-primary" href="' . esc_url($cloud->origin() . '/') . '" target="_blank" rel="noopener noreferrer">'
                . esc_html__('Open Pagecraft', 'pagecraft-builder') . '<span class="screen-reader-text"> '
                . esc_html__('(opens in a new tab)', 'pagecraft-builder') . '</span></a></div></div></div>';
            return;
        }
        $project = current(array_filter($projects, static fn (array $p): bool => (string) $p['id'] === $selected));
        if (!$review || !is_array($project) || !in_array($scope, ['site', 'page'], true)) {
            // After a replacement the person lands back here, with the result shown as a toast.
            if ($latest !== null) $this->lastReplacement($latest);
            $this->choose($projects, $selected, $scope);
            return;
        }
        $pages = $scope === 'page' ? $cloud->pages($selected) : [];
        $sourcePage = current(array_filter($pages, static fn (array $p): bool => (string) $p['id'] === $source));
        $targets = array_values(array_filter(CloudReplacement::destinations(), static fn (\WP_Post $p): bool => current_user_can('edit_post', $p->ID)));
        $target = current(array_filter($targets, static fn (\WP_Post $p): bool => $p->ID === $destination));
        $back = add_query_arg(['page' => 'pagecraft-connect', 'project' => $selected, 'scope' => $scope], admin_url('admin.php'));
        if ($scope === 'page' && (!is_array($sourcePage) || !$target)) {
            echo '<form class="pagecraft-pick" method="get" action="' . esc_url(admin_url('admin.php')) . '">'
                . '<input type="hidden" name="page" value="pagecraft-connect"><input type="hidden" name="scope" value="page">'
                . '<input type="hidden" name="review" value="1"><input type="hidden" name="project" value="' . esc_attr($selected) . '">'
                . '<div class="pagecraft-pick__band"><p><strong>' . esc_html((string) $project['name']) . '</strong> · '
                . esc_html__('One page', 'pagecraft-builder') . '</p><a href="' . esc_url($back) . '">' . esc_html__('Change', 'pagecraft-builder')
                . '<span class="screen-reader-text"> ' . esc_html__('project or scope', 'pagecraft-builder') . '</span></a></div>'
                . '<div class="pagecraft-pick__pages"><div><label for="pc-source-page">' . esc_html__('Page from Cloud', 'pagecraft-builder') . '</label>'
                . '<select id="pc-source-page" name="source_page" required><option value="">' . esc_html__('Choose a Cloud page', 'pagecraft-builder') . '</option>';
            foreach ($pages as $page) {
                echo '<option value="' . esc_attr((string) $page['id']) . '">' . esc_html((string) ($page['name'] ?? $page['title'] ?? $page['id'])) . '</option>';
            }
            echo '</select></div><span class="pagecraft-pick__arrow" aria-hidden="true">&rarr;</span><div><label for="pc-destination">'
                . esc_html__('WordPress page to replace', 'pagecraft-builder')
                . '</label><select id="pc-destination" name="destination" required><option value="">'
                . esc_html__('Choose a WordPress page', 'pagecraft-builder') . '</option>';
            foreach ($targets as $post) {
                echo '<option value="' . esc_attr((string) $post->ID) . '">' . esc_html($post->post_title . ' · ' . $post->post_status . ' · #' . $post->ID) . '</option>';
            }
            echo '</select></div></div><div class="pagecraft-pick__foot"><p>'
                . esc_html__('Nothing changes until you confirm on the next step.', 'pagecraft-builder')
                . '</p><button class="button button-primary">' . esc_html__('Review replacement', 'pagecraft-builder') . '</button></div></form>';
            return;
        }
        // The review keeps the frame of the steps before it: what was chosen, then what happens, then the confirmation.
        $facts = $scope === 'site' ? [
            [__('Cloud project', 'pagecraft-builder'), (string) $project['name'], sprintf(
                /* translators: %d: number of pages */
                _n('%d page', '%d pages', (int) $project['pageCount'], 'pagecraft-builder'),
                (int) $project['pageCount']
            )],
            [__('WordPress site to replace', 'pagecraft-builder'), (string) get_bloginfo('name'), (string) preg_replace('#^https?://#', '', untrailingslashit(home_url()))],
        ] : [
            [__('Page from Cloud', 'pagecraft-builder'), (string) ($sourcePage['name'] ?? $sourcePage['title'] ?? $source), ''],
            [__('WordPress page to replace', 'pagecraft-builder'), (string) $target->post_title, (string) wp_make_link_relative((string) get_permalink($target->ID))],
        ];
        echo '<div class="pagecraft-pick"><h2 class="screen-reader-text">' . esc_html__('Review replacement', 'pagecraft-builder') . '</h2>'
            . '<div class="pagecraft-pick__band"><p><strong>' . esc_html((string) $project['name']) . '</strong> · '
            . esc_html($scope === 'site' ? __('The whole site', 'pagecraft-builder') : __('One page', 'pagecraft-builder'))
            . '</p><a href="' . esc_url($back) . '">' . esc_html__('Change', 'pagecraft-builder')
            . '<span class="screen-reader-text"> ' . esc_html__('project or scope', 'pagecraft-builder') . '</span></a></div>'
            . '<div class="pagecraft-pick__pages">';
        foreach ($facts as $index => [$label, $value, $detail]) {
            echo ($index === 1 ? '<span class="pagecraft-pick__arrow" aria-hidden="true">&rarr;</span>' : '')
                . '<div><span class="pagecraft-pick__label">' . esc_html($label) . '</span><span class="pagecraft-pick__fixed">'
                . esc_html($value) . ($detail !== '' ? ' <small>· ' . esc_html($detail) . '</small>' : '') . '</span></div>';
        }
        echo '</div><div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-cloud-transfer__impact"><tbody>'
            . '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="2">' . esc_html__('What happens', 'pagecraft-builder') . '</th></tr>';
        $replacedLabel = __('Replaced', 'pagecraft-builder');
        $keptLabel = __('Kept', 'pagecraft-builder');
        $effects = $scope === 'site' ? [
            ['change', __('Published', 'pagecraft-builder'), sprintf('%d Cloud pages will be published as this site’s page collection.', (int) $project['pageCount'])],
            ['change', __('Archived', 'pagecraft-builder'), 'Existing pages outside the incoming collection will be archived, not permanently deleted.'],
            ['change', $replacedLabel, 'Pagecraft navigation, homepage, header and footer will be replaced.'],
            ['keep', $keptLabel, 'Posts, products, users, plugins and unrelated media will be preserved.'],
        ] : [
            ['change', $replacedLabel, 'All content and Pagecraft styling on the destination page will be replaced.'],
            ['keep', $keptLabel, 'Its WordPress URL, title and publication status will stay the same.'],
            ['note', __('Scope', 'pagecraft-builder'), 'The Cloud header and footer will apply to this page only. Other pages and menus will not change.'],
            ['note', __('Check after', 'pagecraft-builder'), 'Other Cloud pages are not imported. Review links to them after replacement.'],
        ];
        $effects[] = ['note', __('Recovery', 'pagecraft-builder'), __('The site as it is now is saved first. You can undo this replacement from this screen until the next one.', 'pagecraft-builder')];
        foreach ($effects as [$kind, $label, $effect]) {
            echo '<tr><th scope="row" class="pagecraft-effect pagecraft-effect--' . esc_attr($kind) . '">' . esc_html($label) . '</th><td>' . esc_html($effect) . '</td></tr>';
        }
        echo '</tbody></table></div><form class="pagecraft-cloud-transfer pagecraft-confirm" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-pagecraft-working="'
            . esc_attr__('Replacing… This can take up to a minute. Keep this tab open.', 'pagecraft-builder') . '">';
        wp_nonce_field('pagecraft_cloud_import_' . $selected);
        foreach (['action' => 'pagecraft_cloud_import', 'project' => $selected, 'scope' => $scope,
            'source_page' => $source, 'destination' => (string) $destination,
            'destination_state' => CloudReplacement::fingerprint($scope, $destination),
            'source_version' => (string) ($project['sourceVersion'] ?? 0)] as $key => $value) {
            echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        echo '<label class="pagecraft-cloud-import__choice"><input type="checkbox" name="confirm_replace" value="1" required><span>'
            . esc_html__('I understand that this replaces WordPress content, including local edits.', 'pagecraft-builder')
            . '</span></label>';
        echo '<button class="button button-primary pagecraft-button--danger">' . esc_html($scope === 'site' ? 'Replace site' : 'Replace page')
            . '</button></form></div>';
    }

    /**
     * The first step: the project list is the picker, then the scope, then one button.
     *
     * @param array<int, array<string, mixed>> $projects
     */
    private function choose(array $projects, string $selected, string $scope): void
    {
        $current = self::projectOnThisSite();
        echo '<form class="pagecraft-pick" method="get" action="' . esc_url(admin_url('admin.php')) . '">'
            . '<input type="hidden" name="page" value="pagecraft-connect">'
            . '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-pick__projects"><tbody>'
            . '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="4">' . esc_html__('1 · Choose a project', 'pagecraft-builder')
            . '<span class="pagecraft-table__band-note">' . esc_html(sprintf(
                /* translators: %d: number of Cloud projects */
                _n('%d project', '%d projects', count($projects), 'pagecraft-builder'),
                count($projects)
            )) . '</span></th></tr>';
        foreach (array_values($projects) as $index => $item) {
            $id = (string) $item['id'];
            $field = 'pc-project-' . $index;
            echo '<tr class="pagecraft-pick__row' . ($id === $selected ? ' is-selected' : '') . '"><td class="pagecraft-pick__radio">'
                . '<input type="radio" id="' . esc_attr($field) . '" name="project" value="' . esc_attr($id) . '" required'
                . checked($selected, $id, false) . '></td><th scope="row"><label for="' . esc_attr($field) . '">'
                . esc_html((string) $item['name']) . '</label></th><td class="pagecraft-pick__count">' . esc_html(sprintf(
                    /* translators: %d: number of pages */
                    _n('%d page', '%d pages', (int) $item['pageCount'], 'pagecraft-builder'),
                    (int) $item['pageCount']
                )) . '</td><td class="pagecraft-pick__note">'
                . ($current !== '' && $current === $id ? esc_html__('On this site now', 'pagecraft-builder') : '') . '</td></tr>';
        }
        echo '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="4">' . esc_html__('2 · What to replace', 'pagecraft-builder') . '</th></tr>'
            . '</tbody></table></div><fieldset class="pagecraft-pick__scope"><legend class="screen-reader-text">'
            . esc_html__('What to replace', 'pagecraft-builder') . '</legend>';
        foreach ([
            'site' => [__('The whole site', 'pagecraft-builder'), __('Pages, navigation, homepage and Pagecraft site design.', 'pagecraft-builder')],
            'page' => [__('One page', 'pagecraft-builder'), __('Keeps its URL. Other pages are left alone.', 'pagecraft-builder')],
        ] as $value => [$title, $description]) {
            echo '<label class="pagecraft-cloud-import__choice"><input type="radio" name="scope" value="' . esc_attr($value)
                . '" required' . checked($scope, $value, false) . '><span><strong>' . esc_html($title)
                . '</strong><small>' . esc_html($description) . '</small></span></label>';
        }
        echo '</fieldset><div class="pagecraft-pick__foot"><p>' . esc_html__('Nothing changes until you confirm on the next step.', 'pagecraft-builder')
            . '</p><button class="button button-primary" name="review" value="1">' . esc_html__('Review replacement', 'pagecraft-builder')
            . '</button></div></form>';
    }

    /**
     * One line naming the most recent replacement, the only one that can be undone.
     *
     * @param array{id:int,createdAt:string,scope:string,kind:string,label:string,updated:int,archived:int,replaced:array{0:int,1:int},snapshot:array<string,mixed>} $latest
     */
    private function lastReplacement(array $latest): void
    {
        [$what, $detail] = self::describe($latest);
        echo '<div class="pagecraft-pick pagecraft-pick--last"><div class="pagecraft-pick__last"><span class="pagecraft-pick__last-label">'
            . esc_html($latest['kind'] === 'undo' ? __('Last change', 'pagecraft-builder') : __('Last replacement', 'pagecraft-builder'))
            . '</span><p><strong>' . esc_html($what) . '</strong>' . ($detail !== '' ? ' <span>· ' . esc_html($detail) . '</span>' : '')
            . '</p><a class="button" href="' . esc_url(add_query_arg(['page' => 'pagecraft-connect', 'undo' => $latest['id']], admin_url('admin.php')))
            . '">' . esc_html($latest['kind'] === 'undo' ? __('Redo replacement', 'pagecraft-builder') : __('Undo replacement', 'pagecraft-builder'))
            . '</a></div></div>';
    }

    /**
     * The confirm step for undoing: what comes back, what is archived, what is lost.
     *
     * @param array{id:int,createdAt:string,scope:string,kind:string,label:string,updated:int,archived:int,replaced:array{0:int,1:int},snapshot:array<string,mixed>} $latest
     */
    private function reviewUndo(array $latest): void
    {
        [$what, $detail] = self::describe($latest);
        $plan = CloudRecovery::plan($latest['snapshot']);
        $site = $latest['scope'] === 'site';
        $redo = $latest['kind'] === 'undo';
        $pages = sprintf(
            /* translators: %d: number of pages */
            _n('%d page', '%d pages', $plan['pages'], 'pagecraft-builder'),
            $plan['pages']
        );
        $templates = sprintf(
            /* translators: %d: number of templates */
            _n('%d template', '%d templates', $plan['templates'], 'pagecraft-builder'),
            $plan['templates']
        );
        $effects = [[
            'keep', __('Restored', 'pagecraft-builder'),
            $site
                ? sprintf(
                    /* translators: 1: page count, 2: template count */
                    __('%1$s and %2$s return exactly as they were, with their addresses, home page and menus.', 'pagecraft-builder'),
                    $pages,
                    $templates
                )
                : sprintf(
                    /* translators: 1: page title, 2: template count */
                    __('“%1$s” and %2$s return exactly as they were. Other pages and menus do not change.', 'pagecraft-builder'),
                    (string) get_the_title($plan['destination']),
                    $templates
                ),
        ]];
        if ($plan['archived'] > 0) {
            $effects[] = ['change', __('Archived', 'pagecraft-builder'), sprintf(
                /* translators: %d: number of pages and templates */
                _n(
                    '%d page or template added since is archived, not deleted.',
                    '%d pages and templates added since are archived, not deleted.',
                    $plan['archived'],
                    'pagecraft-builder'
                ),
                $plan['archived']
            )];
        }
        // Nothing is destroyed: changed pages are saved in the recovery point taken first.
        $effects[] = $plan['edited'] > 0
            ? ['change', __('Edits since', 'pagecraft-builder'), sprintf(
                /* translators: %d: number of pages and templates */
                _n(
                    '%d page or template was changed since. Those changes leave the live site; reversing this brings them back.',
                    '%d pages and templates were changed since. Those changes leave the live site; reversing this brings them back.',
                    $plan['edited'],
                    'pagecraft-builder'
                ),
                $plan['edited']
            )]
            : ['note', __('Edits since', 'pagecraft-builder'), __('Nothing has been changed since.', 'pagecraft-builder')];
        if ($plan['missing'] > 0) {
            $effects[] = ['change', __('Cannot return', 'pagecraft-builder'), sprintf(
                /* translators: %d: number of pages and templates */
                _n(
                    '%d page or template was permanently deleted since and stays deleted.',
                    '%d pages and templates were permanently deleted since and stay deleted.',
                    $plan['missing'],
                    'pagecraft-builder'
                ),
                $plan['missing']
            )];
        }
        $effects[] = ['note', __('Kept', 'pagecraft-builder'), __('Posts, media, users, plugins, form entries and pages made by hand since.', 'pagecraft-builder')];
        $effects[] = ['note', __('Recovery', 'pagecraft-builder'), __('The site as it is now is saved first, so this can be reversed from this screen.', 'pagecraft-builder')];

        echo '<div class="pagecraft-pick"><h2 class="screen-reader-text">'
            . esc_html($redo ? __('Review redo', 'pagecraft-builder') : __('Review undo', 'pagecraft-builder')) . '</h2>'
            . '<div class="pagecraft-pick__band"><p><strong>'
            . esc_html($redo ? __('Redo', 'pagecraft-builder') : __('Undo', 'pagecraft-builder')) . '</strong> · ' . esc_html($what)
            . ($detail !== '' ? ' · ' . esc_html($detail) : '') . '</p><a href="' . esc_url(admin_url('admin.php?page=pagecraft-connect')) . '">'
            . esc_html__('Cancel', 'pagecraft-builder') . '</a></div>'
            . '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-cloud-transfer__impact"><tbody>'
            . '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="2">' . esc_html__('What happens', 'pagecraft-builder') . '</th></tr>';
        foreach ($effects as [$kind, $label, $effect]) {
            echo '<tr><th scope="row" class="pagecraft-effect pagecraft-effect--' . esc_attr($kind) . '">' . esc_html($label) . '</th><td>' . esc_html($effect) . '</td></tr>';
        }
        echo '</tbody></table></div><form class="pagecraft-cloud-transfer pagecraft-confirm" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-pagecraft-working="'
            . esc_attr__('Restoring… This can take up to a minute. Keep this tab open.', 'pagecraft-builder') . '">';
        wp_nonce_field('pagecraft_cloud_undo_' . $latest['id']);
        foreach (['action' => 'pagecraft_cloud_undo', 'record' => (string) $latest['id'],
            'state' => CloudRecovery::fingerprint($latest['snapshot'])] as $key => $value) {
            echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '">';
        }
        echo '<label class="pagecraft-cloud-import__choice"><input type="checkbox" name="confirm_undo" value="1" required><span>'
            . esc_html($site
                ? __('I understand that this replaces the current site.', 'pagecraft-builder')
                : __('I understand that this replaces the current page.', 'pagecraft-builder'))
            . '</span></label><button class="button button-primary pagecraft-button--danger">'
            . esc_html($redo ? __('Redo replacement', 'pagecraft-builder') : __('Undo replacement', 'pagecraft-builder'))
            . '</button></form></div>';
    }

    /**
     * @param array{id:int,createdAt:string,scope:string,kind:string,label:string,updated:int,archived:int,replaced:array{0:int,1:int},snapshot:array<string,mixed>} $latest
     * @return array{0:string,1:string}
     */
    private static function describe(array $latest): array
    {
        $site = $latest['scope'] === 'site';
        $label = $latest['label'];
        if ($latest['kind'] === 'undo') {
            $what = $site ? __('Whole-site replacement undone', 'pagecraft-builder') : __('Page replacement undone', 'pagecraft-builder');
        } elseif ($site) {
            $what = $label !== ''
                /* translators: %s: Cloud project name */
                ? sprintf(__('Whole site replaced with %s', 'pagecraft-builder'), $label)
                : __('Whole site replaced', 'pagecraft-builder');
        } else {
            $what = $label !== ''
                /* translators: %s: page title */
                ? sprintf(__('“%s” replaced', 'pagecraft-builder'), $label)
                : __('One page replaced', 'pagecraft-builder');
        }
        $details = [];
        $time = strtotime($latest['createdAt']);
        if ($time) $details[] = wp_date(get_option('date_format') . ' ' . get_option('time_format'), $time);
        if ($site && $latest['kind'] !== 'undo' && ($latest['updated'] > 0 || $latest['archived'] > 0)) {
            $details[] = sprintf(
                /* translators: 1: pages published, 2: pages archived */
                __('%1$d published, %2$d archived', 'pagecraft-builder'),
                $latest['updated'],
                $latest['archived']
            );
        }
        return [$what, implode(' · ', $details)];
    }

    /** The Cloud project the homepage came from, or an empty string when it did not come from Cloud. */
    private static function projectOnThisSite(): string
    {
        $front = (int) get_option('page_on_front');
        return $front > 0 ? (string) get_post_meta($front, ManagedPage::SOURCE_PROJECT_ID, true) : '';
    }
}
