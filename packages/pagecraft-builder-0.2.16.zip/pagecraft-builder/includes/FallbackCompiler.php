<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class FallbackCompiler
{
    public static function content(PortablePagePackage $package): string
    {
        return self::contentFromHtml($package->compiledHtml());
    }

    public static function contentFromHtml(string $html): string
    {
        if (preg_match_all('/<main\b/i', $html) !== 1
            || !preg_match('/<main\b[^>]*\bid=(?:"pagecraft-main"|\'pagecraft-main\')[^>]*>([\s\S]*)<\/main\s*>/i', $html, $match)) {
            throw new PackageException('The compiled Pagecraft page has no unambiguous page body.');
        }
        $body = self::cleanInternalLinks($match[1]);
        self::assertSafeMarkup($body);
        $sanitized = wp_kses($body, self::allowedHtml(), self::allowedProtocols());
        if (trim($body) !== '' && trim($sanitized) === '') {
            throw new PackageException('WordPress could not preserve the compiled Pagecraft page safely.');
        }
        return '<div id="pagecraft-main" class="pagecraft-main" data-pagecraft-fallback="1">'
            . $sanitized . '</div>';
    }

    public static function globalContent(PortablePagePackage $package, string $kind): string
    {
        if (!in_array($kind, ['header', 'footer'], true)) {
            throw new PackageException('The Pagecraft global element kind is invalid.');
        }
        $label = strtoupper($kind);
        $start = '<!--PAGECRAFT_SHARED_' . $label . '_START-->';
        $end = '<!--PAGECRAFT_SHARED_' . $label . '_END-->';
        $html = $package->compiledHtml();
        $pattern = '/' . preg_quote($start, '/') . '([\s\S]*?)' . preg_quote($end, '/') . '/';
        if (substr_count($html, $start) !== 1 || substr_count($html, $end) !== 1
            || !preg_match($pattern, $html, $match)) {
            throw new PackageException('The compiled Pagecraft page has no unambiguous global ' . $kind . '.');
        }

        $fragment = preg_replace_callback(
            '/<(\/?)' . preg_quote($kind, '/') . '(\b[^>]*)>/i',
            static fn (array $tag): string => '<' . $tag[1] . 'div' . $tag[2] . '>',
            self::cleanInternalLinks($match[1])
        );
        if (!is_string($fragment)) {
            throw new PackageException('WordPress could not normalize the global ' . $kind . ' landmark.');
        }
        return self::sanitizeFragment($fragment, 'global ' . $kind);
    }

    public static function needsRuntime(string $html): bool
    {
        return preg_match(
            '/\b(?:data-(?:slider|copy|tabs|nav|facade|video-lightbox|lightbox|pagecraft-controls|audio|countdown|filter|compare|hotspot|strips|switcher|exhibit|scrolly|clocks|roster|tiers|qapills|chapters|slotpicker)|bp-(?:duration|delay|easing))\b|class\s*=\s*["\'][^"\']*\b(?:pagecraft-accordion|bp-animate|pc-(?:fade|slide|scale|zoom|rotate|bounce|flip|spin|elastic))/i',
            $html
        ) === 1;
    }

    public static function css(PortablePagePackage $package): string
    {
        return implode("\n", array_filter([
            self::globalCss($package),
            self::pageCss($package),
        ], static fn (string $part): bool => $part !== ''));
    }

    public static function globalCss(PortablePagePackage $package): string
    {
        return self::safeCss($package->globalCss());
    }

    public static function pageCss(PortablePagePackage $package): string
    {
        return self::safeCss($package->pageCss());
    }

    public static function safeCssSource(string $css): string
    {
        return self::safeCss($css);
    }

    /** @param array<string,string> $routes Source Pagecraft slug to actual WordPress permalink. */
    public static function remapProjectHtmlLinks(string $html, array $routes): string
    {
        $mapped = preg_replace_callback(
            '/(\shref\s*=\s*)(["\'])([^"\']*)\2/i',
            static function (array $match) use ($routes): string {
                $original = (string) $match[3];
                $target = self::projectLink($original, $routes);
                if ($target === $original) return $match[0];
                return $match[1] . $match[2]
                    . htmlspecialchars($target, ENT_QUOTES | ENT_HTML5, 'UTF-8')
                    . $match[2];
            },
            $html
        );
        if (!is_string($mapped)) {
            throw new PackageException('WordPress could not map Pagecraft links to their imported pages.');
        }
        return $mapped;
    }

    /**
     * Keep link controls in the editable document aligned with the imported native routes.
     * Text fields that merely mention a filename remain untouched.
     *
     * @param array<string,mixed> $document
     * @param array<string,string> $routes
     * @return array<string,mixed>
     */
    public static function remapProjectDocumentLinks(array $document, array $routes): array
    {
        $linkKeys = [];
        foreach (($document['meta']['components'] ?? []) as $component) {
            if (!is_array($component)) continue;
            foreach (($component['props'] ?? []) as $prop) {
                if (is_array($prop) && ($prop['t'] ?? '') === 'link') {
                    $linkKeys[(string) ($component['id'] ?? '')][] = (string) ($prop['k'] ?? '');
                }
            }
        }
        $walk = static function (array &$node) use (&$walk, $routes, $linkKeys): void {
            foreach (['link', 'href'] as $key) {
                if (isset($node[$key]) && is_string($node[$key])) {
                    $node[$key] = self::projectLink($node[$key], $routes);
                }
            }
            if (($node['t'] ?? '') === 'link' && isset($node['def']) && is_string($node['def'])) {
                $node['def'] = self::projectLink($node['def'], $routes);
            }
            foreach (($linkKeys[(string) ($node['use'] ?? '')] ?? []) as $key) {
                if ($key !== '' && isset($node['vals'][$key]) && is_string($node['vals'][$key])) {
                    $node['vals'][$key] = self::projectLink($node['vals'][$key], $routes);
                }
            }
            foreach ($node as &$child) {
                if (is_array($child)) $walk($child);
            }
        };
        $walk($document);
        return $document;
    }

    private static function safeCss(string $css): string
    {
        if (preg_match('/<\/style(?:[\t\n\f\r \/>]|$)/i', $css)) {
            throw new PackageException('The compiled Pagecraft stylesheet contains an unsupported executable or parser directive.');
        }
        $policyCss = self::cssForPolicy($css);
        if (preg_match(
            '/@(?:import|charset|namespace)\b|expression\s*\(|(?:^|[;{])\s*(?:behavior|-moz-binding)\s*:|url\s*\(\s*["\']?\s*(?:javascript|data\s*:\s*text\/html)/i',
            $policyCss
        )) {
            throw new PackageException('The compiled Pagecraft stylesheet contains an unsupported executable or parser directive.');
        }
        return $css;
    }

    /** Normalize CSS comments and escapes before policy checks, preserving quoted comment text. */
    private static function cssForPolicy(string $css): string
    {
        $normalized = '';
        $length = strlen($css);
        $quote = '';
        for ($at = 0; $at < $length; $at++) {
            $character = $css[$at];
            if ($character === '\\') {
                $escaped = substr($css, $at + 1, 6);
                if (preg_match('/^[0-9a-fA-F]{1,6}/', $escaped, $match)) {
                    $codepoint = hexdec($match[0]);
                    $normalized .= $codepoint > 0 && $codepoint < 128 ? chr($codepoint) : 'x';
                    $at += strlen($match[0]);
                    if (isset($css[$at + 1]) && preg_match('/[ \t\n\r\f]/', $css[$at + 1])) $at++;
                } elseif (($css[$at + 1] ?? '') === "\r" && ($css[$at + 2] ?? '') === "\n") {
                    $at += 2;
                } elseif (isset($css[$at + 1]) && in_array($css[$at + 1], ["\n", "\r", "\f"], true)) {
                    $at++;
                } elseif (isset($css[$at + 1])) {
                    $normalized .= $css[++$at];
                }
                continue;
            }
            if ($quote !== '') {
                $normalized .= $character;
                if ($character === $quote) {
                    $quote = '';
                }
                continue;
            }
            if ($character === '"' || $character === "'") {
                $quote = $character;
                $normalized .= $character;
                continue;
            }
            if ($character === '/' && ($css[$at + 1] ?? '') === '*') {
                $end = strpos($css, '*/', $at + 2);
                $at = $end === false ? $length : $end + 1;
                continue;
            }
            $normalized .= $character;
        }
        return $normalized;
    }

    /** @param array<string,string> $routes */
    private static function projectLink(string $value, array $routes): string
    {
        if ($value === '' || str_starts_with($value, '#')) return $value;
        [$base, $query, $fragment] = self::linkParts(
            html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8')
        );
        $path = $base;
        if (preg_match('#^[a-z][a-z0-9+.-]*://#i', $base)) {
            if (!function_exists('home_url')) return $value;
            $home = wp_parse_url(home_url('/'));
            $candidate = wp_parse_url($base);
            if (!is_array($home) || !is_array($candidate)
                || strtolower((string) ($home['host'] ?? '')) !== strtolower((string) ($candidate['host'] ?? ''))
                || strtolower((string) ($home['scheme'] ?? '')) !== strtolower((string) ($candidate['scheme'] ?? ''))
                || (int) ($home['port'] ?? 0) !== (int) ($candidate['port'] ?? 0)) {
                return $value;
            }
            $path = (string) ($candidate['path'] ?? '');
            $homePath = trim((string) ($home['path'] ?? ''), '/');
            if ($homePath !== '') {
                $path = preg_replace('~^/' . preg_quote($homePath, '~') . '(?:/|$)~', '/', $path) ?? $path;
            }
        } elseif (preg_match('#^[a-z][a-z0-9+.-]*:#i', $base) || str_starts_with($base, '//')) {
            return $value;
        }
        foreach ($routes as $route) {
            [$routeBase, $routeQuery] = self::linkParts(
                html_entity_decode($route, ENT_QUOTES | ENT_HTML5, 'UTF-8')
            );
            if ($routeQuery !== '' && self::localPath($routeBase) === self::localPath($path)
                && self::queryContains($query, $routeQuery)) {
                return self::mergeLinkQuery($route, $query, $fragment);
            }
        }
        if (self::localPath($path) === '/' && self::hasRoutingQuery($query, $routes)) {
            return $value;
        }
        $path = preg_replace('~^(?:\.\./|\./)+~', '', $path) ?? $path;
        $path = trim($path, '/');
        $path = preg_replace('/\.html$/i', '', $path) ?? $path;
        if ($path === '') $path = 'index';
        if (str_ends_with(strtolower($path), '/index')) {
            $path = substr($path, 0, -strlen('/index')) ?: 'index';
        }
        return isset($routes[$path])
            ? self::mergeLinkQuery($routes[$path], $query, $fragment)
            : $value;
    }

    /** @return array{0:string,1:string,2:string} Base, query without ?, fragment including #. */
    private static function linkParts(string $value): array
    {
        $fragment = '';
        $hash = strpos($value, '#');
        if ($hash !== false) {
            $fragment = substr($value, $hash);
            $value = substr($value, 0, $hash);
        }
        $query = '';
        $question = strpos($value, '?');
        if ($question !== false) {
            $query = substr($value, $question + 1);
            $value = substr($value, 0, $question);
        }
        return [$value, $query, $fragment];
    }

    private static function localPath(string $base): ?string
    {
        if (preg_match('#^[a-z][a-z0-9+.-]*://#i', $base)) {
            $parts = wp_parse_url($base);
            if (!is_array($parts)) return null;
            $base = (string) ($parts['path'] ?? '');
            if (function_exists('home_url')) {
                $home = wp_parse_url(home_url('/'));
                $homePath = is_array($home) ? trim((string) ($home['path'] ?? ''), '/') : '';
                if ($homePath !== '') {
                    $base = preg_replace('~^/' . preg_quote($homePath, '~') . '(?:/|$)~', '/', $base) ?? $base;
                }
            }
        } elseif (preg_match('#^[a-z][a-z0-9+.-]*:#i', $base) || str_starts_with($base, '//')) {
            return null;
        }
        return '/' . trim($base, '/');
    }

    private static function queryContains(string $query, string $required): bool
    {
        $available = self::queryPairs($query);
        foreach (self::queryPairs($required) as $key => $values) {
            foreach ($values as $value) {
                if (!isset($available[$key]) || !in_array($value, $available[$key], true)) return false;
            }
        }
        return true;
    }

    /** @param array<string,string> $routes */
    private static function hasRoutingQuery(string $query, array $routes): bool
    {
        $routingKeys = ['page_id' => true, 'p' => true];
        foreach ($routes as $route) {
            [, $routeQuery] = self::linkParts(
                html_entity_decode($route, ENT_QUOTES | ENT_HTML5, 'UTF-8')
            );
            foreach (array_keys(self::queryPairs($routeQuery)) as $key) {
                $routingKeys[$key] = true;
            }
        }
        foreach (array_keys(self::queryPairs($query)) as $key) {
            if (isset($routingKeys[$key])) return true;
        }
        return false;
    }

    /** @return array<string,list<string>> */
    private static function queryPairs(string $query): array
    {
        $pairs = [];
        foreach ($query === '' ? [] : explode('&', $query) as $part) {
            [$key, $value] = array_pad(explode('=', $part, 2), 2, '');
            $key = urldecode($key);
            $pairs[$key][] = urldecode($value);
        }
        return $pairs;
    }

    private static function mergeLinkQuery(string $route, string $query, string $fragment): string
    {
        [$base, $routeQuery, $routeFragment] = self::linkParts(
            html_entity_decode($route, ENT_QUOTES | ENT_HTML5, 'UTF-8')
        );
        $routeKeys = array_fill_keys(array_keys(self::queryPairs($routeQuery)), true);
        $extra = [];
        foreach ($query === '' ? [] : explode('&', $query) as $part) {
            $key = urldecode((string) (explode('=', $part, 2)[0] ?? ''));
            if (!isset($routeKeys[$key])) $extra[] = $part;
        }
        $merged = implode('&', array_filter([
            $routeQuery,
            implode('&', $extra),
        ], static fn (string $part): bool => $part !== ''));
        return $base . ($merged !== '' ? '?' . $merged : '')
            . ($fragment !== '' ? $fragment : $routeFragment);
    }

    private static function sanitizeFragment(string $html, string $label): string
    {
        self::assertSafeMarkup($html);
        $sanitized = wp_kses($html, self::allowedHtml(), self::allowedProtocols());
        if (trim($html) !== '' && trim($sanitized) === '') {
            throw new PackageException('WordPress could not preserve the compiled Pagecraft ' . $label . ' safely.');
        }
        return $sanitized;
    }

    private static function cleanInternalLinks(string $html): string
    {
        $cleaned = preg_replace_callback(
            '/(\shref\s*=\s*)(["\'])([^"\']*)\2/i',
            static function (array $match): string {
                $value = html_entity_decode($match[3], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                if ($value === '' || str_starts_with($value, '#')
                    || preg_match('#^(?:[a-z][a-z0-9+.-]*:|//)#i', $value)) {
                    return $match[0];
                }
                if (!preg_match('~^(?:\.\./|\./|/)*([A-Za-z0-9][A-Za-z0-9/_-]*?)\.html([?#].*)?$~i', $value, $path)) {
                    return $match[0];
                }
                $route = trim($path[1], '/');
                if ($route === 'index') {
                    $route = '';
                } elseif (str_ends_with(strtolower($route), '/index')) {
                    $route = substr($route, 0, -strlen('/index'));
                }
                $clean = '/' . ($route !== '' ? $route . '/' : '');
                if (function_exists('home_url')) {
                    $destination = $route !== '' ? get_page_by_path($route, OBJECT, 'page') : null;
                    $clean = is_object($destination) ? (string) get_permalink($destination->ID) : home_url($clean);
                }
                $clean .= $path[2] ?? '';
                return $match[1] . $match[2] . htmlspecialchars($clean, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $match[2];
            },
            $html
        );
        if (!is_string($cleaned)) {
            throw new PackageException('WordPress could not normalize Pagecraft internal links.');
        }
        return $cleaned;
    }

    private static function assertSafeMarkup(string $html): void
    {
        // Attribute names may contain hyphens: bp-animation-once is native data,
        // whereas a standalone on* attribute is executable browser markup.
        if (preg_match('/<(?:script|style|object|embed|base|meta|link)\b|(?<![a-z0-9:_-])on[a-z0-9_-]+\s*=|(?<![a-z0-9:_-])srcdoc\s*=|(?:javascript|data\s*:\s*text\/html)\s*:/i', $html)) {
            throw new PackageException('The compiled Pagecraft page contains unsupported executable markup.');
        }
        // WordPress 6.6+ always provides this parser. Standalone persistence tests that do not
        // bootstrap WordPress still retain the broad executable-markup guard above.
        if (!class_exists(\WP_HTML_Tag_Processor::class)) return;
        $tags = new \WP_HTML_Tag_Processor($html);
        while ($tags->next_tag()) {
            $style = $tags->get_attribute('style');
            if (is_string($style)) {
                $policyStyle = self::cssForPolicy($style);
                if (preg_match('/expression\s*\(|url\s*\(|(?:^|;)\s*(?:behavior|-moz-binding)\s*:|@import/i', $policyStyle)) {
                    throw new PackageException('The compiled Pagecraft page contains an unsafe inline style.');
                }
            }
            $tag = $tags->get_tag();
            if ($tag === 'IFRAME') {
                $source = $tags->get_attribute('src');
                if ($source !== null && !self::absoluteHttpsUrl($source)) {
                    throw new PackageException('Pagecraft iframe embeds must use an absolute HTTPS URL.');
                }
            } elseif ($tag === 'FORM') {
                $action = $tags->get_attribute('action');
                if ($action !== null && !self::absoluteHttpsUrl($action)) {
                    throw new PackageException('Pagecraft form actions must use an absolute HTTPS URL.');
                }
            }
            if ($tags->has_class('pagecraft-video-play')) {
                $embed = $tags->get_attribute('data-embed');
                if ($embed !== null && !self::absoluteHttpsUrl($embed)) {
                    throw new PackageException('Pagecraft runtime video embeds must use a credential-free absolute HTTPS URL.');
                }
            }
        }
    }

    private static function absoluteHttpsUrl(mixed $value): bool
    {
        if (!is_string($value) || $value === '') return false;
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/[\x00-\x20\x7f\\\\]/', $value)) return false;
        $url = wp_parse_url($value);
        $host = is_array($url) ? (string) ($url['host'] ?? '') : '';
        $hostIsValid = filter_var($host, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) !== false
            || filter_var(trim($host, '[]'), FILTER_VALIDATE_IP) !== false;
        return is_array($url) && strtolower((string) ($url['scheme'] ?? '')) === 'https'
            && $hostIsValid && !isset($url['user']) && !isset($url['pass']);
    }

    /** @return array<string, array<string, bool>> */
    private static function allowedHtml(): array
    {
        $global = [
            'id' => true, 'class' => true, 'title' => true, 'role' => true, 'tabindex' => true,
            'data-*' => true, 'hidden' => true, 'dir' => true, 'lang' => true,
            'style' => true,
            'bp-duration' => true, 'bp-delay' => true, 'bp-easing' => true,
            'bp-animation-once' => true
        ];
        // KSES supports data-* but requires explicit ARIA attribute names.
        foreach ([
            'label', 'labelledby', 'describedby', 'controls', 'expanded', 'hidden',
            'selected', 'live', 'atomic', 'busy', 'pressed', 'current', 'disabled',
            'orientation', 'haspopup', 'required', 'invalid', 'errormessage',
            'checked', 'level', 'valuemin', 'valuemax', 'valuenow', 'valuetext',
            'modal', 'owns', 'activedescendant', 'roledescription'
        ] as $attribute) {
            $global['aria-' . $attribute] = true;
        }
        $tags = [
            'div', 'section', 'article', 'header', 'footer', 'aside', 'nav', 'span',
            'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'strong', 'em', 'b', 'i', 'u', 's', 'small',
            'ul', 'ol', 'li', 'dl', 'dt', 'dd', 'blockquote', 'cite', 'pre', 'code', 'br', 'hr',
            'figure', 'figcaption', 'picture', 'table', 'caption', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td',
            'details', 'summary', 'address'
        ];
        $allowed = [];
        foreach ($tags as $tag) {
            $allowed[$tag] = $global;
        }
        $allowed['details'] = $global + ['open' => true, 'name' => true];
        $allowed['a'] = $global + ['href' => true, 'target' => true, 'rel' => true, 'download' => true];
        $allowed['img'] = $global + [
            'src' => true, 'srcset' => true, 'sizes' => true, 'alt' => true, 'width' => true,
            'height' => true, 'loading' => true, 'decoding' => true
        ];
        $allowed['source'] = $global + ['src' => true, 'srcset' => true, 'sizes' => true, 'type' => true, 'media' => true];
        $allowed['video'] = $global + [
            'src' => true, 'poster' => true, 'width' => true, 'height' => true, 'controls' => true,
            'autoplay' => true, 'loop' => true, 'muted' => true, 'playsinline' => true, 'preload' => true
        ];
        $allowed['iframe'] = $global + [
            'src' => true, 'width' => true, 'height' => true, 'allow' => true, 'allowfullscreen' => true,
            'loading' => true, 'referrerpolicy' => true
        ];
        $allowed['audio'] = $global + [
            'src' => true, 'controls' => true, 'loop' => true, 'muted' => true, 'preload' => true
        ];
        $allowed['progress'] = $global + ['value' => true, 'max' => true];
        $allowed['time'] = $global + ['datetime' => true];
        // Image hotspots use native popovers, which work without scripts.
        $allowed['div'] = $global + ['popover' => true];
        $allowed['button'] = $global + [
            'type' => true, 'name' => true, 'value' => true, 'disabled' => true,
            'popovertarget' => true, 'popovertargetaction' => true
        ];
        $allowed['form'] = $global + ['action' => true, 'method' => true, 'autocomplete' => true, 'novalidate' => true];
        $allowed['label'] = $global + ['for' => true];
        $allowed['input'] = $global + [
            'type' => true, 'name' => true, 'value' => true, 'placeholder' => true, 'required' => true,
            'checked' => true, 'disabled' => true, 'autocomplete' => true, 'accept' => true,
            'min' => true, 'max' => true, 'step' => true
        ];
        $allowed['textarea'] = $global + [
            'name' => true, 'placeholder' => true, 'required' => true, 'disabled' => true,
            'rows' => true, 'cols' => true, 'autocomplete' => true
        ];
        $allowed['select'] = $global + ['name' => true, 'required' => true, 'disabled' => true, 'multiple' => true];
        $allowed['option'] = $global + ['value' => true, 'selected' => true, 'disabled' => true];
        $allowed['svg'] = $global + [
            'xmlns' => true, 'viewbox' => true, 'width' => true, 'height' => true,
            'fill' => true, 'stroke' => true, 'focusable' => true,
            'stroke-width' => true, 'stroke-linecap' => true, 'stroke-linejoin' => true
        ];
        $svg = $global + [
            'd' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true,
            'stroke-linecap' => true, 'stroke-linejoin' => true, 'viewbox' => true,
            'x' => true, 'y' => true, 'x1' => true, 'x2' => true, 'y1' => true, 'y2' => true,
            'cx' => true, 'cy' => true, 'r' => true, 'rx' => true, 'ry' => true,
            'points' => true, 'width' => true, 'height' => true
        ];
        foreach (['g', 'path', 'circle', 'rect', 'line', 'polyline', 'polygon'] as $tag) {
            $allowed[$tag] = $svg;
        }
        return $allowed;
    }

    /** @return list<string> */
    private static function allowedProtocols(): array
    {
        return ['http', 'https', 'mailto', 'tel'];
    }
}
