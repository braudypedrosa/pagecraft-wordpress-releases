<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Undoes the most recent Cloud replacement from the snapshot that replacement saved.
 *
 * Only the newest record can be undone. Undoing saves a snapshot of its own first, so the
 * undo is itself the newest record and can be undone in turn.
 */
final class CloudRecovery
{
    /** Changes within this window of the snapshot are the replacement itself, not later edits. */
    private const SETTLE_SECONDS = 120;

    /**
     * @return array{id:int,createdAt:string,scope:string,kind:string,label:string,updated:int,archived:int,replaced:array{0:int,1:int},snapshot:array<string,mixed>}|null
     */
    public static function latest(): ?array
    {
        $records = get_posts([
            'post_type' => WholeProjectImporter::JOB_POST_TYPE, 'post_status' => 'private',
            'posts_per_page' => 1, 'orderby' => 'ID', 'order' => 'DESC',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One row, on an admin screen only.
            'meta_key' => CloudReplacement::BACKUP, 'meta_compare' => 'EXISTS',
        ]);
        $record = $records[0] ?? null;
        if (!$record instanceof \WP_Post) return null;
        $snapshot = json_decode((string) get_post_meta($record->ID, CloudReplacement::BACKUP, true), true);
        if (!is_array($snapshot) || !is_array($snapshot['posts'] ?? null) || $snapshot['posts'] === []
            || !in_array($snapshot['scope'] ?? null, ['site', 'page'], true)) {
            return null;
        }
        $summary = json_decode((string) $record->post_content, true);
        $summary = is_array($summary) ? $summary : [];
        return [
            'id' => (int) $record->ID,
            'createdAt' => (string) ($snapshot['createdAt'] ?? ''),
            'scope' => (string) $snapshot['scope'],
            'kind' => ($summary['kind'] ?? '') === 'undo' ? 'undo' : 'replace',
            'label' => (string) ($summary['label'] ?? ''),
            'updated' => (int) ($summary['updated'] ?? 0),
            'archived' => (int) ($summary['archived'] ?? 0),
            'replaced' => [
                (int) ($summary['replaced'][0] ?? $summary['updated'] ?? 0),
                (int) ($summary['replaced'][1] ?? $summary['archived'] ?? 0),
            ],
            'snapshot' => $snapshot,
        ];
    }

    /**
     * What undoing would do, counted from the site as it is now. Read-only.
     *
     * @param array<string,mixed> $snapshot
     * @return array{pages:int,templates:int,missing:int,archived:int,edited:int,destination:int}
     */
    public static function plan(array $snapshot): array
    {
        $scope = (string) $snapshot['scope'];
        $destination = self::destination($snapshot);
        $saved = self::savedPosts($snapshot);
        $plan = ['pages' => 0, 'templates' => 0, 'missing' => 0, 'archived' => 0, 'edited' => 0, 'destination' => $destination];
        $since = strtotime((string) ($snapshot['createdAt'] ?? '')) ?: 0;
        $changedSince = static fn (\WP_Post $post): bool => $since > 0
            && (int) strtotime($post->post_modified_gmt . ' UTC') > $since + self::SETTLE_SECONDS;
        foreach ($saved as $postId => $record) {
            $current = get_post($postId);
            if (!$current instanceof \WP_Post) {
                $plan['missing']++;
                continue;
            }
            $plan[$current->post_type === GlobalElement::POST_TYPE ? 'templates' : 'pages']++;
            if ($changedSince($current)) $plan['edited']++;
        }
        foreach (self::added($scope, $destination, $saved) as $post) {
            $plan['archived']++;
            if ($changedSince($post)) $plan['edited']++;
        }
        return $plan;
    }

    /** @param array<string,mixed> $snapshot */
    public static function fingerprint(array $snapshot): string
    {
        return CloudReplacement::fingerprint((string) $snapshot['scope'], self::destination($snapshot));
    }

    /** @return array{restored:int,archived:int,missing:int,backupId:int} */
    public function undo(int $recordId, bool $confirmed, string $expectedState): array
    {
        $latest = self::latest();
        if (!$confirmed || $latest === null) {
            throw new PackageException('Review and confirm the undo before continuing.');
        }
        if ($latest['id'] !== $recordId) {
            throw new PackageException('Only the most recent replacement can be undone. Review it again; nothing was restored.');
        }
        $snapshot = $latest['snapshot'];
        $scope = $latest['scope'];
        foreach ([Capabilities::MANAGE, Capabilities::IMPORT, 'edit_theme_options'] as $capability) {
            if (!current_user_can($capability)) throw new PackageException('You are not allowed to restore Pagecraft content.');
        }
        if ($scope === 'site' && !current_user_can('publish_pages')) {
            throw new PackageException('Restoring a site requires permission to publish pages.');
        }
        $destination = self::destination($snapshot);
        $replacement = new CloudReplacement();

        return EditorWriteLock::run(0, function () use ($replacement, $snapshot, $scope, $destination, $expectedState, $latest): array {
            if ($expectedState === '' || !hash_equals(self::fingerprint($snapshot), $expectedState)) {
                throw new PackageException('WordPress changed since the review. Review the undo again; nothing was restored.');
            }
            $saved = self::savedPosts($snapshot);
            $records = [];
            foreach (CloudReplacement::replacementRecords($scope, self::pages($scope, $destination)) as $post) {
                $records[$post->ID] = $post;
            }
            foreach (array_keys($saved) as $postId) {
                $post = get_post($postId);
                if ($post instanceof \WP_Post) $records[$post->ID] = $post;
            }
            ksort($records);
            foreach ($records as $post) {
                if (!current_user_can('edit_post', $post->ID)) {
                    throw new PackageException('You must be allowed to edit every page and template this restores.');
                }
            }
            return EditorWriteLock::runMany(array_keys($records), fn (): array => $replacement->transaction(
                function () use ($replacement, $snapshot, $scope, $destination, $saved, $records, $expectedState, $latest): array {
                    if (!hash_equals(self::fingerprint($snapshot), $expectedState)) {
                        throw new PackageException('WordPress changed while the undo was being prepared. Review it again.');
                    }
                    // Saved before anything changes, so this undo can itself be undone.
                    $backup = $replacement->backup($scope, array_values($records));

                    $archived = 0;
                    foreach (self::added($scope, $destination, $saved) as $post) {
                        $update = ['ID' => $post->ID, 'post_status' => CloudReplacement::ARCHIVE_STATUS];
                        if ($post->post_type === 'page') {
                            // Frees the address for the page that is coming back.
                            $update['post_name'] = 'pc-archive-' . $post->ID . '-' . $post->post_name;
                        }
                        self::update($update);
                        $archived++;
                    }

                    $restored = 0;
                    $missing = 0;
                    // Records that return to the archive go first: that releases the addresses the rest need.
                    foreach ([true, false] as $archivedPass) {
                        foreach ($saved as $postId => $record) {
                            $isArchived = ($record['post']['post_status'] ?? '') === CloudReplacement::ARCHIVE_STATUS;
                            if ($isArchived !== $archivedPass) continue;
                            if (!get_post($postId) instanceof \WP_Post) {
                                $missing++;
                                continue;
                            }
                            self::restorePost($postId, $record);
                            $restored++;
                        }
                    }

                    foreach (is_array($snapshot['options'] ?? null) ? $snapshot['options'] : [] as $option => $value) {
                        if ($value === null) {
                            delete_option((string) $option);
                        } else {
                            update_option((string) $option, $value);
                        }
                    }
                    if ($scope === 'site' && is_array($snapshot['menus'] ?? null)) {
                        (new NativeMenu())->restoreSnapshot($snapshot['menus']);
                    }

                    // Undoing an undo puts the replacement back, so the record reads as a replacement again.
                    $redo = $latest['kind'] === 'undo';
                    $summary = ['scope' => $scope, 'kind' => $redo ? 'replace' : 'undo', 'label' => $latest['label'],
                        'updated' => $redo ? $latest['replaced'][0] : $restored,
                        'archived' => $redo ? $latest['replaced'][1] : $archived,
                        'replaced' => $latest['replaced']];
                    $backupId = wp_insert_post([
                        'post_type' => WholeProjectImporter::JOB_POST_TYPE, 'post_status' => 'private',
                        'post_title' => 'Replacement recovery ' . gmdate('Y-m-d H:i:s') . ' UTC',
                        'post_content' => wp_slash((string) wp_json_encode($summary)),
                        'meta_input' => [CloudReplacement::BACKUP => wp_slash((string) wp_json_encode($backup))],
                    ], true);
                    if (is_wp_error($backupId) || !$backupId) {
                        throw new PackageException('WordPress could not retain the recovery snapshot. Nothing was restored.');
                    }
                    return ['restored' => $restored, 'archived' => $archived, 'missing' => $missing, 'backupId' => (int) $backupId];
                }
            ));
        });
    }

    /**
     * @param array<string,mixed> $snapshot
     * @return array<int,array{post:array<string,mixed>,meta:array<string,mixed>}>
     */
    private static function savedPosts(array $snapshot): array
    {
        $saved = [];
        foreach (is_array($snapshot['posts'] ?? null) ? $snapshot['posts'] : [] as $postId => $record) {
            if ((int) $postId > 0 && is_array($record) && is_array($record['post'] ?? null)) {
                $saved[(int) $postId] = ['post' => $record['post'], 'meta' => is_array($record['meta'] ?? null) ? $record['meta'] : []];
            }
        }
        return $saved;
    }

    /** The one page a page-scope snapshot covers; zero for a whole-site snapshot. @param array<string,mixed> $snapshot */
    private static function destination(array $snapshot): int
    {
        if (($snapshot['scope'] ?? '') !== 'page') return 0;
        foreach (self::savedPosts($snapshot) as $postId => $record) {
            if (($record['post']['post_type'] ?? '') === 'page') return $postId;
        }
        return 0;
    }

    /** @return list<\WP_Post> */
    private static function pages(string $scope, int $destination): array
    {
        if ($scope === 'site') return CloudReplacement::destinations();
        $post = get_post($destination);
        return $post instanceof \WP_Post ? [$post] : [];
    }

    /**
     * Imported pages and templates that exist now but were not there when the snapshot was taken.
     * Pages someone made by hand since are left alone.
     *
     * @param array<int,mixed> $saved
     * @return list<\WP_Post>
     */
    private static function added(string $scope, int $destination, array $saved): array
    {
        $added = [];
        foreach (CloudReplacement::replacementRecords($scope, self::pages($scope, $destination)) as $post) {
            if (isset($saved[$post->ID]) || $post->post_status === CloudReplacement::ARCHIVE_STATUS) continue;
            if ($post->post_type === 'page'
                && (string) get_post_meta($post->ID, ManagedPage::SOURCE_PROJECT_ID, true) === '') {
                continue;
            }
            $added[] = $post;
        }
        return $added;
    }

    /** @param array{post:array<string,mixed>,meta:array<string,mixed>} $record */
    private static function restorePost(int $postId, array $record): void
    {
        $fields = ['ID' => $postId];
        foreach (['post_title', 'post_content', 'post_excerpt', 'post_status', 'post_name', 'post_parent', 'menu_order'] as $field) {
            if (array_key_exists($field, $record['post'])) $fields[$field] = $record['post'][$field];
        }
        self::update($fields);
        $name = (string) ($record['post']['post_name'] ?? '');
        if ($name !== '' && (string) get_post_field('post_name', $postId) !== $name) {
            throw new PackageException('WordPress could not give a restored page its address back. Nothing was restored.');
        }
        foreach (array_keys((array) get_post_meta($postId)) as $key) {
            delete_post_meta($postId, (string) $key);
        }
        foreach ($record['meta'] as $key => $values) {
            foreach (is_array($values) ? $values : [] as $value) {
                add_post_meta($postId, (string) $key, wp_slash(maybe_unserialize($value)));
            }
        }
    }

    /** @param array<string,mixed> $post */
    private static function update(array $post): void
    {
        $result = wp_update_post(wp_slash($post), true);
        if (is_wp_error($result) || !$result) {
            throw new PackageException('WordPress could not complete the undo. Nothing was restored.');
        }
    }
}
