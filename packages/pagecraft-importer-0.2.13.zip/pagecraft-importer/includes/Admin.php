<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use Throwable;

final class Admin
{
    public function __construct(
        private readonly Distribution $distribution,
        private readonly Preflight $preflight,
        private readonly Installer $installer
    ) {
    }

    public function hooks(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_post_pagecraft_importer_apply', [$this, 'apply']);
        add_action('admin_post_pagecraft_importer_rollback_theme', [$this, 'rollback']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
    }

    public function menu(): void
    {
        add_management_page(
            __('Pagecraft Importer', 'pagecraft-importer'),
            __('Pagecraft Importer', 'pagecraft-importer'),
            Capabilities::MANAGE,
            'pagecraft-importer',
            [$this, 'render']
        );
    }

    public function assets(string $hook): void
    {
        if ($hook === 'tools_page_pagecraft-importer') {
            wp_enqueue_style('pagecraft-importer', PAGECRAFT_IMPORTER_URL . 'assets/admin.css', [], PAGECRAFT_IMPORTER_VERSION);
        }
    }

    public function render(): void
    {
        if (!Capabilities::allowed()) wp_die(esc_html__('You cannot manage Pagecraft packages.', 'pagecraft-importer'));
        $checks = $this->preflight->report();
        $error = '';
        try {
            $manifest = $this->distribution->stable();
        } catch (Throwable $caught) {
            $manifest = [];
            $error = $caught->getMessage();
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Cosmetic message from a safe admin redirect.
        $message = sanitize_text_field(wp_unslash((string) ($_GET['pagecraft_message'] ?? '')));
        $products = $this->products($manifest);
        $changes = array_values(array_filter($products, static fn (array $row): bool => $row['action'] !== ''));
        $ticked = count(array_filter($changes, static fn (array $row): bool => $row['ticked']));
        $ready = $this->preflight->passes($checks);
        $status = $manifest === [] ? __('Release unavailable', 'pagecraft-importer')
            : ($changes === [] ? __('Up to date', 'pagecraft-importer') : sprintf(
                /* translators: %d: number of changes that can be made */
                _n('%d change available', '%d changes available', count($changes), 'pagecraft-importer'),
                count($changes)
            ));
        ?>
        <div class="wrap pc-importer">
            <hr class="wp-header-end">
            <div class="pc-importer__sheet">
                <header class="pc-importer__bar">
                    <span class="pc-importer__brand"><svg viewBox="0 0 95 95" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" d="M11 0h73v71H63l-6-6-6 6H29v6h22v18H11Zm18 18v59h22V53h15V18Z"/></svg><?php esc_html_e('Pagecraft', 'pagecraft-importer'); ?></span>
                    <span class="pc-importer__version"><?php echo esc_html(sprintf(
                        /* translators: %s: Importer version number */
                        __('Importer %s', 'pagecraft-importer'),
                        PAGECRAFT_IMPORTER_VERSION
                    )); ?></span>
                </header>
                <div class="pc-importer__mast">
                    <div>
                        <h1><?php esc_html_e('Pagecraft Importer', 'pagecraft-importer'); ?></h1>
                        <p><?php esc_html_e('Installs and updates Pagecraft Builder and Theme from signed releases.', 'pagecraft-importer'); ?></p>
                    </div>
                    <span class="pc-importer__status"><?php echo esc_html($status); ?></span>
                </div>
                <?php if ($message !== '') : ?>
                    <p class="pc-importer__notice is-ok" role="status"><span class="pc-importer__dot" aria-hidden="true"></span><?php echo esc_html($message); ?></p>
                <?php endif; ?>
                <?php $this->checks($checks); ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="pagecraft_importer_apply">
                    <?php wp_nonce_field('pagecraft_importer_apply'); ?>
                    <h2 class="pc-importer__band"><?php esc_html_e('Pagecraft on this site', 'pagecraft-importer'); ?>
                        <span><?php echo esc_html($manifest === [] ? __('No signed release', 'pagecraft-importer') : sprintf(
                            /* translators: %s: release version number */
                            __('Signed release %s', 'pagecraft-importer'),
                            (string) ($manifest['products']['builder']['version'] ?? '')
                        )); ?></span></h2>
                    <?php if ($error !== '') : ?>
                        <p class="pc-importer__notice is-error" role="alert"><span class="pc-importer__dot" aria-hidden="true"></span><?php echo esc_html($error); ?></p>
                    <?php endif; ?>
                    <ul class="pc-importer__rows">
                        <?php foreach ($products as $row) : ?>
                            <li>
                                <?php if ($row['action'] !== '') : ?>
                                    <input type="checkbox" id="pc-importer-<?php echo esc_attr($row['action']); ?>" name="actions[]" value="<?php echo esc_attr($row['action']); ?>"<?php checked($row['ticked']); ?>>
                                    <label for="pc-importer-<?php echo esc_attr($row['action']); ?>"><?php echo esc_html($row['label']); ?><?php if ($row['detail'] !== '') : ?> <span>· <?php echo esc_html($row['detail']); ?></span><?php endif; ?></label>
                                <?php else : ?>
                                    <span class="pc-importer__spacer" aria-hidden="true"></span>
                                    <span><?php echo esc_html($row['label']); ?><?php if ($row['detail'] !== '') : ?> <span>· <?php echo esc_html($row['detail']); ?></span><?php endif; ?></span>
                                <?php endif; ?>
                                <span class="pc-importer__pill<?php echo $row['action'] !== '' ? ' is-change' : ''; ?>"><?php echo esc_html($row['state']); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ($changes !== []) : ?>
                        <div class="pc-importer__foot">
                            <p><?php echo esc_html($this->footNote($changes)); ?></p>
                            <button type="submit" class="button button-primary" data-pc-importer-apply<?php disabled(!$ready); ?>><?php echo esc_html($this->applyLabel($ticked)); ?></button>
                        </div>
                    <?php endif; ?>
                </form>
                <?php if (is_array(get_option('pagecraft_importer_previous_theme', null))) : ?>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pc-importer__foot pc-importer__rollback">
                        <input type="hidden" name="action" value="pagecraft_importer_rollback_theme">
                        <?php wp_nonce_field('pagecraft_importer_rollback_theme'); ?>
                        <p><?php esc_html_e('The theme this site used before Pagecraft Theme is saved.', 'pagecraft-importer'); ?></p>
                        <button type="submit" class="button"><?php esc_html_e('Restore previous theme', 'pagecraft-importer'); ?></button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <script>
        (function () {
            var button = document.querySelector('.pc-importer [data-pc-importer-apply]');
            if (!button) return;
            var labels = <?php echo wp_json_encode(['none' => $this->applyLabel(0), 'one' => $this->applyLabel(1), 'many' => $this->applyLabel(2)]); ?>;
            var boxes = button.form.querySelectorAll('input[name="actions[]"]');
            var update = function () {
                var n = Array.prototype.filter.call(boxes, function (box) { return box.checked; }).length;
                button.textContent = n === 0 ? labels.none : (n === 1 ? labels.one : labels.many.replace('2', String(n)));
            };
            Array.prototype.forEach.call(boxes, function (box) { box.addEventListener('change', update); });
        }());
        </script>
        <?php
    }

    /**
     * Checks that need attention are listed; the ones that pass fold into one line with the full list behind it.
     *
     * @param array<string,array{ok:bool,blocking:bool,message:string}> $checks
     */
    private function checks(array $checks): void
    {
        $names = [
            'wordpress' => __('WordPress', 'pagecraft-importer'), 'php' => __('PHP', 'pagecraft-importer'),
            'https' => __('HTTPS', 'pagecraft-importer'), 'permalinks' => __('permalinks', 'pagecraft-importer'),
            'uploads' => __('uploads', 'pagecraft-importer'), 'single_site' => __('single site', 'pagecraft-importer'),
            'crypto' => __('signature checks', 'pagecraft-importer'), 'filesystem' => __('file access', 'pagecraft-importer'),
            'existing_content' => __('no existing pages', 'pagecraft-importer'), 'theme_impact' => __('Pagecraft Theme active', 'pagecraft-importer'),
        ];
        $failing = [
            'existing_content' => __('This site already has pages. Back up the site before switching theme; existing content is not deleted.', 'pagecraft-importer'),
            'theme_impact' => __('Pagecraft Theme is not the active theme yet.', 'pagecraft-importer'),
        ];
        $passed = array_keys(array_filter($checks, static fn (array $check): bool => $check['ok']));
        echo '<h2 class="pc-importer__band">' . esc_html__('Checks', 'pagecraft-importer') . '<span>' . esc_html(sprintf(
            /* translators: 1: number of checks that pass, 2: number of checks */
            __('%1$d of %2$d pass', 'pagecraft-importer'),
            count($passed),
            count($checks)
        )) . '</span></h2><ul class="pc-importer__rows">';
        foreach ($checks as $key => $check) {
            if ($check['ok']) continue;
            echo '<li class="' . ($check['blocking'] ? 'is-error' : 'is-warning') . '"><span class="pc-importer__dot" aria-hidden="true"></span><span>'
                . esc_html($failing[$key] ?? sprintf(
                    /* translators: %s: requirement, for example "PHP 8.1 or later" */
                    __('Needed: %s', 'pagecraft-importer'),
                    $check['message']
                )) . '</span><span class="screen-reader-text">' . esc_html($check['blocking'] ? __('Blocks installing', 'pagecraft-importer') : __('Warning', 'pagecraft-importer')) . '</span></li>';
        }
        if ($passed !== []) {
            $shown = array_map(static fn (string $key): string => $names[$key] ?? $key, array_slice($passed, 0, 5));
            $rest = count($passed) - count($shown);
            $summary = $rest > 0 ? sprintf(
                /* translators: 1: a list of passed checks, 2: how many more passed */
                __('%1$s and %2$d more pass', 'pagecraft-importer'),
                implode(', ', $shown),
                $rest
            ) : sprintf(
                /* translators: %s: a list of passed checks */
                __('%s pass', 'pagecraft-importer'),
                implode(', ', $shown)
            );
            echo '<li class="is-ok pc-importer__passed"><span class="pc-importer__dot" aria-hidden="true"></span><details><summary><span>'
                . esc_html($summary) . '</span><span class="pc-importer__more">' . esc_html__('Show all', 'pagecraft-importer') . '</span></summary><ul>';
            foreach ($passed as $key) {
                echo '<li>' . esc_html($checks[$key]['message']) . '</li>';
            }
            echo '</ul></details></li>';
        }
        echo '</ul>';
    }

    /**
     * One row per Pagecraft product: what is installed, what the signed release offers, and the change that closes the gap.
     *
     * @param array<string,mixed> $manifest
     * @return list<array{label:string,detail:string,state:string,action:string,ticked:bool}>
     */
    private function products(array $manifest): array
    {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $plugins = get_plugins();
        $builderFile = 'pagecraft-builder/pagecraft-builder.php';
        $builder = (string) ($plugins[$builderFile]['Version'] ?? '');
        $themeObject = wp_get_theme('pagecraft');
        $theme = $themeObject->exists() && !$themeObject->errors() ? (string) $themeObject->get('Version') : '';
        $release = static fn (string $name): string => (string) ($manifest['products'][$name]['version'] ?? '');
        $rows = [];
        foreach ([
            ['builder', __('Pagecraft Builder', 'pagecraft-importer'), $builder, 'install_builder'],
            ['theme', __('Pagecraft Theme', 'pagecraft-importer'), $theme, 'install_theme'],
        ] as [$name, $label, $installed, $action]) {
            $available = $release($name);
            if ($installed === '') {
                $rows[] = ['label' => $label, 'detail' => $available !== '' ? sprintf(
                    /* translators: %s: version number */
                    __('not installed · %s available', 'pagecraft-importer'),
                    $available
                ) : __('not installed', 'pagecraft-importer'), 'state' => __('Install', 'pagecraft-importer'),
                    'action' => $available !== '' ? $action : '', 'ticked' => false];
                continue;
            }
            $newer = $available !== '' && version_compare($available, $installed, '>');
            $rows[] = ['label' => $label, 'detail' => $newer ? $installed . ' → ' . $available : $installed,
                'state' => $newer ? __('Update', 'pagecraft-importer') : __('Current', 'pagecraft-importer'),
                'action' => $newer ? $action : '', 'ticked' => $newer];
        }
        $importerRelease = $release('importer');
        $rows[] = ['label' => __('Pagecraft Importer', 'pagecraft-importer'),
            'detail' => $importerRelease !== '' && version_compare($importerRelease, PAGECRAFT_IMPORTER_VERSION, '>')
                ? PAGECRAFT_IMPORTER_VERSION . ' → ' . $importerRelease . ' · ' . __('update it from the Updates screen', 'pagecraft-importer')
                : PAGECRAFT_IMPORTER_VERSION . ' · ' . __('updates from the Updates screen', 'pagecraft-importer'),
            'state' => $importerRelease !== '' && version_compare($importerRelease, PAGECRAFT_IMPORTER_VERSION, '>')
                ? __('On Updates screen', 'pagecraft-importer') : __('Current', 'pagecraft-importer'),
            'action' => '', 'ticked' => false];
        if ($theme !== '' && get_stylesheet() !== 'pagecraft') {
            $rows[] = ['label' => __('Switch this site to Pagecraft Theme', 'pagecraft-importer'), 'detail' => __('changes how existing content looks', 'pagecraft-importer'),
                'state' => __('Switch', 'pagecraft-importer'), 'action' => $manifest !== [] ? 'switch_theme' : '', 'ticked' => false];
        } elseif ($theme !== '') {
            $rows[] = ['label' => __('Pagecraft Theme is the active theme', 'pagecraft-importer'), 'detail' => '',
                'state' => __('Active', 'pagecraft-importer'), 'action' => '', 'ticked' => false];
        }
        if ($builder !== '' && !is_plugin_active($builderFile)) {
            $rows[] = ['label' => __('Activate Pagecraft Builder', 'pagecraft-importer'), 'detail' => __('needs the matching Pagecraft Theme, active', 'pagecraft-importer'),
                'state' => __('Activate', 'pagecraft-importer'), 'action' => $manifest !== [] ? 'activate_builder' : '', 'ticked' => false];
        }
        return $rows;
    }

    /** @param list<array{label:string,detail:string,state:string,action:string,ticked:bool}> $changes */
    private function footNote(array $changes): string
    {
        $actions = array_column($changes, 'action');
        return in_array('install_builder', $actions, true) && in_array('install_theme', $actions, true)
            ? __('Only ticked changes run. Update Builder and Theme together: Builder works only with the Theme of the same version.', 'pagecraft-importer')
            : __('Only ticked changes run.', 'pagecraft-importer');
    }

    private function applyLabel(int $count): string
    {
        if ($count === 0) return __('Apply changes', 'pagecraft-importer');
        /* translators: %d: number of ticked changes */
        return sprintf(_n('Apply %d change', 'Apply %d changes', $count, 'pagecraft-importer'), $count);
    }

    public function apply(): void
    {
        if (!Capabilities::allowed()) {
            wp_die(esc_html__('You cannot manage Pagecraft packages.', 'pagecraft-importer'), '', ['response' => 403]);
        }
        check_admin_referer('pagecraft_importer_apply');
        $actions = array_values(array_filter(array_map(
            'sanitize_key',
            (array) wp_unslash($_POST['actions'] ?? [])
        )));
        try {
            $messages = $this->installer->apply($actions);
            $this->redirect($messages === [] ? 'No changes were selected.' : implode(' ', $messages));
        } catch (Throwable $error) {
            wp_die(esc_html($error->getMessage()), esc_html__('Pagecraft installation failed', 'pagecraft-importer'), ['response' => 400]);
        }
    }

    public function rollback(): void
    {
        $this->guard('pagecraft_importer_rollback_theme');
        try { $this->redirect($this->installer->rollbackTheme()); }
        catch (Throwable $error) {
            wp_die(esc_html($error->getMessage()), esc_html__('Pagecraft rollback failed', 'pagecraft-importer'), ['response' => 400]);
        }
    }

    private function guard(string $nonce): void
    {
        if (!Capabilities::allowed()) wp_die(esc_html__('You cannot manage Pagecraft packages.', 'pagecraft-importer'), '', ['response' => 403]);
        check_admin_referer($nonce);
    }

    private function redirect(string $message): never
    {
        wp_safe_redirect(add_query_arg([
            'page' => 'pagecraft-importer', 'pagecraft_message' => $message
        ], admin_url('tools.php')));
        exit;
    }
}
