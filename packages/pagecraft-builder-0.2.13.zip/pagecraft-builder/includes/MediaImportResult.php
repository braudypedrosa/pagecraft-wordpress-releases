<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Local WordPress ownership for every asset referenced by one portable package.
 */
final class MediaImportResult
{
    /**
     * @param array<string,array{attachmentId:int,path:string,url:string,hash:string}> $assets
     * @param list<int> $createdAttachmentIds
     */
    public function __construct(
        private array $assets,
        private array $createdAttachmentIds
    ) {
    }

    public function documentJson(string $source): string
    {
        try {
            $document = json_decode($source, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new PackageException('The Pagecraft document could not be localized: ' . $error->getMessage());
        }
        if (!is_array($document)) {
            throw new PackageException('The Pagecraft document could not be localized.');
        }
        $this->localizeLinks($document);
        $this->rewriteValue($document);
        return DocumentJson::encode($document);
    }

    public function rewrite(string $source): string
    {
        foreach ($this->assets as $sourceId => $asset) {
            $source = preg_replace_callback(
                '/asset:' . preg_quote($sourceId, '/') . '(?:@\d+)?/',
                static fn (): string => $asset['url'],
                $source
            ) ?? $source;
            $source = preg_replace_callback(
                '#(?:\.\./)*/?' . preg_quote($asset['path'], '#') . '#',
                static fn (): string => $asset['url'],
                $source
            ) ?? $source;
        }
        return $source;
    }

    public function rewriteHtml(string $html): string
    {
        $html = $this->rewrite($html);
        foreach ($this->assets as $asset) {
            $url = $asset['url'];
            $attachmentId = $asset['attachmentId'];
            $html = preg_replace_callback('/<img\b[^>]*>/i', static function (array $match) use ($url, $attachmentId): string {
                $tag = $match[0];
                if (!preg_match('/\bsrc\s*=\s*(["\'])' . preg_quote($url, '/') . '\1/i', $tag)) {
                    return $tag;
                }
                return ImageMarkup::forAttachment($tag, $attachmentId);
            }, $html) ?? $html;
        }
        return $html;
    }

    /** @return list<int> */
    public function attachmentIds(): array
    {
        return array_values(array_map(
            static fn (array $asset): int => $asset['attachmentId'],
            $this->assets
        ));
    }

    public function attachmentIdsJson(): string
    {
        return CanonicalJson::encode(array_map('strval', $this->attachmentIds()));
    }

    public function rollback(): void
    {
        foreach ($this->createdAttachmentIds as $attachmentId) {
            wp_delete_attachment($attachmentId, true);
        }
    }

    /** Keep editable document links consistent with the localized compiled HTML.
     * @param array<string,mixed> $document
     */
    private function localizeLinks(array &$document): void
    {
        if (!function_exists('home_url')) return;
        $linkKeys = [];
        foreach (($document['meta']['components'] ?? []) as $component) {
            foreach (($component['props'] ?? []) as $prop) {
                if (($prop['t'] ?? '') === 'link') $linkKeys[$component['id']][] = $prop['k'];
            }
        }
        $url = static function (string $value): string {
            if (!preg_match('~^(?:\./|/)?([A-Za-z0-9][A-Za-z0-9/_-]*?)\.html([?#].*)?$~i', $value, $m)) return $value;
            $route = $m[1] === 'index' ? '' : preg_replace('~/index$~i', '', $m[1]);
            return home_url('/' . ($route !== '' ? $route . '/' : '')) . ($m[2] ?? '');
        };
        $walk = static function (array &$node) use (&$walk, $url, $linkKeys): void {
            foreach (['link', 'href'] as $key) {
                if (isset($node[$key]) && is_string($node[$key])) $node[$key] = $url($node[$key]);
            }
            if (($node['t'] ?? '') === 'link' && isset($node['def']) && is_string($node['def'])) $node['def'] = $url($node['def']);
            foreach (($linkKeys[$node['use'] ?? ''] ?? []) as $key) {
                if (isset($node['vals'][$key]) && is_string($node['vals'][$key])) $node['vals'][$key] = $url($node['vals'][$key]);
            }
            foreach ($node as &$child) if (is_array($child)) $walk($child);
        };
        $walk($document);
    }

    private function rewriteValue(mixed &$value): void
    {
        if (is_string($value)) {
            $value = $this->rewrite($value);
            return;
        }
        if (!is_array($value)) {
            return;
        }
        foreach ($value as &$child) {
            $this->rewriteValue($child);
        }
    }
}
