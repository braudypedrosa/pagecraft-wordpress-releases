<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Keeps an imported breadcrumb trail when WordPress compiles a single page.
 *
 * An automatic trail is worked out from every page in a project. WordPress stores one page per
 * document, so the compiler cannot see the front page and would drop the "Home" crumb. Pagecraft
 * Cloud ships the trail it resolved with each breadcrumb, so that trail is used as written.
 */
final class Breadcrumbs
{
    private const FRONT_PAGE_SLUG = 'index';

    /**
     * @param array<string,mixed> $document
     * @return array<string,mixed>
     */
    public static function keepImportedTrails(array $document): array
    {
        foreach (is_array($document['pages'] ?? null) ? $document['pages'] : [] as $page) {
            if (is_array($page) && ($page['slug'] ?? null) === self::FRONT_PAGE_SLUG) {
                // The compiler can see the front page, so automatic trails already work.
                return $document;
            }
        }
        self::walk($document);
        return $document;
    }

    /** @param array<array-key,mixed> $node */
    private static function walk(array &$node): void
    {
        if (($node['type'] ?? null) === 'crumbs' && is_array($node['props'] ?? null)
            && ($node['props']['mode'] ?? null) !== 'manual' && self::isTrail($node['props']['items'] ?? null)) {
            $node['props']['mode'] = 'manual';
        }
        foreach ($node as &$child) {
            if (is_array($child)) {
                self::walk($child);
            }
        }
    }

    /** A usable trail has a linked ancestor and a labelled current page. */
    private static function isTrail(mixed $items): bool
    {
        if (!is_array($items) || !array_is_list($items) || count($items) < 2) {
            return false;
        }
        foreach ($items as $index => $item) {
            if (!is_array($item) || !is_string($item['label'] ?? null) || trim($item['label']) === '') {
                return false;
            }
            $last = $index === count($items) - 1;
            if (!$last && (!is_string($item['href'] ?? null) || trim($item['href']) === '')) {
                return false;
            }
        }
        return true;
    }
}
