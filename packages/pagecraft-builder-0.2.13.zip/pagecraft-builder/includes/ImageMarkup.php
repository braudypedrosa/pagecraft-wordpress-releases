<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Ties compiled `<img>` tags to their WordPress media items.
 *
 * The media class, `srcset` and `sizes` are what let WordPress serve smaller files to smaller
 * screens. Imports add them; a page rebuilt by the editor must keep them.
 */
final class ImageMarkup
{
    /** @var array<string,int> */
    private static array $attachmentIds = [];

    /** Adds the media class, `srcset` and `sizes` for a known media item to one `<img>` tag. */
    public static function forAttachment(string $tag, int $attachmentId): string
    {
        if (preg_match('/\bclass\s*=\s*(["\'])(.*?)\1/i', $tag, $class)) {
            $classes = preg_match('/(?:^|\s)wp-image-' . $attachmentId . '(?:\s|$)/', $class[2])
                ? trim($class[2])
                : trim($class[2] . ' wp-image-' . $attachmentId);
            $tag = preg_replace('/\bclass\s*=\s*(["\'])(.*?)\1/i', 'class="' . esc_attr($classes) . '"', $tag, 1) ?? $tag;
        } else {
            $tag = preg_replace('/\s*\/?>$/', ' class="wp-image-' . $attachmentId . '">', $tag, 1) ?? $tag;
        }
        $srcset = wp_get_attachment_image_srcset($attachmentId, 'full');
        if (is_string($srcset) && $srcset !== '' && !preg_match('/\bsrcset\s*=/i', $tag)) {
            $tag = preg_replace('/\s*\/?>$/', ' srcset="' . esc_attr($srcset) . '">', $tag, 1) ?? $tag;
        }
        $sizes = wp_get_attachment_image_sizes($attachmentId, 'full');
        if (is_string($sizes) && $sizes !== '' && !preg_match('/\bsizes\s*=/i', $tag)) {
            $tag = preg_replace('/\s*\/?>$/', ' sizes="' . esc_attr($sizes) . '">', $tag, 1) ?? $tag;
        }
        return $tag;
    }

    /** Tags every `<img>` whose file is a WordPress media item and is not tagged yet. */
    public static function tagMediaLibraryImages(string $html): string
    {
        if (!function_exists('attachment_url_to_postid') || !function_exists('wp_get_upload_dir')
            || stripos($html, '<img') === false) {
            return $html;
        }
        $uploads = wp_get_upload_dir();
        $baseUrl = is_array($uploads) && is_string($uploads['baseurl'] ?? null) ? rtrim($uploads['baseurl'], '/') . '/' : '';
        if ($baseUrl === '/') {
            return $html;
        }
        return preg_replace_callback('/<img\b[^>]*>/i', static function (array $match) use ($baseUrl): string {
            $tag = $match[0];
            if (preg_match('/\bclass\s*=\s*(["\'])[^"\']*\bwp-image-[1-9][0-9]*\b/i', $tag)
                || !preg_match('/\bsrc\s*=\s*(["\'])(.*?)\1/i', $tag, $src)) {
                return $tag;
            }
            $url = html_entity_decode($src[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (!str_starts_with($url, $baseUrl)) {
                return $tag;
            }
            $attachmentId = self::$attachmentIds[$url] ??= (int) attachment_url_to_postid($url);
            if ($attachmentId <= 0 || !str_starts_with((string) get_post_mime_type($attachmentId), 'image/')) {
                return $tag;
            }
            return self::forAttachment($tag, $attachmentId);
        }, $html) ?? $html;
    }
}
