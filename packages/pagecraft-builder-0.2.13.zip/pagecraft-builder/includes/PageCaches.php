<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Clears full-page caches after Pagecraft itself changes version.
 *
 * A cached page keeps pointing at the previous release's stylesheet and script addresses, so
 * visitors would stay on the old files until the cache expired on its own.
 */
final class PageCaches
{
    public const OPTION = 'pagecraft_installed_versions';

    public static function register(): void
    {
        add_action('init', [self::class, 'clearAfterUpdate']);
    }

    /** Clears page caches once whenever the installed Builder, Theme or Importer version changes. */
    public static function clearAfterUpdate(): void
    {
        $installed = self::installed();
        if (get_option(self::OPTION) === $installed) {
            return;
        }

        update_option(self::OPTION, $installed, true);
        self::clear();
    }

    /** The installed Pagecraft versions as one comparable value. */
    public static function installed(): string
    {
        return implode('|', [
            PAGECRAFT_BUILDER_VERSION,
            defined('PAGECRAFT_THEME_VERSION') ? (string) constant('PAGECRAFT_THEME_VERSION') : '',
            defined('PAGECRAFT_IMPORTER_VERSION') ? (string) constant('PAGECRAFT_IMPORTER_VERSION') : '',
        ]);
    }

    /**
     * Asks each known page cache to drop its saved pages. Every call is a no-op when that
     * cache is not installed. Hosts with their own cache can listen for
     * `pagecraft_clear_page_caches`.
     */
    public static function clear(): void
    {
        // LiteSpeed Cache and Cache Enabler listen for these actions.
        do_action('litespeed_purge_all');
        do_action('cache_enabler_clear_complete_cache');

        // WP Rocket, W3 Total Cache, WP Super Cache, SiteGround Optimizer.
        foreach (['rocket_clean_domain', 'w3tc_flush_posts', 'wp_cache_clear_cache', 'sg_cachepress_purge_cache'] as $function) {
            if (function_exists($function)) {
                try {
                    $function();
                } catch (\Throwable) {
                    // A failing cache plugin must never break the site after an update.
                }
            }
        }

        do_action('pagecraft_clear_page_caches');
    }
}
