<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class GlobalElement
{
    public const POST_TYPE = 'pagecraft_global';
    public const KIND = '_pagecraft_global_kind';
    public const DOCUMENT = '_pagecraft_global_document';
    public const DOCUMENT_VERSION = '_pagecraft_global_document_version';
    public const SCHEMA_VERSION = '_pagecraft_schema_version';
    public const RENDERER_VERSION = '_pagecraft_renderer_version';
    public const COMPILED_HASH = ManagedPage::COMPILED_HASH;
    public const IMPORTED_OUTPUT_HASH = ManagedPage::IMPORTED_OUTPUT_HASH;
    public const COMPILER_EDITOR_VERSION = ManagedPage::COMPILER_EDITOR_VERSION;
    public const COMPILER_RENDERER_REVISION = ManagedPage::COMPILER_RENDERER_REVISION;
    public const COMPILER_DOCUMENT_SHA256 = ManagedPage::COMPILER_DOCUMENT_SHA256;
    public const COMPILER_RENDER_CONTEXT_SHA256 = ManagedPage::COMPILER_RENDER_CONTEXT_SHA256;
    public const COMPILED_AT = ManagedPage::COMPILED_AT;
    public const SOURCE_PROJECT_ID = '_pagecraft_source_project_id';
    public const SOURCE_VERSION = '_pagecraft_source_version';
    public const CSS_PATH = '_pagecraft_global_css_path';
    public const CSS_HASH = '_pagecraft_global_css_hash';
    /**
     * A template's own rules, kept apart from the shared foundation in CSS_PATH. Every foundation
     * loads before any template's own rules, so one template's foundation can never reset another's.
     */
    public const NODE_CSS_PATH = ManagedPage::PAGE_CSS_PATH;
    public const NODE_CSS_HASH = ManagedPage::PAGE_CSS_HASH;
    public const RUNTIME_PATH = '_pagecraft_runtime_path';
    public const RUNTIME_HASH = '_pagecraft_runtime_hash';
    public const MEDIA_ATTACHMENTS = '_pagecraft_media_attachments';
    public const UPDATED_AT = '_pagecraft_imported_at';
    public const DEFAULT_HEADER = 'pagecraft_default_header_id';
    public const DEFAULT_FOOTER = 'pagecraft_default_footer_id';
    public const PAGE_HEADER_MODE = '_pagecraft_header_mode';
    public const PAGE_HEADER_ID = '_pagecraft_header_id';
    public const PAGE_FOOTER_MODE = '_pagecraft_footer_mode';
    public const PAGE_FOOTER_ID = '_pagecraft_footer_id';

    /** @return list<string> */
    public static function keys(): array
    {
        return [
            self::KIND,
            self::DOCUMENT,
            self::DOCUMENT_VERSION,
            self::SCHEMA_VERSION,
            self::RENDERER_VERSION,
            self::COMPILED_HASH,
            self::IMPORTED_OUTPUT_HASH,
            self::COMPILER_EDITOR_VERSION,
            self::COMPILER_RENDERER_REVISION,
            self::COMPILER_DOCUMENT_SHA256,
            self::COMPILER_RENDER_CONTEXT_SHA256,
            self::COMPILED_AT,
            self::SOURCE_PROJECT_ID,
            self::SOURCE_VERSION,
            self::CSS_PATH,
            self::CSS_HASH,
            self::NODE_CSS_PATH,
            self::NODE_CSS_HASH,
            self::RUNTIME_PATH,
            self::RUNTIME_HASH,
            self::MEDIA_ATTACHMENTS,
            self::UPDATED_AT,
            TemplateConditions::META,
            TemplateConditions::PRIORITY,
            ManagedPage::IMPORT_JOB_ID,
        ];
    }

    public static function register(): void
    {
        register_post_type(self::POST_TYPE, [
            'labels' => [
                'name' => __('Theme Templates', 'pagecraft-builder'),
                'singular_name' => __('Theme Template', 'pagecraft-builder'),
                'menu_name' => __('Theme Builder', 'pagecraft-builder'),
                'all_items' => __('All Theme Templates', 'pagecraft-builder'),
                'add_new_item' => __('Add Theme Template', 'pagecraft-builder'),
                'edit_item' => __('Edit Theme Template', 'pagecraft-builder'),
                'new_item' => __('New Theme Template', 'pagecraft-builder'),
                'search_items' => __('Search Theme Templates', 'pagecraft-builder'),
                'not_found' => __('No theme templates found.', 'pagecraft-builder'),
                'item_published' => __('Theme template activated.', 'pagecraft-builder'),
                'item_updated' => __('Theme template updated.', 'pagecraft-builder'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'show_in_rest' => false,
            'rewrite' => false,
            'query_var' => false,
            'supports' => ['title', 'revisions', 'custom-fields'],
            'map_meta_cap' => true,
            'capability_type' => ['page', 'pages'],
        ]);

        foreach (self::keys() as $key) {
            register_post_meta(self::POST_TYPE, $key, [
                'type' => 'string',
                'single' => true,
                'show_in_rest' => false,
                'revisions_enabled' => true,
                'sanitize_callback' => static fn (mixed $value): string => is_string($value) ? $value : '',
                'auth_callback' => static function (bool $allowed, string $metaKey, int $postId): bool {
                    return $allowed || current_user_can('edit_post', $postId);
                },
            ]);
        }
    }

    /** @param array<string,string> $internalRoutes */
    public function import(PortablePagePackage $package, string $kind, int $onlyPage = 0, array $internalRoutes = []): int
    {
        return EditorWriteLock::runSourceWrite(
            [],
            fn (): int => $this->importLocked($package, $kind, $onlyPage, $internalRoutes)
        );
    }

    /** @param array<string,string> $internalRoutes */
    private function importLocked(PortablePagePackage $package, string $kind, int $onlyPage, array $internalRoutes): int
    {
        if (!current_user_can(Capabilities::MANAGE)) {
            throw new PackageException('You are not allowed to update Pagecraft global elements.');
        }
        self::assertKind($kind);
        $media = (new MediaLibrary())->import($package);
        try {
            $content = $media->rewriteHtml(FallbackCompiler::globalContent($package, $kind));
            if ($internalRoutes !== []) {
                $content = FallbackCompiler::remapProjectHtmlLinks($content, $internalRoutes);
            }
            $css = ImportedFonts::prepend($package, $media->rewrite(FallbackCompiler::globalCss($package)));
            $assets = new GeneratedAssetStore();
            $cssAsset = $css !== '' ? $assets->writeCss('global', $css) : null;
            $runtimeAsset = FallbackCompiler::needsRuntime($content) ? $assets->writeRuntime() : null;
            $sourceDocument = json_decode(CanonicalJson::encode($package->document()), true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($sourceDocument)) {
                throw new PackageException('The Pagecraft project document cannot be prepared for global editing.');
            }
            $editableDocument = GlobalElementEditor::documentFromRegion(
                $sourceDocument,
                $kind,
                $kind === 'header' ? 'Pagecraft Header' : 'Pagecraft Footer'
            );
            if ($internalRoutes !== []) {
                $editableDocument = FallbackCompiler::remapProjectDocumentLinks($editableDocument, $internalRoutes);
            }
            $document = $media->rewrite(DocumentJson::encode($editableDocument));
            $provenance = $package->provenance();
            $metadata = [
                self::KIND => $kind,
                self::DOCUMENT => $document,
                self::DOCUMENT_VERSION => '1',
                self::SCHEMA_VERSION => (string) $package->manifest()->schemaVersion,
                self::RENDERER_VERSION => (string) $package->manifest()->rendererVersion,
                self::COMPILED_HASH => hash('sha256', $content),
                self::IMPORTED_OUTPUT_HASH => hash('sha256', $content),
                self::COMPILER_EDITOR_VERSION => '',
                self::COMPILER_RENDERER_REVISION => '',
                self::COMPILER_DOCUMENT_SHA256 => '',
                self::COMPILER_RENDER_CONTEXT_SHA256 => '',
                self::COMPILED_AT => '',
                self::SOURCE_PROJECT_ID => (string) $provenance->sourceId,
                self::SOURCE_VERSION => (string) $provenance->sourceVersion,
                self::CSS_PATH => $cssAsset['path'] ?? '',
                self::CSS_HASH => $cssAsset['hash'] ?? '',
                // A package carries one stylesheet per region; the split starts at the first compile here.
                self::NODE_CSS_PATH => '',
                self::NODE_CSS_HASH => '',
                self::RUNTIME_PATH => $runtimeAsset['path'] ?? '',
                self::RUNTIME_HASH => $runtimeAsset['hash'] ?? '',
                self::MEDIA_ATTACHMENTS => $media->attachmentIdsJson(),
                self::UPDATED_AT => gmdate('c'),
                TemplateConditions::META => TemplateConditions::encode(TemplateConditions::defaults($kind)),
                TemplateConditions::PRIORITY => '0',
            ];

            // A page transfer owns a separate pair; it must never update site defaults
            // or another page's imported header/footer.
            $sourceId = (string) $provenance->sourceId . ($onlyPage > 0 ? ':page:' . $onlyPage : '');
            $metadata[self::SOURCE_PROJECT_ID] = $sourceId;
            if ($onlyPage > 0) {
                $metadata[TemplateConditions::META] = TemplateConditions::encode([
                    ['action' => 'include', 'type' => 'post', 'value' => (string) $onlyPage],
                ]);
            }
            $existing = get_page_by_path(self::slug($kind, $sourceId), OBJECT, self::POST_TYPE);
            if (!$existing) {
                $legacy = get_page_by_path('pagecraft-' . $kind, OBJECT, self::POST_TYPE);
                if ($legacy && (string) get_post_meta((int) $legacy->ID, self::SOURCE_PROJECT_ID, true) === $sourceId) {
                    $existing = $legacy;
                }
            }
            $postId = is_object($existing) ? (int) $existing->ID : 0;
            return EditorWriteLock::runSourceWrite($postId > 0 ? [$postId] : [], function () use (
                &$postId,
                $content,
                $kind,
                $media,
                $metadata,
                $onlyPage,
                $sourceId
            ): int {
                if ($postId > 0 && self::matchesStored($postId, $content, $metadata)) {
                    // WordPress deliberately skips a revision when revisioned fields are unchanged.
                    // Treat an exact package reimport as a no-op before requiring a safety revision;
                    // media created only for this attempt must not leak.
                    $media->rollback();
                    return $postId;
                }
                $metadata[self::DOCUMENT_VERSION] = $postId > 0
                    ? (string) (max(1, (int) get_post_meta($postId, self::DOCUMENT_VERSION, true)) + 1)
                    : '1';
                if ($postId > 0) {
                    if (!post_type_supports(self::POST_TYPE, 'revisions') || !wp_revisions_enabled(get_post($postId))) {
                        throw new PackageException('WordPress revisions must be enabled for Pagecraft global elements.');
                    }
                    $revision = wp_save_post_revision($postId);
                    if (is_wp_error($revision)) {
                        throw new PackageException('WordPress could not revise the Pagecraft ' . $kind . ': ' . $revision->get_error_message());
                    }
                    $saved = wp_update_post([
                        'ID' => $postId,
                        'post_content' => wp_slash($content),
                    ], true);
                } else {
                    $saved = wp_insert_post([
                        'post_type' => self::POST_TYPE,
                        'post_status' => 'publish',
                        'post_title' => $kind === 'header' ? 'Pagecraft Header' : 'Pagecraft Footer',
                        'post_name' => self::slug($kind, $sourceId),
                        'post_content' => wp_slash($content),
                        'meta_input' => array_map('wp_slash', $metadata),
                    ], true);
                }
                if (is_wp_error($saved)) {
                    throw new PackageException('WordPress could not store the Pagecraft ' . $kind . ': ' . $saved->get_error_message());
                }
                $postId = (int) $saved;
                foreach ($metadata as $key => $value) {
                    update_post_meta($postId, $key, wp_slash($value));
                }
                if ($onlyPage === 0 && function_exists('get_option') && (int) get_option(self::defaultOption($kind), 0) <= 0) {
                    update_option(self::defaultOption($kind), $postId, false);
                }

                return $postId;
            });
        } catch (\Throwable $error) {
            $media->rollback();
            throw $error;
        }
    }

    /** @phpstan-assert 'header'|'footer'|'single_page'|'single_post'|'archive'|'search'|'not_found' $kind */
    public static function assertKind(string $kind): void
    {
        if (!in_array($kind, self::kinds(), true)) {
            throw new PackageException('The Pagecraft theme template kind is invalid.');
        }
    }

    /** @return list<string> */
    public static function kinds(): array
    {
        return ['header', 'footer', 'single_page', 'single_post', 'archive', 'search', 'not_found'];
    }

    /** @return list<string> */
    public static function templateKinds(): array
    {
        return ['single_page', 'single_post', 'archive', 'search', 'not_found'];
    }

    public static function label(string $kind): string
    {
        self::assertKind($kind);
        return match ($kind) {
            'header' => __('Header', 'pagecraft-builder'),
            'footer' => __('Footer', 'pagecraft-builder'),
            'single_page' => __('Single Page', 'pagecraft-builder'),
            'single_post' => __('Single Post', 'pagecraft-builder'),
            'archive' => __('Archive', 'pagecraft-builder'),
            'search' => __('Search Results', 'pagecraft-builder'),
            'not_found' => __('404 Page', 'pagecraft-builder'),
        };
    }

    public static function group(string $kind): string
    {
        return match ($kind) {
            'header', 'footer' => 'site-parts',
            'single_page', 'single_post' => 'singular',
            'archive' => 'listings',
            'search', 'not_found' => 'system',
            default => 'all',
        };
    }

    private static function slug(string $kind, string $sourceId): string
    {
        return 'pagecraft-' . $kind . '-' . substr(hash('sha256', $sourceId), 0, 12);
    }

    /** @param array<string,string> $metadata */
    private static function matchesStored(int $postId, string $content, array $metadata): bool
    {
        $post = get_post($postId);
        if (!is_object($post) || (string) $post->post_content !== $content) return false;
        foreach ($metadata as $key => $value) {
            if ($key === self::UPDATED_AT || $key === self::DOCUMENT_VERSION) continue;
            if ((string) get_post_meta($postId, $key, true) !== $value) return false;
        }
        return true;
    }

    public static function defaultOption(string $kind): string
    {
        if (!in_array($kind, ['header', 'footer'], true)) {
            throw new PackageException('Only headers and footers can be sitewide defaults.');
        }
        return $kind === 'header' ? self::DEFAULT_HEADER : self::DEFAULT_FOOTER;
    }

    /** @return list<\WP_Post> */
    public static function all(?string $kind = null): array
    {
        if ($kind !== null) {
            self::assertKind($kind);
        }
        $args = [
            'post_type' => self::POST_TYPE,
            'post_status' => ['publish', 'draft', 'private'],
            'posts_per_page' => 200,
            'orderby' => ['modified' => 'DESC', 'ID' => 'DESC'],
        ];
        if ($kind !== null) {
            $args['meta_key'] = self::KIND;
            $args['meta_value'] = $kind;
        }
        return get_posts($args);
    }

    public static function resolve(string $kind, int $pageId): int
    {
        self::assertKind($kind);
        $modeKey = $kind === 'header' ? self::PAGE_HEADER_MODE : self::PAGE_FOOTER_MODE;
        $idKey = $kind === 'header' ? self::PAGE_HEADER_ID : self::PAGE_FOOTER_ID;
        $mode = (string) get_post_meta($pageId, $modeKey, true);
        if ($mode === 'none') return 0;
        if ($mode === 'selected') {
            $selected = (int) get_post_meta($pageId, $idKey, true);
            if (self::valid($selected, $kind)) return $selected;
        }
        $conditional = TemplateResolver::current([$kind]);
        if (self::valid($conditional, $kind)) return $conditional;
        $default = (int) get_option(self::defaultOption($kind), 0);
        return self::valid($default, $kind) ? $default : 0;
    }

    public static function valid(int $postId, string $kind): bool
    {
        return $postId > 0
            && get_post_type($postId) === self::POST_TYPE
            && get_post_status($postId) === 'publish'
            && hash_equals($kind, (string) get_post_meta($postId, self::KIND, true));
    }

    public static function findForSource(string $sourceProjectId, string $kind, bool $includeArchived = false): int
    {
        self::assertKind($kind);
        $ids = get_posts([
            'post_type' => self::POST_TYPE,
            'post_status' => $includeArchived
                ? ['publish', 'draft', 'pending', 'private', 'future', CloudReplacement::ARCHIVE_STATUS]
                : 'any',
            'posts_per_page' => 2,
            'fields' => 'ids',
            'meta_query' => [
                'relation' => 'AND',
                ['key' => self::SOURCE_PROJECT_ID, 'value' => $sourceProjectId, 'compare' => '='],
                ['key' => self::KIND, 'value' => $kind, 'compare' => '='],
            ],
        ]);
        if (count($ids) > 1) throw new PackageException('Multiple local global elements claim the same Pagecraft source identity.');
        return isset($ids[0]) ? (int) $ids[0] : 0;
    }
}
