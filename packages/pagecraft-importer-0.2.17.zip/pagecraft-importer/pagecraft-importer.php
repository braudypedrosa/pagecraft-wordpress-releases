<?php
/**
 * Plugin Name: Pagecraft Importer
 * Plugin URI: https://build.itspagecraft.com/
 * Description: Verifies, installs, updates, and keeps Pagecraft Builder and Theme compatible.
 * Version: 0.2.17
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * Author: Pagecraft
 * License: GPL-3.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain: pagecraft-importer
 * Domain Path: /languages
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

define('PAGECRAFT_IMPORTER_VERSION', '0.2.17');
define('PAGECRAFT_IMPORTER_FILE', __FILE__);
define('PAGECRAFT_IMPORTER_DIR', plugin_dir_path(__FILE__));
define('PAGECRAFT_IMPORTER_URL', plugin_dir_url(__FILE__));

require_once PAGECRAFT_IMPORTER_DIR . 'includes/Autoload.php';
\Pagecraft\Importer\Autoload::register();

register_activation_hook(__FILE__, [\Pagecraft\Importer\Capabilities::class, 'activate']);

add_action('init', static function (): void {
    load_plugin_textdomain('pagecraft-importer', false, dirname(plugin_basename(PAGECRAFT_IMPORTER_FILE)) . '/languages');
});

add_action('plugins_loaded', static function (): void {
    \Pagecraft\Importer\Plugin::instance()->boot();
});
