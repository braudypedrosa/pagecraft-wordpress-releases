<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use Throwable;

/**
 * Offers Pagecraft releases on WordPress's own Updates screen.
 *
 * WordPress only learns that a newer version exists and where the file is. The file it then
 * downloads is the one named in the signed feed, checked against the signed size and hash before
 * WordPress is allowed to install it.
 */
final class Updates
{
    /** Feed product => the plugin file WordPress knows it by. */
    private const PLUGINS = [
        'importer' => 'pagecraft-importer/pagecraft-importer.php',
        'builder' => 'pagecraft-builder/pagecraft-builder.php',
    ];
    private const THEME = 'pagecraft';
    private const HOME = 'https://itspagecraft.com/';

    public function __construct(
        private readonly Distribution $distribution,
        private readonly Installer $installer
    ) {
    }

    public function hooks(): void
    {
        add_filter('pre_set_site_transient_update_plugins', [$this, 'offer']);
        add_filter('pre_set_site_transient_update_themes', [$this, 'offerTheme']);
        add_filter('upgrader_pre_download', [$this, 'verifyDownload'], 10, 4);
    }

    public function offer(mixed $transient): mixed
    {
        if (!is_object($transient) || empty($transient->checked)) return $transient;
        try {
            $manifest = $this->distribution->stable();
            foreach (self::PLUGINS as $name => $plugin) {
                $installed = (string) ($transient->checked[$plugin] ?? '');
                $product = $manifest['products'][$name] ?? null;
                $url = $manifest['_downloads'][$name] ?? null;
                if ($installed === '' || !is_array($product) || !is_string($url)
                    || version_compare((string) $product['version'], $installed, '<=')) {
                    continue;
                }
                $transient->response[$plugin] = (object) [
                    'id' => (string) $product['slug'],
                    'slug' => (string) $product['slug'],
                    'plugin' => $plugin,
                    'new_version' => (string) $product['version'],
                    'url' => self::HOME,
                    'package' => $url,
                    'tested' => (string) ($product['requirements']['testedWordPress'] ?? ''),
                    'requires_php' => ltrim((string) ($product['requirements']['php'] ?? '8.1'), '>= '),
                ];
            }
        } catch (Throwable) {
            // A failed update check must not interfere with the rest of wp-admin.
        }
        return $transient;
    }

    public function offerTheme(mixed $transient): mixed
    {
        if (!is_object($transient) || empty($transient->checked[self::THEME])) return $transient;
        try {
            $manifest = $this->distribution->stable();
            $product = $manifest['products']['theme'] ?? null;
            $url = $manifest['_downloads']['theme'] ?? null;
            if (!is_array($product) || !is_string($url)
                || version_compare((string) $product['version'], (string) $transient->checked[self::THEME], '<=')) {
                return $transient;
            }
            $transient->response[self::THEME] = [
                'theme' => self::THEME,
                'new_version' => (string) $product['version'],
                'url' => self::HOME,
                'package' => $url,
                'requires' => ltrim((string) ($product['requirements']['wordpress'] ?? ''), '>= '),
                'requires_php' => ltrim((string) ($product['requirements']['php'] ?? '8.1'), '>= '),
            ];
        } catch (Throwable) {
            // A failed update check must not interfere with the rest of wp-admin.
        }
        return $transient;
    }

    public function verifyDownload(mixed $reply, string $package, mixed $upgrader, array $hookExtra): mixed
    {
        if ($reply !== false) return $reply;
        $name = array_search((string) ($hookExtra['plugin'] ?? ''), self::PLUGINS, true);
        if ($name === false && ($hookExtra['theme'] ?? '') === self::THEME) $name = 'theme';
        if (!is_string($name)) return $reply;
        try {
            $manifest = $this->distribution->stable(true);
            $expected = (string) ($manifest['_downloads'][$name] ?? '');
            if ($expected === '' || !hash_equals($expected, $package)) {
                return new \WP_Error('pagecraft_importer_unsigned_update', __('This update is not the one in the signed Pagecraft release feed.', 'pagecraft-importer'));
            }
            return $this->installer->verifiedDownload($name, $manifest);
        } catch (Throwable $error) {
            return new \WP_Error('pagecraft_importer_update_failed', $error->getMessage());
        }
    }
}
