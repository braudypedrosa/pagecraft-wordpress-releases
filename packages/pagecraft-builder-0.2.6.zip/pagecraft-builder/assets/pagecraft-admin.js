(function () {
  'use strict';

  const output = document.querySelector('[data-pagecraft-output]');
  if (output) {
    const fail = (message) => {
      const status = output.querySelector('[data-output-status]');
      status.textContent = message;
      status.classList.add('is-error');
    };
    const config = window.PAGECRAFT_OUTPUT;
    if (!config || config.error) fail(config?.error || 'The site output checker is unavailable. Reload and try again.');
    else import(config.controllerUrl).then(module => module.mountOutputUpdater(output, config))
      .catch(() => fail('The site output checker could not load. Reload and try again.'));
  }

  // The Overview row keeps its plain sentence whenever the check cannot run.
  const outputSummary = document.querySelector('[data-pagecraft-output-summary]');
  if (outputSummary && window.PAGECRAFT_OUTPUT && !window.PAGECRAFT_OUTPUT.error) {
    import(window.PAGECRAFT_OUTPUT.controllerUrl)
      .then(module => module.mountOutputSummary(outputSummary, window.PAGECRAFT_OUTPUT))
      .catch(() => {});
  }

  const dialogs = new Map();
  const dialogOpeners = new WeakMap();
  const dialogFormMarkup = new WeakMap();
  document.querySelectorAll('.pagecraft-template-dialog[id]').forEach((dialog) => {
    dialogs.set(dialog.id, dialog);
    const form = dialog.querySelector('form');
    if (form) dialogFormMarkup.set(dialog, form.innerHTML);
    dialog.addEventListener('click', (event) => {
      if (event.target === dialog) dialog.close();
    });
    dialog.addEventListener('close', () => {
      const currentForm = dialog.querySelector('form');
      const initialMarkup = dialogFormMarkup.get(dialog);
      if (currentForm && typeof initialMarkup === 'string') currentForm.innerHTML = initialMarkup;
      const opener = dialogOpeners.get(dialog);
      if (opener instanceof HTMLElement) opener.focus();
    });
  });

  document.addEventListener('click', (event) => {
    const opener = event.target.closest('[data-pagecraft-dialog]');
    if (opener) {
      const dialog = dialogs.get(opener.getAttribute('data-pagecraft-dialog'));
      if (dialog && !dialog.open) {
        dialogOpeners.set(dialog, opener);
        dialog.showModal();
      }
      return;
    }
    const closer = event.target.closest('[data-pagecraft-dialog-close]');
    if (closer) {
      const dialog = closer.closest('dialog');
      if (dialog) dialog.close();
      return;
    }
    const add = event.target.closest('[data-condition-add]');
    if (add) {
      const list = add.previousElementSibling;
      const source = list && list.querySelector('[data-condition-row]');
      if (!source) return;
      const row = source.cloneNode(true);
      row.querySelectorAll('select').forEach((select, index) => {
        select.selectedIndex = index === 0 ? 0 : 0;
      });
      list.appendChild(row);
      const first = row.querySelector('select');
      if (first) first.focus();
      return;
    }
    const remove = event.target.closest('[data-condition-remove]');
    if (remove) {
      const row = remove.closest('[data-condition-row]');
      const list = row && row.parentElement;
      if (!row || !list) return;
      const rows = list.querySelectorAll('[data-condition-row]');
      if (rows.length === 1) {
        row.querySelectorAll('select').forEach((select) => { select.selectedIndex = 0; });
      } else {
        row.remove();
        const next = list.querySelector('[data-condition-row] select');
        if (next) next.focus();
      }
    }
  });

  document.addEventListener('submit', (event) => {
    const form = event.target.closest('[data-template-delete-form]');
    if (!form) return;
    const title = form.getAttribute('data-template-title') || 'this template';
    if (!window.confirm(`Move “${title}” to Trash?`)) event.preventDefault();
  });

  const templateEmpty = document.querySelector('[data-template-empty]');
  const templatePanels = Array.from(document.querySelectorAll('[data-template-panel]'));
  const bulkForm = document.querySelector('[data-template-bulk-form]');
  const bulkAction = document.querySelector('[data-template-bulk-action]');
  const bulkApply = document.querySelector('[data-template-bulk-apply]');
  const bulkCount = document.querySelector('[data-template-bulk-count]');
  const selectAllTemplates = document.querySelector('[data-template-select-all]');
  const templateSelectors = Array.from(document.querySelectorAll('[data-template-select]'));
  let templateFilterValue = 'all';
  const templateEmptyCopy = {
    all: ['No templates yet.', 'Create a template to get started.'],
    'site-parts': ['No site part templates yet.', 'Create a header or footer template.'],
    singular: ['No singular templates yet.', 'Create a page or post template.'],
    listings: ['No listing templates yet.', 'Create an archive or search template.'],
    system: ['No system templates yet.', 'Create a 404 template.'],
  };

  const visibleTemplateSelectors = () => templateSelectors.filter((checkbox) => {
    const row = checkbox.closest('[data-template-group]');
    return row && !row.hidden;
  });

  const updateBulkSelection = () => {
    const visible = visibleTemplateSelectors();
    const selected = templateSelectors.filter((checkbox) => checkbox.checked);
    const selectedVisible = visible.filter((checkbox) => checkbox.checked);
    templateSelectors.forEach((checkbox) => {
      const row = checkbox.closest('tr');
      if (row) row.classList.toggle('is-selected', checkbox.checked);
    });
    if (selectAllTemplates) {
      selectAllTemplates.disabled = visible.length === 0;
      selectAllTemplates.checked = visible.length > 0 && selectedVisible.length === visible.length;
      selectAllTemplates.indeterminate = selectedVisible.length > 0 && selectedVisible.length < visible.length;
    }
    if (bulkApply) bulkApply.disabled = selected.length === 0 || !bulkAction || bulkAction.value === '';
    if (bulkCount) bulkCount.textContent = selected.length > 0 ? `${selected.length} selected` : '';
  };

  const resetBulkSelection = () => {
    templateSelectors.forEach((checkbox) => { checkbox.checked = false; });
    updateBulkSelection();
  };

  if (selectAllTemplates) {
    selectAllTemplates.addEventListener('change', () => {
      visibleTemplateSelectors().forEach((checkbox) => { checkbox.checked = selectAllTemplates.checked; });
      updateBulkSelection();
    });
  }
  templateSelectors.forEach((checkbox) => checkbox.addEventListener('change', updateBulkSelection));
  if (bulkAction) bulkAction.addEventListener('change', updateBulkSelection);
  if (bulkForm) {
    bulkForm.addEventListener('submit', (event) => {
      const selected = templateSelectors.filter((checkbox) => checkbox.checked).length;
      const action = bulkAction ? bulkAction.value : '';
      if (selected === 0 || action === '') {
        event.preventDefault();
        return;
      }
      const messages = {
        publish: `Activate ${selected} ${selected === 1 ? 'template' : 'templates'}?`,
        draft: `Pause ${selected} ${selected === 1 ? 'template' : 'templates'}?`,
        trash: `Move ${selected} ${selected === 1 ? 'template' : 'templates'} to Trash?`,
      };
      if (!window.confirm(messages[action] || 'Apply this action?')) event.preventDefault();
    });
  }

  const updateTemplateEmpty = () => {
    if (!templateEmpty) return;
    const activePanel = templatePanels.find((panel) => !panel.hidden);
    const visibleRows = Array.from(activePanel ? activePanel.querySelectorAll('[data-template-group]') : [])
      .filter((row) => !row.hidden);
    templateEmpty.hidden = visibleRows.length > 0;
    const copy = templateEmptyCopy[templateFilterValue] || templateEmptyCopy.all;
    const title = templateEmpty.querySelector('[data-template-empty-title]');
    const description = templateEmpty.querySelector('[data-template-empty-copy]');
    if (title) title.textContent = copy[0];
    if (description) description.textContent = copy[1];
  };

  const applyTemplateFilter = (value) => {
    templateFilterValue = value;
    document.querySelectorAll('[data-template-group]').forEach((row) => {
      row.hidden = value !== 'all' && row.getAttribute('data-template-group') !== value;
    });
    resetBulkSelection();
    updateTemplateEmpty();
  };

  document.querySelectorAll('[data-template-filter]').forEach((filter) => {
    filter.addEventListener('click', () => {
      const value = filter.getAttribute('data-template-filter') || 'all';
      document.querySelectorAll('[data-template-filter]').forEach((item) => {
        const active = item === filter;
        item.classList.toggle('is-active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      applyTemplateFilter(value);
    });
  });

  const setTemplateView = (value, remember = true) => {
    const selected = value === 'table' ? 'table' : 'visual';
    document.querySelectorAll('[data-template-view]').forEach((button) => {
      const active = button.getAttribute('data-template-view') === selected;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    templatePanels.forEach((panel) => {
      panel.hidden = panel.getAttribute('data-template-panel') !== selected;
    });
    if (remember) {
      try { window.localStorage.setItem('pagecraft-template-view', selected); } catch (error) { /* no-op */ }
    }
    updateTemplateEmpty();
  };

  document.querySelectorAll('[data-template-view]').forEach((button) => {
    button.addEventListener('click', () => setTemplateView(button.getAttribute('data-template-view') || 'visual'));
  });

  let savedTemplateView = 'visual';
  try { savedTemplateView = window.localStorage.getItem('pagecraft-template-view') || 'visual'; } catch (error) { /* no-op */ }
  applyTemplateFilter('all');
  setTemplateView(savedTemplateView, false);

  const requested = new URLSearchParams(window.location.search).get('conditions');
  if (requested) {
    const dialog = dialogs.get(`pagecraft-conditions-${requested}`);
    if (dialog) dialog.showModal();
  }
}());

/* Console screens: toasts, row menus, controls that save on change, and the replacement in progress. */
(function () {
  'use strict';

  const screen = document.querySelector('.pagecraft-console');
  if (!screen) return;

  /* Result messages are printed in the page so they work without JavaScript; here they become toasts. */
  const toasts = Array.from(screen.querySelectorAll('.pagecraft-toast'));
  if (toasts.length) {
    const box = document.createElement('div');
    box.className = 'pagecraft-toasts';
    toasts.forEach((toast) => {
      const close = document.createElement('button');
      close.type = 'button';
      close.className = 'pagecraft-toast__close';
      close.setAttribute('aria-label', 'Dismiss');
      close.textContent = '×';
      close.addEventListener('click', () => toast.remove());
      toast.appendChild(close);
      box.appendChild(toast);
    });
    screen.appendChild(box);
    /* Confirmations leave by themselves; warnings and errors stay until dismissed. */
    const passing = toasts.filter(toast => toast.classList.contains('pagecraft-toast--success'));
    const leave = () => {
      if (box.matches(':hover') || box.contains(document.activeElement)) { window.setTimeout(leave, 2000); return; }
      passing.forEach(toast => toast.remove());
    };
    if (passing.length) window.setTimeout(leave, 6000);
    /* A reload should not show the same result again. */
    try {
      const url = new URL(window.location.href);
      const before = url.search;
      ['pagecraft_message', 'pagecraft_count', 'pagecraft_error', 'pagecraft_cloud_available'].forEach(key => url.searchParams.delete(key));
      if (url.search !== before) window.history.replaceState(null, '', url);
    } catch (error) { /* The address stays as it is. */ }
  }

  /* Only one row menu is open at a time; clicking away or pressing Escape closes it. */
  const menus = () => Array.from(screen.querySelectorAll('.pagecraft-more[open]'));
  document.addEventListener('click', (event) => {
    const inside = event.target.closest('.pagecraft-more');
    menus().forEach((menu) => { if (menu !== inside) menu.removeAttribute('open'); });
    if (inside && event.target.closest('[data-pagecraft-dialog]')) inside.removeAttribute('open');
  });
  /*
   * Tables scroll sideways, which also clips anything hanging below them. An open menu is placed
   * against the window instead, and flips above its button when there is no room underneath.
   */
  const placeMenu = (details) => {
    const menu = details.querySelector('.pagecraft-more__menu');
    const summary = details.querySelector('summary');
    if (!menu || !summary) return;
    if (!details.open) { menu.removeAttribute('style'); return; }
    const button = summary.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.right = 'auto';
    const size = menu.getBoundingClientRect();
    const below = button.bottom + 4;
    const top = below + size.height > window.innerHeight - 8 && button.top - 4 - size.height > 8
      ? button.top - 4 - size.height
      : below;
    menu.style.top = Math.round(top) + 'px';
    menu.style.left = Math.round(Math.max(8, button.right - size.width)) + 'px';
  };
  document.addEventListener('toggle', (event) => {
    if (event.target instanceof HTMLElement && event.target.matches('.pagecraft-more')) placeMenu(event.target);
  }, true);
  const closeMenus = () => menus().forEach((menu) => menu.removeAttribute('open'));
  window.addEventListener('scroll', closeMenus, true);
  window.addEventListener('resize', closeMenus);

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    menus().forEach((menu) => {
      menu.removeAttribute('open');
      const summary = menu.querySelector('summary');
      if (summary) summary.focus();
    });
  });

  screen.querySelectorAll('[data-pagecraft-autosubmit]').forEach((form) => {
    form.addEventListener('change', () => form.submit());
  });

  /* A replacement can take up to a minute: say so, and stop a second submit. */
  screen.querySelectorAll('form[data-pagecraft-working]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (form.classList.contains('is-working')) { event.preventDefault(); return; }
      form.classList.add('is-working');
      form.setAttribute('aria-busy', 'true');
    });
  });
})();
