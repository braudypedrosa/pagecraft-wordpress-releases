<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class Admin
{
    public const MENU_SLUG = 'pagecraft';
    public const EDITOR_SLUG = 'pagecraft-editor';
    private const MENU_ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 95 95"><path fill="#000" fill-rule="evenodd" d="M11 0h73v71H63l-6-6-6 6H29v6h22v18H11Zm18 18v59h22V53h15V18Z"/></svg>';

    public function register(): void
    {
        add_action('admin_menu', [$this, 'menus']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
        add_action('enqueue_block_editor_assets', [$this, 'blockEditorAssets']);
        add_action('wp_ajax_pagecraft_editor_frame', [$this, 'editorFrame']);
        add_action('wp_ajax_pagecraft_cloud_pages', [$this, 'cloudPages']);
        add_action('wp_ajax_pagecraft_cloud_import_page', [$this, 'cloudImportPage']);
        add_action('admin_post_pagecraft_prepare_page', [$this, 'preparePage']);
        add_action('admin_post_pagecraft_create_page', [$this, 'createPage']);
        add_action('admin_post_pagecraft_create_global', [$this, 'createGlobal']);
        add_action('admin_post_pagecraft_template_conditions', [$this, 'saveTemplateConditions']);
        add_action('admin_post_pagecraft_template_status', [$this, 'changeTemplateStatus']);
        add_action('admin_post_pagecraft_template_delete', [$this, 'deleteTemplate']);
        add_action('admin_post_pagecraft_template_bulk', [$this, 'bulkTemplateAction']);
        add_action('admin_post_pagecraft_preview_global', [$this, 'previewGlobal']);
        add_action('admin_post_pagecraft_cloud_start', [$this, 'cloudStart']);
        add_action('admin_post_pagecraft_cloud_check', [$this, 'cloudCheck']);
        add_action('admin_post_pagecraft_cloud_callback', [$this, 'cloudCallback']);
        add_action('admin_post_pagecraft_cloud_disconnect', [$this, 'cloudDisconnect']);
        add_action('admin_post_pagecraft_cloud_import', [$this, 'cloudImport']);
        add_action('admin_bar_menu', [$this, 'adminBarEditLink'], 90);
        add_filter('page_row_actions', [$this, 'rowActions'], 10, 2);
        add_filter('post_row_actions', [$this, 'globalRowActions'], 10, 2);
    }

    public function menus(): void
    {
        add_menu_page(
            __('Pagecraft', 'pagecraft-builder'),
            __('Pagecraft', 'pagecraft-builder'),
            Capabilities::EDIT,
            self::MENU_SLUG,
            [$this, 'overview'],
            $this->menuIcon(),
            25
        );
        add_submenu_page(self::MENU_SLUG, __('Overview', 'pagecraft-builder'), __('Overview', 'pagecraft-builder'),
            Capabilities::EDIT, self::MENU_SLUG, [$this, 'overview']);
        $unread = FormSubmissions::unreadCount();
        add_submenu_page(self::MENU_SLUG, __('Submissions', 'pagecraft-builder'), __('Submissions', 'pagecraft-builder')
            . ($unread > 0 ? ' <span class="awaiting-mod">' . esc_html(number_format_i18n($unread)) . '</span>' : ''),
            Capabilities::MANAGE, SubmissionsScreen::SLUG, [$this, 'submissions']);
        add_submenu_page(self::MENU_SLUG, __('Theme Builder', 'pagecraft-builder'), __('Theme Builder', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-globals', [$this, 'globals']);
        add_submenu_page(self::MENU_SLUG, __('Site Settings', 'pagecraft-builder'), __('Site Settings', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-site-settings', [$this, 'siteSettings']);
        add_submenu_page(self::MENU_SLUG, __('Pagecraft Cloud', 'pagecraft-builder'), __('Pagecraft Cloud', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-connect', [$this, 'connect']);
        add_submenu_page(self::MENU_SLUG, __('Status', 'pagecraft-builder'), __('Status', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-settings', [$this, 'settings']);
        add_submenu_page('options.php', __('Pagecraft Cloud', 'pagecraft-builder'), __('Pagecraft Cloud', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-import-export', [$this, 'connect']);
        add_submenu_page('options.php', __('Edit with Pagecraft', 'pagecraft-builder'), __('Edit with Pagecraft', 'pagecraft-builder'),
            Capabilities::EDIT, self::EDITOR_SLUG, [$this, 'editor']);
    }

    private function menuIcon(): string
    {
        return 'data:image/svg+xml;base64,' . base64_encode(self::MENU_ICON_SVG);
    }

    public function assets(string $hook): void
    {
        if (!str_contains($hook, 'pagecraft')) {
            return;
        }
        wp_enqueue_style(
            'pagecraft-builder-admin',
            PAGECRAFT_BUILDER_URL . 'assets/pagecraft-admin.css',
            [],
            $this->assetVersion('pagecraft-admin.css')
        );
        wp_enqueue_script(
            'pagecraft-builder-admin',
            PAGECRAFT_BUILDER_URL . 'assets/pagecraft-admin.js',
            [],
            $this->assetVersion('pagecraft-admin.js'),
            true
        );
        // Status checks and updates site output; the Overview only runs the same check.
        $checksOutput = str_contains($hook, 'pagecraft-settings') || $hook === 'toplevel_page_' . self::MENU_SLUG;
        if ($checksOutput && current_user_can(Capabilities::MANAGE) && current_user_can('edit_theme_options')) {
            try {
                $compiler = CompilerContract::current();
                $relative = 'compiler/' . $compiler->editorVersion . '-' . $compiler->rendererRevision . '/compiler.js';
                if (!is_file(PAGECRAFT_BUILDER_DIR . 'assets/' . $relative)) {
                    throw new PackageException('The sealed Pagecraft compiler is missing. Reinstall the Builder package.');
                }
                wp_localize_script('pagecraft-builder-admin', 'PAGECRAFT_OUTPUT', [
                    'restUrl' => untrailingslashit(rest_url(RestController::NAMESPACE)),
                    'nonce' => wp_create_nonce('wp_rest'),
                    'controllerUrl' => add_query_arg('ver', $this->assetVersion('pagecraft-generated-output.js'),
                        PAGECRAFT_BUILDER_URL . 'assets/pagecraft-generated-output.js'),
                    'compilerUrl' => PAGECRAFT_BUILDER_URL . 'assets/' . $relative,
                ]);
            } catch (PackageException $error) {
                wp_localize_script('pagecraft-builder-admin', 'PAGECRAFT_OUTPUT', ['error' => $error->getMessage()]);
            }
        }
    }

    private function assetVersion(string $name): string
    {
        $hash = hash_file('sha256', PAGECRAFT_BUILDER_DIR . 'assets/' . $name);
        return PAGECRAFT_BUILDER_VERSION . '-' . substr(is_string($hash) ? $hash : '', 0, 12);
    }

    public function blockEditorAssets(): void
    {
        $screen = get_current_screen();
        if (!$screen instanceof \WP_Screen || $screen->base !== 'post' || $screen->post_type !== 'page') {
            return;
        }

        global $post;
        $postId = $post instanceof \WP_Post ? (int) $post->ID : 0;
        if (($postId > 0 && !current_user_can('edit_post', $postId))
            || ($postId < 1 && !current_user_can('edit_pages'))
            || !current_user_can(Capabilities::EDIT)) {
            return;
        }

        wp_enqueue_style(
            'pagecraft-builder-block-editor',
            PAGECRAFT_BUILDER_URL . 'assets/pagecraft-block-editor.css',
            [],
            PAGECRAFT_BUILDER_VERSION
        );
        wp_enqueue_script(
            'pagecraft-builder-block-editor',
            PAGECRAFT_BUILDER_URL . 'assets/pagecraft-block-editor.js',
            ['wp-data'],
            PAGECRAFT_BUILDER_VERSION,
            true
        );
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only controls whether the user-requested chooser opens after Gutenberg loads.
        $openOnLoad = isset($_GET['pagecraft_choose']) && absint($_GET['pagecraft_choose']) === 1;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only selects the requested chooser view after OAuth returns.
        $openCloudOnLoad = isset($_GET['pagecraft_cloud']) && absint($_GET['pagecraft_cloud']) === 1;
        wp_localize_script('pagecraft-builder-block-editor', 'PAGECRAFT_BLOCK_EDITOR', [
            'postId' => $postId,
            'editorUrl' => $postId > 0 && ManagedPage::isManaged($postId) ? $this->editorUrl($postId) : '',
            'prepareUrl' => admin_url('admin-post.php'),
            'prepareNonce' => wp_create_nonce('pagecraft_prepare_page'),
            'cloudPagesUrl' => admin_url('admin-ajax.php?action=pagecraft_cloud_pages'),
            'cloudImportUrl' => admin_url('admin-ajax.php?action=pagecraft_cloud_import_page'),
            'cloudStartUrl' => admin_url('admin-post.php'),
            'cloudNonce' => wp_create_nonce('pagecraft_cloud_page'),
            'cloudStartNonce' => wp_create_nonce('pagecraft_cloud_start'),
            'openOnLoad' => $openOnLoad,
            'openCloudOnLoad' => $openCloudOnLoad,
            'templates' => $this->pageTemplates(),
            'labels' => [
                'button' => __('Edit with Pagecraft', 'pagecraft-builder'),
                'title' => __('Start with Pagecraft', 'pagecraft-builder'),
                'intro' => __('Choose how to begin.', 'pagecraft-builder'),
                'blank' => __('Blank Page', 'pagecraft-builder'),
                'blankDescription' => __('Start with a blank canvas.', 'pagecraft-builder'),
                'template' => __('Use a template', 'pagecraft-builder'),
                'templateDescription' => __('Choose a ready-made layout.', 'pagecraft-builder'),
                'templateTitle' => __('Choose a page template', 'pagecraft-builder'),
                'templateIntro' => __('Start with a complete Pagecraft page, then make every section your own.', 'pagecraft-builder'),
                'templateBack' => __('Back', 'pagecraft-builder'),
                'templateSearch' => __('Search templates', 'pagecraft-builder'),
                'templateFilter' => __('Filter templates', 'pagecraft-builder'),
                'templateAll' => __('All', 'pagecraft-builder'),
                'templateEmpty' => __('No matching templates.', 'pagecraft-builder'),
                'templatePreparing' => __('Preparing this template…', 'pagecraft-builder'),
                'cloud' => __('Import from Pagecraft Cloud', 'pagecraft-builder'),
                'cloudDescription' => __('Choose a page from Pagecraft Cloud.', 'pagecraft-builder'),
                'cloudTitle' => __('Choose a Cloud page', 'pagecraft-builder'),
                'cloudIntro' => __('Select a page to import into this WordPress page.', 'pagecraft-builder'),
                'cloudBack' => __('Back', 'pagecraft-builder'),
                'cloudLoading' => __('Loading your pages…', 'pagecraft-builder'),
                'cloudConnectTitle' => __('Connect your Pagecraft account', 'pagecraft-builder'),
                'cloudConnectDescription' => __('Connect to choose a page from Pagecraft Cloud.', 'pagecraft-builder'),
                'cloudConnectAction' => __('Connect Pagecraft account', 'pagecraft-builder'),
                'cloudEmpty' => __('No Cloud pages found.', 'pagecraft-builder'),
                'cloudEmptyDescription' => __('Create a page in Pagecraft Cloud, then try again.', 'pagecraft-builder'),
                'cloudSearch' => __('Search pages', 'pagecraft-builder'),
                'cloudNoResults' => __('No matching pages.', 'pagecraft-builder'),
                'cloudRetry' => __('Try again', 'pagecraft-builder'),
                'cloudLoadError' => __('Pagecraft Cloud could not load your pages. Try again.', 'pagecraft-builder'),
                'cloudImporting' => __('Importing this page…', 'pagecraft-builder'),
                'cloudImportError' => __('WordPress could not import this page. Try again.', 'pagecraft-builder'),
                'close' => __('Close', 'pagecraft-builder'),
                'untitled' => __('Untitled page', 'pagecraft-builder'),
                'saving' => __('Saving this page…', 'pagecraft-builder'),
                'error' => __('WordPress could not save this page. Try again.', 'pagecraft-builder'),
            ],
        ]);
    }

    /**
     * Every Pagecraft screen is one sheet: the bar, then a header (title, one sentence, actions),
     * then that screen's toolbar and tables.
     *
     * @param array{classes?:string,badge?:string,badgeState?:string,actions?:callable,before?:callable} $options
     */
    private function adminPageStart(string $active, string $title, string $description, array $options = []): void
    {
        $className = trim('wrap pagecraft-admin pagecraft-admin--shell pagecraft-console ' . ($options['classes'] ?? ''));
        echo '<div class="' . esc_attr($className) . '"><div class="pagecraft-admin-shell">'
            . '<header class="pagecraft-admin-nav"><a class="pagecraft-admin-nav__brand" href="'
            . esc_url(admin_url('admin.php?page=' . self::MENU_SLUG)) . '">'
            . '<svg viewBox="0 0 95 95" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" d="M11 0h73v71H63l-6-6-6 6H29v6h22v18H11Zm18 18v59h22V53h15V18Z"/></svg>'
            . '<span>' . esc_html__('Pagecraft', 'pagecraft-builder') . '</span></a>';
        $this->adminNavigation($active);
        echo '</header><main class="pagecraft-admin__content">';
        if (isset($options['before'])) {
            ($options['before'])();
        }
        echo '<div class="pagecraft-admin__mast"><div class="pagecraft-admin__title"><h1>' . esc_html($title);
        if (($options['badge'] ?? '') !== '') {
            echo ' <span class="pagecraft-state pagecraft-state--' . esc_attr($options['badgeState'] ?? 'ok') . '">'
                . esc_html($options['badge']) . '</span>';
        }
        echo '</h1>' . ($description !== '' ? '<p>' . esc_html($description) . '</p>' : '') . '</div>';
        if (isset($options['actions'])) {
            echo '<div class="pagecraft-admin__mast-actions">';
            ($options['actions'])();
            echo '</div>';
        }
        echo '</div>';
    }

    private function adminNavigation(string $active): void
    {
        $groups = [
            __('Workspace', 'pagecraft-builder') => [
                ['overview', __('Overview', 'pagecraft-builder'), admin_url('admin.php?page=' . self::MENU_SLUG), 0],
            ],
        ];
        if (current_user_can(Capabilities::MANAGE)) {
            $groups[__('Workspace', 'pagecraft-builder')][] = ['submissions', __('Submissions', 'pagecraft-builder'), SubmissionsScreen::url(), FormSubmissions::unreadCount()];
            $groups[__('Design', 'pagecraft-builder')] = [
                ['globals', __('Theme Builder', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-globals'), 0],
                ['site-settings', __('Site Settings', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-site-settings'), 0],
            ];
            $groups[__('Transfer', 'pagecraft-builder')] = [
                ['cloud', __('Pagecraft Cloud', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-connect'), 0],
            ];
            $groups[__('System', 'pagecraft-builder')] = [
                ['settings', __('Status', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-settings'), 0],
            ];
        }

        echo '<nav class="pagecraft-admin-nav__menu" aria-label="' . esc_attr__('Pagecraft administration', 'pagecraft-builder') . '">';
        foreach ($groups as $label => $items) {
            // The group names divide the bar visually and are read out to screen readers.
            echo '<div class="pagecraft-admin-nav__group"><span class="pagecraft-admin-nav__label screen-reader-text">' . esc_html($label) . '</span>';
            foreach ($items as [$id, $itemLabel, $url, $count]) {
                $isActive = hash_equals($active, $id);
                echo '<a class="pagecraft-admin-nav__item' . ($isActive ? ' is-active' : '') . '" href="'
                    . esc_url($url) . '"' . ($isActive ? ' aria-current="page"' : '') . '><span>' . esc_html($itemLabel) . '</span>';
                if ($count > 0) {
                    echo '<span class="pagecraft-admin-nav__count" aria-label="'
                        . esc_attr(sprintf(_n('%d unread', '%d unread', $count, 'pagecraft-builder'), $count)) . '">'
                        . esc_html(number_format_i18n($count)) . '</span>';
                }
                echo '</a>';
            }
            echo '</div>';
        }
        echo '</nav>';
        /* translators: %s: Pagecraft Builder version number. */
        echo '<span class="pagecraft-admin-nav__version">' . esc_html(sprintf(__('Builder %s', 'pagecraft-builder'), PAGECRAFT_BUILDER_VERSION)) . '</span>';
    }

    private function adminPageEnd(): void
    {
        echo '</main></div></div>';
    }

    /** A result message. With JavaScript it becomes a toast; without, it is a line at the top of the sheet. */
    private function toast(string $message, string $kind = 'success', string $title = ''): void
    {
        echo '<div class="pagecraft-toast pagecraft-toast--' . esc_attr($kind) . '" role="' . ($kind === 'error' ? 'alert' : 'status') . '"><p>'
            . ($title !== '' ? '<strong>' . esc_html($title) . '</strong> ' : '') . esc_html($message) . '</p></div>';
    }

    public function submissions(): void
    {
        $this->guard(Capabilities::MANAGE);
        $header = SubmissionsScreen::header();
        $this->adminPageStart('submissions', $header['title'], $header['description'], $header['options']);
        SubmissionsScreen::render();
        $this->adminPageEnd();
    }

    public function overview(): void
    {
        $this->guard(Capabilities::EDIT);
        $this->adminPageStart(
            'overview',
            __('Pagecraft', 'pagecraft-builder'),
            __('Create and manage Pagecraft designs. Start designing by creating a new Pagecraft page.', 'pagecraft-builder'),
            ['actions' => function (): void {
                echo '<a class="button button-primary" href="'
                    . esc_url(add_query_arg('pagecraft_choose', '1', admin_url('post-new.php?post_type=page'))) . '">'
                    . esc_html__('Add New with Pagecraft', 'pagecraft-builder') . '</a><a class="button" href="'
                    . esc_url($this->pagesUrl()) . '">' . esc_html__('View all pages', 'pagecraft-builder') . '</a>';
            }]
        );
        if (current_user_can(Capabilities::MANAGE)) {
            $unread = FormSubmissions::unreadCount();
            $globalCount = count(GlobalElement::all());
            $cloudConnected = (new CloudImport())->connection() !== null;
            $checksOutput = current_user_can('edit_theme_options');
            // What the last site output check found. The page script checks again and corrects this row.
            $outdated = $checksOutput ? absint(get_user_setting('pagecraft_output_stale', '0')) : 0;
            echo '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-table--facts"><tbody>';
            $this->overviewBand(__('Needs attention', 'pagecraft-builder'), 'attention', $unread === 0 && $outdated === 0);
            if ($unread > 0) {
                $this->overviewRow(
                    __('Submissions', 'pagecraft-builder'),
                    sprintf(_n('%d unread entry', '%d unread entries', $unread, 'pagecraft-builder'), $unread),
                    __('Open inbox', 'pagecraft-builder'),
                    SubmissionsScreen::url()
                );
                SubmissionsScreen::newestUnreadRows(3);
            }
            if ($outdated > 0) {
                $this->overviewOutputRow($checksOutput, $outdated);
            }
            $this->overviewBand(__('Site', 'pagecraft-builder'), 'site');
            $this->overviewRow(
                __('Theme Builder', 'pagecraft-builder'),
                sprintf(_n('%d site template', '%d site templates', $globalCount, 'pagecraft-builder'), $globalCount),
                __('Open Theme Builder', 'pagecraft-builder'),
                admin_url('admin.php?page=pagecraft-globals')
            );
            $this->overviewRow(
                __('Site Settings', 'pagecraft-builder'),
                __('Colours, fonts and styles used across Pagecraft pages.', 'pagecraft-builder'),
                __('Open Site Settings', 'pagecraft-builder'),
                admin_url('admin.php?page=pagecraft-site-settings')
            );
            $this->overviewRow(
                __('Pagecraft Cloud', 'pagecraft-builder'),
                $cloudConnected ? __('Connected', 'pagecraft-builder') : __('Not connected', 'pagecraft-builder'),
                $cloudConnected ? __('Choose a project', 'pagecraft-builder') : __('Open Pagecraft Cloud', 'pagecraft-builder'),
                admin_url('admin.php?page=pagecraft-connect')
            );
            if ($outdated === 0) {
                $this->overviewOutputRow($checksOutput, 0);
            }
            echo '</tbody></table></div>';
        }
        $this->adminPageEnd();
    }

    /** A band stays in the page when it is empty, hidden, so the page script can fill it. */
    private function overviewBand(string $label, string $id, bool $hidden = false): void
    {
        echo '<tr class="pagecraft-table__band" data-overview-band="' . esc_attr($id) . '"' . ($hidden ? ' hidden' : '')
            . '><th scope="colgroup" colspan="3">' . esc_html($label) . '</th></tr>';
    }

    private function overviewRow(string $name, string $value, string $linkLabel, string $url): void
    {
        echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html($name) . '</th><td>' . esc_html($value)
            . '</td><td class="pagecraft-table__end"><a href="' . esc_url($url) . '">' . esc_html($linkLabel) . '</a></td></tr>';
    }

    /**
     * Outdated site output is listed under "Needs attention"; otherwise it is the last row of "Site".
     * Where the person may maintain site output, the page script runs the same check as the Status
     * screen, then corrects this row's text and place.
     */
    private function overviewOutputRow(bool $checksOutput, int $outdated): void
    {
        $one = __('1 page or template needs updating', 'pagecraft-builder');
        /* translators: %d: number of pages and templates. */
        $many = __('%d pages and templates need updating', 'pagecraft-builder');
        echo '<tr' . ($checksOutput ? ' data-pagecraft-output-summary data-stale-one="' . esc_attr($one) . '" data-stale-many="'
            . esc_attr($many) . '" data-current="' . esc_attr__('Up to date', 'pagecraft-builder') . '"' : '')
            . '><th scope="row" class="pagecraft-table__key">' . esc_html__('Site output', 'pagecraft-builder')
            . '</th><td data-output-summary-text aria-live="polite">' . esc_html(match (true) {
                $outdated === 1 => $one,
                $outdated > 1 => sprintf($many, $outdated),
                default => __('Check whether generated pages and templates match this editor.', 'pagecraft-builder'),
            }) . '</td><td class="pagecraft-table__end"><a href="' . esc_url(admin_url('admin.php?page=pagecraft-settings')) . '">'
            . esc_html__('Open Status', 'pagecraft-builder') . '</a></td></tr>';
    }

    public function globals(): void
    {
        $this->guard(Capabilities::MANAGE);
        $this->adminPageStart(
            'globals',
            __('Theme Builder', 'pagecraft-builder'),
            __('Create templates for different parts of your WordPress site.', 'pagecraft-builder'),
            ['classes' => 'pagecraft-theme-builder', 'actions' => static function (): void {
                echo '<button type="button" class="button button-primary" data-pagecraft-dialog="pagecraft-new-template">'
                    . esc_html__('New template', 'pagecraft-builder') . '</button>';
            }]
        );
        $this->noticeFromQuery();

        /* One pass over the templates: both views, the filter counts and the dialogs use the same facts. */
        $templates = [];
        $counts = ['all' => 0, 'site-parts' => 0, 'singular' => 0, 'listings' => 0, 'system' => 0];
        $activeCount = 0;
        foreach (GlobalElement::all() as $global) {
            $kind = (string) get_post_meta((int) $global->ID, GlobalElement::KIND, true);
            if (!in_array($kind, GlobalElement::kinds(), true)) continue;
            $rules = (string) get_post_meta((int) $global->ID, TemplateConditions::META, true);
            if ($rules === '') $rules = TemplateConditions::encode(TemplateConditions::defaults($kind));
            $active = get_post_status($global) === 'publish';
            $group = GlobalElement::group($kind);
            $counts['all']++;
            if (isset($counts[$group])) $counts[$group]++;
            if ($active) $activeCount++;
            $templates[] = [
                'post' => $global, 'kind' => $kind, 'group' => $group, 'rules' => $rules, 'active' => $active,
                'title' => get_the_title($global),
                'hasDocument' => (string) get_post_meta((int) $global->ID, GlobalElement::DOCUMENT, true) !== '',
                'preview' => wp_nonce_url(
                    admin_url('admin-post.php?action=pagecraft_preview_global&global=' . (int) $global->ID),
                    'pagecraft_preview_global_' . (int) $global->ID
                ),
            ];
        }

        echo '<section class="pagecraft-template-workbench" aria-label="' . esc_attr__('Templates', 'pagecraft-builder')
            . '"><div class="pagecraft-toolbar pagecraft-template-toolbar"><div class="pagecraft-template-filters" role="group" aria-label="'
            . esc_attr__('Filter templates', 'pagecraft-builder') . '">';
        foreach ([
            'all' => __('All', 'pagecraft-builder'),
            'site-parts' => __('Site parts', 'pagecraft-builder'),
            'singular' => __('Singular', 'pagecraft-builder'),
            'listings' => __('Listings', 'pagecraft-builder'),
            'system' => __('System', 'pagecraft-builder'),
        ] as $filter => $label) {
            echo '<button type="button" class="pagecraft-chip pagecraft-template-filter' . ($filter === 'all' ? ' is-active' : '')
                . '" data-template-filter="' . esc_attr($filter) . '" aria-pressed="' . ($filter === 'all' ? 'true' : 'false') . '">'
                . esc_html($label) . '<span class="pagecraft-chip__count">' . esc_html(number_format_i18n($counts[$filter])) . '</span></button>';
        }
        echo '</div><div class="pagecraft-template-ledger__tools">';
        if ($templates !== []) {
            echo '<span class="pagecraft-toolbar__facts">' . esc_html(sprintf(
                /* translators: 1: number of active templates, 2: number of draft templates */
                __('%1$d active · %2$d draft', 'pagecraft-builder'),
                $activeCount,
                count($templates) - $activeCount
            )) . '</span>';
        }
        echo '<div class="pagecraft-template-view-switch" role="group" aria-label="'
            . esc_attr__('Template view', 'pagecraft-builder') . '"><button type="button" class="pagecraft-template-view is-active" data-template-view="visual" aria-pressed="true"><span>'
            . esc_html__('Visual', 'pagecraft-builder') . '</span></button><button type="button" class="pagecraft-template-view" data-template-view="table" aria-pressed="false"><span>'
            . esc_html__('Table', 'pagecraft-builder') . '</span></button></div></div></div><div class="pagecraft-template-ledger">';

        /* Visual: the live preview and one line of facts. Type and conditions are not repeated as columns. */
        echo '<div class="pagecraft-table-scroll" data-template-panel="visual"><table class="pagecraft-table pagecraft-table--previews"><thead><tr><th scope="col">'
            . esc_html__('Template', 'pagecraft-builder') . '</th><th scope="col">' . esc_html__('Status', 'pagecraft-builder')
            . '</th><th scope="col" class="pagecraft-table__wide-only">' . esc_html__('Updated', 'pagecraft-builder')
            . '</th><th scope="col" class="pagecraft-table__end"><span class="screen-reader-text">' . esc_html__('Actions', 'pagecraft-builder') . '</span></th></tr></thead><tbody>';
        foreach ($templates as $template) {
            $global = $template['post'];
            echo '<tr class="pagecraft-template-row" data-template-group="' . esc_attr($template['group']) . '"><th scope="row"><div class="pagecraft-template-row__lead">'
                . '<div class="pagecraft-template-preview pagecraft-template-preview--' . esc_attr($template['kind']) . '">';
            if ($template['hasDocument']) {
                // A thumbnail is a still picture: it runs no scripts, so it asks for a page without any.
                echo '<iframe tabindex="-1" aria-hidden="true" sandbox="allow-same-origin" src="'
                    . esc_url(add_query_arg('thumbnail', '1', $template['preview'])) . '"></iframe>';
            } else {
                echo '<span>' . esc_html__('No preview', 'pagecraft-builder') . '</span>';
            }
            echo '</div><div class="pagecraft-template-row__body"><strong>' . esc_html($template['title']) . '</strong><small><span class="pagecraft-template-kind">'
                . esc_html(GlobalElement::label($template['kind'])) . '</span><span aria-hidden="true"> · </span>'
                . esc_html($this->templateConditionSummary($template['rules'])) . '</small></div></div></th><td>';
            $this->templateState($template['active']);
            echo '</td><td class="pagecraft-table__muted pagecraft-table__wide-only">'
                . esc_html(get_post_modified_time(get_option('date_format'), false, $global)) . '</td><td class="pagecraft-table__end">';
            $this->templateActions($global, $template['active'], $template['hasDocument'], $template['preview']);
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';

        echo '<div class="pagecraft-template-table-wrap" data-template-panel="table" hidden><form id="pagecraft-template-bulk-form" class="pagecraft-toolbar pagecraft-template-bulk" action="'
            . esc_url(admin_url('admin-post.php')) . '" method="post" data-template-bulk-form>';
        wp_nonce_field('pagecraft_template_bulk');
        echo '<input type="hidden" name="action" value="pagecraft_template_bulk"><label class="screen-reader-text" for="pagecraft-template-bulk-action">'
            . esc_html__('Bulk action', 'pagecraft-builder') . '</label><select id="pagecraft-template-bulk-action" name="bulk_action" data-template-bulk-action>'
            . '<option value="">' . esc_html__('Bulk actions', 'pagecraft-builder') . '</option><option value="publish">'
            . esc_html__('Activate', 'pagecraft-builder') . '</option><option value="draft">'
            . esc_html__('Pause', 'pagecraft-builder') . '</option><option value="trash">'
            . esc_html__('Move to Trash', 'pagecraft-builder') . '</option></select><button class="button" data-template-bulk-apply disabled>'
            . esc_html__('Apply', 'pagecraft-builder') . '</button><span class="pagecraft-template-bulk__count" data-template-bulk-count aria-live="polite"></span></form>'
            . '<div class="pagecraft-table-scroll pagecraft-template-table-scroll"><table class="pagecraft-table pagecraft-template-table"><thead><tr><th scope="col" class="pagecraft-template-table__check"><input type="checkbox" data-template-select-all aria-label="'
            . esc_attr__('Select all templates', 'pagecraft-builder') . '"></th><th scope="col">'
            . esc_html__('Template', 'pagecraft-builder') . '</th><th scope="col">'
            . esc_html__('Type', 'pagecraft-builder') . '</th><th scope="col" class="pagecraft-table__wide-only">'
            . esc_html__('Display conditions', 'pagecraft-builder') . '</th><th scope="col">'
            . esc_html__('Status', 'pagecraft-builder') . '</th><th scope="col" class="pagecraft-table__wide-only">'
            . esc_html__('Updated', 'pagecraft-builder') . '</th><th scope="col" class="pagecraft-table__end"><span class="screen-reader-text">'
            . esc_html__('Actions', 'pagecraft-builder') . '</span></th></tr></thead><tbody>';
        foreach ($templates as $template) {
            $global = $template['post'];
            $summary = $this->templateConditionSummary($template['rules']);
            echo '<tr data-template-group="' . esc_attr($template['group']) . '"><td class="pagecraft-template-table__check"><input type="checkbox" name="templates[]" value="'
                . esc_attr((string) $global->ID) . '" form="pagecraft-template-bulk-form" data-template-select aria-label="'
                . esc_attr(sprintf(__('Select %s', 'pagecraft-builder'), $template['title'])) . '"></td><th scope="row"><strong>'
                . esc_html($template['title']) . '</strong><small class="pagecraft-table__narrow-only">' . esc_html($summary) . '</small></th><td>'
                . esc_html(GlobalElement::label($template['kind'])) . '</td><td class="pagecraft-table__wide-only">' . esc_html($summary) . '</td><td>';
            $this->templateState($template['active']);
            echo '</td><td class="pagecraft-table__muted pagecraft-table__wide-only">'
                . esc_html(get_post_modified_time(get_option('date_format'), false, $global)) . '</td><td class="pagecraft-table__end">';
            $this->templateActions($global, $template['active'], $template['hasDocument'], $template['preview']);
            echo '</td></tr>';
        }
        echo '</tbody></table></div></div>';
        echo '<div class="pagecraft-empty pagecraft-template-empty" data-template-empty' . ($templates !== [] ? ' hidden' : '') . '>'
            . '<strong data-template-empty-title>'
            . esc_html__('No templates yet.', 'pagecraft-builder') . '</strong><p data-template-empty-copy>'
            . esc_html__('Create a template to get started.', 'pagecraft-builder') . '</p></div>';
        foreach ($templates as $template) {
            $this->templateConditionsDialog($template['post'], $template['rules']);
        }
        echo '</div></section>';
        $this->newTemplateDialog();
        $this->adminPageEnd();
    }

    private function templateState(bool $active): void
    {
        echo '<span class="pagecraft-template-state pagecraft-state pagecraft-state--' . ($active ? 'ok is-active' : 'off') . '">'
            . esc_html($active ? __('Active', 'pagecraft-builder') : __('Draft', 'pagecraft-builder')) . '</span>';
    }

    /** The one action people come for stays on the row; the rest is in the row's menu. */
    private function templateActions(\WP_Post $global, bool $active, bool $hasDocument, string $preview): void
    {
        $postId = (int) $global->ID;
        $title = get_the_title($global);
        echo '<div class="pagecraft-row-actions"><a class="button" href="' . esc_url($this->globalEditorUrl($postId)) . '">'
            . esc_html($hasDocument ? __('Edit design', 'pagecraft-builder') : __('Start designing', 'pagecraft-builder')) . '</a>'
            . '<details class="pagecraft-more"><summary aria-label="'
            /* translators: %s: template name */
            . esc_attr(sprintf(__('More actions for %s', 'pagecraft-builder'), $title)) . '"><span aria-hidden="true">⋯</span></summary><div class="pagecraft-more__menu">'
            . '<button type="button" data-pagecraft-dialog="pagecraft-conditions-' . esc_attr((string) $postId) . '">'
            . esc_html__('Conditions', 'pagecraft-builder') . '</button>';
        if ($hasDocument) {
            echo '<a target="_blank" rel="noopener" href="' . esc_url($preview) . '">' . esc_html__('Preview', 'pagecraft-builder') . '</a>';
        }
        echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
        wp_nonce_field('pagecraft_template_status_' . $postId);
        echo '<input type="hidden" name="action" value="pagecraft_template_status"><input type="hidden" name="template" value="'
            . esc_attr((string) $postId) . '"><input type="hidden" name="status" value="' . ($active ? 'draft' : 'publish') . '">'
            . '<button' . (!$active && !$hasDocument ? ' disabled title="' . esc_attr__('Design and save this template before activation.', 'pagecraft-builder') . '"' : '') . '>'
            . esc_html($active ? __('Pause', 'pagecraft-builder') : __('Activate', 'pagecraft-builder')) . '</button></form>';
        echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post" data-template-delete-form data-template-title="'
            . esc_attr($title) . '">';
        wp_nonce_field('pagecraft_template_delete_' . $postId);
        echo '<input type="hidden" name="action" value="pagecraft_template_delete"><input type="hidden" name="template" value="'
            . esc_attr((string) $postId) . '"><button class="pagecraft-more__danger">'
            . esc_html__('Delete', 'pagecraft-builder') . '</button></form></div></details></div>';
    }

    private function newTemplateDialog(): void
    {
        echo '<dialog class="pagecraft-template-dialog" id="pagecraft-new-template"><form action="'
            . esc_url(admin_url('admin-post.php')) . '" method="post"><div class="pagecraft-template-dialog__head"><div><h2>' . esc_html__('New template', 'pagecraft-builder')
            . '</h2></div><button type="button" class="pagecraft-dialog-close" data-pagecraft-dialog-close aria-label="'
            . esc_attr__('Close', 'pagecraft-builder') . '">' . wp_kses(self::closeIcon(), self::iconAllowedHtml()) . '</button></div>';
        wp_nonce_field('pagecraft_create_global');
        echo '<input type="hidden" name="action" value="pagecraft_create_global"><label class="pagecraft-template-title"><span>'
            . esc_html__('Template name', 'pagecraft-builder') . '</span><input type="text" name="title" required maxlength="120" placeholder="'
            . esc_attr__('e.g. Blog post', 'pagecraft-builder') . '"></label><fieldset class="pagecraft-template-types"><legend>'
            . esc_html__('Template type', 'pagecraft-builder') . '</legend>';
        foreach (GlobalElement::kinds() as $index => $kind) {
            echo '<label><input type="radio" name="kind" value="' . esc_attr($kind) . '"' . ($index === 0 ? ' checked' : '') . '><span><b>'
                . esc_html(GlobalElement::label($kind)) . '</b><small>' . esc_html($this->templateKindDescription($kind)) . '</small></span></label>';
        }
        echo '</fieldset><footer><button type="button" class="button" data-pagecraft-dialog-close>'
            . esc_html__('Cancel', 'pagecraft-builder') . '</button><button class="button button-primary">'
            . esc_html__('Create template', 'pagecraft-builder') . '</button></footer></form></dialog>';
    }

    private function templateConditionsDialog(\WP_Post $global, string $rulesJson): void
    {
        $kind = (string) get_post_meta((int) $global->ID, GlobalElement::KIND, true);
        $rules = TemplateConditions::normalize($rulesJson);
        if ($rules === []) $rules = TemplateConditions::defaults($kind);
        $options = $this->templateConditionOptions($kind);
        echo '<dialog class="pagecraft-template-dialog pagecraft-template-dialog--conditions" id="pagecraft-conditions-'
            . esc_attr((string) $global->ID) . '"><form action="' . esc_url(admin_url('admin-post.php')) . '" method="post"><div class="pagecraft-template-dialog__head"><div><h2>'
            . esc_html__('Display conditions', 'pagecraft-builder') . '</h2><p>' . esc_html(get_the_title($global))
            . '</p></div><button type="button" class="pagecraft-dialog-close" data-pagecraft-dialog-close aria-label="'
            . esc_attr__('Close', 'pagecraft-builder') . '">' . wp_kses(self::closeIcon(), self::iconAllowedHtml()) . '</button></div>';
        wp_nonce_field('pagecraft_template_conditions_' . (int) $global->ID);
        echo '<input type="hidden" name="action" value="pagecraft_template_conditions"><input type="hidden" name="template" value="'
            . esc_attr((string) $global->ID) . '"><div class="pagecraft-condition-list" data-condition-list>';
        foreach ($rules as $rule) {
            $target = $rule['type'] . ($rule['value'] !== '' ? ':' . $rule['value'] : '');
            $this->templateConditionRow($options, $rule['action'], $target);
        }
        echo '</div><button type="button" class="pagecraft-condition-add" data-condition-add>' . wp_kses(self::plusIcon(), self::iconAllowedHtml()) . '<span>'
            . esc_html__('Add condition', 'pagecraft-builder') . '</span></button><label class="pagecraft-template-priority"><span><b>'
            . esc_html__('Priority', 'pagecraft-builder') . '</b><small>'
            . esc_html__('Used when two templates have the same conditions.', 'pagecraft-builder') . '</small></span><input type="number" min="-100" max="100" name="priority" value="'
            . esc_attr((string) (int) get_post_meta((int) $global->ID, TemplateConditions::PRIORITY, true)) . '"></label><footer><button type="button" class="button" data-pagecraft-dialog-close>'
            . esc_html__('Cancel', 'pagecraft-builder') . '</button><button class="button button-primary">'
            . esc_html__('Save conditions', 'pagecraft-builder') . '</button></footer></form></dialog>';
    }

    /** @param array<string,string> $options */
    private function templateConditionRow(array $options, string $action = 'include', string $target = 'site'): void
    {
        echo '<div class="pagecraft-condition-row" data-condition-row><select name="condition_action[]" aria-label="'
            . esc_attr__('Condition action', 'pagecraft-builder') . '"><option value="include"' . selected($action, 'include', false) . '>'
            . esc_html__('Include', 'pagecraft-builder') . '</option><option value="exclude"' . selected($action, 'exclude', false) . '>'
            . esc_html__('Exclude', 'pagecraft-builder') . '</option></select><select name="condition_target[]" aria-label="'
            . esc_attr__('Condition target', 'pagecraft-builder') . '">';
        foreach ($options as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($target, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select><button type="button" class="pagecraft-condition-remove" data-condition-remove aria-label="'
            . esc_attr__('Remove condition', 'pagecraft-builder') . '">' . wp_kses(self::closeIcon(), self::iconAllowedHtml()) . '</button></div>';
    }

    /** @return array<string,string> */
    private function templateConditionOptions(string $kind): array
    {
        $sitePart = in_array($kind, ['header', 'footer'], true);
        $options = match ($kind) {
            'single_page' => [],
            'single_post' => ['singular' => __('All posts and custom post types', 'pagecraft-builder')],
            'archive' => ['archive' => __('All archives', 'pagecraft-builder')],
            'search' => ['search' => __('Search results', 'pagecraft-builder')],
            'not_found' => ['not_found' => __('404 page', 'pagecraft-builder')],
            default => [
                'site' => __('Entire site', 'pagecraft-builder'),
                'singular' => __('All posts and pages', 'pagecraft-builder'),
                'archive' => __('All archives', 'pagecraft-builder'),
                'search' => __('Search results', 'pagecraft-builder'),
                'not_found' => __('404 page', 'pagecraft-builder'),
            ],
        };
        $postTypes = get_post_types(['public' => true, 'show_in_nav_menus' => true], 'objects');
        foreach ($postTypes as $type) {
            if ($type->name === 'attachment') continue;
            $name = (string) $type->name;
            $label = (string) ($type->labels->name ?? $type->label);
            if ($sitePart || ($kind === 'single_page' && $name === 'page') || ($kind === 'single_post' && $name !== 'page')) {
                $options['post_type:' . $name] = sprintf(__('All %s', 'pagecraft-builder'), $label);
            }
            if (($sitePart || $kind === 'archive') && ((bool) $type->has_archive || $name === 'post')) {
                $options['post_type_archive:' . $name] = sprintf(__('%s archive', 'pagecraft-builder'), $label);
            }
        }
        if ($sitePart || $kind === 'archive') foreach (get_taxonomies(['public' => true], 'objects') as $taxonomy) {
            $name = (string) $taxonomy->name;
            $label = (string) ($taxonomy->labels->name ?? $taxonomy->label);
            $options['taxonomy:' . $name] = sprintf(__('All %s archives', 'pagecraft-builder'), $label);
            $terms = get_terms(['taxonomy' => $name, 'hide_empty' => false, 'number' => 50]);
            if (is_wp_error($terms)) continue;
            foreach ($terms as $term) {
                $options['term:' . $name . ':' . (int) $term->term_id] = $label . ': ' . (string) $term->name;
            }
        }
        $exactTypes = array_values(array_filter(array_keys($postTypes), static function (string $name) use ($kind, $sitePart): bool {
            return $name !== 'attachment' && ($sitePart || ($kind === 'single_page' && $name === 'page') || ($kind === 'single_post' && $name !== 'page'));
        }));
        foreach (get_posts([
            'post_type' => $exactTypes === [] ? ['__none__'] : $exactTypes,
            'post_status' => ['publish', 'draft', 'private'],
            'posts_per_page' => 100,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]) as $post) {
            if ($kind === 'single_page' && ManagedPage::isManaged((int) $post->ID)) continue;
            $title = get_the_title($post);
            $options['post:' . (int) $post->ID] = sprintf(__('%1$s: %2$s', 'pagecraft-builder'), ucfirst((string) $post->post_type), $title !== '' ? $title : __('Untitled', 'pagecraft-builder'));
        }
        return $options;
    }

    private function templateConditionSummary(mixed $rules): string
    {
        $parts = [];
        foreach (TemplateConditions::normalize($rules) as $rule) {
            if ($rule['type'] !== 'post') {
                $parts[] = TemplateConditions::summary([$rule]);
                continue;
            }
            $parts[] = ($rule['action'] === 'exclude' ? 'Except ' : '')
                . $this->exactContentConditionLabel($rule['value']);
        }
        return $parts === [] ? 'No display conditions' : implode(' · ', $parts);
    }

    private function exactContentConditionLabel(string $value): string
    {
        $postId = absint($value);
        $post = $postId > 0 ? get_post($postId) : null;
        if (!$post instanceof \WP_Post) {
            return sprintf(__('Deleted content #%d', 'pagecraft-builder'), $postId);
        }

        $postType = get_post_type_object((string) $post->post_type);
        $typeLabel = is_object($postType) ? trim((string) $postType->labels->singular_name) : '';
        if ($typeLabel === '' && is_object($postType)) {
            $typeLabel = trim((string) $postType->label);
        }
        if ($typeLabel === '') {
            $typeLabel = ucwords(str_replace(['_', '-'], ' ', (string) $post->post_type));
        }
        $title = trim((string) get_the_title($post));
        return sprintf(
            __('%1$s: %2$s', 'pagecraft-builder'),
            $typeLabel,
            $title !== '' ? $title : __('Untitled', 'pagecraft-builder')
        );
    }

    private function templateKindDescription(string $kind): string
    {
        return match ($kind) {
            'header' => __('Appears at the top of the site.', 'pagecraft-builder'),
            'footer' => __('Appears at the bottom of the site.', 'pagecraft-builder'),
            'single_page' => __('Used for pages.', 'pagecraft-builder'),
            'single_post' => __('Used for posts and custom post types.', 'pagecraft-builder'),
            'archive' => __('Used for blog and archive pages.', 'pagecraft-builder'),
            'search' => __('Used for search results.', 'pagecraft-builder'),
            'not_found' => __('Used when a page cannot be found.', 'pagecraft-builder'),
            default => '',
        };
    }

    /** @return array<string,array<string,bool>> */
    private static function iconAllowedHtml(): array
    {
        return [
            'svg' => ['class' => true, 'viewbox' => true, 'aria-hidden' => true, 'focusable' => true],
            'path' => ['d' => true],
            'rect' => ['x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true],
        ];
    }

    private static function closeIcon(): string
    {
        return '<svg class="pagecraft-control-icon" viewBox="0 0 20 20" aria-hidden="true" focusable="false">'
            . '<path d="M5 5l10 10M15 5L5 15"/></svg>';
    }

    private static function plusIcon(): string
    {
        return '<svg class="pagecraft-control-icon pagecraft-control-icon--small" viewBox="0 0 20 20" aria-hidden="true" focusable="false">'
            . '<path d="M10 4v12M4 10h12"/></svg>';
    }

    public function siteSettings(): void
    {
        $this->guard(Capabilities::MANAGE);
        $frame = add_query_arg([
            'action' => 'pagecraft_editor_frame',
            'settings' => 1,
            '_wpnonce' => wp_create_nonce('pagecraft_editor_frame_settings'),
        ], admin_url('admin-ajax.php'));
        $this->adminPageStart(
            'site-settings',
            __('Site Settings', 'pagecraft-builder'),
            __('Set the colours, fonts and styles used across Pagecraft pages.', 'pagecraft-builder')
        );
        // The loading line sits behind the frame, so it shows until the settings paint, with or without JavaScript.
        echo '<div class="pagecraft-site-settings" data-pagecraft-settings-frame aria-busy="true">'
            . '<p class="pagecraft-site-settings__loading" role="status">' . esc_html__('Loading Site Settings…', 'pagecraft-builder') . '</p>'
            . '<iframe class="pagecraft-site-settings__frame" src="' . esc_url($frame) . '" title="'
            . esc_attr__('Pagecraft Site Settings', 'pagecraft-builder')
            . '" referrerpolicy="same-origin"></iframe></div>';
        $this->adminPageEnd();
    }

    public function connect(): void
    {
        $this->guard(Capabilities::MANAGE);
        $cloud = new CloudImport();
        $connected = $cloud->connection() !== null;
        $this->adminPageStart(
            'cloud',
            __('Pagecraft Cloud', 'pagecraft-builder'),
            $connected
                ? __('Replace this site, or one page, with a project from your Cloud account. Cloud stays unchanged and there is no automatic sync.', 'pagecraft-builder')
                : __('Connect your account, then replace a site or a page.', 'pagecraft-builder'),
            [
                'classes' => 'pagecraft-cloud',
                // The connection state sits beside the button that changes it, as plain text.
                'actions' => static function () use ($connected): void {
                    echo '<span class="pagecraft-admin__status">'
                        . esc_html($connected ? __('Connected', 'pagecraft-builder') : __('Not connected', 'pagecraft-builder')) . '</span>';
                    if (!$connected) {
                        return;
                    }
                    echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
                    wp_nonce_field('pagecraft_cloud_disconnect');
                    echo '<input type="hidden" name="action" value="pagecraft_cloud_disconnect"><button class="button">'
                        . esc_html__('Disconnect', 'pagecraft-builder') . '</button></form>';
                },
            ]
        );
        $this->cloudNoticeFromQuery();
        if (!$connected) {
            // Before connecting, the screen says what the three steps after it are, in the picker frame.
            echo '<div class="pagecraft-pick"><div class="pagecraft-pick__band"><h2>'
                . esc_html__('Connect your Pagecraft account', 'pagecraft-builder') . '</h2></div><ol class="pagecraft-pick__steps">';
            foreach ([
                __('Sign in to Pagecraft and approve access.', 'pagecraft-builder'),
                __('Choose a project, and the whole site or one page.', 'pagecraft-builder'),
                __('Review what will change, then confirm.', 'pagecraft-builder'),
            ] as $index => $step) {
                echo '<li><span aria-hidden="true">' . esc_html((string) ($index + 1)) . '</span>' . esc_html($step) . '</li>';
            }
            echo '</ol><div class="pagecraft-pick__foot"><p>' . esc_html__('Nothing is imported until you choose a project and confirm.', 'pagecraft-builder')
                . '</p><div class="pagecraft-pick__actions"><form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
            wp_nonce_field('pagecraft_cloud_check');
            echo '<input type="hidden" name="action" value="pagecraft_cloud_check"><button class="button">'
                . esc_html__('Check availability', 'pagecraft-builder') . '</button></form><form action="'
                . esc_url(admin_url('admin-post.php')) . '" method="post">';
            wp_nonce_field('pagecraft_cloud_start');
            echo '<input type="hidden" name="action" value="pagecraft_cloud_start"><button class="button button-primary">'
                . esc_html__('Connect Pagecraft account', 'pagecraft-builder') . '</button></form></div></div></div>';
            $this->adminPageEnd();
            return;
        }
        try {
            (new CloudTransferScreen())->render($cloud);
        } catch (PackageException $error) {
            $this->toast($error->getMessage(), 'error', __('Pagecraft could not complete the request', 'pagecraft-builder'));
            echo '<div class="pagecraft-pad"><a class="button" href="'
                . esc_url(admin_url('admin.php?page=pagecraft-connect')) . '">'
                . esc_html__('Try again', 'pagecraft-builder') . '</a></div>';
        }
        $this->adminPageEnd();
    }

    public function settings(): void
    {
        $this->guard(Capabilities::MANAGE);
        $this->adminPageStart(
            'settings',
            __('Status', 'pagecraft-builder'),
            __('Site output, how Pagecraft works with WordPress, and the versions in use.', 'pagecraft-builder')
        );
        $this->noticeFromQuery();
        if (current_user_can('edit_theme_options')) {
            echo '<section class="pagecraft-output" data-pagecraft-output aria-label="' . esc_attr__('Site output', 'pagecraft-builder') . '">'
                . '<div class="pagecraft-toolbar"><h2>' . esc_html__('Site output', 'pagecraft-builder') . '</h2>'
                . '<p class="pagecraft-output__status" data-output-status role="status" aria-live="polite">'
                . esc_html__('Checking site output…', 'pagecraft-builder') . '</p>'
                . '<div class="pagecraft-output__actions"><button type="button" class="button" data-output-check disabled>'
                . esc_html__('Check again', 'pagecraft-builder') . '</button>'
                . '<button type="button" class="button" data-output-stop hidden>'
                . esc_html__('Stop after this item', 'pagecraft-builder') . '</button>'
                . '<button type="button" class="button button-primary" data-output-update disabled aria-describedby="pagecraft-output-help">'
                . esc_html__('Update site output', 'pagecraft-builder') . '</button></div></div>'
                . '<p class="pagecraft-lede" id="pagecraft-output-help">'
                . esc_html__('Refresh generated pages and templates with this editor. Editable content stays unchanged. A revision is kept for recovery.', 'pagecraft-builder')
                . '</p><ul class="pagecraft-output__list" data-output-list tabindex="0" aria-label="'
                . esc_attr__('Page and template update results', 'pagecraft-builder') . '" hidden></ul>'
                . '<noscript><p class="pagecraft-lede">' . esc_html__('Enable JavaScript to check and update site output.', 'pagecraft-builder')
                . '</p></noscript></section>';
        }
        echo '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-table--facts"><tbody>'
            . '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="3">' . esc_html__('WordPress integration', 'pagecraft-builder')
            . '<span class="pagecraft-table__band-note">' . esc_html__('Pagecraft handles design. WordPress handles site administration.', 'pagecraft-builder') . '</span></th></tr>';
        foreach ([
            [__('Editor entry points', 'pagecraft-builder'), __('Edit with Pagecraft is available on every WordPress page.', 'pagecraft-builder')],
            [__('Publishing and URLs', 'pagecraft-builder'), __('Managed in WordPress.', 'pagecraft-builder')],
            [__('Media and content', 'pagecraft-builder'), __('Stored in WordPress.', 'pagecraft-builder')],
            [__('Plugin removal', 'pagecraft-builder'), __('Pages, templates and media stay in WordPress if Pagecraft is removed.', 'pagecraft-builder')],
        ] as [$name, $detail]) {
            echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html($name) . '</th><td colspan="2">'
                . esc_html($detail) . '</td></tr>';
        }
        echo '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="3">' . esc_html__('System', 'pagecraft-builder')
            . '<span class="pagecraft-table__band-note">' . esc_html__('Current versions.', 'pagecraft-builder') . '</span></th></tr>';
        foreach ([
            [__('Pagecraft Builder', 'pagecraft-builder'), PAGECRAFT_BUILDER_VERSION],
            [__('Pagecraft Theme', 'pagecraft-builder'), (string) wp_get_theme('pagecraft')->get('Version')],
            [__('Pagecraft Importer', 'pagecraft-builder'), defined('PAGECRAFT_IMPORTER_VERSION') ? (string) constant('PAGECRAFT_IMPORTER_VERSION') : ''],
            [__('WordPress', 'pagecraft-builder'), (string) get_bloginfo('version')],
            [__('PHP', 'pagecraft-builder'), PHP_VERSION],
        ] as [$name, $version]) {
            echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html($name) . '</th>'
                . ($version !== ''
                    ? '<td class="pagecraft-table__code" colspan="2">' . esc_html($version) . '</td>'
                    : '<td class="pagecraft-table__muted" colspan="2">' . esc_html__('Not active', 'pagecraft-builder') . '</td>')
                . '</tr>';
        }
        echo '</tbody></table></div>';
        $this->adminPageEnd();
    }

    public function editor(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only editor route; per-post capability is checked below.
        $globalId = isset($_GET['global']) ? absint($_GET['global']) : 0;
        if ($globalId > 0) {
            $this->guardGlobal($globalId);
            $frame = add_query_arg([
                'action' => 'pagecraft_editor_frame',
                'global' => $globalId,
                '_wpnonce' => wp_create_nonce('pagecraft_editor_frame_global_' . $globalId),
            ], admin_url('admin-ajax.php'));
            echo '<div class="pagecraft-editor-admin"><iframe class="pagecraft-editor-admin__frame" src="'
                . esc_url($frame) . '" title="' . esc_attr__('Pagecraft global element editor', 'pagecraft-builder')
                . '" allow="clipboard-write" referrerpolicy="same-origin"></iframe></div>';
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only editor route; per-post capability is checked below.
        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;
        $this->guardPage($postId);
        if (!ManagedPage::isManaged($postId)
            && (int) get_post_meta($postId, ManagedPage::CONVERSION_REVISION, true) === 0) {
            $this->editorChoice($postId);
            return;
        }
        $frameArgs = [
            'action' => 'pagecraft_editor_frame',
            'post' => $postId,
            '_wpnonce' => wp_create_nonce('pagecraft_editor_frame_' . $postId),
        ];
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Template selection is allowlisted again by the iframe endpoint.
        $templateId = isset($_GET['pagecraft_template']) ? sanitize_key(wp_unslash($_GET['pagecraft_template'])) : '';
        if ($this->pageTemplate($templateId) !== null) $frameArgs['pagecraft_template'] = $templateId;
        $frame = add_query_arg($frameArgs, admin_url('admin-ajax.php'));
        echo '<div class="pagecraft-editor-admin"><iframe class="pagecraft-editor-admin__frame" src="'
            . esc_url($frame) . '" title="' . esc_attr__('Pagecraft editor', 'pagecraft-builder')
            . '" allow="clipboard-write" referrerpolicy="same-origin"></iframe></div>';
    }

    private function editorChoice(int $postId): void
    {
        echo '<div class="wrap pagecraft-admin pagecraft-start"><a class="pagecraft-admin__back" href="'
            . esc_url($this->pagesUrl()) . '">&larr; ' . esc_html__('WordPress Pages', 'pagecraft-builder') . '</a>'
            . '<h1>' . esc_html__('Start with Pagecraft', 'pagecraft-builder') . '</h1>'
            . '<p class="pagecraft-start__intro">' . esc_html__('Choose how to begin.', 'pagecraft-builder') . '</p>'
            . '<div class="pagecraft-start__choices"><section><h2>' . esc_html__('Blank Page', 'pagecraft-builder') . '</h2>'
            . '<p>' . esc_html__('Start with a blank canvas.', 'pagecraft-builder') . '</p>'
            . '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
        wp_nonce_field('pagecraft_prepare_page');
        echo '<input type="hidden" name="action" value="pagecraft_prepare_page"><input type="hidden" name="post" value="'
            . esc_attr((string) $postId) . '"><button class="button button-primary">'
            . esc_html__('Blank Page', 'pagecraft-builder') . '</button></form></section>'
            . '<section><h2>' . esc_html__('Use a template', 'pagecraft-builder') . '</h2><p>'
            . esc_html__('Choose a ready-made layout.', 'pagecraft-builder') . '</p><form action="'
            . esc_url(admin_url('admin-post.php')) . '" method="post">';
        wp_nonce_field('pagecraft_prepare_page');
        echo '<input type="hidden" name="action" value="pagecraft_prepare_page"><input type="hidden" name="post" value="'
            . esc_attr((string) $postId) . '"><label class="screen-reader-text" for="pagecraft-template">'
            . esc_html__('Page template', 'pagecraft-builder') . '</label><select id="pagecraft-template" name="template">';
        foreach ($this->pageTemplates() as $template) {
            if ($template['id'] === 'blank') continue;
            echo '<option value="' . esc_attr($template['id']) . '">' . esc_html($template['name']) . '</option>';
        }
        echo '</select> <button class="button button-primary">' . esc_html__('Use template', 'pagecraft-builder') . '</button></form></section>'
            . '<section><h2>' . esc_html__('Import from Pagecraft Cloud', 'pagecraft-builder') . '</h2>'
            . '<p>' . esc_html__('Choose a project from Pagecraft Cloud.', 'pagecraft-builder') . '</p>'
            . '<a class="button" href="' . esc_url(admin_url('admin.php?page=pagecraft-connect')) . '">'
            . esc_html__('Import from Pagecraft Cloud', 'pagecraft-builder') . '</a></section>'
            . '</div></div>';
    }

    public function editorFrame(): void
    {
        $settingsOnly = isset($_GET['settings']) && absint($_GET['settings']) === 1;
        if ($settingsOnly) {
            check_ajax_referer('pagecraft_editor_frame_settings');
            $this->guard(Capabilities::MANAGE);
            $this->renderEditorFrame(0, false, true);
        }
        $globalId = isset($_GET['global']) ? absint($_GET['global']) : 0;
        if ($globalId > 0) {
            check_ajax_referer('pagecraft_editor_frame_global_' . $globalId);
            $this->guardGlobal($globalId);
            $this->renderEditorFrame($globalId, true);
        }
        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;
        check_ajax_referer('pagecraft_editor_frame_' . $postId);
        $this->guardPage($postId);
        if (!ManagedPage::isManaged($postId)
            && (int) get_post_meta($postId, ManagedPage::CONVERSION_REVISION, true) === 0) {
            $this->fail(__('This page has not been prepared for Pagecraft conversion.', 'pagecraft-builder'), 403);
        }
        $this->renderEditorFrame($postId, false);
    }

    private function renderEditorFrame(int $postId, bool $global, bool $settingsOnly = false): never
    {
        $asset = PAGECRAFT_BUILDER_DIR . 'assets/pagecraft-editor.html';
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Trusted local bundled editor asset, never a remote URL.
        $html = @file_get_contents($asset);
        if (!is_string($html) || $html === '') {
            $this->fail(__('The Pagecraft editor asset is missing. Reinstall Pagecraft Builder.', 'pagecraft-builder'), 500);
        }
        if ($settingsOnly) {
            $loaded = ['document' => null, 'version' => 0];
        } else {
            try {
                $loaded = $global ? (new GlobalElementEditor())->load($postId) : (new PageEditor())->load($postId);
                if (!$global && is_array($loaded['document'])) {
                    $loaded['document'] = (new NativeMenu())->hydrateDocument($loaded['document']);
                }
            } catch (PackageException $error) {
                $this->fail($error->getMessage(), 400);
            }
        }
        $post = get_post($postId);
        $user = wp_get_current_user();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only, allowlisted startup hint protected by the surrounding frame nonce.
        $templateId = isset($_GET['pagecraft_template']) ? sanitize_key(wp_unslash($_GET['pagecraft_template'])) : '';
        $initialTemplate = $this->pageTemplate($templateId);
        $designSettings = new DesignSettings();
        $design = $designSettings->read();
        $config = [
            'restUrl' => untrailingslashit(rest_url(RestController::NAMESPACE)),
            'nonce' => wp_create_nonce('wp_rest'),
            'doc' => is_array($loaded['document']) ? DocumentJson::document($loaded['document']) : null,
            'version' => $loaded['version'],
            'role' => 'owner',
            'siteName' => get_bloginfo('name'),
            'settingsOnly' => $settingsOnly,
            'initialTemplate' => $initialTemplate === null ? null : $initialTemplate['id'],
            'designSettings' => DocumentJson::design($design),
            'designVersion' => $designSettings->version($design),
            'themeTemplate' => $global ? [
                'kind' => (string) get_post_meta($postId, GlobalElement::KIND, true),
                'label' => GlobalElement::label((string) get_post_meta($postId, GlobalElement::KIND, true)),
                'conditionsUrl' => admin_url('admin.php?page=pagecraft-globals&conditions=' . $postId),
            ] : null,
            'dynamicFields' => $global ? $this->wordpressDynamicFields() : [],
            'page' => [
                'id' => $postId,
                'title' => get_the_title($post),
                'slug' => (string) ($post->post_name ?? ''),
                'status' => (string) get_post_status($post),
            ],
            'pageTitleUrl' => $global || $settingsOnly ? null : add_query_arg('context', 'edit', rest_url('wp/v2/pages/' . $postId)),
            'user' => ['id' => (string) $user->ID, 'name' => (string) $user->display_name],
            'capabilities' => array_values(array_merge(
                ['edit_document', 'edit_structure', 'restore_revisions'],
                current_user_can('edit_pages') ? ['manage_pages'] : [],
                current_user_can('upload_files') ? ['upload_media'] : [],
                current_user_can(Capabilities::MANAGE) && current_user_can('edit_theme_options')
                    ? ['manage_menus', 'manage_settings'] : []
            )),
            'wordpressContent' => $settingsOnly ? [] : $this->wordpressContent(),
            'documentPath' => $global ? '/globals/' . $postId . '/document' : null,
            'revisionsPath' => $global ? '/globals/' . $postId . '/revisions' : null,
            'previewUrl' => $settingsOnly ? null : ($global ? add_query_arg([
                'action' => 'pagecraft_preview_global',
                'global' => $postId,
                '_wpnonce' => wp_create_nonce('pagecraft_preview_global_' . $postId),
            ], admin_url('admin-post.php')) : get_preview_post_link($postId)),
            'pagesUrl' => $settingsOnly ? admin_url('admin.php?page=pagecraft-site-settings')
                : ($global ? admin_url('admin.php?page=pagecraft-globals') : $this->pagesUrl()),
            'exitUrl' => $settingsOnly ? admin_url('admin.php?page=pagecraft-site-settings')
                : ($global ? admin_url('admin.php?page=pagecraft-globals') : get_edit_post_link($postId, 'raw')),
            'returnLabel' => $settingsOnly
                ? __('Return to Site Settings', 'pagecraft-builder')
                : ($global
                ? __('Save and return to Theme Builder', 'pagecraft-builder')
                : __('Save and return to WordPress Pages', 'pagecraft-builder')),
        ];
        $script = '<script>window.PC_WORDPRESS=' . wp_json_encode(
            $config,
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        ) . ';</script>';
        $marker = "<script>\n/* =====================================================================";
        if (!str_contains($html, $marker)) {
            $this->fail(__('The Pagecraft editor asset is incompatible with this plugin.', 'pagecraft-builder'), 500);
        }
        $html = str_replace($marker, $script . "\n" . $marker, $html);
        nocache_headers();
        header('Content-Type: text/html; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        // The canvas is a srcdoc frame, so it inherits this policy. It links the chosen Google Fonts
        // stylesheet; without that host here the canvas silently shows fallback typefaces.
        header("Content-Security-Policy: default-src 'self' data: blob: https:; script-src 'self' 'unsafe-inline' blob:; style-src 'self' 'unsafe-inline' data: https://fonts.googleapis.com; img-src 'self' data: blob: https:; connect-src 'self' blob: https:; frame-src 'self' https:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'");
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted generated editor artifact plus encoded config.
        exit;
    }

    public function preparePage(): void
    {
        $postId = isset($_POST['post']) ? absint($_POST['post']) : 0;
        $templateId = isset($_POST['template']) ? sanitize_key(wp_unslash($_POST['template'])) : 'blank';
        check_admin_referer('pagecraft_prepare_page');
        $this->guardPage($postId);
        $template = $this->pageTemplate($templateId);
        if ($template === null) $this->fail(__('Choose a valid Pagecraft template.', 'pagecraft-builder'), 400);
        if (ManagedPage::isManaged($postId)) {
            wp_safe_redirect($this->editorUrl($postId));
            exit;
        }
        try {
            update_post_meta($postId, ManagedPage::CONVERSION_REVISION, $this->conversionRevision($postId));
            $post = get_post($postId);
            $currentTitle = trim((string) ($post->post_title ?? ''));
            if ($templateId !== 'blank'
                && in_array($currentTitle, ['', __('Untitled page', 'pagecraft-builder'), __('Untitled Pagecraft page', 'pagecraft-builder')], true)) {
                wp_update_post(['ID' => $postId, 'post_title' => sanitize_text_field((string) $template['name'])]);
            }
        } catch (PackageException $error) {
            $this->fail($error->getMessage(), 400);
        }
        wp_safe_redirect($this->editorUrl($postId, $templateId));
        exit;
    }

    public function createPage(): void
    {
        check_admin_referer('pagecraft_create_page');
        $this->guard(Capabilities::EDIT);
        $postId = wp_insert_post([
            'post_type' => 'page',
            'post_status' => 'draft',
            'post_title' => __('Untitled Pagecraft page', 'pagecraft-builder'),
        ], true);
        if (is_wp_error($postId)) {
            $this->fail($postId->get_error_message(), 400);
        }
        update_post_meta((int) $postId, ManagedPage::CONVERSION_REVISION, '-1');
        wp_safe_redirect($this->editorUrl((int) $postId));
        exit;
    }

    public function createGlobal(): void
    {
        $kind = sanitize_key((string) ($_POST['kind'] ?? ''));
        if (!in_array($kind, GlobalElement::kinds(), true)) {
            $this->fail(__('The Pagecraft theme template type is invalid.', 'pagecraft-builder'), 400);
        }
        check_admin_referer('pagecraft_create_global');
        $this->guard(Capabilities::MANAGE);
        $title = sanitize_text_field(wp_unslash((string) ($_POST['title'] ?? '')));
        if ($title === '') {
            $title = sprintf(__('Untitled %s', 'pagecraft-builder'), GlobalElement::label($kind));
        }
        $postId = wp_insert_post([
            'post_type' => GlobalElement::POST_TYPE,
            'post_status' => 'draft',
            'post_title' => $title,
            'meta_input' => [
                GlobalElement::KIND => $kind,
                TemplateConditions::META => TemplateConditions::encode(TemplateConditions::defaults($kind)),
                TemplateConditions::PRIORITY => '0',
            ],
        ], true);
        if (is_wp_error($postId)) {
            $this->fail($postId->get_error_message(), 400);
        }
        wp_safe_redirect($this->globalEditorUrl((int) $postId));
        exit;
    }

    public function saveTemplateConditions(): void
    {
        $postId = absint($_POST['template'] ?? 0);
        check_admin_referer('pagecraft_template_conditions_' . $postId);
        $this->guardGlobal($postId);
        $actions = isset($_POST['condition_action']) && is_array($_POST['condition_action'])
            ? array_values(array_map('sanitize_text_field', wp_unslash($_POST['condition_action']))) : [];
        $targets = isset($_POST['condition_target']) && is_array($_POST['condition_target'])
            ? array_values(array_map('sanitize_text_field', wp_unslash($_POST['condition_target']))) : [];
        $rules = [];
        foreach ($targets as $index => $target) {
            $target = sanitize_text_field((string) $target);
            [$type, $value] = array_pad(explode(':', $target, 2), 2, '');
            $rules[] = [
                'action' => sanitize_key((string) ($actions[$index] ?? 'include')),
                'type' => sanitize_key($type),
                'value' => $value,
            ];
        }
        $rules = TemplateConditions::normalize($rules);
        if (!TemplateConditions::hasInclude($rules)) {
            $this->fail(__('A live template needs at least one include condition.', 'pagecraft-builder'), 400);
        }
        $priority = max(-100, min(100, (int) sanitize_text_field(wp_unslash($_POST['priority'] ?? '0'))));
        if ((string) get_post_meta($postId, GlobalElement::DOCUMENT, true) !== '') {
            $revision = wp_save_post_revision($postId);
            if (is_wp_error($revision)) {
                $this->fail(__('WordPress could not create a safety revision.', 'pagecraft-builder'), 500);
            }
        }
        update_post_meta($postId, TemplateConditions::META, wp_slash(TemplateConditions::encode($rules)));
        update_post_meta($postId, TemplateConditions::PRIORITY, (string) $priority);
        update_post_meta($postId, GlobalElement::UPDATED_AT, gmdate('c'));
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-globals&pagecraft_message=conditions'));
        exit;
    }

    public function changeTemplateStatus(): void
    {
        $postId = absint($_POST['template'] ?? 0);
        check_admin_referer('pagecraft_template_status_' . $postId);
        $this->guardGlobal($postId);
        $status = sanitize_key((string) ($_POST['status'] ?? ''));
        if (!in_array($status, ['publish', 'draft'], true)) {
            $this->fail(__('The requested template status is invalid.', 'pagecraft-builder'), 400);
        }
        if ($status === 'publish') {
            if ((string) get_post_meta($postId, GlobalElement::DOCUMENT, true) === '') {
                $this->fail(__('Design and save this template before activating it.', 'pagecraft-builder'), 400);
            }
            $rules = (string) get_post_meta($postId, TemplateConditions::META, true);
            if (!TemplateConditions::hasInclude($rules)) {
                $this->fail(__('Add an include condition before activating this template.', 'pagecraft-builder'), 400);
            }
        }
        $updated = wp_update_post(['ID' => $postId, 'post_status' => $status], true);
        if (is_wp_error($updated)) {
            $this->fail($updated->get_error_message(), 500);
        }
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-globals&pagecraft_message=' . ($status === 'publish' ? 'activated' : 'paused')));
        exit;
    }

    public function deleteTemplate(): void
    {
        $postId = absint($_POST['template'] ?? 0);
        check_admin_referer('pagecraft_template_delete_' . $postId);
        $this->guardGlobal($postId);
        if (!current_user_can('delete_post', $postId)) {
            $this->fail(__('You are not allowed to delete this Pagecraft template.', 'pagecraft-builder'), 403);
        }
        $kind = (string) get_post_meta($postId, GlobalElement::KIND, true);
        $this->trashTemplate($postId, $kind);
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-globals&pagecraft_message=deleted'));
        exit;
    }

    public function bulkTemplateAction(): void
    {
        check_admin_referer('pagecraft_template_bulk');
        $this->guard(Capabilities::MANAGE);
        $action = sanitize_key((string) ($_POST['bulk_action'] ?? ''));
        if (!in_array($action, ['publish', 'draft', 'trash'], true)) {
            $this->fail(__('Choose a bulk action.', 'pagecraft-builder'), 400);
        }
        $submitted = isset($_POST['templates']) && is_array($_POST['templates'])
            ? array_map('sanitize_text_field', wp_unslash($_POST['templates'])) : [];
        $postIds = array_values(array_unique(array_filter(array_map('absint', $submitted))));
        if ($postIds === []) {
            $this->fail(__('Select at least one template.', 'pagecraft-builder'), 400);
        }
        if (count($postIds) > 200) {
            $this->fail(__('Too many templates were selected.', 'pagecraft-builder'), 400);
        }

        $kinds = [];
        foreach ($postIds as $postId) {
            $this->guardGlobal($postId);
            $kinds[$postId] = (string) get_post_meta($postId, GlobalElement::KIND, true);
            if ($action === 'trash' && !current_user_can('delete_post', $postId)) {
                $this->fail(__('You are not allowed to delete one or more selected templates.', 'pagecraft-builder'), 403);
            }
            if ($action === 'publish') {
                if ((string) get_post_meta($postId, GlobalElement::DOCUMENT, true) === '') {
                    $this->fail(__('Design and save every selected template before activating them.', 'pagecraft-builder'), 400);
                }
                $rules = (string) get_post_meta($postId, TemplateConditions::META, true);
                if (!TemplateConditions::hasInclude($rules)) {
                    $this->fail(__('Add an include condition to every selected template before activating them.', 'pagecraft-builder'), 400);
                }
            }
        }

        foreach ($postIds as $postId) {
            if ($action === 'trash') {
                $this->trashTemplate($postId, $kinds[$postId]);
                continue;
            }
            $updated = wp_update_post(['ID' => $postId, 'post_status' => $action], true);
            if (is_wp_error($updated)) {
                $this->fail($updated->get_error_message(), 500);
            }
        }

        $message = match ($action) {
            'publish' => 'bulk_activated',
            'draft' => 'bulk_paused',
            default => 'bulk_deleted',
        };
        wp_safe_redirect(add_query_arg([
            'page' => 'pagecraft-globals',
            'pagecraft_message' => $message,
            'pagecraft_count' => count($postIds),
        ], admin_url('admin.php')));
        exit;
    }

    private function trashTemplate(int $postId, string $kind): void
    {
        $trashed = wp_trash_post($postId);
        if (!$trashed instanceof \WP_Post) {
            $this->fail(__('WordPress could not move this template to Trash.', 'pagecraft-builder'), 500);
        }
        if (in_array($kind, ['header', 'footer'], true)
            && (int) get_option(GlobalElement::defaultOption($kind), 0) === $postId) {
            update_option(GlobalElement::defaultOption($kind), 0, false);
        }
    }

    public function previewGlobal(): void
    {
        $postId = isset($_GET['global']) ? absint($_GET['global']) : 0;
        check_admin_referer('pagecraft_preview_global_' . $postId);
        $this->guardGlobal($postId);
        $post = get_post($postId);
        $kind = (string) get_post_meta($postId, GlobalElement::KIND, true);
        GlobalElement::assertKind($kind);
        $content = (string) ($post->post_content ?? '');
        $content = $this->previewDynamicFields($content);
        $cssUrl = $this->generatedAssetUrl(
            (string) get_post_meta($postId, GlobalElement::CSS_PATH, true),
            (string) get_post_meta($postId, GlobalElement::CSS_HASH, true),
            'css'
        );
        $runtimeUrl = $this->generatedAssetUrl(
            (string) get_post_meta($postId, GlobalElement::RUNTIME_PATH, true),
            (string) get_post_meta($postId, GlobalElement::RUNTIME_HASH, true),
            'js'
        );
        nocache_headers();
        header('Content-Type: text/html; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'self' data:; style-src 'self' 'unsafe-inline' https:; font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: https:; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'");
        echo '<!doctype html><html lang="' . esc_attr((string) get_bloginfo('language')) . '"><head><meta charset="'
            . esc_attr((string) get_option('blog_charset', 'UTF-8')) . '"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>' . esc_html(get_the_title($post)) . ' — ' . esc_html__('Pagecraft preview', 'pagecraft-builder') . '</title>';
        if ($cssUrl !== '') {
            echo '<link rel="stylesheet" href="' . esc_url($cssUrl) . '">';
        }
        $tag = $kind === 'header' ? 'header' : ($kind === 'footer' ? 'footer' : 'main');
        echo '</head><body><' . esc_attr($tag) . ' class="pagecraft-global pagecraft-global-' . esc_attr($kind) . '">'
            . $content // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- compiled content is sanitized before persistence.
            . '</' . esc_attr($tag) . '>';
        // Thumbnails are sandboxed without scripts; sending the runtime there only logs a blocked-script error.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The nonce was checked above.
        $thumbnail = isset($_GET['thumbnail']) && absint($_GET['thumbnail']) === 1;
        if ($runtimeUrl !== '' && !$thumbnail) {
            echo '<script src="' . esc_url($runtimeUrl) . '" defer></script>';
        }
        echo '</body></html>';
        exit;
    }

    private function previewDynamicFields(string $content): string
    {
        $sample = '<article style="padding:16px;border:1px solid #dedacf"><strong>'
            . esc_html__('Sample WordPress result', 'pagecraft-builder') . '</strong><p>'
            . esc_html__('A live route repeats this design for the current query.', 'pagecraft-builder') . '</p></article>';
        return strtr($content, [
            '{{wp.site.title}}' => esc_html((string) get_bloginfo('name')),
            '{{wp.site.description}}' => esc_html((string) get_bloginfo('description')),
            '{{wp.site.home_url}}' => esc_url(home_url('/')),
            '{{wp.post.title}}' => esc_html__('A WordPress title appears here', 'pagecraft-builder'),
            '{{wp.post.content}}' => '<p>' . esc_html__('The current WordPress content renders here while Pagecraft controls its composition.', 'pagecraft-builder') . '</p>',
            '{{wp.post.excerpt}}' => esc_html__('A native excerpt for the current post or page.', 'pagecraft-builder'),
            '{{wp.post.featured_image}}' => '<div style="aspect-ratio:16/9;background:#ebe8dd;display:grid;place-items:center;color:#5b625c">'
                . esc_html__('Featured image', 'pagecraft-builder') . '</div>',
            '{{wp.post.author}}' => esc_html__('WordPress author', 'pagecraft-builder'),
            '{{wp.post.date}}' => esc_html(wp_date((string) get_option('date_format'))),
            '{{wp.archive.title}}' => esc_html__('Archive title', 'pagecraft-builder'),
            '{{wp.archive.description}}' => esc_html__('WordPress supplies the current archive description.', 'pagecraft-builder'),
            '{{wp.search.query}}' => esc_html__('Search phrase', 'pagecraft-builder'),
            '{{wp.query.loop}}' => $sample . $sample,
            '{{wp.pagination}}' => '<nav aria-label="' . esc_attr__('Pagination', 'pagecraft-builder') . '">1&nbsp;&nbsp;2&nbsp;&nbsp;3</nav>',
        ]);
    }

    public function cloudPages(): void
    {
        check_ajax_referer('pagecraft_cloud_page', 'nonce');
        if (!current_user_can(Capabilities::EDIT) || !current_user_can(Capabilities::IMPORT)) {
            wp_send_json_error(['message' => __('You are not allowed to import Pagecraft pages.', 'pagecraft-builder')], 403);
        }

        $cloud = new CloudImport();
        if (!$cloud->connection()) {
            wp_send_json_success(['connected' => false, 'projects' => []]);
        }

        try {
            $projects = [];
            foreach ($cloud->catalog() as $project) {
                $projectId = sanitize_text_field((string) ($project['id'] ?? ''));
                if ($projectId === '') continue;
                $pages = [];
                foreach (is_array($project['pages'] ?? null) ? $project['pages'] : [] as $page) {
                    if (!is_array($page)) continue;
                    $pageId = sanitize_text_field((string) ($page['id'] ?? ''));
                    if ($pageId === '') continue;
                    $pages[] = [
                        'id' => $pageId,
                        'name' => sanitize_text_field((string) (($page['name'] ?? '') ?: __('Untitled page', 'pagecraft-builder'))),
                        'slug' => sanitize_title((string) ($page['slug'] ?? '')),
                    ];
                }
                $projects[] = [
                    'id' => $projectId,
                    'name' => sanitize_text_field((string) (($project['name'] ?? '') ?: __('Untitled project', 'pagecraft-builder'))),
                    'pages' => $pages,
                ];
            }
            wp_send_json_success(['connected' => true, 'projects' => $projects]);
        } catch (PackageException $error) {
            wp_send_json_error([
                'connected' => $cloud->connection() !== null,
                'message' => $error->getMessage(),
            ], 502);
        }
    }

    public function cloudImportPage(): void
    {
        check_ajax_referer('pagecraft_cloud_page', 'nonce');
        $postId = absint($_POST['post'] ?? 0);
        $projectId = sanitize_text_field(wp_unslash((string) ($_POST['project'] ?? '')));
        $pageId = sanitize_text_field(wp_unslash((string) ($_POST['cloud_page'] ?? '')));
        if ($postId <= 0 || get_post_type($postId) !== 'page' || !current_user_can(Capabilities::EDIT)
            || !current_user_can(Capabilities::IMPORT) || !current_user_can('edit_post', $postId)) {
            wp_send_json_error(['message' => __('You are not allowed to import into this page.', 'pagecraft-builder')], 403);
        }
        if ($projectId === '' || $pageId === '') {
            wp_send_json_error(['message' => __('Choose a Pagecraft Cloud page.', 'pagecraft-builder')], 400);
        }

        $temporary = '';
        $response = [];
        $errorStatus = 0;
        try {
            $temporary = (new CloudImport())->downloadPage($projectId, $pageId);
            $package = PortablePagePackage::fromFile($temporary);
            if ($package->isSite() || !hash_equals($pageId, (string) ($package->page()->id ?? ''))) {
                throw new PackageException('Pagecraft returned a different page package. Choose the page again.');
            }
            $post = get_post($postId);
            $currentTitle = trim((string) ($post->post_title ?? ''));
            $replaceTitle = in_array($currentTitle, ['', __('Untitled page', 'pagecraft-builder'), __('Untitled Pagecraft page', 'pagecraft-builder')], true)
                ? sanitize_text_field((string) (($package->page()->name ?? '') ?: ($package->page()->title ?? '')))
                : '';
            (new CloudReplacement())->replace(
                $package, 'page', $postId, true, CloudReplacement::fingerprint('page', $postId), $replaceTitle
            );
            $response = ['editorUrl' => $this->editorUrl($postId)];
        } catch (\Throwable $error) {
            if (!$error instanceof PackageException) {
                error_log('Pagecraft Cloud page import failed: ' . $error->getMessage());
            }
            $response = [
                'message' => $error instanceof PackageException
                    ? $error->getMessage()
                    : __('WordPress could not import this Pagecraft page. Try again.', 'pagecraft-builder'),
            ];
            $errorStatus = $error instanceof PackageException ? 400 : 500;
        } finally {
            if ($temporary !== '' && is_file($temporary)) wp_delete_file($temporary);
        }
        if ($errorStatus) wp_send_json_error($response, $errorStatus);
        wp_send_json_success($response);
    }

    public function cloudStart(): void
    {
        check_admin_referer('pagecraft_cloud_start');
        $this->guard(Capabilities::MANAGE);
        $callback = admin_url('admin-post.php?action=pagecraft_cloud_callback');
        $returnTo = '';
        $postId = absint($_POST['post'] ?? 0);
        if ($postId > 0) {
            $this->guardPage($postId);
            $returnTo = add_query_arg([
                'pagecraft_choose' => 1,
                'pagecraft_cloud' => 1,
            ], get_edit_post_link($postId, 'raw'));
        }
        try {
            wp_safe_redirect((new CloudImport())->authorizationUrl($callback, $returnTo));
        } catch (PackageException $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', $error->getMessage(), admin_url('admin.php?page=pagecraft-connect')));
        }
        exit;
    }

    public function cloudCheck(): void
    {
        check_admin_referer('pagecraft_cloud_check');
        $this->guard(Capabilities::MANAGE);
        try {
            (new CloudImport())->checkAvailability();
            wp_safe_redirect(admin_url('admin.php?page=pagecraft-connect&pagecraft_cloud_available=1'));
        } catch (PackageException $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', $error->getMessage(), admin_url('admin.php?page=pagecraft-connect')));
        }
        exit;
    }

    public function cloudCallback(): void
    {
        $this->guard(Capabilities::MANAGE);
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- OAuth PKCE state is verified and consumed by CloudImport::complete().
        $code = sanitize_text_field(wp_unslash((string) ($_GET['code'] ?? '')));
        $state = sanitize_text_field(wp_unslash((string) ($_GET['state'] ?? '')));
        // phpcs:enable
        try {
            if ($code === '' || $state === '') throw new PackageException('Pagecraft did not return a complete authorization response.');
            $returnTo = (new CloudImport())->complete($code, $state, admin_url('admin-post.php?action=pagecraft_cloud_callback'));
            $destination = $returnTo !== '' ? wp_validate_redirect($returnTo, '') : '';
            if ($destination === '' || !str_starts_with($destination, admin_url())) {
                $destination = admin_url('admin.php?page=pagecraft-connect&pagecraft_connected=1');
            }
            wp_safe_redirect($destination);
        } catch (PackageException $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', $error->getMessage(), admin_url('admin.php?page=pagecraft-connect')));
        }
        exit;
    }

    public function cloudDisconnect(): void
    {
        check_admin_referer('pagecraft_cloud_disconnect');
        $this->guard(Capabilities::MANAGE);
        (new CloudImport())->disconnect();
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-connect&pagecraft_disconnected=1'));
        exit;
    }

    public function cloudImport(): void
    {
        $projectId = sanitize_text_field(wp_unslash((string) ($_POST['project'] ?? '')));
        check_admin_referer('pagecraft_cloud_import_' . $projectId);
        $this->guard(Capabilities::IMPORT);
        $temporary = '';
        try {
            $scope = sanitize_key((string) ($_POST['scope'] ?? ''));
            if ($projectId === '' || !in_array($scope, ['site', 'page'], true) || empty($_POST['confirm_replace'])) {
                throw new PackageException('Review and confirm the replacement first.');
            }
            $sourcePage = sanitize_text_field(wp_unslash((string) ($_POST['source_page'] ?? '')));
            $destination = absint($_POST['destination'] ?? 0);
            $cloud = new CloudImport();
            $temporary = $scope === 'site' ? $cloud->downloadProject($projectId) : $cloud->downloadPage($projectId, $sourcePage);
            $package = PortablePagePackage::fromFile($temporary);
            if (!hash_equals($projectId, (string) $package->provenance()->sourceId)
                || (int) $package->provenance()->sourceVersion !== absint($_POST['source_version'] ?? 0)
                || ($scope === 'page' && ($package->isSite() || !hash_equals($sourcePage, (string) $package->page()->id)))) {
                throw new PackageException('The Cloud selection changed. Review it again before replacing WordPress content.');
            }
            ImportedFonts::reset();
            $result = (new CloudReplacement())->replace($package, $scope, $destination, true,
                sanitize_text_field(wp_unslash((string) ($_POST['destination_state'] ?? ''))));
            // The replacement is complete and correct apart from its typefaces, so this is a note, not an error.
            $fontNote = ImportedFonts::missed()
                ? ' The web fonts could not be loaded from Google Fonts, so pages show fallback fonts. Replace again to retry.'
                : '';
            wp_safe_redirect(add_query_arg([
                'project' => $projectId,
                'pagecraft_message' => ($scope === 'page'
                    ? sprintf('Page replaced. Other pages are unchanged. Recovery record %d.', $result['backupId'])
                    : sprintf('Site replaced: %d pages published, %d archived. Recovery record %d.',
                        $result['updated'], $result['archived'], $result['backupId'])) . $fontNote,
            ], admin_url('admin.php?page=pagecraft-connect')));
        } catch (\Throwable $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', rawurlencode($error->getMessage()),
                admin_url('admin.php?page=pagecraft-connect&project=' . rawurlencode($projectId))));
        } finally {
            if ($temporary !== '' && is_file($temporary)) wp_delete_file($temporary);
        }
        exit;
    }

    public function adminBarEditLink(\WP_Admin_Bar $bar): void
    {
        if (is_admin()) return;
        $postId = (int) get_queried_object_id();
        if (get_post_type($postId) !== 'page' || !ManagedPage::isManaged($postId)
            || !current_user_can(Capabilities::EDIT) || !current_user_can('edit_post', $postId)) return;
        if ($bar->get_node('edit')) {
            $bar->add_node([
                'id' => 'pagecraft-edit',
                'parent' => 'edit',
                'title' => __('Edit with Pagecraft', 'pagecraft-builder'),
                'href' => $this->editorUrl($postId),
            ]);
        }
    }

    /** @param array<string,string> $actions @return array<string,string> */
    public function rowActions(array $actions, \WP_Post $post): array
    {
        if ($post->post_type !== 'page' || !current_user_can(Capabilities::EDIT) || !current_user_can('edit_post', $post->ID)) {
            return $actions;
        }
        $url = ManagedPage::isManaged((int) $post->ID)
            ? $this->editorUrl((int) $post->ID)
            : add_query_arg('pagecraft_choose', '1', get_edit_post_link($post->ID, 'raw'));
        $pagecraft = '<a href="' . esc_url($url) . '">'
            . esc_html__('Edit with Pagecraft', 'pagecraft-builder') . '</a>';
        return ['pagecraft' => $pagecraft] + $actions;
    }

    /** @param array<string,string> $actions @return array<string,string> */
    public function globalRowActions(array $actions, \WP_Post $post): array
    {
        if ($post->post_type !== GlobalElement::POST_TYPE || !current_user_can(Capabilities::MANAGE)
            || !current_user_can('edit_post', $post->ID)) {
            return $actions;
        }
        return ['pagecraft' => '<a href="' . esc_url($this->globalEditorUrl($post->ID)) . '">'
            . esc_html__('Edit with Pagecraft', 'pagecraft-builder') . '</a>'] + $actions;
    }

    private function noticeFromQuery(): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Cosmetic messages from safe admin redirects.
        if (isset($_GET['pagecraft_message'])) {
            $message = sanitize_text_field(wp_unslash((string) $_GET['pagecraft_message']));
            $count = max(1, absint($_GET['pagecraft_count'] ?? 1));
            $message = match ($message) {
                'defaults' => __('Pagecraft settings saved.', 'pagecraft-builder'),
                'conditions' => __('Conditions saved.', 'pagecraft-builder'),
                'activated' => __('Template activated.', 'pagecraft-builder'),
                'paused' => __('Template paused.', 'pagecraft-builder'),
                'deleted' => __('Template moved to Trash.', 'pagecraft-builder'),
                'bulk_activated' => sprintf(_n('%d template activated.', '%d templates activated.', $count, 'pagecraft-builder'), $count),
                'bulk_paused' => sprintf(_n('%d template paused.', '%d templates paused.', $count, 'pagecraft-builder'), $count),
                'bulk_deleted' => sprintf(_n('%d template moved to Trash.', '%d templates moved to Trash.', $count, 'pagecraft-builder'), $count),
                default => $message,
            };
            $this->toast($message);
        }
        if (isset($_GET['pagecraft_error'])) {
            $this->toast(sanitize_text_field(wp_unslash((string) $_GET['pagecraft_error'])), 'error');
        }
        // phpcs:enable
    }

    private function cloudNoticeFromQuery(): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Status from the verified OAuth callback redirect.
        if (isset($_GET['pagecraft_cloud_available'])) {
            $this->toast(
                __('The authorization service responded correctly. Continue with Connect Pagecraft account.', 'pagecraft-builder'),
                'success',
                __('Pagecraft Cloud is reachable', 'pagecraft-builder')
            );
        }
        if (isset($_GET['pagecraft_error'])) {
            $message = sanitize_text_field(wp_unslash((string) $_GET['pagecraft_error']));
            if ($message === 'Pagecraft Cloud could not complete the request.') {
                $message = __('Pagecraft could not save this connection. Try connecting again.', 'pagecraft-builder');
            }
            $this->toast($message, 'error', __('Pagecraft could not complete the request', 'pagecraft-builder'));
        }
        if (isset($_GET['pagecraft_message'])) {
            $message = sanitize_text_field(wp_unslash((string) $_GET['pagecraft_message']));
            // A replacement that could not load its fonts carries that as a second sentence: show it as its own warning.
            $split = strpos($message, ' The web fonts could not be loaded');
            if ($split !== false) {
                $this->toast(substr($message, 0, $split));
                $this->toast(trim(substr($message, $split)), 'warning');
            } else {
                $this->toast($message);
            }
        }
        // phpcs:enable
    }

    /** @return list<array{token:string,label:string,group:string,description:string}> */
    private function wordpressDynamicFields(): array
    {
        return [
            ['token' => '{{wp.site.title}}', 'label' => __('Site title', 'pagecraft-builder'), 'group' => __('Site', 'pagecraft-builder'), 'description' => __('Current WordPress site title.', 'pagecraft-builder')],
            ['token' => '{{wp.site.description}}', 'label' => __('Site tagline', 'pagecraft-builder'), 'group' => __('Site', 'pagecraft-builder'), 'description' => __('Current WordPress tagline.', 'pagecraft-builder')],
            ['token' => '{{wp.site.home_url}}', 'label' => __('Home URL', 'pagecraft-builder'), 'group' => __('Site', 'pagecraft-builder'), 'description' => __('Canonical WordPress home URL.', 'pagecraft-builder')],
            ['token' => '{{wp.post.title}}', 'label' => __('Post title', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Title of the current page, post or custom post.', 'pagecraft-builder')],
            ['token' => '{{wp.post.content}}', 'label' => __('Post content', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Rendered WordPress block and classic content.', 'pagecraft-builder')],
            ['token' => '{{wp.post.excerpt}}', 'label' => __('Post excerpt', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Manual excerpt or WordPress-generated summary.', 'pagecraft-builder')],
            ['token' => '{{wp.post.featured_image}}', 'label' => __('Featured image', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Responsive featured image for the current post.', 'pagecraft-builder')],
            ['token' => '{{wp.post.author}}', 'label' => __('Author name', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Display name of the current author.', 'pagecraft-builder')],
            ['token' => '{{wp.post.date}}', 'label' => __('Published date', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Localized publication date.', 'pagecraft-builder')],
            ['token' => '{{wp.archive.title}}', 'label' => __('Archive title', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('Context-aware archive, taxonomy or author title.', 'pagecraft-builder')],
            ['token' => '{{wp.archive.description}}', 'label' => __('Archive description', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('Description for the current archive.', 'pagecraft-builder')],
            ['token' => '{{wp.search.query}}', 'label' => __('Search query', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('The visitor’s current search phrase.', 'pagecraft-builder')],
            ['token' => '{{wp.query.loop}}', 'label' => __('Results loop', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('Accessible cards for the active WordPress query.', 'pagecraft-builder')],
            ['token' => '{{wp.pagination}}', 'label' => __('Pagination', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('WordPress pagination for the current query.', 'pagecraft-builder')],
        ];
    }

    private function wordpressContent(): array
    {
        $home = home_url('/');
        $parts = wp_parse_url($home);
        if (!is_array($parts) || !is_string($parts['scheme'] ?? null) || !is_string($parts['host'] ?? null)) {
            return [];
        }
        $origin = $parts['scheme'] . '://' . $parts['host']
            . (isset($parts['port']) ? ':' . (int) $parts['port'] : '');
        $targetPath = '/' . trim((string) ($parts['path'] ?? '/'), '/');
        if ($targetPath !== '/') {
            $targetPath = rtrim($targetPath, '/');
        }
        $posts = get_posts([
            'post_type' => ['page', 'post'],
            'post_status' => ['draft', 'pending', 'publish', 'private'],
            'posts_per_page' => 500,
            'orderby' => ['post_type' => 'ASC', 'menu_order' => 'ASC', 'title' => 'ASC'],
        ]);
        $items = [];
        foreach ($posts as $post) {
            if (!in_array($post->post_type, ['page', 'post'], true)) {
                continue;
            }
            $items[] = [
                'id' => (string) $post->ID,
                'objectType' => (string) $post->post_type,
                'title' => get_the_title($post),
                'url' => get_permalink($post),
                'modifiedAt' => get_post_modified_time('c', true, $post),
            ];
        }
        return [[
            'connectionId' => 'wordpress-local',
            'environment' => 'production',
            'profile' => 'pagecraft-theme',
            'targetOrigin' => $origin,
            'targetPath' => $targetPath,
            'items' => $items,
        ]];
    }

    private function pagesUrl(): string
    {
        return admin_url('edit.php?post_type=page');
    }

    private function editorUrl(int $postId, string $templateId = ''): string
    {
        $url = admin_url('admin.php?page=' . self::EDITOR_SLUG . '&post=' . $postId);
        return $templateId === '' ? $url : add_query_arg('pagecraft_template', $templateId, $url);
    }

    /** @return list<array{id:string,name:string,description:string,category:string,keywords:list<string>,preview:string}> */
    private function pageTemplates(): array
    {
        static $templates = null;
        if (is_array($templates)) return $templates;
        $templates = [];
        $path = PAGECRAFT_BUILDER_DIR . 'assets/pagecraft-templates.json';
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Trusted bundled catalog, never a remote URL.
        $raw = @file_get_contents($path);
        if (!is_string($raw) || $raw === '') return $templates;
        $catalog = json_decode($raw, true);
        if (!is_array($catalog) || ($catalog['format'] ?? '') !== 'pagecraft.template-catalog.v1'
            || !is_array($catalog['templates'] ?? null)) return $templates;
        foreach ($catalog['templates'] as $template) {
            if (!is_array($template)
                || !preg_match('/^[a-z][a-z0-9-]*$/', (string) ($template['id'] ?? ''))
                || trim((string) ($template['name'] ?? '')) === ''
                || !str_starts_with(trim((string) ($template['preview'] ?? '')), '<svg')) continue;
            $templates[] = [
                'id' => sanitize_key((string) $template['id']),
                'name' => sanitize_text_field((string) $template['name']),
                'description' => sanitize_text_field((string) ($template['description'] ?? '')),
                'category' => sanitize_text_field((string) ($template['category'] ?? '')),
                'keywords' => array_values(array_filter(array_map('sanitize_text_field',
                    is_array($template['keywords'] ?? null) ? $template['keywords'] : []))),
                'preview' => (string) $template['preview'],
            ];
        }
        return $templates;
    }

    /** @return array{id:string,name:string,description:string,category:string,keywords:list<string>,preview:string}|null */
    private function pageTemplate(string $templateId): ?array
    {
        foreach ($this->pageTemplates() as $template) {
            if (hash_equals($template['id'], $templateId)) return $template;
        }
        return null;
    }

    private function globalEditorUrl(int $postId): string
    {
        return admin_url('admin.php?page=' . self::EDITOR_SLUG . '&global=' . $postId);
    }

    private function guard(string $capability): void
    {
        if (!current_user_can($capability)) {
            $this->fail(__('You are not allowed to use Pagecraft.', 'pagecraft-builder'), 403);
        }
    }

    private function guardPage(int $postId): void
    {
        if ($postId <= 0 || get_post_type($postId) !== 'page' || !current_user_can(Capabilities::EDIT)
            || !current_user_can('edit_post', $postId)) {
            $this->fail(__('You are not allowed to edit this Pagecraft page.', 'pagecraft-builder'), 403);
        }
    }

    private function guardGlobal(int $postId): void
    {
        if ($postId <= 0 || get_post_type($postId) !== GlobalElement::POST_TYPE
            || !current_user_can(Capabilities::MANAGE) || !current_user_can('edit_post', $postId)) {
            $this->fail(__('You are not allowed to edit this Pagecraft global element.', 'pagecraft-builder'), 403);
        }
        GlobalElement::assertKind((string) get_post_meta($postId, GlobalElement::KIND, true));
    }

    private function conversionRevision(int $postId): string
    {
        $post = get_post($postId);
        if (!post_type_supports('page', 'revisions') || !wp_revisions_enabled($post)) {
            throw new PackageException('WordPress revisions must be enabled before converting this page.');
        }
        $revision = wp_save_post_revision($postId);
        if (is_wp_error($revision)) {
            throw new PackageException($revision->get_error_message());
        }
        if (!is_int($revision) || $revision <= 0) {
            if (is_object($post) && trim((string) $post->post_content) !== '') {
                throw new PackageException('WordPress could not create the required conversion backup.');
            }
            return '-1';
        }
        return (string) $revision;
    }

    private function generatedAssetUrl(string $path, string $hash, string $extension): string
    {
        if (!preg_match('#^pagecraft/(?:global|runtime)-([a-f0-9]{64})\.(css|js)$#', $path, $match)
            || !hash_equals($match[1], $hash) || $match[2] !== $extension) {
            return '';
        }
        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) {
            return '';
        }
        $file = trailingslashit((string) $uploads['basedir']) . $path;
        return is_file($file) && is_readable($file) ? trailingslashit((string) $uploads['baseurl']) . $path : '';
    }

    private function fail(string $message, int $status): never
    {
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Message is escaped; response is an integer status.
        wp_die(esc_html($message), '', ['response' => $status]);
    }
}
