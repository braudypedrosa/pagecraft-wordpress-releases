<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Theme Builder: the template list, its dialogs, and the actions on a template.
 *
 * Part of the Admin class, kept in its own file. Only Admin uses it.
 */
trait AdminThemeBuilder
{
    public function globals(): void
    {
        $this->guard(Capabilities::MANAGE);
        $this->adminPageStart(
            'globals',
            __('Theme Builder', 'pagecraft-builder'),
            __('Create templates for different parts of your WordPress site.', 'pagecraft-builder'),
            ['classes' => 'pagecraft-theme-builder', 'actions' => static function (): void {
                echo '<button type="button" class="button button-primary" data-pagecraft-dialog="pagecraft-new-template">'
                    . esc_html__('New template', 'pagecraft-builder') . '</button>';
            }]
        );
        $this->noticeFromQuery();

        /* One pass over the templates: both views, the filter counts and the dialogs use the same facts. */
        $templates = [];
        $counts = ['all' => 0, 'site-parts' => 0, 'singular' => 0, 'listings' => 0, 'system' => 0];
        $activeCount = 0;
        foreach (GlobalElement::all() as $global) {
            $kind = (string) get_post_meta((int) $global->ID, GlobalElement::KIND, true);
            if (!in_array($kind, GlobalElement::kinds(), true)) continue;
            $rules = (string) get_post_meta((int) $global->ID, TemplateConditions::META, true);
            if ($rules === '') $rules = TemplateConditions::encode(TemplateConditions::defaults($kind));
            $active = get_post_status($global) === 'publish';
            $group = GlobalElement::group($kind);
            $counts['all']++;
            if (isset($counts[$group])) $counts[$group]++;
            if ($active) $activeCount++;
            $templates[] = [
                'post' => $global, 'kind' => $kind, 'group' => $group, 'rules' => $rules, 'active' => $active,
                'title' => get_the_title($global),
                'hasDocument' => (string) get_post_meta((int) $global->ID, GlobalElement::DOCUMENT, true) !== '',
                'preview' => wp_nonce_url(
                    admin_url('admin-post.php?action=pagecraft_preview_global&global=' . (int) $global->ID),
                    'pagecraft_preview_global_' . (int) $global->ID
                ),
            ];
        }

        echo '<section class="pagecraft-template-workbench" aria-label="' . esc_attr__('Templates', 'pagecraft-builder')
            . '"><div class="pagecraft-toolbar pagecraft-template-toolbar"><div class="pagecraft-template-filters" role="group" aria-label="'
            . esc_attr__('Filter templates', 'pagecraft-builder') . '">';
        foreach ([
            'all' => __('All', 'pagecraft-builder'),
            'site-parts' => __('Site parts', 'pagecraft-builder'),
            'singular' => __('Singular', 'pagecraft-builder'),
            'listings' => __('Listings', 'pagecraft-builder'),
            'system' => __('System', 'pagecraft-builder'),
        ] as $filter => $label) {
            echo '<button type="button" class="pagecraft-chip pagecraft-template-filter' . ($filter === 'all' ? ' is-active' : '')
                . '" data-template-filter="' . esc_attr($filter) . '" aria-pressed="' . ($filter === 'all' ? 'true' : 'false') . '">'
                . esc_html($label) . '<span class="pagecraft-chip__count">' . esc_html(number_format_i18n($counts[$filter])) . '</span></button>';
        }
        echo '</div><div class="pagecraft-template-ledger__tools">';
        if ($templates !== []) {
            echo '<span class="pagecraft-toolbar__facts">' . esc_html(sprintf(
                /* translators: 1: number of active templates, 2: number of draft templates */
                __('%1$d active · %2$d draft', 'pagecraft-builder'),
                $activeCount,
                count($templates) - $activeCount
            )) . '</span>';
        }
        echo '<div class="pagecraft-template-view-switch" role="group" aria-label="'
            . esc_attr__('Template view', 'pagecraft-builder') . '"><button type="button" class="pagecraft-template-view is-active" data-template-view="visual" aria-pressed="true"><span>'
            . esc_html__('Visual', 'pagecraft-builder') . '</span></button><button type="button" class="pagecraft-template-view" data-template-view="table" aria-pressed="false"><span>'
            . esc_html__('Table', 'pagecraft-builder') . '</span></button></div></div></div><div class="pagecraft-template-ledger">';

        /* Visual: the live preview and one line of facts. Type and conditions are not repeated as columns. */
        echo '<div class="pagecraft-table-scroll" data-template-panel="visual"><table class="pagecraft-table pagecraft-table--previews"><thead><tr><th scope="col">'
            . esc_html__('Template', 'pagecraft-builder') . '</th><th scope="col">' . esc_html__('Status', 'pagecraft-builder')
            . '</th><th scope="col" class="pagecraft-table__wide-only">' . esc_html__('Updated', 'pagecraft-builder')
            . '</th><th scope="col" class="pagecraft-table__end"><span class="screen-reader-text">' . esc_html__('Actions', 'pagecraft-builder') . '</span></th></tr></thead><tbody>';
        foreach ($templates as $template) {
            $global = $template['post'];
            echo '<tr class="pagecraft-template-row" data-template-group="' . esc_attr($template['group']) . '"><th scope="row"><div class="pagecraft-template-row__lead">'
                . '<div class="pagecraft-template-preview pagecraft-template-preview--' . esc_attr($template['kind']) . '">';
            if ($template['hasDocument']) {
                // A thumbnail is a still picture: it runs no scripts, so it asks for a page without any.
                echo '<iframe tabindex="-1" aria-hidden="true" sandbox="allow-same-origin" src="'
                    . esc_url(add_query_arg('thumbnail', '1', $template['preview'])) . '"></iframe>';
            } else {
                echo '<span>' . esc_html__('No preview', 'pagecraft-builder') . '</span>';
            }
            echo '</div><div class="pagecraft-template-row__body"><strong>' . esc_html($template['title']) . '</strong><small><span class="pagecraft-template-kind">'
                . esc_html(GlobalElement::label($template['kind'])) . '</span><span aria-hidden="true"> · </span>'
                . esc_html($this->templateConditionSummary($template['rules'])) . '</small></div></div></th><td>';
            $this->templateState($template['active']);
            echo '</td><td class="pagecraft-table__muted pagecraft-table__wide-only">'
                . esc_html(get_post_modified_time(get_option('date_format'), false, $global)) . '</td><td class="pagecraft-table__end">';
            $this->templateActions($global, $template['active'], $template['hasDocument'], $template['preview']);
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';

        echo '<div class="pagecraft-template-table-wrap" data-template-panel="table" hidden><form id="pagecraft-template-bulk-form" class="pagecraft-toolbar pagecraft-template-bulk" action="'
            . esc_url(admin_url('admin-post.php')) . '" method="post" data-template-bulk-form>';
        wp_nonce_field('pagecraft_template_bulk');
        echo '<input type="hidden" name="action" value="pagecraft_template_bulk"><label class="screen-reader-text" for="pagecraft-template-bulk-action">'
            . esc_html__('Bulk action', 'pagecraft-builder') . '</label><select id="pagecraft-template-bulk-action" name="bulk_action" data-template-bulk-action>'
            . '<option value="">' . esc_html__('Bulk actions', 'pagecraft-builder') . '</option><option value="publish">'
            . esc_html__('Activate', 'pagecraft-builder') . '</option><option value="draft">'
            . esc_html__('Pause', 'pagecraft-builder') . '</option><option value="trash">'
            . esc_html__('Move to Trash', 'pagecraft-builder') . '</option></select><button class="button" data-template-bulk-apply disabled>'
            . esc_html__('Apply', 'pagecraft-builder') . '</button><span class="pagecraft-template-bulk__count" data-template-bulk-count aria-live="polite"></span></form>'
            . '<div class="pagecraft-table-scroll pagecraft-template-table-scroll"><table class="pagecraft-table pagecraft-template-table"><thead><tr><th scope="col" class="pagecraft-template-table__check"><input type="checkbox" data-template-select-all aria-label="'
            . esc_attr__('Select all templates', 'pagecraft-builder') . '"></th><th scope="col">'
            . esc_html__('Template', 'pagecraft-builder') . '</th><th scope="col">'
            . esc_html__('Type', 'pagecraft-builder') . '</th><th scope="col" class="pagecraft-table__wide-only">'
            . esc_html__('Display conditions', 'pagecraft-builder') . '</th><th scope="col">'
            . esc_html__('Status', 'pagecraft-builder') . '</th><th scope="col" class="pagecraft-table__wide-only">'
            . esc_html__('Updated', 'pagecraft-builder') . '</th><th scope="col" class="pagecraft-table__end"><span class="screen-reader-text">'
            . esc_html__('Actions', 'pagecraft-builder') . '</span></th></tr></thead><tbody>';
        foreach ($templates as $template) {
            $global = $template['post'];
            $summary = $this->templateConditionSummary($template['rules']);
            echo '<tr data-template-group="' . esc_attr($template['group']) . '"><td class="pagecraft-template-table__check"><input type="checkbox" name="templates[]" value="'
                . esc_attr((string) $global->ID) . '" form="pagecraft-template-bulk-form" data-template-select aria-label="'
                . esc_attr(sprintf(__('Select %s', 'pagecraft-builder'), $template['title'])) . '"></td><th scope="row"><strong>'
                . esc_html($template['title']) . '</strong><small class="pagecraft-table__narrow-only">' . esc_html($summary) . '</small></th><td>'
                . esc_html(GlobalElement::label($template['kind'])) . '</td><td class="pagecraft-table__wide-only">' . esc_html($summary) . '</td><td>';
            $this->templateState($template['active']);
            echo '</td><td class="pagecraft-table__muted pagecraft-table__wide-only">'
                . esc_html(get_post_modified_time(get_option('date_format'), false, $global)) . '</td><td class="pagecraft-table__end">';
            $this->templateActions($global, $template['active'], $template['hasDocument'], $template['preview']);
            echo '</td></tr>';
        }
        echo '</tbody></table></div></div>';
        echo '<div class="pagecraft-empty pagecraft-template-empty" data-template-empty' . ($templates !== [] ? ' hidden' : '') . '>'
            . '<strong data-template-empty-title>'
            . esc_html__('No templates yet.', 'pagecraft-builder') . '</strong><p data-template-empty-copy>'
            . esc_html__('Create a template to get started.', 'pagecraft-builder') . '</p></div>';
        foreach ($templates as $template) {
            $this->templateConditionsDialog($template['post'], $template['rules']);
        }
        // Deleting moves a template to the WordPress Trash; this is the way back to it.
        $trashed = (int) (wp_count_posts(GlobalElement::POST_TYPE)->trash ?? 0);
        if ($trashed > 0 && current_user_can('edit_others_pages')) {
            echo '<p class="pagecraft-template-trash">' . esc_html(sprintf(
                /* translators: %d: number of templates */
                _n('%d template is in the Trash.', '%d templates are in the Trash.', $trashed, 'pagecraft-builder'),
                $trashed
            )) . ' <a href="' . esc_url(add_query_arg(
                ['post_status' => 'trash', 'post_type' => GlobalElement::POST_TYPE],
                admin_url('edit.php')
            )) . '">' . esc_html__('Open Trash', 'pagecraft-builder') . '</a> '
                . esc_html__('to restore or permanently delete. A restored template comes back paused.', 'pagecraft-builder') . '</p>';
        }
        echo '</div></section>';
        $this->newTemplateDialog();
        $this->adminPageEnd();
    }

    private function templateState(bool $active): void
    {
        echo '<span class="pagecraft-template-state pagecraft-state pagecraft-state--' . ($active ? 'ok is-active' : 'off') . '">'
            . esc_html($active ? __('Active', 'pagecraft-builder') : __('Draft', 'pagecraft-builder')) . '</span>';
    }

    /** The one action people come for stays on the row; the rest is in the row's menu. */
    private function templateActions(\WP_Post $global, bool $active, bool $hasDocument, string $preview): void
    {
        $postId = (int) $global->ID;
        $title = get_the_title($global);
        echo '<div class="pagecraft-row-actions"><a class="button" href="' . esc_url($this->globalEditorUrl($postId)) . '">'
            . esc_html($hasDocument ? __('Edit design', 'pagecraft-builder') : __('Start designing', 'pagecraft-builder')) . '</a>'
            . '<details class="pagecraft-more"><summary aria-label="'
            /* translators: %s: template name */
            . esc_attr(sprintf(__('More actions for %s', 'pagecraft-builder'), $title)) . '"><span aria-hidden="true">⋯</span></summary><div class="pagecraft-more__menu">'
            . '<button type="button" data-pagecraft-dialog="pagecraft-conditions-' . esc_attr((string) $postId) . '">'
            . esc_html__('Conditions', 'pagecraft-builder') . '</button>';
        if ($hasDocument) {
            echo '<a target="_blank" rel="noopener" href="' . esc_url($preview) . '">' . esc_html__('Preview', 'pagecraft-builder') . '</a>';
        }
        echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
        wp_nonce_field('pagecraft_template_status_' . $postId);
        echo '<input type="hidden" name="action" value="pagecraft_template_status"><input type="hidden" name="template" value="'
            . esc_attr((string) $postId) . '"><input type="hidden" name="status" value="' . ($active ? 'draft' : 'publish') . '">'
            . '<button' . (!$active && !$hasDocument ? ' disabled title="' . esc_attr__('Design and save this template before activation.', 'pagecraft-builder') . '"' : '') . '>'
            . esc_html($active ? __('Pause', 'pagecraft-builder') : __('Activate', 'pagecraft-builder')) . '</button></form>';
        echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post" data-template-delete-form data-template-title="'
            . esc_attr($title) . '">';
        wp_nonce_field('pagecraft_template_delete_' . $postId);
        echo '<input type="hidden" name="action" value="pagecraft_template_delete"><input type="hidden" name="template" value="'
            . esc_attr((string) $postId) . '"><button class="pagecraft-more__danger">'
            . esc_html__('Delete', 'pagecraft-builder') . '</button></form></div></details></div>';
    }

    private function newTemplateDialog(): void
    {
        echo '<dialog class="pagecraft-template-dialog" id="pagecraft-new-template"><form action="'
            . esc_url(admin_url('admin-post.php')) . '" method="post"><div class="pagecraft-template-dialog__head"><div><h2>' . esc_html__('New template', 'pagecraft-builder')
            . '</h2></div><button type="button" class="pagecraft-dialog-close" data-pagecraft-dialog-close aria-label="'
            . esc_attr__('Close', 'pagecraft-builder') . '">' . wp_kses(self::closeIcon(), self::iconAllowedHtml()) . '</button></div>';
        wp_nonce_field('pagecraft_create_global');
        echo '<input type="hidden" name="action" value="pagecraft_create_global"><label class="pagecraft-template-title"><span>'
            . esc_html__('Template name', 'pagecraft-builder') . '</span><input type="text" name="title" required maxlength="120" placeholder="'
            . esc_attr__('e.g. Blog post', 'pagecraft-builder') . '"></label><fieldset class="pagecraft-template-types"><legend>'
            . esc_html__('Template type', 'pagecraft-builder') . '</legend>';
        foreach (GlobalElement::kinds() as $index => $kind) {
            echo '<label><input type="radio" name="kind" value="' . esc_attr($kind) . '"' . ($index === 0 ? ' checked' : '') . '><span><b>'
                . esc_html(GlobalElement::label($kind)) . '</b><small>' . esc_html($this->templateKindDescription($kind)) . '</small></span></label>';
        }
        echo '</fieldset><footer><button type="button" class="button" data-pagecraft-dialog-close>'
            . esc_html__('Cancel', 'pagecraft-builder') . '</button><button class="button button-primary">'
            . esc_html__('Create template', 'pagecraft-builder') . '</button></footer></form></dialog>';
    }

    private function templateConditionsDialog(\WP_Post $global, string $rulesJson): void
    {
        $kind = (string) get_post_meta((int) $global->ID, GlobalElement::KIND, true);
        $rules = TemplateConditions::normalize($rulesJson);
        if ($rules === []) $rules = TemplateConditions::defaults($kind);
        $options = $this->templateConditionOptions($kind);
        echo '<dialog class="pagecraft-template-dialog pagecraft-template-dialog--conditions" id="pagecraft-conditions-'
            . esc_attr((string) $global->ID) . '"><form action="' . esc_url(admin_url('admin-post.php')) . '" method="post"><div class="pagecraft-template-dialog__head"><div><h2>'
            . esc_html__('Display conditions', 'pagecraft-builder') . '</h2><p>' . esc_html(get_the_title($global))
            . '</p></div><button type="button" class="pagecraft-dialog-close" data-pagecraft-dialog-close aria-label="'
            . esc_attr__('Close', 'pagecraft-builder') . '">' . wp_kses(self::closeIcon(), self::iconAllowedHtml()) . '</button></div>';
        wp_nonce_field('pagecraft_template_conditions_' . (int) $global->ID);
        echo '<input type="hidden" name="action" value="pagecraft_template_conditions"><input type="hidden" name="template" value="'
            . esc_attr((string) $global->ID) . '"><div class="pagecraft-condition-list" data-condition-list>';
        foreach ($rules as $rule) {
            $target = $rule['type'] . ($rule['value'] !== '' ? ':' . $rule['value'] : '');
            $this->templateConditionRow($options, $rule['action'], $target);
        }
        echo '</div><button type="button" class="pagecraft-condition-add" data-condition-add>' . wp_kses(self::plusIcon(), self::iconAllowedHtml()) . '<span>'
            . esc_html__('Add condition', 'pagecraft-builder') . '</span></button><label class="pagecraft-template-priority"><span><b>'
            . esc_html__('Priority', 'pagecraft-builder') . '</b><small>'
            . esc_html__('Used when two templates have the same conditions.', 'pagecraft-builder') . '</small></span><input type="number" min="-100" max="100" name="priority" value="'
            . esc_attr((string) (int) get_post_meta((int) $global->ID, TemplateConditions::PRIORITY, true)) . '"></label><footer><button type="button" class="button" data-pagecraft-dialog-close>'
            . esc_html__('Cancel', 'pagecraft-builder') . '</button><button class="button button-primary">'
            . esc_html__('Save conditions', 'pagecraft-builder') . '</button></footer></form></dialog>';
    }

    /** @param array<string,string> $options */
    private function templateConditionRow(array $options, string $action = 'include', string $target = 'site'): void
    {
        echo '<div class="pagecraft-condition-row" data-condition-row><select name="condition_action[]" aria-label="'
            . esc_attr__('Condition action', 'pagecraft-builder') . '"><option value="include"' . selected($action, 'include', false) . '>'
            . esc_html__('Include', 'pagecraft-builder') . '</option><option value="exclude"' . selected($action, 'exclude', false) . '>'
            . esc_html__('Exclude', 'pagecraft-builder') . '</option></select><select name="condition_target[]" aria-label="'
            . esc_attr__('Condition target', 'pagecraft-builder') . '">';
        foreach ($options as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($target, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select><button type="button" class="pagecraft-condition-remove" data-condition-remove aria-label="'
            . esc_attr__('Remove condition', 'pagecraft-builder') . '">' . wp_kses(self::closeIcon(), self::iconAllowedHtml()) . '</button></div>';
    }

    /** @return array<string,string> */
    private function templateConditionOptions(string $kind): array
    {
        $sitePart = in_array($kind, ['header', 'footer'], true);
        $options = match ($kind) {
            'single_page' => [],
            'single_post' => ['singular' => __('All posts and custom post types', 'pagecraft-builder')],
            'archive' => ['archive' => __('All archives', 'pagecraft-builder')],
            'search' => ['search' => __('Search results', 'pagecraft-builder')],
            'not_found' => ['not_found' => __('404 page', 'pagecraft-builder')],
            default => [
                'site' => __('Entire site', 'pagecraft-builder'),
                'singular' => __('All posts and pages', 'pagecraft-builder'),
                'archive' => __('All archives', 'pagecraft-builder'),
                'search' => __('Search results', 'pagecraft-builder'),
                'not_found' => __('404 page', 'pagecraft-builder'),
            ],
        };
        $postTypes = get_post_types(['public' => true, 'show_in_nav_menus' => true], 'objects');
        foreach ($postTypes as $type) {
            if ($type->name === 'attachment') continue;
            $name = (string) $type->name;
            $label = (string) ($type->labels->name ?? $type->label);
            if ($sitePart || ($kind === 'single_page' && $name === 'page') || ($kind === 'single_post' && $name !== 'page')) {
                $options['post_type:' . $name] = sprintf(__('All %s', 'pagecraft-builder'), $label);
            }
            if (($sitePart || $kind === 'archive') && ((bool) $type->has_archive || $name === 'post')) {
                $options['post_type_archive:' . $name] = sprintf(__('%s archive', 'pagecraft-builder'), $label);
            }
        }
        if ($sitePart || $kind === 'archive') foreach (get_taxonomies(['public' => true], 'objects') as $taxonomy) {
            $name = (string) $taxonomy->name;
            $label = (string) ($taxonomy->labels->name ?? $taxonomy->label);
            $options['taxonomy:' . $name] = sprintf(__('All %s archives', 'pagecraft-builder'), $label);
            $terms = get_terms(['taxonomy' => $name, 'hide_empty' => false, 'number' => 50]);
            if (is_wp_error($terms)) continue;
            foreach ($terms as $term) {
                $options['term:' . $name . ':' . (int) $term->term_id] = $label . ': ' . (string) $term->name;
            }
        }
        $exactTypes = array_values(array_filter(array_keys($postTypes), static function (string $name) use ($kind, $sitePart): bool {
            return $name !== 'attachment' && ($sitePart || ($kind === 'single_page' && $name === 'page') || ($kind === 'single_post' && $name !== 'page'));
        }));
        foreach (get_posts([
            'post_type' => $exactTypes === [] ? ['__none__'] : $exactTypes,
            'post_status' => ['publish', 'draft', 'private'],
            'posts_per_page' => 100,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]) as $post) {
            if ($kind === 'single_page' && ManagedPage::isManaged((int) $post->ID)) continue;
            $title = get_the_title($post);
            $options['post:' . (int) $post->ID] = sprintf(__('%1$s: %2$s', 'pagecraft-builder'), ucfirst((string) $post->post_type), $title !== '' ? $title : __('Untitled', 'pagecraft-builder'));
        }
        return $options;
    }

    private function templateConditionSummary(mixed $rules): string
    {
        $parts = [];
        foreach (TemplateConditions::normalize($rules) as $rule) {
            if ($rule['type'] !== 'post') {
                $parts[] = TemplateConditions::summary([$rule]);
                continue;
            }
            $parts[] = ($rule['action'] === 'exclude' ? 'Except ' : '')
                . $this->exactContentConditionLabel($rule['value']);
        }
        return $parts === [] ? 'No display conditions' : implode(' · ', $parts);
    }

    private function exactContentConditionLabel(string $value): string
    {
        $postId = absint($value);
        $post = $postId > 0 ? get_post($postId) : null;
        if (!$post instanceof \WP_Post) {
            return sprintf(__('Deleted content #%d', 'pagecraft-builder'), $postId);
        }

        $postType = get_post_type_object((string) $post->post_type);
        $typeLabel = is_object($postType) ? trim((string) $postType->labels->singular_name) : '';
        if ($typeLabel === '' && is_object($postType)) {
            $typeLabel = trim((string) $postType->label);
        }
        if ($typeLabel === '') {
            $typeLabel = ucwords(str_replace(['_', '-'], ' ', (string) $post->post_type));
        }
        $title = trim((string) get_the_title($post));
        return sprintf(
            __('%1$s: %2$s', 'pagecraft-builder'),
            $typeLabel,
            $title !== '' ? $title : __('Untitled', 'pagecraft-builder')
        );
    }

    private function templateKindDescription(string $kind): string
    {
        return match ($kind) {
            'header' => __('Appears at the top of the site.', 'pagecraft-builder'),
            'footer' => __('Appears at the bottom of the site.', 'pagecraft-builder'),
            'single_page' => __('Used for pages.', 'pagecraft-builder'),
            'single_post' => __('Used for posts and custom post types.', 'pagecraft-builder'),
            'archive' => __('Used for blog and archive pages.', 'pagecraft-builder'),
            'search' => __('Used for search results.', 'pagecraft-builder'),
            'not_found' => __('Used when a page cannot be found.', 'pagecraft-builder'),
            default => '',
        };
    }

    public function createGlobal(): void
    {
        $kind = sanitize_key((string) ($_POST['kind'] ?? ''));
        if (!in_array($kind, GlobalElement::kinds(), true)) {
            $this->fail(__('The Pagecraft theme template type is invalid.', 'pagecraft-builder'), 400);
        }
        check_admin_referer('pagecraft_create_global');
        $this->guard(Capabilities::MANAGE);
        $title = sanitize_text_field(wp_unslash((string) ($_POST['title'] ?? '')));
        if ($title === '') {
            $title = sprintf(__('Untitled %s', 'pagecraft-builder'), GlobalElement::label($kind));
        }
        $postId = wp_insert_post([
            'post_type' => GlobalElement::POST_TYPE,
            'post_status' => 'draft',
            'post_title' => $title,
            'meta_input' => [
                GlobalElement::KIND => $kind,
                TemplateConditions::META => TemplateConditions::encode(TemplateConditions::defaults($kind)),
                TemplateConditions::PRIORITY => '0',
            ],
        ], true);
        if (is_wp_error($postId)) {
            $this->fail($postId->get_error_message(), 400);
        }
        wp_safe_redirect($this->globalEditorUrl((int) $postId));
        exit;
    }

    public function saveTemplateConditions(): void
    {
        $postId = absint($_POST['template'] ?? 0);
        check_admin_referer('pagecraft_template_conditions_' . $postId);
        $this->guardGlobal($postId);
        $actions = isset($_POST['condition_action']) && is_array($_POST['condition_action'])
            ? array_values(array_map('sanitize_text_field', wp_unslash($_POST['condition_action']))) : [];
        $targets = isset($_POST['condition_target']) && is_array($_POST['condition_target'])
            ? array_values(array_map('sanitize_text_field', wp_unslash($_POST['condition_target']))) : [];
        $rules = [];
        foreach ($targets as $index => $target) {
            $target = sanitize_text_field((string) $target);
            [$type, $value] = array_pad(explode(':', $target, 2), 2, '');
            $rules[] = [
                'action' => sanitize_key((string) ($actions[$index] ?? 'include')),
                'type' => sanitize_key($type),
                'value' => $value,
            ];
        }
        $rules = TemplateConditions::normalize($rules);
        if (!TemplateConditions::hasInclude($rules)) {
            $this->fail(__('A live template needs at least one include condition.', 'pagecraft-builder'), 400);
        }
        $priority = max(-100, min(100, (int) sanitize_text_field(wp_unslash($_POST['priority'] ?? '0'))));
        if ((string) get_post_meta($postId, GlobalElement::DOCUMENT, true) !== '') {
            $revision = wp_save_post_revision($postId);
            if (is_wp_error($revision)) {
                $this->fail(__('WordPress could not create a safety revision.', 'pagecraft-builder'), 500);
            }
        }
        update_post_meta($postId, TemplateConditions::META, wp_slash(TemplateConditions::encode($rules)));
        update_post_meta($postId, TemplateConditions::PRIORITY, (string) $priority);
        update_post_meta($postId, GlobalElement::UPDATED_AT, gmdate('c'));
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-globals&pagecraft_message=conditions'));
        exit;
    }

    public function changeTemplateStatus(): void
    {
        $postId = absint($_POST['template'] ?? 0);
        check_admin_referer('pagecraft_template_status_' . $postId);
        $this->guardGlobal($postId);
        $status = sanitize_key((string) ($_POST['status'] ?? ''));
        if (!in_array($status, ['publish', 'draft'], true)) {
            $this->fail(__('The requested template status is invalid.', 'pagecraft-builder'), 400);
        }
        if ($status === 'publish') {
            if ((string) get_post_meta($postId, GlobalElement::DOCUMENT, true) === '') {
                $this->fail(__('Design and save this template before activating it.', 'pagecraft-builder'), 400);
            }
            $rules = (string) get_post_meta($postId, TemplateConditions::META, true);
            if (!TemplateConditions::hasInclude($rules)) {
                $this->fail(__('Add an include condition before activating this template.', 'pagecraft-builder'), 400);
            }
        }
        $updated = wp_update_post(['ID' => $postId, 'post_status' => $status], true);
        if (is_wp_error($updated)) {
            $this->fail($updated->get_error_message(), 500);
        }
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-globals&pagecraft_message=' . ($status === 'publish' ? 'activated' : 'paused')));
        exit;
    }

    public function deleteTemplate(): void
    {
        $postId = absint($_POST['template'] ?? 0);
        check_admin_referer('pagecraft_template_delete_' . $postId);
        $this->guardGlobal($postId);
        if (!current_user_can('delete_post', $postId)) {
            $this->fail(__('You are not allowed to delete this Pagecraft template.', 'pagecraft-builder'), 403);
        }
        $kind = (string) get_post_meta($postId, GlobalElement::KIND, true);
        $this->trashTemplate($postId, $kind);
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-globals&pagecraft_message=deleted'));
        exit;
    }

    public function bulkTemplateAction(): void
    {
        check_admin_referer('pagecraft_template_bulk');
        $this->guard(Capabilities::MANAGE);
        $action = sanitize_key((string) ($_POST['bulk_action'] ?? ''));
        if (!in_array($action, ['publish', 'draft', 'trash'], true)) {
            $this->fail(__('Choose a bulk action.', 'pagecraft-builder'), 400);
        }
        $submitted = isset($_POST['templates']) && is_array($_POST['templates'])
            ? array_map('sanitize_text_field', wp_unslash($_POST['templates'])) : [];
        $postIds = array_values(array_unique(array_filter(array_map('absint', $submitted))));
        if ($postIds === []) {
            $this->fail(__('Select at least one template.', 'pagecraft-builder'), 400);
        }
        if (count($postIds) > 200) {
            $this->fail(__('Too many templates were selected.', 'pagecraft-builder'), 400);
        }

        $kinds = [];
        foreach ($postIds as $postId) {
            $this->guardGlobal($postId);
            $kinds[$postId] = (string) get_post_meta($postId, GlobalElement::KIND, true);
            if ($action === 'trash' && !current_user_can('delete_post', $postId)) {
                $this->fail(__('You are not allowed to delete one or more selected templates.', 'pagecraft-builder'), 403);
            }
            if ($action === 'publish') {
                if ((string) get_post_meta($postId, GlobalElement::DOCUMENT, true) === '') {
                    $this->fail(__('Design and save every selected template before activating them.', 'pagecraft-builder'), 400);
                }
                $rules = (string) get_post_meta($postId, TemplateConditions::META, true);
                if (!TemplateConditions::hasInclude($rules)) {
                    $this->fail(__('Add an include condition to every selected template before activating them.', 'pagecraft-builder'), 400);
                }
            }
        }

        foreach ($postIds as $postId) {
            if ($action === 'trash') {
                $this->trashTemplate($postId, $kinds[$postId]);
                continue;
            }
            $updated = wp_update_post(['ID' => $postId, 'post_status' => $action], true);
            if (is_wp_error($updated)) {
                $this->fail($updated->get_error_message(), 500);
            }
        }

        $message = match ($action) {
            'publish' => 'bulk_activated',
            'draft' => 'bulk_paused',
            default => 'bulk_deleted',
        };
        wp_safe_redirect(add_query_arg([
            'page' => 'pagecraft-globals',
            'pagecraft_message' => $message,
            'pagecraft_count' => count($postIds),
        ], admin_url('admin.php')));
        exit;
    }

    private function trashTemplate(int $postId, string $kind): void
    {
        $trashed = wp_trash_post($postId);
        if (!$trashed instanceof \WP_Post) {
            $this->fail(__('WordPress could not move this template to Trash.', 'pagecraft-builder'), 500);
        }
        if (in_array($kind, ['header', 'footer'], true)
            && (int) get_option(GlobalElement::defaultOption($kind), 0) === $postId) {
            update_option(GlobalElement::defaultOption($kind), 0, false);
        }
    }

    public function previewGlobal(): void
    {
        $postId = isset($_GET['global']) ? absint($_GET['global']) : 0;
        check_admin_referer('pagecraft_preview_global_' . $postId);
        $this->guardGlobal($postId);
        $post = get_post($postId);
        $kind = (string) get_post_meta($postId, GlobalElement::KIND, true);
        GlobalElement::assertKind($kind);
        $content = (string) ($post->post_content ?? '');
        $content = $this->previewDynamicFields($content);
        $cssUrl = $this->generatedAssetUrl(
            (string) get_post_meta($postId, GlobalElement::CSS_PATH, true),
            (string) get_post_meta($postId, GlobalElement::CSS_HASH, true),
            'css'
        );
        $nodeCssUrl = $this->generatedAssetUrl(
            (string) get_post_meta($postId, GlobalElement::NODE_CSS_PATH, true),
            (string) get_post_meta($postId, GlobalElement::NODE_CSS_HASH, true),
            'css'
        );
        $runtimeUrl = $this->generatedAssetUrl(
            (string) get_post_meta($postId, GlobalElement::RUNTIME_PATH, true),
            (string) get_post_meta($postId, GlobalElement::RUNTIME_HASH, true),
            'js'
        );
        nocache_headers();
        header('Content-Type: text/html; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'self' data:; style-src 'self' 'unsafe-inline' https:; font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: https:; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'");
        echo '<!doctype html><html lang="' . esc_attr((string) get_bloginfo('language')) . '"><head><meta charset="'
            . esc_attr((string) get_option('blog_charset', 'UTF-8')) . '"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>' . esc_html(get_the_title($post)) . ' — ' . esc_html__('Pagecraft preview', 'pagecraft-builder') . '</title>';
        foreach (array_filter([$cssUrl, $nodeCssUrl]) as $stylesheet) {
            echo '<link rel="stylesheet" href="' . esc_url($stylesheet) . '">';
        }
        $tag = $kind === 'header' ? 'header' : ($kind === 'footer' ? 'footer' : 'main');
        echo '</head><body><' . esc_attr($tag) . ' class="pagecraft-global pagecraft-global-' . esc_attr($kind) . '">'
            . $content // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- compiled content is sanitized before persistence.
            . '</' . esc_attr($tag) . '>';
        // Thumbnails are sandboxed without scripts; sending the runtime there only logs a blocked-script error.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The nonce was checked above.
        $thumbnail = isset($_GET['thumbnail']) && absint($_GET['thumbnail']) === 1;
        if ($runtimeUrl !== '' && !$thumbnail) {
            echo '<script src="' . esc_url($runtimeUrl) . '" defer></script>';
        }
        echo '</body></html>';
        exit;
    }

    private function previewDynamicFields(string $content): string
    {
        $sample = '<article style="padding:16px;border:1px solid #dedacf"><strong>'
            . esc_html__('Sample WordPress result', 'pagecraft-builder') . '</strong><p>'
            . esc_html__('A live route repeats this design for the current query.', 'pagecraft-builder') . '</p></article>';
        return strtr($content, [
            '{{wp.site.title}}' => esc_html((string) get_bloginfo('name')),
            '{{wp.site.description}}' => esc_html((string) get_bloginfo('description')),
            '{{wp.site.home_url}}' => esc_url(home_url('/')),
            '{{wp.post.title}}' => esc_html__('A WordPress title appears here', 'pagecraft-builder'),
            '{{wp.post.content}}' => '<p>' . esc_html__('The current WordPress content renders here while Pagecraft controls its composition.', 'pagecraft-builder') . '</p>',
            '{{wp.post.excerpt}}' => esc_html__('A native excerpt for the current post or page.', 'pagecraft-builder'),
            '{{wp.post.featured_image}}' => '<div style="aspect-ratio:16/9;background:#ebe8dd;display:grid;place-items:center;color:#5b625c">'
                . esc_html__('Featured image', 'pagecraft-builder') . '</div>',
            '{{wp.post.author}}' => esc_html__('WordPress author', 'pagecraft-builder'),
            '{{wp.post.date}}' => esc_html(wp_date((string) get_option('date_format'))),
            '{{wp.archive.title}}' => esc_html__('Archive title', 'pagecraft-builder'),
            '{{wp.archive.description}}' => esc_html__('WordPress supplies the current archive description.', 'pagecraft-builder'),
            '{{wp.search.query}}' => esc_html__('Search phrase', 'pagecraft-builder'),
            '{{wp.query.loop}}' => $sample . $sample,
            '{{wp.pagination}}' => '<nav aria-label="' . esc_attr__('Pagination', 'pagecraft-builder') . '">1&nbsp;&nbsp;2&nbsp;&nbsp;3</nav>',
        ]);
    }

    /** @param array<string,string> $actions @return array<string,string> */
    public function globalRowActions(array $actions, \WP_Post $post): array
    {
        if ($post->post_type !== GlobalElement::POST_TYPE || !current_user_can(Capabilities::MANAGE)
            || !current_user_can('edit_post', $post->ID)) {
            return $actions;
        }
        return ['pagecraft' => '<a href="' . esc_url($this->globalEditorUrl($post->ID)) . '">'
            . esc_html__('Edit with Pagecraft', 'pagecraft-builder') . '</a>'] + $actions;
    }
}
