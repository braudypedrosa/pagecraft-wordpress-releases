<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

// Admin is one class split across files by screen. The parts are loaded here so the class is
// complete however it is included.
require_once __DIR__ . '/AdminThemeBuilder.php';
require_once __DIR__ . '/AdminCloud.php';
require_once __DIR__ . '/AdminEditor.php';

final class Admin
{
    use AdminThemeBuilder;
    use AdminCloud;
    use AdminEditor;

    public const MENU_SLUG = 'pagecraft';
    public const EDITOR_SLUG = 'pagecraft-editor';
    /** Where the admin page leaves the editor's settings for the frame to read. */
    private const EDITOR_CONFIG = 'pagecraftEditorConfig';
    private const EDITOR_CONTENT_SECURITY_POLICY = "Content-Security-Policy: default-src 'self' data: blob: https:; script-src 'self' 'unsafe-inline' blob:; style-src 'self' 'unsafe-inline' data: https://fonts.googleapis.com; img-src 'self' data: blob: https:; connect-src 'self' blob: https:; frame-src 'self' https:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'";
    /** Load order matters: shared foundations first, then each screen, then toasts and narrow layouts. */
    private const ADMIN_STYLESHEETS = [
        'pagecraft-builder-admin' => 'pagecraft-admin.css',
        'pagecraft-builder-admin-theme-builder' => 'pagecraft-admin-theme-builder.css',
        'pagecraft-builder-admin-screens' => 'pagecraft-admin-screens.css',
        'pagecraft-builder-admin-cloud' => 'pagecraft-admin-cloud.css',
        'pagecraft-builder-admin-shared' => 'pagecraft-admin-shared.css',
    ];
    private const MENU_ICON_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 95 95"><path fill="#000" fill-rule="evenodd" d="M11 0h73v71H63l-6-6-6 6H29v6h22v18H11Zm18 18v59h22V53h15V18Z"/></svg>';

    public function register(): void
    {
        add_action('admin_menu', [$this, 'menus']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
        add_action('enqueue_block_editor_assets', [$this, 'blockEditorAssets']);
        add_action('wp_ajax_pagecraft_editor_frame', [$this, 'editorFrame']);
        add_action('wp_ajax_pagecraft_cloud_pages', [$this, 'cloudPages']);
        add_action('wp_ajax_pagecraft_cloud_import_page', [$this, 'cloudImportPage']);
        add_action('admin_post_pagecraft_prepare_page', [$this, 'preparePage']);
        add_action('admin_post_pagecraft_create_page', [$this, 'createPage']);
        add_action('admin_post_pagecraft_create_global', [$this, 'createGlobal']);
        add_action('admin_post_pagecraft_template_conditions', [$this, 'saveTemplateConditions']);
        add_action('admin_post_pagecraft_template_status', [$this, 'changeTemplateStatus']);
        add_action('admin_post_pagecraft_template_delete', [$this, 'deleteTemplate']);
        add_action('admin_post_pagecraft_template_bulk', [$this, 'bulkTemplateAction']);
        add_action('admin_post_pagecraft_preview_global', [$this, 'previewGlobal']);
        add_action('admin_post_pagecraft_cloud_start', [$this, 'cloudStart']);
        add_action('admin_post_pagecraft_cloud_check', [$this, 'cloudCheck']);
        add_action('admin_post_pagecraft_cloud_callback', [$this, 'cloudCallback']);
        add_action('admin_post_pagecraft_cloud_disconnect', [$this, 'cloudDisconnect']);
        add_action('admin_post_pagecraft_cloud_import', [$this, 'cloudImport']);
        add_action('admin_post_pagecraft_cloud_undo', [$this, 'cloudUndo']);
        add_action('admin_bar_menu', [$this, 'adminBarEditLink'], 90);
        add_filter('page_row_actions', [$this, 'rowActions'], 10, 2);
        add_filter('display_post_states', [$this, 'postStates'], 10, 2);
        add_action('admin_enqueue_scripts', [$this, 'pagesListAssets']);
        add_filter('post_row_actions', [$this, 'globalRowActions'], 10, 2);
    }

    public function menus(): void
    {
        add_menu_page(
            __('Pagecraft', 'pagecraft-builder'),
            __('Pagecraft', 'pagecraft-builder'),
            Capabilities::EDIT,
            self::MENU_SLUG,
            [$this, 'overview'],
            $this->menuIcon(),
            25
        );
        add_submenu_page(self::MENU_SLUG, __('Overview', 'pagecraft-builder'), __('Overview', 'pagecraft-builder'),
            Capabilities::EDIT, self::MENU_SLUG, [$this, 'overview']);
        $unread = FormSubmissions::unreadCount();
        add_submenu_page(self::MENU_SLUG, __('Submissions', 'pagecraft-builder'), __('Submissions', 'pagecraft-builder')
            . ($unread > 0 ? ' <span class="awaiting-mod">' . esc_html(number_format_i18n($unread)) . '</span>' : ''),
            Capabilities::MANAGE, SubmissionsScreen::SLUG, [$this, 'submissions']);
        add_submenu_page(self::MENU_SLUG, __('Theme Builder', 'pagecraft-builder'), __('Theme Builder', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-globals', [$this, 'globals']);
        add_submenu_page(self::MENU_SLUG, __('Site Settings', 'pagecraft-builder'), __('Site Settings', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-site-settings', [$this, 'siteSettings']);
        add_submenu_page(self::MENU_SLUG, __('Pagecraft Cloud', 'pagecraft-builder'), __('Pagecraft Cloud', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-connect', [$this, 'connect']);
        add_submenu_page(self::MENU_SLUG, __('Status', 'pagecraft-builder'), __('Status', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-settings', [$this, 'settings']);
        add_submenu_page('options.php', __('Pagecraft Cloud', 'pagecraft-builder'), __('Pagecraft Cloud', 'pagecraft-builder'),
            Capabilities::MANAGE, 'pagecraft-import-export', [$this, 'connect']);
        add_submenu_page('options.php', __('Edit with Pagecraft', 'pagecraft-builder'), __('Edit with Pagecraft', 'pagecraft-builder'),
            Capabilities::EDIT, self::EDITOR_SLUG, [$this, 'editor']);
    }

    private function menuIcon(): string
    {
        return 'data:image/svg+xml;base64,' . base64_encode(self::MENU_ICON_SVG);
    }

    public function assets(string $hook): void
    {
        if (!str_contains($hook, 'pagecraft')) {
            return;
        }
        // One stylesheet kept in parts. Each depends on the one before, so they load in this order
        // and later parts can refine earlier ones exactly as they did in a single file.
        $previous = [];
        foreach (self::ADMIN_STYLESHEETS as $handle => $file) {
            wp_enqueue_style($handle, PAGECRAFT_BUILDER_URL . 'assets/' . $file, $previous, $this->assetVersion($file));
            $previous = [$handle];
        }
        wp_enqueue_script(
            'pagecraft-builder-admin',
            PAGECRAFT_BUILDER_URL . 'assets/pagecraft-admin.js',
            [],
            $this->assetVersion('pagecraft-admin.js'),
            true
        );
        // Status checks and updates site output; the Overview only runs the same check.
        $checksOutput = str_contains($hook, 'pagecraft-settings') || $hook === 'toplevel_page_' . self::MENU_SLUG;
        if ($checksOutput && current_user_can(Capabilities::MANAGE) && current_user_can('edit_theme_options')) {
            try {
                $compiler = CompilerContract::current();
                $relative = 'compiler/' . $compiler->editorVersion . '-' . $compiler->rendererRevision . '/compiler.js';
                if (!is_file(PAGECRAFT_BUILDER_DIR . 'assets/' . $relative)) {
                    throw new PackageException('The sealed Pagecraft compiler is missing. Reinstall the Builder package.');
                }
                wp_localize_script('pagecraft-builder-admin', 'PAGECRAFT_OUTPUT', [
                    'restUrl' => untrailingslashit(rest_url(RestController::NAMESPACE)),
                    'nonce' => wp_create_nonce('wp_rest'),
                    'controllerUrl' => add_query_arg('ver', $this->assetVersion('pagecraft-generated-output.js'),
                        PAGECRAFT_BUILDER_URL . 'assets/pagecraft-generated-output.js'),
                    'compilerUrl' => PAGECRAFT_BUILDER_URL . 'assets/' . $relative,
                ]);
            } catch (PackageException $error) {
                wp_localize_script('pagecraft-builder-admin', 'PAGECRAFT_OUTPUT', ['error' => $error->getMessage()]);
            }
        }
    }

    private function assetVersion(string $name): string
    {
        $hash = hash_file('sha256', PAGECRAFT_BUILDER_DIR . 'assets/' . $name);
        return PAGECRAFT_BUILDER_VERSION . '-' . substr(is_string($hash) ? $hash : '', 0, 12);
    }

    public function blockEditorAssets(): void
    {
        $screen = get_current_screen();
        if (!$screen instanceof \WP_Screen || $screen->base !== 'post' || $screen->post_type !== 'page') {
            return;
        }

        global $post;
        $postId = $post instanceof \WP_Post ? (int) $post->ID : 0;
        if (($postId > 0 && !current_user_can('edit_post', $postId))
            || ($postId < 1 && !current_user_can('edit_pages'))
            || !current_user_can(Capabilities::EDIT)) {
            return;
        }

        wp_enqueue_style(
            'pagecraft-builder-block-editor',
            PAGECRAFT_BUILDER_URL . 'assets/pagecraft-block-editor.css',
            [],
            PAGECRAFT_BUILDER_VERSION
        );
        wp_enqueue_script(
            'pagecraft-builder-block-editor',
            PAGECRAFT_BUILDER_URL . 'assets/pagecraft-block-editor.js',
            ['wp-data'],
            PAGECRAFT_BUILDER_VERSION,
            true
        );
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only controls whether the user-requested chooser opens after Gutenberg loads.
        $openOnLoad = isset($_GET['pagecraft_choose']) && absint($_GET['pagecraft_choose']) === 1;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only selects the requested chooser view after OAuth returns.
        $openCloudOnLoad = isset($_GET['pagecraft_cloud']) && absint($_GET['pagecraft_cloud']) === 1;
        wp_localize_script('pagecraft-builder-block-editor', 'PAGECRAFT_BLOCK_EDITOR', [
            'postId' => $postId,
            'editorUrl' => $postId > 0 && ManagedPage::isManaged($postId) ? $this->editorUrl($postId) : '',
            'prepareUrl' => admin_url('admin-post.php'),
            'prepareNonce' => wp_create_nonce('pagecraft_prepare_page'),
            'cloudPagesUrl' => admin_url('admin-ajax.php?action=pagecraft_cloud_pages'),
            'cloudImportUrl' => admin_url('admin-ajax.php?action=pagecraft_cloud_import_page'),
            'cloudStartUrl' => admin_url('admin-post.php'),
            'cloudNonce' => wp_create_nonce('pagecraft_cloud_page'),
            'cloudStartNonce' => wp_create_nonce('pagecraft_cloud_start'),
            'openOnLoad' => $openOnLoad,
            'openCloudOnLoad' => $openCloudOnLoad,
            'templates' => $this->pageTemplates(),
            'labels' => [
                'button' => __('Edit with Pagecraft', 'pagecraft-builder'),
                'title' => __('Start with Pagecraft', 'pagecraft-builder'),
                'intro' => __('Choose how to begin.', 'pagecraft-builder'),
                'blank' => __('Blank Page', 'pagecraft-builder'),
                'blankDescription' => __('Start with a blank canvas.', 'pagecraft-builder'),
                'template' => __('Use a template', 'pagecraft-builder'),
                'templateDescription' => __('Choose a ready-made layout.', 'pagecraft-builder'),
                'templateTitle' => __('Choose a page template', 'pagecraft-builder'),
                'templateIntro' => __('Start with a complete Pagecraft page, then make every section your own.', 'pagecraft-builder'),
                'templateBack' => __('Back', 'pagecraft-builder'),
                'templateSearch' => __('Search templates', 'pagecraft-builder'),
                'templateFilter' => __('Filter templates', 'pagecraft-builder'),
                'templateAll' => __('All', 'pagecraft-builder'),
                'templateEmpty' => __('No matching templates.', 'pagecraft-builder'),
                'templatePreparing' => __('Preparing this template…', 'pagecraft-builder'),
                'cloud' => __('Import from Pagecraft Cloud', 'pagecraft-builder'),
                'cloudDescription' => __('Choose a page from Pagecraft Cloud.', 'pagecraft-builder'),
                'cloudTitle' => __('Choose a Cloud page', 'pagecraft-builder'),
                'cloudIntro' => __('Select a page to import into this WordPress page.', 'pagecraft-builder'),
                'cloudBack' => __('Back', 'pagecraft-builder'),
                'cloudLoading' => __('Loading your pages…', 'pagecraft-builder'),
                'cloudConnectTitle' => __('Connect your Pagecraft account', 'pagecraft-builder'),
                'cloudConnectDescription' => __('Connect to choose a page from Pagecraft Cloud.', 'pagecraft-builder'),
                'cloudConnectAction' => __('Connect Pagecraft account', 'pagecraft-builder'),
                'cloudEmpty' => __('No Cloud pages found.', 'pagecraft-builder'),
                'cloudEmptyDescription' => __('Create a page in Pagecraft Cloud, then try again.', 'pagecraft-builder'),
                'cloudSearch' => __('Search pages', 'pagecraft-builder'),
                'cloudNoResults' => __('No matching pages.', 'pagecraft-builder'),
                'cloudRetry' => __('Try again', 'pagecraft-builder'),
                'cloudLoadError' => __('Pagecraft Cloud could not load your pages. Try again.', 'pagecraft-builder'),
                'cloudImporting' => __('Importing this page…', 'pagecraft-builder'),
                'cloudImportError' => __('WordPress could not import this page. Try again.', 'pagecraft-builder'),
                'close' => __('Close', 'pagecraft-builder'),
                'untitled' => __('Untitled page', 'pagecraft-builder'),
                'saving' => __('Saving this page…', 'pagecraft-builder'),
                'error' => __('WordPress could not save this page. Try again.', 'pagecraft-builder'),
            ],
        ]);
    }

    /**
     * Every Pagecraft screen is one sheet: the bar, then a header (title, one sentence, actions),
     * then that screen's toolbar and tables.
     *
     * @param array{classes?:string,badge?:string,badgeState?:string,actions?:callable,before?:callable} $options
     */
    private function adminPageStart(string $active, string $title, string $description, array $options = []): void
    {
        $className = trim('wrap pagecraft-admin pagecraft-admin--shell pagecraft-console ' . ($options['classes'] ?? ''));
        // WordPress moves other plugins' notices to this marker, above the Pagecraft frame rather than inside its header.
        echo '<div class="' . esc_attr($className) . '"><hr class="wp-header-end"><div class="pagecraft-admin-shell">'
            . '<header class="pagecraft-admin-nav"><a class="pagecraft-admin-nav__brand" href="'
            . esc_url(admin_url('admin.php?page=' . self::MENU_SLUG)) . '">'
            . '<svg viewBox="0 0 95 95" aria-hidden="true" focusable="false"><path fill="currentColor" fill-rule="evenodd" d="M11 0h73v71H63l-6-6-6 6H29v6h22v18H11Zm18 18v59h22V53h15V18Z"/></svg>'
            . '<span>' . esc_html__('Pagecraft', 'pagecraft-builder') . '</span></a>';
        $this->adminNavigation($active);
        echo '</header><main class="pagecraft-admin__content">';
        if (isset($options['before'])) {
            ($options['before'])();
        }
        echo '<div class="pagecraft-admin__mast"><div class="pagecraft-admin__title"><h1>' . esc_html($title);
        if (($options['badge'] ?? '') !== '') {
            echo ' <span class="pagecraft-state pagecraft-state--' . esc_attr($options['badgeState'] ?? 'ok') . '">'
                . esc_html($options['badge']) . '</span>';
        }
        echo '</h1>' . ($description !== '' ? '<p>' . esc_html($description) . '</p>' : '') . '</div>';
        if (isset($options['actions'])) {
            echo '<div class="pagecraft-admin__mast-actions">';
            ($options['actions'])();
            echo '</div>';
        }
        echo '</div>';
    }

    private function adminNavigation(string $active): void
    {
        $groups = [
            __('Workspace', 'pagecraft-builder') => [
                ['overview', __('Overview', 'pagecraft-builder'), admin_url('admin.php?page=' . self::MENU_SLUG), 0],
            ],
        ];
        if (current_user_can(Capabilities::MANAGE)) {
            $groups[__('Workspace', 'pagecraft-builder')][] = ['submissions', __('Submissions', 'pagecraft-builder'), SubmissionsScreen::url(), FormSubmissions::unreadCount()];
            $groups[__('Design', 'pagecraft-builder')] = [
                ['globals', __('Theme Builder', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-globals'), 0],
                ['site-settings', __('Site Settings', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-site-settings'), 0],
            ];
            $groups[__('Transfer', 'pagecraft-builder')] = [
                ['cloud', __('Pagecraft Cloud', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-connect'), 0],
            ];
            $groups[__('System', 'pagecraft-builder')] = [
                ['settings', __('Status', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-settings'), 0],
            ];
        }

        echo '<nav class="pagecraft-admin-nav__menu" aria-label="' . esc_attr__('Pagecraft administration', 'pagecraft-builder') . '">';
        foreach ($groups as $label => $items) {
            // The group names divide the bar visually and are read out to screen readers.
            echo '<div class="pagecraft-admin-nav__group"><span class="pagecraft-admin-nav__label screen-reader-text">' . esc_html($label) . '</span>';
            foreach ($items as [$id, $itemLabel, $url, $count]) {
                $isActive = hash_equals($active, $id);
                echo '<a class="pagecraft-admin-nav__item' . ($isActive ? ' is-active' : '') . '" href="'
                    . esc_url($url) . '"' . ($isActive ? ' aria-current="page"' : '') . '><span>' . esc_html($itemLabel) . '</span>';
                if ($count > 0) {
                    echo '<span class="pagecraft-admin-nav__count" aria-label="'
                        . esc_attr(sprintf(_n('%d unread', '%d unread', $count, 'pagecraft-builder'), $count)) . '">'
                        . esc_html(number_format_i18n($count)) . '</span>';
                }
                echo '</a>';
            }
            echo '</div>';
        }
        echo '</nav>';
        /* translators: %s: Pagecraft Builder version number. */
        echo '<span class="pagecraft-admin-nav__version">' . esc_html(sprintf(__('Builder %s', 'pagecraft-builder'), PAGECRAFT_BUILDER_VERSION)) . '</span>';
    }

    private function adminPageEnd(): void
    {
        echo '</main></div></div>';
    }

    /** A result message. With JavaScript it becomes a toast; without, it is a line at the top of the sheet. */
    private function toast(string $message, string $kind = 'success', string $title = ''): void
    {
        echo '<div class="pagecraft-toast pagecraft-toast--' . esc_attr($kind) . '" role="' . ($kind === 'error' ? 'alert' : 'status') . '"><p>'
            . ($title !== '' ? '<strong>' . esc_html($title) . '</strong> ' : '') . esc_html($message) . '</p></div>';
    }

    public function submissions(): void
    {
        $this->guard(Capabilities::MANAGE);
        $header = SubmissionsScreen::header();
        $this->adminPageStart('submissions', $header['title'], $header['description'], $header['options']);
        SubmissionsScreen::render();
        $this->adminPageEnd();
    }

    public function overview(): void
    {
        $this->guard(Capabilities::EDIT);
        $this->adminPageStart(
            'overview',
            __('Pagecraft', 'pagecraft-builder'),
            __('Create and manage Pagecraft designs. Start designing by creating a new Pagecraft page.', 'pagecraft-builder'),
            ['actions' => function (): void {
                echo '<a class="button button-primary" href="'
                    . esc_url(add_query_arg('pagecraft_choose', '1', admin_url('post-new.php?post_type=page'))) . '">'
                    . esc_html__('Add New with Pagecraft', 'pagecraft-builder') . '</a><a class="button" href="'
                    . esc_url($this->pagesUrl()) . '">' . esc_html__('View all pages', 'pagecraft-builder') . '</a>';
            }]
        );
        if (current_user_can(Capabilities::MANAGE)) {
            $unread = FormSubmissions::unreadCount();
            $globalCount = count(GlobalElement::all());
            $cloudConnected = (new CloudImport())->connection() !== null;
            $checksOutput = current_user_can('edit_theme_options');
            // What the last site output check found. The page script checks again and corrects this row.
            $outdated = $checksOutput ? absint(get_user_setting('pagecraft_output_stale', '0')) : 0;
            echo '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-table--facts"><tbody>';
            $this->overviewBand(__('Needs attention', 'pagecraft-builder'), 'attention', $unread === 0 && $outdated === 0);
            if ($unread > 0) {
                $this->overviewRow(
                    __('Submissions', 'pagecraft-builder'),
                    sprintf(_n('%d unread entry', '%d unread entries', $unread, 'pagecraft-builder'), $unread),
                    __('Open inbox', 'pagecraft-builder'),
                    SubmissionsScreen::url()
                );
                SubmissionsScreen::newestUnreadRows(3);
            }
            if ($outdated > 0) {
                $this->overviewOutputRow($checksOutput, $outdated);
            }
            $this->overviewBand(__('Site', 'pagecraft-builder'), 'site');
            $this->overviewRow(
                __('Theme Builder', 'pagecraft-builder'),
                sprintf(_n('%d site template', '%d site templates', $globalCount, 'pagecraft-builder'), $globalCount),
                __('Open Theme Builder', 'pagecraft-builder'),
                admin_url('admin.php?page=pagecraft-globals')
            );
            $this->overviewRow(
                __('Site Settings', 'pagecraft-builder'),
                __('Colours, fonts and styles used across Pagecraft pages.', 'pagecraft-builder'),
                __('Open Site Settings', 'pagecraft-builder'),
                admin_url('admin.php?page=pagecraft-site-settings')
            );
            $this->overviewRow(
                __('Pagecraft Cloud', 'pagecraft-builder'),
                $cloudConnected ? __('Connected', 'pagecraft-builder') : __('Not connected', 'pagecraft-builder'),
                $cloudConnected ? __('Choose a project', 'pagecraft-builder') : __('Open Pagecraft Cloud', 'pagecraft-builder'),
                admin_url('admin.php?page=pagecraft-connect')
            );
            if ($outdated === 0) {
                $this->overviewOutputRow($checksOutput, 0);
            }
            echo '</tbody></table></div>';
        }
        $this->adminPageEnd();
    }

    /** A band stays in the page when it is empty, hidden, so the page script can fill it. */
    private function overviewBand(string $label, string $id, bool $hidden = false): void
    {
        echo '<tr class="pagecraft-table__band" data-overview-band="' . esc_attr($id) . '"' . ($hidden ? ' hidden' : '')
            . '><th scope="colgroup" colspan="3">' . esc_html($label) . '</th></tr>';
    }

    private function overviewRow(string $name, string $value, string $linkLabel, string $url): void
    {
        echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html($name) . '</th><td>' . esc_html($value)
            . '</td><td class="pagecraft-table__end"><a href="' . esc_url($url) . '">' . esc_html($linkLabel) . '</a></td></tr>';
    }

    /**
     * Outdated site output is listed under "Needs attention"; otherwise it is the last row of "Site".
     * Where the person may maintain site output, the page script runs the same check as the Status
     * screen, then corrects this row's text and place.
     */
    private function overviewOutputRow(bool $checksOutput, int $outdated): void
    {
        $one = __('1 page or template needs updating', 'pagecraft-builder');
        /* translators: %d: number of pages and templates. */
        $many = __('%d pages and templates need updating', 'pagecraft-builder');
        echo '<tr' . ($checksOutput ? ' data-pagecraft-output-summary data-stale-one="' . esc_attr($one) . '" data-stale-many="'
            . esc_attr($many) . '" data-current="' . esc_attr__('Up to date', 'pagecraft-builder') . '"' : '')
            . '><th scope="row" class="pagecraft-table__key">' . esc_html__('Site output', 'pagecraft-builder')
            . '</th><td data-output-summary-text aria-live="polite">' . esc_html(match (true) {
                $outdated === 1 => $one,
                $outdated > 1 => sprintf($many, $outdated),
                default => __('Check whether generated pages and templates match this editor.', 'pagecraft-builder'),
            }) . '</td><td class="pagecraft-table__end"><a href="' . esc_url(admin_url('admin.php?page=pagecraft-settings')) . '">'
            . esc_html__('Open Status', 'pagecraft-builder') . '</a></td></tr>';
    }

    /** @return array<string,array<string,bool>> */
    private static function iconAllowedHtml(): array
    {
        return [
            'svg' => ['class' => true, 'viewbox' => true, 'aria-hidden' => true, 'focusable' => true],
            'path' => ['d' => true],
            'rect' => ['x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true],
        ];
    }

    private static function closeIcon(): string
    {
        return '<svg class="pagecraft-control-icon" viewBox="0 0 20 20" aria-hidden="true" focusable="false">'
            . '<path d="M5 5l10 10M15 5L5 15"/></svg>';
    }

    private static function plusIcon(): string
    {
        return '<svg class="pagecraft-control-icon pagecraft-control-icon--small" viewBox="0 0 20 20" aria-hidden="true" focusable="false">'
            . '<path d="M10 4v12M4 10h12"/></svg>';
    }

    public function siteSettings(): void
    {
        $this->guard(Capabilities::MANAGE);
        $frame = $this->editorShellUrl();
        $config = $this->editorConfig(0, false, true);
        $this->adminPageStart(
            'site-settings',
            __('Site Settings', 'pagecraft-builder'),
            __('Set the colours, fonts and styles used across Pagecraft pages.', 'pagecraft-builder')
        );
        // The loading line sits behind the frame, so it shows until the settings paint, with or without JavaScript.
        $this->printEditorConfig($config);
        echo '<div class="pagecraft-site-settings" data-pagecraft-settings-frame aria-busy="true">'
            . '<p class="pagecraft-site-settings__loading" role="status">' . esc_html__('Loading Site Settings…', 'pagecraft-builder') . '</p>'
            . '<iframe class="pagecraft-site-settings__frame" src="' . esc_url($frame) . '" title="'
            . esc_attr__('Pagecraft Site Settings', 'pagecraft-builder')
            . '" referrerpolicy="same-origin"></iframe></div>';
        $this->adminPageEnd();
    }

    public function settings(): void
    {
        $this->guard(Capabilities::MANAGE);
        $this->adminPageStart(
            'settings',
            __('Status', 'pagecraft-builder'),
            __('Site output, how Pagecraft works with WordPress, and the versions in use.', 'pagecraft-builder')
        );
        $this->noticeFromQuery();
        if (current_user_can('edit_theme_options')) {
            echo '<section class="pagecraft-output" data-pagecraft-output aria-label="' . esc_attr__('Site output', 'pagecraft-builder') . '">'
                . '<div class="pagecraft-toolbar"><h2>' . esc_html__('Site output', 'pagecraft-builder') . '</h2>'
                . '<p class="pagecraft-output__status" data-output-status role="status" aria-live="polite">'
                . esc_html__('Checking site output…', 'pagecraft-builder') . '</p>'
                . '<div class="pagecraft-output__actions"><button type="button" class="button" data-output-check disabled>'
                . esc_html__('Check again', 'pagecraft-builder') . '</button>'
                . '<button type="button" class="button" data-output-stop hidden>'
                . esc_html__('Stop after this item', 'pagecraft-builder') . '</button>'
                . '<button type="button" class="button button-primary" data-output-update disabled aria-describedby="pagecraft-output-help">'
                . esc_html__('Update site output', 'pagecraft-builder') . '</button></div></div>'
                . '<p class="pagecraft-lede" id="pagecraft-output-help">'
                . esc_html__('Refresh generated pages and templates with this editor. Editable content stays unchanged. A revision is kept for recovery.', 'pagecraft-builder')
                . '</p><ul class="pagecraft-output__list" data-output-list tabindex="0" aria-label="'
                . esc_attr__('Page and template update results', 'pagecraft-builder') . '" hidden></ul>'
                . '<noscript><p class="pagecraft-lede">' . esc_html__('Enable JavaScript to check and update site output.', 'pagecraft-builder')
                . '</p></noscript></section>';
        }
        echo '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-table--facts"><tbody>'
            . '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="3">' . esc_html__('WordPress integration', 'pagecraft-builder')
            . '<span class="pagecraft-table__band-note">' . esc_html__('Pagecraft handles design. WordPress handles site administration.', 'pagecraft-builder') . '</span></th></tr>';
        foreach ([
            [__('Editor entry points', 'pagecraft-builder'), __('Edit with Pagecraft is available on every WordPress page.', 'pagecraft-builder')],
            [__('Publishing and URLs', 'pagecraft-builder'), __('Managed in WordPress.', 'pagecraft-builder')],
            [__('Media and content', 'pagecraft-builder'), __('Stored in WordPress.', 'pagecraft-builder')],
            [__('Plugin removal', 'pagecraft-builder'), __('Pages, templates and media stay in WordPress if Pagecraft is removed.', 'pagecraft-builder')],
        ] as [$name, $detail]) {
            echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html($name) . '</th><td colspan="2">'
                . esc_html($detail) . '</td></tr>';
        }
        echo '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="3">' . esc_html__('System', 'pagecraft-builder')
            . '<span class="pagecraft-table__band-note">' . esc_html__('Current versions.', 'pagecraft-builder') . '</span></th></tr>';
        foreach ([
            [__('Pagecraft Builder', 'pagecraft-builder'), PAGECRAFT_BUILDER_VERSION],
            [__('Pagecraft Theme', 'pagecraft-builder'), (string) wp_get_theme('pagecraft')->get('Version')],
            [__('Pagecraft Importer', 'pagecraft-builder'), defined('PAGECRAFT_IMPORTER_VERSION') ? (string) constant('PAGECRAFT_IMPORTER_VERSION') : ''],
            [__('WordPress', 'pagecraft-builder'), (string) get_bloginfo('version')],
            [__('PHP', 'pagecraft-builder'), PHP_VERSION],
        ] as [$name, $version]) {
            echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html($name) . '</th>'
                . ($version !== ''
                    ? '<td class="pagecraft-table__code" colspan="2">' . esc_html($version) . '</td>'
                    : '<td class="pagecraft-table__muted" colspan="2">' . esc_html__('Not active', 'pagecraft-builder') . '</td>')
                . '</tr>';
        }
        echo '</tbody></table></div>';
        $this->adminPageEnd();
    }

    public function adminBarEditLink(\WP_Admin_Bar $bar): void
    {
        if (is_admin()) return;
        $postId = (int) get_queried_object_id();
        if (get_post_type($postId) !== 'page' || !ManagedPage::isManaged($postId)
            || !current_user_can(Capabilities::EDIT) || !current_user_can('edit_post', $postId)) return;
        if ($bar->get_node('edit')) {
            $bar->add_node([
                'id' => 'pagecraft-edit',
                'parent' => 'edit',
                'title' => __('Edit with Pagecraft', 'pagecraft-builder'),
                'href' => $this->editorUrl($postId),
            ]);
        }
    }

    /** @param array<string,string> $actions @return array<string,string> */
    public function rowActions(array $actions, \WP_Post $post): array
    {
        if ($post->post_type !== 'page' || !current_user_can(Capabilities::EDIT) || !current_user_can('edit_post', $post->ID)) {
            return $actions;
        }
        $url = ManagedPage::isManaged((int) $post->ID)
            ? $this->editorUrl((int) $post->ID)
            : add_query_arg('pagecraft_choose', '1', get_edit_post_link($post->ID, 'raw'));
        $pagecraft = '<a href="' . esc_url($url) . '">'
            . esc_html__('Edit with Pagecraft', 'pagecraft-builder') . '</a>';
        return ['pagecraft' => $pagecraft] + $actions;
    }

    /**
     * Pagecraft pages are marked the way WordPress marks "Front Page" or "Draft": a state after
     * the title, not a column or filter, so WordPress Pages stays the only page list.
     *
     * @param array<string,string> $states
     * @return array<string,string>
     */
    public function postStates(array $states, \WP_Post $post): array
    {
        if ($post->post_type === 'page' && ManagedPage::isManaged((int) $post->ID)) {
            $states['pagecraft'] = __('Pagecraft', 'pagecraft-builder');
        }
        return $states;
    }

    /** "Add New with Pagecraft" beside "Add Page" on the Pages list. WordPress has no hook for that row, so it is placed by script. */
    public function pagesListAssets(string $hook): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($hook !== 'edit.php' || !$screen || $screen->post_type !== 'page'
            || !current_user_can(Capabilities::EDIT) || !current_user_can('edit_pages')) {
            return;
        }
        $url = add_query_arg('pagecraft_choose', '1', admin_url('post-new.php?post_type=page'));
        wp_register_script('pagecraft-pages-list', false, [], PAGECRAFT_BUILDER_VERSION, true);
        wp_enqueue_script('pagecraft-pages-list');
        wp_add_inline_script('pagecraft-pages-list', '(function () {'
            . 'var add = document.querySelector(".wrap .page-title-action");'
            . 'if (!add || document.querySelector(".pagecraft-add-new")) return;'
            . 'var link = document.createElement("a");'
            . 'link.className = "page-title-action pagecraft-add-new";'
            . 'link.href = ' . wp_json_encode(esc_url_raw($url)) . ';'
            . 'link.textContent = ' . wp_json_encode(__('Add New with Pagecraft', 'pagecraft-builder')) . ';'
            . 'add.after(link);'
            . '}());');
        wp_register_style('pagecraft-pages-list', false, [], PAGECRAFT_BUILDER_VERSION);
        wp_enqueue_style('pagecraft-pages-list');
        wp_add_inline_style('pagecraft-pages-list', '.wrap .page-title-action.pagecraft-add-new{border-color:#8fc92a;background:#b7f34a;color:#16191a;font-weight:600}'
            . '.wrap .page-title-action.pagecraft-add-new:hover,.wrap .page-title-action.pagecraft-add-new:focus{border-color:#7db51f;background:#a8e83a;color:#16191a}');
    }

    private function noticeFromQuery(): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Cosmetic messages from safe admin redirects.
        if (isset($_GET['pagecraft_message'])) {
            $message = sanitize_text_field(wp_unslash((string) $_GET['pagecraft_message']));
            $count = max(1, absint($_GET['pagecraft_count'] ?? 1));
            $message = match ($message) {
                'defaults' => __('Pagecraft settings saved.', 'pagecraft-builder'),
                'conditions' => __('Conditions saved.', 'pagecraft-builder'),
                'activated' => __('Template activated.', 'pagecraft-builder'),
                'paused' => __('Template paused.', 'pagecraft-builder'),
                'deleted' => __('Template moved to Trash.', 'pagecraft-builder'),
                'bulk_activated' => sprintf(_n('%d template activated.', '%d templates activated.', $count, 'pagecraft-builder'), $count),
                'bulk_paused' => sprintf(_n('%d template paused.', '%d templates paused.', $count, 'pagecraft-builder'), $count),
                'bulk_deleted' => sprintf(_n('%d template moved to Trash.', '%d templates moved to Trash.', $count, 'pagecraft-builder'), $count),
                default => $message,
            };
            $this->toast($message);
        }
        if (isset($_GET['pagecraft_error'])) {
            $this->toast(sanitize_text_field(wp_unslash((string) $_GET['pagecraft_error'])), 'error');
        }
        // phpcs:enable
    }

    private function pagesUrl(): string
    {
        return admin_url('edit.php?post_type=page');
    }

    private function editorUrl(int $postId, string $templateId = ''): string
    {
        $url = admin_url('admin.php?page=' . self::EDITOR_SLUG . '&post=' . $postId);
        return $templateId === '' ? $url : add_query_arg('pagecraft_template', $templateId, $url);
    }

    private function globalEditorUrl(int $postId): string
    {
        return admin_url('admin.php?page=' . self::EDITOR_SLUG . '&global=' . $postId);
    }

    private function guard(string $capability): void
    {
        if (!current_user_can($capability)) {
            $this->fail(__('You are not allowed to use Pagecraft.', 'pagecraft-builder'), 403);
        }
    }

    private function guardPage(int $postId): void
    {
        if ($postId <= 0 || get_post_type($postId) !== 'page' || !current_user_can(Capabilities::EDIT)
            || !current_user_can('edit_post', $postId)) {
            $this->fail(__('You are not allowed to edit this Pagecraft page.', 'pagecraft-builder'), 403);
        }
    }

    private function guardGlobal(int $postId): void
    {
        if ($postId <= 0 || get_post_type($postId) !== GlobalElement::POST_TYPE
            || !current_user_can(Capabilities::MANAGE) || !current_user_can('edit_post', $postId)) {
            $this->fail(__('You are not allowed to edit this Pagecraft global element.', 'pagecraft-builder'), 403);
        }
        GlobalElement::assertKind((string) get_post_meta($postId, GlobalElement::KIND, true));
    }

    private function conversionRevision(int $postId): string
    {
        $post = get_post($postId);
        if (!post_type_supports('page', 'revisions') || !wp_revisions_enabled($post)) {
            throw new PackageException('WordPress revisions must be enabled before converting this page.');
        }
        $revision = wp_save_post_revision($postId);
        if (is_wp_error($revision)) {
            throw new PackageException($revision->get_error_message());
        }
        if (!is_int($revision) || $revision <= 0) {
            if (is_object($post) && trim((string) $post->post_content) !== '') {
                throw new PackageException('WordPress could not create the required conversion backup.');
            }
            return '-1';
        }
        return (string) $revision;
    }

    private function generatedAssetUrl(string $path, string $hash, string $extension): string
    {
        if (!preg_match('#^pagecraft/(?:global|runtime)-([a-f0-9]{64})\.(css|js)$#', $path, $match)
            || !hash_equals($match[1], $hash) || $match[2] !== $extension) {
            return '';
        }
        $uploads = wp_upload_dir();
        if (!empty($uploads['error'])) {
            return '';
        }
        $file = trailingslashit((string) $uploads['basedir']) . $path;
        return is_file($file) && is_readable($file) ? trailingslashit((string) $uploads['baseurl']) . $path : '';
    }

    private function fail(string $message, int $status): never
    {
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Message is escaped; response is an integer status.
        wp_die(esc_html($message), '', ['response' => $status]);
    }
}
