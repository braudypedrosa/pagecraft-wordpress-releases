<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Explicit replacement, separate from the legacy non-destructive merge importer. */
final class CloudReplacement
{
    public const BACKUP = '_pagecraft_replacement_backup';
    public const ARCHIVE_STATUS = 'pc_archived';

    public static function fingerprint(string $scope, int $destination): string
    {
        $pages = $scope === 'site' ? self::destinations() : array_filter([get_post($destination)]);
        $records = self::replacementRecords($scope, $pages);
        $state = [];
        foreach ($records as $post) {
            $group = $post->post_type === GlobalElement::POST_TYPE ? 'globals' : 'pages';
            $state[$group][$post->ID] = [$post->post_modified_gmt, $post->post_status, $post->post_name, $post->post_title,
                hash('sha256', $post->post_content), get_post_meta($post->ID)];
        }
        if ($scope === 'site') {
            $state['menus'] = (new NativeMenu())->checkpoint();
            foreach (['show_on_front', 'page_on_front', GlobalElement::DEFAULT_HEADER, GlobalElement::DEFAULT_FOOTER] as $key) {
                $state['options'][$key] = get_option($key, null);
            }
        }
        return hash('sha256', (string) wp_json_encode($state));
    }

    /** @return list<\WP_Post> */
    public static function destinations(): array
    {
        return get_posts([
            'post_type' => 'page', 'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC',
        ]);
    }

    /** @return array<string,int|string> */
    public function replace(PortablePagePackage $package, string $scope, int $destination, bool $confirmed, string $expectedState, string $replaceTitle = ''): array
    {
        if (!$confirmed || !in_array($scope, ['site', 'page'], true)) {
            throw new PackageException('Review and confirm the replacement before continuing.');
        }
        foreach ([Capabilities::MANAGE, Capabilities::IMPORT, 'upload_files', 'edit_theme_options'] as $capability) {
            if (!current_user_can($capability)) throw new PackageException('You are not allowed to replace Pagecraft content.');
        }
        if ($scope === 'site' && (!$package->isSite() || !current_user_can('publish_pages'))) {
            throw new PackageException('Site replacement requires a complete site package and permission to publish pages.');
        }
        if ($scope === 'page' && ($destination <= 0 || get_post_type($destination) !== 'page'
            || !current_user_can('edit_post', $destination)
            || !in_array(get_post_status($destination), ['publish', 'draft', 'pending', 'private', 'future'], true))) {
            throw new PackageException('Choose an editable WordPress page to replace.');
        }
        // Package checks precede the transaction and all content writes.
        (new MediaLibrary())->preflight($package);
        foreach ($scope === 'site' ? $package->pages() : [$package->page()] as $page) {
            if ($scope === 'site') $package->selectPage((string) $page->id);
            FallbackCompiler::content($package);
            FallbackCompiler::safeCssSource($package->pageCss());
        }
        FallbackCompiler::globalContent($package, 'header');
        FallbackCompiler::globalContent($package, 'footer');
        FallbackCompiler::safeCssSource($package->globalCss());
        if ($scope === 'site' && !array_filter($package->pages(), static fn (object $p): bool => $p->slug === 'index')) {
            throw new PackageException('The Cloud site needs an index page before it can replace the WordPress site.');
        }

        return EditorWriteLock::run(0, function () use ($package, $scope, $destination, $expectedState, $replaceTitle): array {
            if ($expectedState === '' || !hash_equals(self::fingerprint($scope, $destination), $expectedState)) {
                throw new PackageException('WordPress changed since the review. Review the replacement again; nothing was replaced.');
            }
            $pages = $scope === 'site' ? self::destinations() : [get_post($destination)];
            $records = self::replacementRecords($scope, $pages);
            foreach ($records as $post) {
                if (!current_user_can('edit_post', $post->ID)
                    || ($scope === 'site' && $post->post_type === 'page' && !current_user_can('delete_post', $post->ID))) {
                    throw new PackageException('You must be allowed to replace every page in this selection.');
                }
            }
            $lockIds = array_map(static fn (\WP_Post $p): int => $p->ID, $records);
            return EditorWriteLock::runMany($lockIds, fn (): array => $this->transaction(function () use ($package, $scope, $destination, $records, $expectedState, $replaceTitle): array {
                if (!hash_equals(self::fingerprint($scope, $destination), $expectedState)) {
                    throw new PackageException('WordPress changed while replacement was being prepared. Review it again.');
                }
                $backup = $this->backup($scope, $records);
                if ($scope === 'page') {
                    $conversionRevision = (string) get_post_meta($destination, ManagedPage::CONVERSION_REVISION, true);
                    if (!ManagedPage::isManaged($destination)) {
                        // Even a fresh draft can already have an identical revision. Force a
                        // recoverable snapshot only for this destination, then restore the filter.
                        $forceRevision = static fn ($check, $latest, $post) => (int) $post->ID === $destination ? false : $check;
                        add_filter('wp_save_post_revision_check_for_changes', $forceRevision, PHP_INT_MAX, 3);
                        try {
                            $revision = wp_save_post_revision($destination);
                        } finally {
                            remove_filter('wp_save_post_revision_check_for_changes', $forceRevision, PHP_INT_MAX);
                        }
                        if (is_wp_error($revision) || !$revision) {
                            throw new PackageException('WordPress could not back up the destination page. Nothing was replaced.');
                        }
                        $conversionRevision = (string) $revision;
                        update_post_meta($destination, ManagedPage::CONVERSION_REVISION, (string) $revision);
                    }
                    $result = (new PageImporter())->import($package, [
                        'replace_post_id' => $destination, 'confirm_replace' => true, 'confirm_convert' => true,
                        'replace_title' => $replaceTitle,
                    ]);
                    if ($conversionRevision !== '') {
                        update_post_meta($destination, ManagedPage::CONVERSION_REVISION, $conversionRevision);
                    }
                    update_post_meta($destination, ManagedPage::USE_PAGE_DOCUMENT, '1');
                    foreach (['header', 'footer'] as $kind) {
                        $id = (new GlobalElement())->import($package, $kind, $destination);
                        update_post_meta($destination, '_pagecraft_' . $kind . '_mode', 'selected');
                        update_post_meta($destination, '_pagecraft_' . $kind . '_id', (string) $id);
                    }
                    $summary = ['scope' => 'page', 'pageId' => $result->postId, 'updated' => 1, 'archived' => 0,
                        'label' => (string) get_the_title($destination)];
                } else {
                    // Free incoming URLs without permanently deleting displaced records.
                    // This is inside the transaction, after the recovery snapshot.
                    $incoming = [];
                    foreach ($package->pages() as $sourcePage) $incoming[(string) $sourcePage->id] = $sourcePage;
                    $projectId = (string) $package->provenance()->sourceId;
                    $archived = 0;
                    foreach ($records as $post) {
                        if ($post->post_type !== 'page') continue;
                        $sourceId = (string) get_post_meta($post->ID, ManagedPage::SOURCE_PAGE_ID, true);
                        $isIncoming = (string) get_post_meta($post->ID, ManagedPage::SOURCE_PROJECT_ID, true) === $projectId
                            && isset($incoming[$sourceId]);
                        if ($post->post_status !== self::ARCHIVE_STATUS && !$isIncoming) {
                            $this->updatePost(['ID' => $post->ID, 'post_status' => self::ARCHIVE_STATUS,
                                'post_name' => 'pc-archive-' . $post->ID . '-' . $post->post_name]);
                            $archived++;
                        }
                    }
                    // Restore the incoming identities only after outgoing pages have released their slugs.
                    foreach ($records as $post) {
                        if ($post->post_type !== 'page') continue;
                        $sourceId = (string) get_post_meta($post->ID, ManagedPage::SOURCE_PAGE_ID, true);
                        if ((string) get_post_meta($post->ID, ManagedPage::SOURCE_PROJECT_ID, true) !== $projectId
                            || !isset($incoming[$sourceId])) {
                            continue;
                        }
                        $restored = ['ID' => $post->ID,
                            'post_name' => sanitize_title((string) $incoming[$sourceId]->slug)];
                        if ($post->post_status === self::ARCHIVE_STATUS) $restored['post_status'] = 'publish';
                        $this->updatePost($restored);
                    }
                    $result = (new WholeProjectImporter())->import($package, [
                        'replace_site' => true, 'status' => 'publish', 'set_homepage' => true,
                    ]);
                    $job = (string) $result['jobId'];
                    $globalIds = [];
                    foreach (['header', 'footer'] as $kind) {
                        $globalId = GlobalElement::findForSource($result['projectId'], $kind, true);
                        if ($globalId <= 0) throw new PackageException('The incoming site has no reusable ' . $kind . '.');
                        $this->updatePost(['ID' => $globalId, 'post_status' => 'publish']);
                        $globalIds[$kind] = $globalId;
                    }
                    foreach (get_posts(['post_type' => 'page',
                        'post_status' => ['publish', 'draft', 'pending', 'private', 'future', self::ARCHIVE_STATUS],
                        'posts_per_page' => -1,
                        'meta_key' => ManagedPage::IMPORT_JOB_ID, 'meta_value' => $job]) as $post) {
                        $this->updatePost(['ID' => $post->ID, 'post_status' => 'publish']);
                        update_post_meta($post->ID, ManagedPage::USE_PAGE_DOCUMENT, '1');
                        // Explicit site replacement must not inherit old per-page template choices.
                        foreach (['header', 'footer'] as $kind) {
                            update_post_meta($post->ID, '_pagecraft_' . $kind . '_mode', 'selected');
                            update_post_meta($post->ID, '_pagecraft_' . $kind . '_id',
                                (string) $globalIds[$kind]);
                        }
                    }
                    foreach (['header', 'footer'] as $kind) {
                        update_option($kind === 'header' ? GlobalElement::DEFAULT_HEADER : GlobalElement::DEFAULT_FOOTER,
                            $globalIds[$kind], false);
                    }
                    // Old page-level Theme Builder overrides must not replace the incoming page body.
                    foreach (get_posts(['post_type' => GlobalElement::POST_TYPE, 'post_status' => 'publish',
                        'posts_per_page' => -1]) as $global) {
                        $kind = (string) get_post_meta($global->ID, GlobalElement::KIND, true);
                        if ($kind === 'single_page' || (in_array($kind, ['header', 'footer'], true)
                            && $global->ID !== $globalIds[$kind])) {
                            $this->updatePost(['ID' => $global->ID, 'post_status' => self::ARCHIVE_STATUS]);
                        }
                    }
                    $summary = ['scope' => 'site', 'pageId' => $result['homepageId'],
                        'updated' => $result['created'] + $result['updated'], 'archived' => $archived,
                        'label' => (string) ($package->document()->meta->name ?? '')];
                }
                $backupId = wp_insert_post([
                    'post_type' => WholeProjectImporter::JOB_POST_TYPE, 'post_status' => 'private',
                    'post_title' => 'Replacement recovery ' . gmdate('Y-m-d H:i:s') . ' UTC',
                    'post_content' => wp_slash(wp_json_encode($summary)),
                    'meta_input' => [self::BACKUP => wp_slash(wp_json_encode($backup))],
                ], true);
                if (is_wp_error($backupId) || !$backupId) throw new PackageException('WordPress could not retain the recovery snapshot.');
                CloudRecovery::prune();
                return $summary + ['backupId' => (int) $backupId];
            }));
        });
    }

    /**
     * @param list<\WP_Post> $pages
     * @return list<\WP_Post>
     */
    public static function replacementRecords(string $scope, array $pages): array
    {
        $records = [];
        foreach ($pages as $post) {
            if ($post instanceof \WP_Post) $records[$post->ID] = $post;
        }
        if ($scope === 'site') {
            foreach (get_posts([
                'post_type' => 'page',
                'post_status' => self::ARCHIVE_STATUS,
                'posts_per_page' => -1,
                'meta_query' => [[
                    'key' => ManagedPage::SOURCE_PROJECT_ID,
                    'compare' => 'EXISTS',
                ]],
            ]) as $post) {
                $records[$post->ID] = $post;
            }
        }
        foreach (get_posts([
            'post_type' => GlobalElement::POST_TYPE,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future', self::ARCHIVE_STATUS],
            'posts_per_page' => -1,
        ]) as $post) {
            $records[$post->ID] = $post;
        }
        ksort($records);
        return array_values($records);
    }

    /** @param list<\WP_Post> $records @return array<string,mixed> */
    public function backup(string $scope, array $records): array
    {
        $snapshot = ['scope' => $scope, 'createdAt' => gmdate('c'), 'posts' => [], 'options' => []];
        foreach ($records as $post) {
            $snapshot['posts'][$post->ID] = ['post' => get_post($post->ID, ARRAY_A), 'meta' => get_post_meta($post->ID)];
        }
        foreach (['show_on_front', 'page_on_front', GlobalElement::DEFAULT_HEADER, GlobalElement::DEFAULT_FOOTER,
            WholeProjectImporter::LINKED_PROJECT] as $option) {
            $snapshot['options'][$option] = get_option($option, null);
        }
        $snapshot['menus'] = (new NativeMenu())->checkpoint();
        return $snapshot;
    }

    /** @param array<string,mixed> $post */
    private function updatePost(array $post): void
    {
        $result = wp_update_post($post, true);
        if (is_wp_error($result) || !$result) throw new PackageException('WordPress could not complete the replacement.');
    }

    /** Database changes are committed together; generated assets are immutable. */
    public function transaction(callable $operation): mixed
    {
        global $wpdb;
        foreach ([$wpdb->posts, $wpdb->postmeta, $wpdb->options, $wpdb->terms, $wpdb->termmeta,
            $wpdb->term_taxonomy, $wpdb->term_relationships] as $table) {
            $engine = $wpdb->get_var($wpdb->prepare(
                'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s', $table
            ));
            if (strtoupper((string) $engine) !== 'INNODB') {
                throw new PackageException('Safe replacement requires transactional InnoDB WordPress tables. Nothing was replaced.');
            }
        }
        if ($wpdb->query('START TRANSACTION') === false) throw new PackageException('WordPress could not start a safe replacement.');
        try {
            $result = $operation();
            if ($wpdb->query('COMMIT') === false) throw new PackageException('WordPress could not commit the replacement.');
            return $result;
        } catch (\Throwable $error) {
            $wpdb->query('ROLLBACK');
            throw $error;
        } finally {
            // Core APIs may have primed object caches with uncommitted post/option/menu data.
            wp_cache_flush();
        }
    }
}
