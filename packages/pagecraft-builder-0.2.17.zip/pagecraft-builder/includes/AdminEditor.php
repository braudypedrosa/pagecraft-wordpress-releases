<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * The editor: its admin page, the cached editor document, the settings handed to it, and starting a page.
 *
 * Part of the Admin class, kept in its own file. Only Admin uses it.
 */
trait AdminEditor
{
    public function editor(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only editor route; per-post capability is checked below.
        $globalId = isset($_GET['global']) ? absint($_GET['global']) : 0;
        if ($globalId > 0) {
            $this->guardGlobal($globalId);
            $this->printEditorConfig($this->editorConfig($globalId, true));
            echo '<div class="pagecraft-editor-admin"><iframe class="pagecraft-editor-admin__frame" src="'
                . esc_url($this->editorShellUrl()) . '" title="' . esc_attr__('Pagecraft global element editor', 'pagecraft-builder')
                . '" allow="clipboard-write" referrerpolicy="same-origin"></iframe></div>';
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only editor route; per-post capability is checked below.
        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;
        $this->guardPage($postId);
        if (!ManagedPage::isManaged($postId)
            && (int) get_post_meta($postId, ManagedPage::CONVERSION_REVISION, true) === 0) {
            $this->editorChoice($postId);
            return;
        }
        $this->printEditorConfig($this->editorConfig($postId, false));
        echo '<div class="pagecraft-editor-admin"><iframe class="pagecraft-editor-admin__frame" src="'
            . esc_url($this->editorShellUrl()) . '" title="' . esc_attr__('Pagecraft editor', 'pagecraft-builder')
            . '" allow="clipboard-write" referrerpolicy="same-origin"></iframe></div>';
    }

    private function editorChoice(int $postId): void
    {
        echo '<div class="wrap pagecraft-admin pagecraft-start"><a class="pagecraft-admin__back" href="'
            . esc_url($this->pagesUrl()) . '">&larr; ' . esc_html__('WordPress Pages', 'pagecraft-builder') . '</a>'
            . '<h1>' . esc_html__('Start with Pagecraft', 'pagecraft-builder') . '</h1>'
            . '<p class="pagecraft-start__intro">' . esc_html__('Choose how to begin.', 'pagecraft-builder') . '</p>'
            . '<div class="pagecraft-start__choices"><section><h2>' . esc_html__('Blank Page', 'pagecraft-builder') . '</h2>'
            . '<p>' . esc_html__('Start with a blank canvas.', 'pagecraft-builder') . '</p>'
            . '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
        wp_nonce_field('pagecraft_prepare_page');
        echo '<input type="hidden" name="action" value="pagecraft_prepare_page"><input type="hidden" name="post" value="'
            . esc_attr((string) $postId) . '"><button class="button button-primary">'
            . esc_html__('Blank Page', 'pagecraft-builder') . '</button></form></section>'
            . '<section><h2>' . esc_html__('Use a template', 'pagecraft-builder') . '</h2><p>'
            . esc_html__('Choose a ready-made layout.', 'pagecraft-builder') . '</p><form action="'
            . esc_url(admin_url('admin-post.php')) . '" method="post">';
        wp_nonce_field('pagecraft_prepare_page');
        echo '<input type="hidden" name="action" value="pagecraft_prepare_page"><input type="hidden" name="post" value="'
            . esc_attr((string) $postId) . '"><label class="screen-reader-text" for="pagecraft-template">'
            . esc_html__('Page template', 'pagecraft-builder') . '</label><select id="pagecraft-template" name="template">';
        foreach ($this->pageTemplates() as $template) {
            if ($template['id'] === 'blank') continue;
            echo '<option value="' . esc_attr($template['id']) . '">' . esc_html($template['name']) . '</option>';
        }
        echo '</select> <button class="button button-primary">' . esc_html__('Use template', 'pagecraft-builder') . '</button></form></section>'
            . '<section><h2>' . esc_html__('Import from Pagecraft Cloud', 'pagecraft-builder') . '</h2>'
            . '<p>' . esc_html__('Choose a project from Pagecraft Cloud.', 'pagecraft-builder') . '</p>'
            . '<a class="button" href="' . esc_url(admin_url('admin.php?page=pagecraft-connect')) . '">'
            . esc_html__('Import from Pagecraft Cloud', 'pagecraft-builder') . '</a></section>'
            . '</div></div>';
    }

    /**
     * The editor itself: one large document that is the same for every page, so the browser keeps it.
     * What differs per page (its content, the nonce, the labels) is printed by the admin page around
     * the frame and read from there, which is why this response can be cached.
     */
    public function editorFrame(): void
    {
        if (!current_user_can(Capabilities::EDIT) && !current_user_can(Capabilities::MANAGE)) {
            $this->fail(__('You are not allowed to use the Pagecraft editor.', 'pagecraft-builder'), 403);
        }
        // Browsers say what a request is for. The editor only makes sense inside its admin page.
        $destination = isset($_SERVER['HTTP_SEC_FETCH_DEST']) ? sanitize_key(wp_unslash((string) $_SERVER['HTTP_SEC_FETCH_DEST'])) : '';
        if ($destination !== '' && $destination !== 'iframe') {
            $this->fail(__('Open the Pagecraft editor from WordPress Pages.', 'pagecraft-builder'), 403);
        }
        $html = $this->editorShell();
        $etag = '"' . $this->editorShellVersion() . '"';
        header_remove('Pragma');
        header_remove('Expires');
        header('Cache-Control: private, max-age=31536000, immutable');
        header('ETag: ' . $etag);
        header('Content-Type: text/html; charset=' . get_option('blog_charset', 'UTF-8'));
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        // The canvas is a srcdoc frame, so it inherits this policy. It links the chosen Google Fonts
        // stylesheet; without that host here the canvas silently shows fallback typefaces.
        header(self::EDITOR_CONTENT_SECURITY_POLICY);
        $known = isset($_SERVER['HTTP_IF_NONE_MATCH']) ? sanitize_text_field(wp_unslash((string) $_SERVER['HTTP_IF_NONE_MATCH'])) : '';
        if ($known !== '' && in_array($etag, array_map('trim', explode(',', str_replace('W/', '', $known))), true)) {
            status_header(304);
            exit;
        }
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted generated editor artifact plus a fixed bootstrap.
        exit;
    }

    /** The editor document with the fixed script that picks up its settings from the admin page. */
    private function editorShell(): string
    {
        $asset = PAGECRAFT_BUILDER_DIR . 'assets/pagecraft-editor.html';
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Trusted local bundled editor asset, never a remote URL.
        $html = @file_get_contents($asset);
        if (!is_string($html) || $html === '') {
            $this->fail(__('The Pagecraft editor asset is missing. Reinstall Pagecraft Builder.', 'pagecraft-builder'), 500);
        }
        $marker = "<script>\n/* =====================================================================";
        if (!str_contains($html, $marker)) {
            $this->fail(__('The Pagecraft editor asset is incompatible with this plugin.', 'pagecraft-builder'), 500);
        }
        // Without the admin page there is nothing to edit, so leave rather than start an empty editor.
        $script = '<script>window.PC_WORDPRESS=(function(){try{var c=window.parent!==window&&window.parent.' . self::EDITOR_CONFIG
            . ';if(c)return c}catch(e){}window.location.replace(' . wp_json_encode(
                $this->pagesUrl(),
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
            ) . ');throw new Error("Pagecraft editor opened outside WordPress.")})();</script>';
        return str_replace($marker, $script . "\n" . $marker, $html);
    }

    /** Changes whenever the editor document would, so a new release is never served from an old copy. */
    private function editorShellVersion(): string
    {
        $asset = PAGECRAFT_BUILDER_DIR . 'assets/pagecraft-editor.html';
        return substr(hash('sha256', PAGECRAFT_BUILDER_VERSION . '|' . (string) @filemtime($asset) . '|' . (string) @filesize($asset)
            . '|' . $this->pagesUrl()), 0, 20);
    }

    private function editorShellUrl(): string
    {
        return add_query_arg(
            ['action' => 'pagecraft_editor_frame', 'ver' => $this->editorShellVersion()],
            admin_url('admin-ajax.php')
        );
    }

    /** @param array<string,mixed> $config */
    private function printEditorConfig(array $config): void
    {
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded with every HTML-significant character escaped.
        echo '<script>window.' . self::EDITOR_CONFIG . '=' . wp_json_encode(
            $config,
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        ) . ';</script>';
    }

    /**
     * Everything the editor needs to know about what it is editing. The caller has already checked
     * that this person may edit it.
     *
     * @return array<string,mixed>
     */
    private function editorConfig(int $postId, bool $global, bool $settingsOnly = false): array
    {
        if ($settingsOnly) {
            $loaded = ['document' => null, 'version' => 0];
        } else {
            try {
                $loaded = $global ? (new GlobalElementEditor())->load($postId) : (new PageEditor())->load($postId);
                if (!$global && is_array($loaded['document'])) {
                    $loaded['document'] = Breadcrumbs::keepImportedTrails((new NativeMenu())->hydrateDocument($loaded['document']));
                }
            } catch (PackageException $error) {
                $this->fail($error->getMessage(), 400);
            }
        }
        $post = get_post($postId);
        $user = wp_get_current_user();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only, allowlisted startup hint protected by the surrounding frame nonce.
        $templateId = isset($_GET['pagecraft_template']) ? sanitize_key(wp_unslash($_GET['pagecraft_template'])) : '';
        $initialTemplate = $this->pageTemplate($templateId);
        $designSettings = new DesignSettings();
        $design = $designSettings->read();
        $config = [
            'restUrl' => untrailingslashit(rest_url(RestController::NAMESPACE)),
            'nonce' => wp_create_nonce('wp_rest'),
            'doc' => is_array($loaded['document']) ? DocumentJson::document($loaded['document']) : null,
            'version' => $loaded['version'],
            'role' => 'owner',
            'siteName' => get_bloginfo('name'),
            'settingsOnly' => $settingsOnly,
            'initialTemplate' => $initialTemplate === null ? null : $initialTemplate['id'],
            'designSettings' => DocumentJson::design($design),
            'designVersion' => $designSettings->version($design),
            'themeTemplate' => $global ? [
                'kind' => (string) get_post_meta($postId, GlobalElement::KIND, true),
                'label' => GlobalElement::label((string) get_post_meta($postId, GlobalElement::KIND, true)),
                'conditionsUrl' => admin_url('admin.php?page=pagecraft-globals&conditions=' . $postId),
            ] : null,
            'dynamicFields' => $global ? $this->wordpressDynamicFields() : [],
            'page' => [
                'id' => $postId,
                'title' => get_the_title($post),
                'slug' => (string) ($post->post_name ?? ''),
                'status' => (string) get_post_status($post),
            ],
            'pageTitleUrl' => $global || $settingsOnly ? null : add_query_arg('context', 'edit', rest_url('wp/v2/pages/' . $postId)),
            'user' => ['id' => (string) $user->ID, 'name' => (string) $user->display_name],
            'capabilities' => array_values(array_merge(
                ['edit_document', 'edit_structure', 'restore_revisions'],
                current_user_can('edit_pages') ? ['manage_pages'] : [],
                current_user_can('upload_files') ? ['upload_media'] : [],
                current_user_can(Capabilities::MANAGE) && current_user_can('edit_theme_options')
                    ? ['manage_menus', 'manage_settings'] : []
            )),
            'wordpressContent' => $settingsOnly ? [] : $this->wordpressContent(),
            'documentPath' => $global ? '/globals/' . $postId . '/document' : null,
            'revisionsPath' => $global ? '/globals/' . $postId . '/revisions' : null,
            'previewUrl' => $settingsOnly ? null : ($global ? add_query_arg([
                'action' => 'pagecraft_preview_global',
                'global' => $postId,
                '_wpnonce' => wp_create_nonce('pagecraft_preview_global_' . $postId),
            ], admin_url('admin-post.php')) : get_preview_post_link($postId)),
            'pagesUrl' => $settingsOnly ? admin_url('admin.php?page=pagecraft-site-settings')
                : ($global ? admin_url('admin.php?page=pagecraft-globals') : $this->pagesUrl()),
            'exitUrl' => $settingsOnly ? admin_url('admin.php?page=pagecraft-site-settings')
                : ($global ? admin_url('admin.php?page=pagecraft-globals') : get_edit_post_link($postId, 'raw')),
            'returnLabel' => $settingsOnly
                ? __('Return to Site Settings', 'pagecraft-builder')
                : ($global
                ? __('Save and return to Theme Builder', 'pagecraft-builder')
                : __('Save and return to WordPress Pages', 'pagecraft-builder')),
        ];
        return $config;
    }

    public function preparePage(): void
    {
        $postId = isset($_POST['post']) ? absint($_POST['post']) : 0;
        $templateId = isset($_POST['template']) ? sanitize_key(wp_unslash($_POST['template'])) : 'blank';
        check_admin_referer('pagecraft_prepare_page');
        $this->guardPage($postId);
        $template = $this->pageTemplate($templateId);
        if ($template === null) $this->fail(__('Choose a valid Pagecraft template.', 'pagecraft-builder'), 400);
        if (ManagedPage::isManaged($postId)) {
            wp_safe_redirect($this->editorUrl($postId));
            exit;
        }
        try {
            update_post_meta($postId, ManagedPage::CONVERSION_REVISION, $this->conversionRevision($postId));
            $post = get_post($postId);
            $currentTitle = trim((string) ($post->post_title ?? ''));
            if ($templateId !== 'blank'
                && in_array($currentTitle, ['', __('Untitled page', 'pagecraft-builder'), __('Untitled Pagecraft page', 'pagecraft-builder')], true)) {
                wp_update_post(['ID' => $postId, 'post_title' => sanitize_text_field((string) $template['name'])]);
            }
        } catch (PackageException $error) {
            $this->fail($error->getMessage(), 400);
        }
        wp_safe_redirect($this->editorUrl($postId, $templateId));
        exit;
    }

    public function createPage(): void
    {
        check_admin_referer('pagecraft_create_page');
        $this->guard(Capabilities::EDIT);
        $this->guard('edit_pages');
        $postId = wp_insert_post([
            'post_type' => 'page',
            'post_status' => 'draft',
            'post_title' => __('Untitled Pagecraft page', 'pagecraft-builder'),
        ], true);
        if (is_wp_error($postId)) {
            $this->fail($postId->get_error_message(), 400);
        }
        update_post_meta((int) $postId, ManagedPage::CONVERSION_REVISION, '-1');
        wp_safe_redirect($this->editorUrl((int) $postId));
        exit;
    }

    /** @return list<array{token:string,label:string,group:string,description:string}> */
    private function wordpressDynamicFields(): array
    {
        return [
            ['token' => '{{wp.site.title}}', 'label' => __('Site title', 'pagecraft-builder'), 'group' => __('Site', 'pagecraft-builder'), 'description' => __('Current WordPress site title.', 'pagecraft-builder')],
            ['token' => '{{wp.site.description}}', 'label' => __('Site tagline', 'pagecraft-builder'), 'group' => __('Site', 'pagecraft-builder'), 'description' => __('Current WordPress tagline.', 'pagecraft-builder')],
            ['token' => '{{wp.site.home_url}}', 'label' => __('Home URL', 'pagecraft-builder'), 'group' => __('Site', 'pagecraft-builder'), 'description' => __('Canonical WordPress home URL.', 'pagecraft-builder')],
            ['token' => '{{wp.post.title}}', 'label' => __('Post title', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Title of the current page, post or custom post.', 'pagecraft-builder')],
            ['token' => '{{wp.post.content}}', 'label' => __('Post content', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Rendered WordPress block and classic content.', 'pagecraft-builder')],
            ['token' => '{{wp.post.excerpt}}', 'label' => __('Post excerpt', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Manual excerpt or WordPress-generated summary.', 'pagecraft-builder')],
            ['token' => '{{wp.post.featured_image}}', 'label' => __('Featured image', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Responsive featured image for the current post.', 'pagecraft-builder')],
            ['token' => '{{wp.post.author}}', 'label' => __('Author name', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Display name of the current author.', 'pagecraft-builder')],
            ['token' => '{{wp.post.date}}', 'label' => __('Published date', 'pagecraft-builder'), 'group' => __('Singular', 'pagecraft-builder'), 'description' => __('Localized publication date.', 'pagecraft-builder')],
            ['token' => '{{wp.archive.title}}', 'label' => __('Archive title', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('Context-aware archive, taxonomy or author title.', 'pagecraft-builder')],
            ['token' => '{{wp.archive.description}}', 'label' => __('Archive description', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('Description for the current archive.', 'pagecraft-builder')],
            ['token' => '{{wp.search.query}}', 'label' => __('Search query', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('The visitor’s current search phrase.', 'pagecraft-builder')],
            ['token' => '{{wp.query.loop}}', 'label' => __('Results loop', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('Accessible cards for the active WordPress query.', 'pagecraft-builder')],
            ['token' => '{{wp.pagination}}', 'label' => __('Pagination', 'pagecraft-builder'), 'group' => __('Listings', 'pagecraft-builder'), 'description' => __('WordPress pagination for the current query.', 'pagecraft-builder')],
        ];
    }

    private function wordpressContent(): array
    {
        $home = home_url('/');
        $parts = wp_parse_url($home);
        if (!is_array($parts) || !is_string($parts['scheme'] ?? null) || !is_string($parts['host'] ?? null)) {
            return [];
        }
        $origin = $parts['scheme'] . '://' . $parts['host']
            . (isset($parts['port']) ? ':' . (int) $parts['port'] : '');
        $targetPath = '/' . trim((string) ($parts['path'] ?? '/'), '/');
        if ($targetPath !== '/') {
            $targetPath = rtrim($targetPath, '/');
        }
        $posts = get_posts([
            'post_type' => ['page', 'post'],
            'post_status' => ['draft', 'pending', 'publish', 'private'],
            'posts_per_page' => 500,
            'orderby' => ['post_type' => 'ASC', 'menu_order' => 'ASC', 'title' => 'ASC'],
        ]);
        $items = [];
        foreach ($posts as $post) {
            if (!in_array($post->post_type, ['page', 'post'], true)
                || !current_user_can('read_post', $post->ID)) {
                continue;
            }
            $items[] = [
                'id' => (string) $post->ID,
                'objectType' => (string) $post->post_type,
                'title' => get_the_title($post),
                'url' => get_permalink($post),
                'modifiedAt' => get_post_modified_time('c', true, $post),
            ];
        }
        return [[
            'connectionId' => 'wordpress-local',
            'environment' => 'production',
            'profile' => 'pagecraft-theme',
            'targetOrigin' => $origin,
            'targetPath' => $targetPath,
            'items' => $items,
        ]];
    }

    /** @return list<array{id:string,name:string,description:string,category:string,keywords:list<string>,preview:string}> */
    private function pageTemplates(): array
    {
        static $templates = null;
        if (is_array($templates)) return $templates;
        $templates = [];
        $path = PAGECRAFT_BUILDER_DIR . 'assets/pagecraft-templates.json';
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Trusted bundled catalog, never a remote URL.
        $raw = @file_get_contents($path);
        if (!is_string($raw) || $raw === '') return $templates;
        $catalog = json_decode($raw, true);
        if (!is_array($catalog) || ($catalog['format'] ?? '') !== 'pagecraft.template-catalog.v1'
            || !is_array($catalog['templates'] ?? null)) return $templates;
        foreach ($catalog['templates'] as $template) {
            if (!is_array($template)
                || !preg_match('/^[a-z][a-z0-9-]*$/', (string) ($template['id'] ?? ''))
                || trim((string) ($template['name'] ?? '')) === ''
                || !str_starts_with(trim((string) ($template['preview'] ?? '')), '<svg')) continue;
            $templates[] = [
                'id' => sanitize_key((string) $template['id']),
                'name' => sanitize_text_field((string) $template['name']),
                'description' => sanitize_text_field((string) ($template['description'] ?? '')),
                'category' => sanitize_text_field((string) ($template['category'] ?? '')),
                'keywords' => array_values(array_filter(array_map('sanitize_text_field',
                    is_array($template['keywords'] ?? null) ? $template['keywords'] : []))),
                'preview' => (string) $template['preview'],
            ];
        }
        return $templates;
    }

    /** @return array{id:string,name:string,description:string,category:string,keywords:list<string>,preview:string}|null */
    private function pageTemplate(string $templateId): ?array
    {
        foreach ($this->pageTemplates() as $template) {
            if (hash_equals($template['id'], $templateId)) return $template;
        }
        return null;
    }
}
