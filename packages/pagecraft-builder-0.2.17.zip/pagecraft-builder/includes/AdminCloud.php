<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Pagecraft Cloud: connecting an account, replacing a site or a page, and undoing a replacement.
 *
 * Part of the Admin class, kept in its own file. Only Admin uses it.
 */
trait AdminCloud
{
    public function connect(): void
    {
        $this->guard(Capabilities::MANAGE);
        $cloud = new CloudImport();
        $connected = $cloud->connection() !== null;
        $this->adminPageStart(
            'cloud',
            __('Pagecraft Cloud', 'pagecraft-builder'),
            $connected
                ? __('Replace this site, or one page, with a project from your Cloud account. Cloud stays unchanged and there is no automatic sync.', 'pagecraft-builder')
                : __('Connect your account, then replace a site or a page.', 'pagecraft-builder'),
            [
                'classes' => 'pagecraft-cloud',
                // The connection state sits beside the button that changes it, as plain text.
                'actions' => static function () use ($connected): void {
                    echo '<span class="pagecraft-admin__status">'
                        . esc_html($connected ? __('Connected', 'pagecraft-builder') : __('Not connected', 'pagecraft-builder')) . '</span>';
                    if (!$connected) {
                        return;
                    }
                    echo '<form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
                    wp_nonce_field('pagecraft_cloud_disconnect');
                    echo '<input type="hidden" name="action" value="pagecraft_cloud_disconnect"><button class="button">'
                        . esc_html__('Disconnect', 'pagecraft-builder') . '</button></form>';
                },
            ]
        );
        $this->cloudNoticeFromQuery();
        $screen = new CloudTransferScreen();
        if ($screen->recovery()) {
            $this->adminPageEnd();
            return;
        }
        if (!$connected) {
            // Before connecting, the screen says what the three steps after it are, in the picker frame.
            echo '<div class="pagecraft-pick"><div class="pagecraft-pick__band"><h2>'
                . esc_html__('Connect your Pagecraft account', 'pagecraft-builder') . '</h2></div><ol class="pagecraft-pick__steps">';
            foreach ([
                __('Sign in to Pagecraft and approve access.', 'pagecraft-builder'),
                __('Choose a project, and the whole site or one page.', 'pagecraft-builder'),
                __('Review what will change, then confirm.', 'pagecraft-builder'),
            ] as $index => $step) {
                echo '<li><span aria-hidden="true">' . esc_html((string) ($index + 1)) . '</span>' . esc_html($step) . '</li>';
            }
            echo '</ol><div class="pagecraft-pick__foot"><p>' . esc_html__('Nothing is imported until you choose a project and confirm.', 'pagecraft-builder')
                . '</p><div class="pagecraft-pick__actions"><form action="' . esc_url(admin_url('admin-post.php')) . '" method="post">';
            wp_nonce_field('pagecraft_cloud_check');
            echo '<input type="hidden" name="action" value="pagecraft_cloud_check"><button class="button">'
                . esc_html__('Check availability', 'pagecraft-builder') . '</button></form><form action="'
                . esc_url(admin_url('admin-post.php')) . '" method="post">';
            wp_nonce_field('pagecraft_cloud_start');
            echo '<input type="hidden" name="action" value="pagecraft_cloud_start"><button class="button button-primary">'
                . esc_html__('Connect Pagecraft account', 'pagecraft-builder') . '</button></form></div></div></div>';
            $this->adminPageEnd();
            return;
        }
        try {
            $screen->render($cloud);
        } catch (PackageException $error) {
            $this->toast($error->getMessage(), 'error', __('Pagecraft could not complete the request', 'pagecraft-builder'));
            echo '<div class="pagecraft-pad"><a class="button" href="'
                . esc_url(admin_url('admin.php?page=pagecraft-connect')) . '">'
                . esc_html__('Try again', 'pagecraft-builder') . '</a></div>';
        }
        $this->adminPageEnd();
    }

    public function cloudPages(): void
    {
        check_ajax_referer('pagecraft_cloud_page', 'nonce');
        if (!current_user_can(Capabilities::EDIT) || !current_user_can(Capabilities::IMPORT)) {
            wp_send_json_error(['message' => __('You are not allowed to import Pagecraft pages.', 'pagecraft-builder')], 403);
        }

        $cloud = new CloudImport();
        if (!$cloud->connection()) {
            wp_send_json_success(['connected' => false, 'projects' => []]);
        }

        try {
            $projects = [];
            foreach ($cloud->catalog() as $project) {
                $projectId = sanitize_text_field((string) ($project['id'] ?? ''));
                if ($projectId === '') continue;
                $pages = [];
                foreach (is_array($project['pages'] ?? null) ? $project['pages'] : [] as $page) {
                    if (!is_array($page)) continue;
                    $pageId = sanitize_text_field((string) ($page['id'] ?? ''));
                    if ($pageId === '') continue;
                    $pages[] = [
                        'id' => $pageId,
                        'name' => sanitize_text_field((string) (($page['name'] ?? '') ?: __('Untitled page', 'pagecraft-builder'))),
                        'slug' => sanitize_title((string) ($page['slug'] ?? '')),
                    ];
                }
                $projects[] = [
                    'id' => $projectId,
                    'name' => sanitize_text_field((string) (($project['name'] ?? '') ?: __('Untitled project', 'pagecraft-builder'))),
                    'pages' => $pages,
                ];
            }
            wp_send_json_success(['connected' => true, 'projects' => $projects]);
        } catch (PackageException $error) {
            wp_send_json_error([
                'connected' => $cloud->connection() !== null,
                'message' => $error->getMessage(),
            ], 502);
        }
    }

    public function cloudImportPage(): void
    {
        check_ajax_referer('pagecraft_cloud_page', 'nonce');
        $postId = absint($_POST['post'] ?? 0);
        $projectId = sanitize_text_field(wp_unslash((string) ($_POST['project'] ?? '')));
        $pageId = sanitize_text_field(wp_unslash((string) ($_POST['cloud_page'] ?? '')));
        if ($postId <= 0 || get_post_type($postId) !== 'page' || !current_user_can(Capabilities::EDIT)
            || !current_user_can(Capabilities::IMPORT) || !current_user_can('edit_post', $postId)) {
            wp_send_json_error(['message' => __('You are not allowed to import into this page.', 'pagecraft-builder')], 403);
        }
        if ($projectId === '' || $pageId === '') {
            wp_send_json_error(['message' => __('Choose a Pagecraft Cloud page.', 'pagecraft-builder')], 400);
        }

        $temporary = '';
        $response = [];
        $errorStatus = 0;
        try {
            $temporary = (new CloudImport())->downloadPage($projectId, $pageId);
            $package = PortablePagePackage::fromFile($temporary);
            if ($package->isSite() || !hash_equals($pageId, (string) ($package->page()->id ?? ''))) {
                throw new PackageException('Pagecraft returned a different page package. Choose the page again.');
            }
            $post = get_post($postId);
            $currentTitle = trim((string) ($post->post_title ?? ''));
            $replaceTitle = in_array($currentTitle, ['', __('Untitled page', 'pagecraft-builder'), __('Untitled Pagecraft page', 'pagecraft-builder')], true)
                ? sanitize_text_field((string) (($package->page()->name ?? '') ?: ($package->page()->title ?? '')))
                : '';
            (new CloudReplacement())->replace(
                $package, 'page', $postId, true, CloudReplacement::fingerprint('page', $postId), $replaceTitle
            );
            $response = ['editorUrl' => $this->editorUrl($postId)];
        } catch (\Throwable $error) {
            if (!$error instanceof PackageException) {
                error_log('Pagecraft Cloud page import failed: ' . $error->getMessage());
            }
            $response = [
                'message' => $error instanceof PackageException
                    ? $error->getMessage()
                    : __('WordPress could not import this Pagecraft page. Try again.', 'pagecraft-builder'),
            ];
            $errorStatus = $error instanceof PackageException ? 400 : 500;
        } finally {
            if ($temporary !== '' && is_file($temporary)) wp_delete_file($temporary);
        }
        if ($errorStatus) wp_send_json_error($response, $errorStatus);
        wp_send_json_success($response);
    }

    public function cloudStart(): void
    {
        check_admin_referer('pagecraft_cloud_start');
        $this->guard(Capabilities::MANAGE);
        $callback = admin_url('admin-post.php?action=pagecraft_cloud_callback');
        $returnTo = '';
        $postId = absint($_POST['post'] ?? 0);
        if ($postId > 0) {
            $this->guardPage($postId);
            $returnTo = add_query_arg([
                'pagecraft_choose' => 1,
                'pagecraft_cloud' => 1,
            ], get_edit_post_link($postId, 'raw'));
        }
        try {
            wp_safe_redirect((new CloudImport())->authorizationUrl($callback, $returnTo));
        } catch (PackageException $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', $error->getMessage(), admin_url('admin.php?page=pagecraft-connect')));
        }
        exit;
    }

    public function cloudCheck(): void
    {
        check_admin_referer('pagecraft_cloud_check');
        $this->guard(Capabilities::MANAGE);
        try {
            (new CloudImport())->checkAvailability();
            wp_safe_redirect(admin_url('admin.php?page=pagecraft-connect&pagecraft_cloud_available=1'));
        } catch (PackageException $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', $error->getMessage(), admin_url('admin.php?page=pagecraft-connect')));
        }
        exit;
    }

    public function cloudCallback(): void
    {
        $this->guard(Capabilities::MANAGE);
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- OAuth PKCE state is verified and consumed by CloudImport::complete().
        $code = sanitize_text_field(wp_unslash((string) ($_GET['code'] ?? '')));
        $state = sanitize_text_field(wp_unslash((string) ($_GET['state'] ?? '')));
        // phpcs:enable
        try {
            if ($code === '' || $state === '') throw new PackageException('Pagecraft did not return a complete authorization response.');
            $returnTo = (new CloudImport())->complete($code, $state, admin_url('admin-post.php?action=pagecraft_cloud_callback'));
            $destination = $returnTo !== '' ? wp_validate_redirect($returnTo, '') : '';
            if ($destination === '' || !str_starts_with($destination, admin_url())) {
                $destination = admin_url('admin.php?page=pagecraft-connect&pagecraft_connected=1');
            }
            wp_safe_redirect($destination);
        } catch (PackageException $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', $error->getMessage(), admin_url('admin.php?page=pagecraft-connect')));
        }
        exit;
    }

    public function cloudDisconnect(): void
    {
        check_admin_referer('pagecraft_cloud_disconnect');
        $this->guard(Capabilities::MANAGE);
        (new CloudImport())->disconnect();
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-connect&pagecraft_disconnected=1'));
        exit;
    }

    public function cloudImport(): void
    {
        $projectId = sanitize_text_field(wp_unslash((string) ($_POST['project'] ?? '')));
        check_admin_referer('pagecraft_cloud_import_' . $projectId);
        $this->guard(Capabilities::IMPORT);
        $temporary = '';
        try {
            $scope = sanitize_key((string) ($_POST['scope'] ?? ''));
            if ($projectId === '' || !in_array($scope, ['site', 'page'], true) || empty($_POST['confirm_replace'])) {
                throw new PackageException('Review and confirm the replacement first.');
            }
            $sourcePage = sanitize_text_field(wp_unslash((string) ($_POST['source_page'] ?? '')));
            $destination = absint($_POST['destination'] ?? 0);
            $cloud = new CloudImport();
            $temporary = $scope === 'site' ? $cloud->downloadProject($projectId) : $cloud->downloadPage($projectId, $sourcePage);
            $package = PortablePagePackage::fromFile($temporary);
            if (!hash_equals($projectId, (string) $package->provenance()->sourceId)
                || (int) $package->provenance()->sourceVersion !== absint($_POST['source_version'] ?? 0)
                || ($scope === 'page' && ($package->isSite() || !hash_equals($sourcePage, (string) $package->page()->id)))) {
                throw new PackageException('The Cloud selection changed. Review it again before replacing WordPress content.');
            }
            ImportedFonts::reset();
            $result = (new CloudReplacement())->replace($package, $scope, $destination, true,
                sanitize_text_field(wp_unslash((string) ($_POST['destination_state'] ?? ''))));
            // The replacement is complete and correct apart from its typefaces, so this is a note, not an error.
            $fontNote = ImportedFonts::missed()
                ? ' The web fonts could not be loaded from Google Fonts, so pages show fallback fonts. Replace again to retry.'
                : '';
            wp_safe_redirect(add_query_arg([
                'project' => $projectId,
                'pagecraft_message' => ($scope === 'page'
                    ? sprintf('Page replaced. Other pages are unchanged. Recovery record %d.', $result['backupId'])
                    : sprintf('Site replaced: %d pages published, %d archived. Recovery record %d.',
                        $result['updated'], $result['archived'], $result['backupId'])) . $fontNote,
            ], admin_url('admin.php?page=pagecraft-connect')));
        } catch (\Throwable $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', rawurlencode($error->getMessage()),
                admin_url('admin.php?page=pagecraft-connect&project=' . rawurlencode($projectId))));
        } finally {
            if ($temporary !== '' && is_file($temporary)) wp_delete_file($temporary);
        }
        exit;
    }

    public function cloudUndo(): void
    {
        $recordId = absint($_POST['record'] ?? 0);
        check_admin_referer('pagecraft_cloud_undo_' . $recordId);
        $this->guard(Capabilities::IMPORT);
        try {
            if ($recordId <= 0 || empty($_POST['confirm_undo'])) {
                throw new PackageException('Review and confirm the undo first.');
            }
            $result = (new CloudRecovery())->undo($recordId, true,
                sanitize_text_field(wp_unslash((string) ($_POST['state'] ?? ''))));
            // Cached pages still show the site that was just replaced.
            PageCaches::clear();
            $message = sprintf('Restored: %d pages and templates are back, %d archived.', $result['restored'], $result['archived']);
            if ($result['missing'] > 0) {
                $message .= sprintf(' %d could not return because they were permanently deleted.', $result['missing']);
            }
            wp_safe_redirect(add_query_arg('pagecraft_message', $message, admin_url('admin.php?page=pagecraft-connect')));
        } catch (\Throwable $error) {
            wp_safe_redirect(add_query_arg('pagecraft_error', rawurlencode($error->getMessage()),
                admin_url('admin.php?page=pagecraft-connect')));
        }
        exit;
    }

    private function cloudNoticeFromQuery(): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Status from the verified OAuth callback redirect.
        if (isset($_GET['pagecraft_cloud_available'])) {
            $this->toast(
                __('The authorization service responded correctly. Continue with Connect Pagecraft account.', 'pagecraft-builder'),
                'success',
                __('Pagecraft Cloud is reachable', 'pagecraft-builder')
            );
        }
        if (isset($_GET['pagecraft_error'])) {
            $message = sanitize_text_field(wp_unslash((string) $_GET['pagecraft_error']));
            if ($message === 'Pagecraft Cloud could not complete the request.') {
                $message = __('Pagecraft could not save this connection. Try connecting again.', 'pagecraft-builder');
            }
            $this->toast($message, 'error', __('Pagecraft could not complete the request', 'pagecraft-builder'));
        }
        if (isset($_GET['pagecraft_message'])) {
            $message = sanitize_text_field(wp_unslash((string) $_GET['pagecraft_message']));
            // A replacement that could not load its fonts carries that as a second sentence: show it as its own warning.
            $split = strpos($message, ' The web fonts could not be loaded');
            if ($split !== false) {
                $this->toast(substr($message, 0, $split));
                $this->toast(trim(substr($message, $split)), 'warning');
            } else {
                $this->toast($message);
            }
        }
        // phpcs:enable
    }
}
