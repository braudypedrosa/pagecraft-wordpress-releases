<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class PortablePagePackage
{
    public const FORMAT = 'pagecraft.page-package.v1';
    public const SITE_FORMAT = 'pagecraft.site-package.v1';
    public const SCHEMA_VERSION = 17;
    public const MIN_SCHEMA_VERSION = 13;
    // Each schema pins its renderer identity. Missing and renderer-1 remain supported schema-13
    // packages; schemas 15-16 (rich tabs) use renderer-3 and new exports use renderer-4.
    public const SCHEMA_14_RENDERER_REVISION = 'pagecraft-renderer-2';
    public const SCHEMA_15_RENDERER_REVISION = 'pagecraft-renderer-3';
    public const RENDERER_REVISION = 'pagecraft-renderer-4';
    public const LEGACY_RENDERER_REVISION = 'pagecraft-renderer-1';
    public const MAX_ARCHIVE_BYTES = 314572800;
    public const MAX_FILES = 5000;
    public const MAX_PATH_BYTES = 240;
    public const MAX_FILE_BYTES = 104857600;
    public const MAX_EXPANDED_BYTES = 524288000;
    public const MAX_MANIFEST_BYTES = 2097152;
    public const MAX_DOCUMENT_BYTES = 52428800;

    /** @var array<string, \stdClass> */
    private array $records = [];
    private \ZipArchive $archive;
    private \stdClass $manifest;
    private \stdClass $document;
    private \stdClass $provenance;
    private \stdClass $dependencies;
    private string $archiveHash;
    private string $compiledPath;
    /** @var array<string,string> */
    private array $compiledPaths = [];
    private ?string $globalStylePath = null;
    private ?string $pageStylePath = null;
    /** @var array<string,string> */
    private array $pageStylePaths = [];
    private ?string $legacyStylePath = null;

    private function __construct()
    {
    }

    public static function fromFile(string $path): self
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new PackageException('The PHP ZIP extension is required to import a Pagecraft package.');
        }
        if (!is_file($path) || !is_readable($path)) {
            throw new PackageException('The Pagecraft package could not be read.');
        }
        $archiveBytes = filesize($path);
        if ($archiveBytes === false || $archiveBytes < 22 || $archiveBytes > self::MAX_ARCHIVE_BYTES) {
            throw new PackageException('The Pagecraft package exceeds the archive-size limit or is incomplete.');
        }

        $package = new self();
        $package->archive = new \ZipArchive();
        $opened = $package->archive->open($path, \ZipArchive::RDONLY);
        if ($opened !== true) {
            throw new PackageException('The Pagecraft package is not a readable ZIP archive.');
        }
        $package->archiveHash = (string) hash_file('sha256', $path);
        $package->validateArchive();
        return $package;
    }

    public function __destruct()
    {
        if (isset($this->archive)) {
            $this->archive->close();
        }
    }

    public function manifest(): \stdClass
    {
        return $this->manifest;
    }

    public function document(): \stdClass
    {
        return $this->document;
    }

    public function documentJson(): string
    {
        if (($this->manifest->kind ?? '') !== 'site') return $this->readText('source/document.json');
        $document = clone $this->document;
        $document->pages = [$this->page()];
        return CanonicalJson::encode($document);
    }

    public function fullDocumentJson(): string
    {
        return $this->readText('source/document.json');
    }

    public function page(): \stdClass
    {
        return $this->document->pages[0];
    }

    /** @return list<\stdClass> */
    public function pages(): array
    {
        return array_values($this->document->pages);
    }

    public function isSite(): bool
    {
        return ($this->manifest->kind ?? '') === 'site';
    }

    public function selectPage(string $pageId): void
    {
        foreach ($this->document->pages as $index => $page) {
            if ($page instanceof \stdClass && hash_equals($pageId, (string) ($page->id ?? ''))) {
                $this->document->pages = array_values($this->document->pages);
                $selected = $this->document->pages[$index];
                $path = $this->compiledPaths[$pageId] ?? '';
                $style = $this->pageStylePaths[$pageId] ?? '';
                if ($path === '' || $style === '') throw new PackageException('The selected Pagecraft page has no compiled files.');
                array_splice($this->document->pages, $index, 1);
                array_unshift($this->document->pages, $selected);
                $this->compiledPath = $path;
                $this->pageStylePath = $style;
                return;
            }
        }
        throw new PackageException('The selected Pagecraft project page does not exist.');
    }

    public function provenance(): \stdClass
    {
        return $this->provenance;
    }

    public function dependencies(): \stdClass
    {
        return $this->dependencies;
    }

    public function packageHash(): string
    {
        return $this->archiveHash;
    }

    public function compiledHtml(): string
    {
        return $this->readText($this->compiledPath);
    }

    public function compiledCss(): string
    {
        return implode("\n", array_filter([
            $this->globalCss(),
            $this->pageCss(),
        ], static fn (string $part): bool => $part !== ''));
    }

    public function globalCss(): string
    {
        return $this->globalStylePath !== null ? $this->readText($this->globalStylePath) : '';
    }

    public function pageCss(): string
    {
        $path = $this->pageStylePath ?? $this->legacyStylePath;
        return $path !== null ? $this->readText($path) : '';
    }

    /** @return list<\stdClass> */
    public function assetRecords(): array
    {
        return array_values(array_filter(
            $this->records,
            static fn (\stdClass $record): bool => ($record->role ?? null) === 'asset'
        ));
    }

    public function assetBytes(string $path): string
    {
        $record = $this->records[strtolower($path)] ?? null;
        if (!$record instanceof \stdClass || ($record->role ?? null) !== 'asset' || $record->path !== $path) {
            throw new PackageException('The requested Pagecraft asset is not part of this package.');
        }
        $source = $this->archive->getFromName($path, 0, \ZipArchive::FL_UNCHANGED);
        if (!is_string($source) || strlen($source) !== $record->bytes || hash('sha256', $source) !== $record->sha256) {
            throw new PackageException('The Pagecraft asset failed integrity verification: ' . $path . '.');
        }
        return $source;
    }

    private function validateArchive(): void
    {
        if ($this->archive->numFiles < 2 || $this->archive->numFiles > self::MAX_FILES) {
            throw new PackageException('The Pagecraft package exceeds the file-count limit or is incomplete.');
        }

        $seen = [];
        $expanded = 0;
        for ($index = 0; $index < $this->archive->numFiles; $index++) {
            $stat = $this->archive->statIndex($index, \ZipArchive::FL_UNCHANGED);
            if (!is_array($stat) || !isset($stat['name'], $stat['size'], $stat['comp_size'], $stat['comp_method'])) {
                throw new PackageException('The Pagecraft package contains malformed ZIP metadata.');
            }
            $name = (string) $stat['name'];
            self::assertSafePath($name);
            $folded = strtolower($name);
            if (isset($seen[$folded])) {
                throw new PackageException('The Pagecraft package contains a duplicate path: ' . $name);
            }
            $seen[$folded] = true;
            $size = (int) $stat['size'];
            $compressed = (int) $stat['comp_size'];
            if ($size < 0 || $size > self::MAX_FILE_BYTES) {
                throw new PackageException('A Pagecraft package file exceeds the size limit: ' . $name);
            }
            $expanded += $size;
            if ($expanded > self::MAX_EXPANDED_BYTES) {
                throw new PackageException('The Pagecraft package exceeds the expanded-size limit.');
            }
            if (($compressed === 0 && $size > 0) || ($compressed > 0 && $size / $compressed > 100)) {
                throw new PackageException('The Pagecraft package contains an unsafe compression ratio.');
            }
            if (!in_array((int) $stat['comp_method'], [\ZipArchive::CM_STORE, \ZipArchive::CM_DEFLATE], true)) {
                throw new PackageException('The Pagecraft package uses unsupported ZIP compression.');
            }
            if (isset($stat['encryption_method']) && (int) $stat['encryption_method'] !== \ZipArchive::EM_NONE) {
                throw new PackageException('Encrypted Pagecraft package entries are not supported.');
            }
            $operations = 0;
            $attributes = 0;
            if ($this->archive->getExternalAttributesIndex($index, $operations, $attributes)
                && $operations === \ZipArchive::OPSYS_UNIX
                && (($attributes >> 16) & 0170000) === 0120000) {
                throw new PackageException('Pagecraft packages cannot contain symbolic links.');
            }
        }

        $manifestSource = $this->readText('manifest.json', self::MAX_MANIFEST_BYTES);
        $this->manifest = CanonicalJson::decodeObject($manifestSource, 'Pagecraft package manifest');
        $this->validateManifest();
    }

    public static function supportsRendererContract(mixed $schemaVersion, mixed $rendererVersion, mixed $rendererRevision): bool
    {
        if (!is_int($schemaVersion)) return false;
        $revisions = match ($schemaVersion) {
            13 => [null, self::LEGACY_RENDERER_REVISION, self::SCHEMA_14_RENDERER_REVISION],
            14 => [null, self::LEGACY_RENDERER_REVISION, self::SCHEMA_14_RENDERER_REVISION],
            15, 16 => [self::SCHEMA_15_RENDERER_REVISION],
            17 => [self::RENDERER_REVISION],
            default => null,
        };
        return $revisions !== null
            && $rendererVersion === 'pagecraft-core-' . $schemaVersion
            && in_array($rendererRevision, $revisions, true);
    }

    private function validateManifest(): void
    {
        $manifest = $this->manifest;
        $kind = (string) ($manifest->kind ?? '');
        if (!in_array(($manifest->format ?? null), [self::FORMAT, self::SITE_FORMAT], true)
            || !in_array($kind, ['page', 'site'], true)
            || (($kind === 'page') !== (($manifest->format ?? null) === self::FORMAT))
            || ($manifest->packageVersion ?? null) !== 1) {
            throw new PackageException('This is not a supported Pagecraft page package.');
        }
        if (!self::supportsRendererContract(
            $manifest->schemaVersion ?? null,
            $manifest->rendererVersion ?? null,
            property_exists($manifest, 'rendererRevision') ? ($manifest->rendererRevision ?? null) : null
        )) {
            throw new PackageException(
                'This package requires a different Pagecraft schema or renderer. '
                . 'Open it in a current Pagecraft editor to migrate it before importing.'
            );
        }
        if (($manifest->documentPath ?? null) !== 'source/document.json'
            || ($manifest->provenancePath ?? null) !== 'source/provenance.json'
            || ($manifest->dependenciesPath ?? null) !== 'source/dependencies.json'
            || !isset($manifest->cms) || ($manifest->cms->policy ?? null) !== 'reject'
            || ($manifest->cms->flattened ?? null) !== false
            || !isset($manifest->files) || !is_array($manifest->files)) {
            throw new PackageException('The Pagecraft page manifest contract is invalid.');
        }
        if (($kind === 'page' && (!is_string($manifest->entryPageId ?? null) || $manifest->entryPageId === ''))
            || ($kind === 'site' && isset($manifest->entryPageId))) {
            throw new PackageException('The Pagecraft package entry-page contract is invalid.');
        }
        if (count($manifest->files) + 1 !== $this->archive->numFiles) {
            throw new PackageException('The Pagecraft package contains unlisted or missing files.');
        }
        if (($manifest->contentHash ?? null) !== hash('sha256', CanonicalJson::encode($manifest->files))) {
            throw new PackageException('The Pagecraft package file manifest hash is invalid.');
        }

        $previous = null;
        $compiled = [];
        foreach ($manifest->files as $record) {
            if (!$record instanceof \stdClass || !$this->validFileRecord($record)) {
                throw new PackageException('The Pagecraft package contains an invalid file record.');
            }
            $path = (string) $record->path;
            if ($previous !== null && strcmp($previous, $path) >= 0) {
                throw new PackageException('The Pagecraft package file manifest is not deterministically ordered.');
            }
            $previous = $path;
            if (isset($this->records[strtolower($path)])) {
                throw new PackageException('The Pagecraft package file manifest repeats a path.');
            }
            $this->records[strtolower($path)] = $record;
            $this->verifyFile($record);
            if ($record->role === 'compiled-page') {
                $compiled[] = $path;
            } elseif ($record->role === 'style') {
                if ($path === 'styles/global.css') {
                    $this->globalStylePath = $path;
                } elseif (str_starts_with($path, 'styles/pages/')) {
                    if ($kind === 'page' && $this->pageStylePath !== null) {
                        throw new PackageException('A Pagecraft page package cannot contain multiple page stylesheets.');
                    }
                    if ($kind === 'page') $this->pageStylePath = $path;
                } else {
                    if ($this->legacyStylePath !== null) {
                        throw new PackageException('A legacy Pagecraft page package cannot contain multiple stylesheets.');
                    }
                    $this->legacyStylePath = $path;
                }
            }
        }
        $modernStyles = $this->globalStylePath !== null
            && ($kind === 'site' || $this->pageStylePath !== null)
            && $this->legacyStylePath === null;
        $legacyStyles = $this->legacyStylePath !== null && $this->globalStylePath === null && $this->pageStylePath === null;
        if (($kind === 'page' && count($compiled) !== 1)
            || ($kind === 'site' && count($compiled) < 1)
            || (!$modernStyles && !$legacyStyles)) {
            throw new PackageException(
                'A Pagecraft page package must contain one compiled page and either split global/page styles or one legacy stylesheet.'
            );
        }
        $this->compiledPath = $compiled[0];

        $documentSource = $this->readText('source/document.json', self::MAX_DOCUMENT_BYTES);
        $this->document = CanonicalJson::decodeObject($documentSource, 'Pagecraft package document');
        $this->provenance = CanonicalJson::decodeObject(
            $this->readText('source/provenance.json'),
            'Pagecraft package provenance'
        );
        $this->dependencies = CanonicalJson::decodeObject(
            $this->readText('source/dependencies.json'),
            'Pagecraft package dependencies'
        );
        $this->validateSourceContracts();
    }

    private function validateSourceContracts(): void
    {
        if (($this->document->schemaVersion ?? null) !== ($this->manifest->schemaVersion ?? null)
            || !isset($this->document->meta) || !$this->document->meta instanceof \stdClass
            || !isset($this->document->header) || !is_array($this->document->header)
            || !isset($this->document->footer) || !is_array($this->document->footer)
            || !isset($this->document->pages) || !is_array($this->document->pages)
            || count($this->document->pages) < 1) {
            throw new PackageException('The Pagecraft page document does not match its manifest entry page.');
        }
        if (($this->manifest->kind ?? '') === 'page'
            && (count($this->document->pages) !== 1
                || ($this->document->pages[0]->id ?? null) !== ($this->manifest->entryPageId ?? null))) {
            throw new PackageException('The Pagecraft page document does not match its manifest entry page.');
        }
        $ids = [];
        foreach ($this->document->pages as $page) {
            if (!$page instanceof \stdClass || !is_string($page->id ?? null) || $page->id === ''
                || isset($ids[$page->id]) || !is_string($page->name ?? null)
                || !is_string($page->slug ?? null) || !preg_match('/^[a-z0-9][a-z0-9-]{0,79}$/', $page->slug)
                || !isset($page->tree) || !is_array($page->tree)) {
                throw new PackageException('The Pagecraft project contains an invalid or duplicate page.');
            }
            $ids[$page->id] = true;
            $compiled = 'compiled/' . $page->slug . '.html';
            $style = 'styles/pages/' . $page->slug . '.css';
            if (!isset($this->records[strtolower($compiled)], $this->records[strtolower($style)])) {
                throw new PackageException('A Pagecraft project page is missing its compiled HTML or stylesheet.');
            }
            $this->compiledPaths[$page->id] = $compiled;
            $this->pageStylePaths[$page->id] = $style;
        }
        if (($this->manifest->kind ?? '') === 'site') {
            $compiledCount = count(array_filter($this->records, static fn (\stdClass $record): bool => $record->role === 'compiled-page'));
            $pageStyleCount = count(array_filter($this->records, static fn (\stdClass $record): bool => $record->role === 'style' && str_starts_with($record->path, 'styles/pages/')));
            if ($compiledCount !== count($ids) || $pageStyleCount !== count($ids)) {
                throw new PackageException('The Pagecraft site package does not contain exactly one compiled page and stylesheet per page.');
            }
            $firstId = (string) $this->document->pages[0]->id;
            $this->compiledPath = $this->compiledPaths[$firstId];
            $this->pageStylePath = $this->pageStylePaths[$firstId];
        }
        if (($this->provenance->format ?? null) !== 'pagecraft.provenance.v1'
            || !in_array(($this->provenance->origin ?? null), ['pagecraft-cloud', 'wordpress-local'], true)
            || !is_string($this->provenance->sourceId ?? null)
            || $this->provenance->sourceId === ''
            || !is_int($this->provenance->sourceVersion ?? null)
            || $this->provenance->sourceVersion < 0) {
            throw new PackageException('The Pagecraft package provenance is invalid.');
        }
        $cms = $this->dependencies->cms ?? null;
        if (($this->dependencies->format ?? null) !== 'pagecraft.dependencies.v1'
            || !$cms instanceof \stdClass || ($cms->policy ?? null) !== 'reject'
            || ($cms->collections ?? null) !== 0 || ($cms->boundNodes ?? null) !== 0
            || ($cms->collectionLists ?? null) !== 0 || ($cms->detailPages ?? null) !== 0) {
            throw new PackageException('Pagecraft CMS content must be flattened explicitly before WordPress import.');
        }
        $dependencyAssets = $this->dependencies->assets ?? null;
        $packagedAssets = array_map(
            static fn (\stdClass $record): string => (string) $record->asset->id,
            $this->assetRecords()
        );
        if (!is_array($dependencyAssets)
            || count(array_filter($dependencyAssets, 'is_string')) !== count($dependencyAssets)) {
            throw new PackageException('The Pagecraft package asset dependency list is invalid.');
        }
        $dependencyAssets = array_values($dependencyAssets);
        sort($dependencyAssets, SORT_STRING);
        sort($packagedAssets, SORT_STRING);
        if ($dependencyAssets !== $packagedAssets || count(array_unique($packagedAssets)) !== count($packagedAssets)) {
            throw new PackageException('The Pagecraft package assets do not match its document references.');
        }
        $this->assertDocumentHasNoCms();
        $head = (string) (($this->document->meta->headHtml ?? '') ?: '');
        $pageHeads = implode("\n", array_map(static fn (\stdClass $page): string => (string) (($page->headHtml ?? '') ?: ''), $this->document->pages));
        if (preg_match('/<script\b|\bon[a-z0-9_-]+\s*=|javascript\s*:/i', $head . "\n" . $pageHeads)) {
            throw new PackageException('Executable custom head code is not supported by the WordPress v1 importer.');
        }
    }

    private function assertDocumentHasNoCms(): void
    {
        $collections = $this->document->meta->collections ?? [];
        if (!is_array($collections) || count($collections) !== 0
            || count(array_filter($this->document->pages, static fn (\stdClass $page): bool => !empty($page->collection))) > 0) {
            throw new PackageException('Pagecraft CMS content must be flattened explicitly before WordPress import.');
        }
        $trees = [$this->document->header, $this->document->footer];
        foreach ($this->document->pages as $page) $trees[] = $page->tree;
        foreach (($this->document->meta->blocks ?? []) as $block) {
            if ($block instanceof \stdClass && isset($block->node)) {
                $trees[] = [$block->node];
            }
        }
        foreach (($this->document->meta->components ?? []) as $component) {
            if ($component instanceof \stdClass && isset($component->node)) {
                $trees[] = [$component->node];
            }
        }
        foreach ($trees as $tree) {
            if (!is_array($tree)) {
                throw new PackageException('The Pagecraft package document tree is malformed.');
            }
            foreach ($tree as $node) {
                if ($this->nodeUsesCms($node)) {
                    throw new PackageException('Pagecraft CMS content must be flattened explicitly before WordPress import.');
                }
            }
        }
    }

    private function nodeUsesCms(mixed $node): bool
    {
        if (!$node instanceof \stdClass) {
            throw new PackageException('The Pagecraft package document contains a malformed node.');
        }
        if (($node->type ?? null) === 'list') {
            return true;
        }
        if (isset($node->bind) && $node->bind instanceof \stdClass) {
            foreach (get_object_vars($node->bind) as $binding) {
                if ($binding instanceof \stdClass && ($binding->src ?? null) === 'field') {
                    return true;
                }
            }
        }
        $condition = $node->showIf ?? null;
        if ($condition instanceof \stdClass) {
            $conditionBinding = $condition->bind ?? null;
            if ($conditionBinding instanceof \stdClass && ($conditionBinding->src ?? null) === 'field') {
                return true;
            }
        }
        $children = $node->children ?? [];
        if (!is_array($children)) {
            throw new PackageException('The Pagecraft package document contains malformed node children.');
        }
        foreach ($children as $child) {
            if ($this->nodeUsesCms($child)) {
                return true;
            }
        }
        return false;
    }

    private function validFileRecord(\stdClass $record): bool
    {
        if (!is_string($record->path ?? null) || !is_string($record->role ?? null)
            || !is_string($record->mediaType ?? null) || !is_int($record->bytes ?? null)
            || $record->bytes < 0 || $record->bytes > self::MAX_FILE_BYTES
            || !is_string($record->sha256 ?? null) || !preg_match('/^[a-f0-9]{64}$/', $record->sha256)) {
            return false;
        }
        self::assertSafePath($record->path);
        if (($record->role ?? '') !== 'asset' && isset($record->asset)) return false;
        $path = $record->path;
        $type = $record->mediaType;
        return match ($record->role) {
            'document' => $path === 'source/document.json' && $type === 'application/json',
            'provenance' => $path === 'source/provenance.json' && $type === 'application/json',
            'dependencies' => $path === 'source/dependencies.json' && $type === 'application/json',
            'compiled-page' => str_starts_with($path, 'compiled/') && str_ends_with(strtolower($path), '.html')
                && $type === 'text/html; charset=utf-8',
            'compiled-support' => in_array($path, ['compiled/robots.txt', 'compiled/sitemap.xml'], true)
                && in_array($type, ['text/plain; charset=utf-8', 'application/xml; charset=utf-8'], true),
            'style' => str_starts_with($path, 'styles/') && str_ends_with(strtolower($path), '.css')
                && $type === 'text/css; charset=utf-8',
            'preview' => str_starts_with($path, 'previews/') && str_ends_with(strtolower($path), '.html')
                && $type === 'text/html; charset=utf-8',
            'asset' => str_starts_with($path, 'assets/') && in_array($type, [
                'image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/avif', 'image/svg+xml'
            ], true) && $this->validAssetMetadata($record),
            default => false,
        };
    }

    private function validAssetMetadata(\stdClass $record): bool
    {
        $asset = $record->asset ?? null;
        if (!$asset instanceof \stdClass || !is_string($asset->id ?? null)
            || !preg_match('/^[A-Za-z0-9][A-Za-z0-9._:-]*$/', $asset->id)
            || !is_string($asset->name ?? null) || $asset->name === ''
            || !is_int($asset->width ?? null) || $asset->width < 0
            || !is_int($asset->height ?? null) || $asset->height < 0) {
            return false;
        }
        return $record->path === self::assetPath($asset->id, $asset->name);
    }

    private static function assetPath(string $id, string $name): string
    {
        $cleanId = strtolower((string) preg_replace('/[^A-Za-z0-9]+/', '', $id));
        $cleanId = $cleanId !== '' ? $cleanId : 'asset';
        $cleaned = strtolower(trim((string) preg_replace('/[^A-Za-z0-9_.-]+/', '-', $name), '-'));
        $cleaned = $cleaned !== '' ? $cleaned : 'image';
        $dot = strrpos($cleaned, '.');
        $hasExtension = $dot !== false && $dot > 0 && $dot < strlen($cleaned) - 1;
        $extension = $hasExtension ? substr(substr($cleaned, (int) $dot), 0, 17) : '';
        $rawStem = $hasExtension ? substr($cleaned, 0, (int) $dot) : $cleaned;
        $stem = str_ends_with($rawStem, '-' . $cleanId)
            ? $rawStem : substr($rawStem, 0, 180) . '-' . $cleanId;
        return 'assets/' . $stem . $extension;
    }

    private function verifyFile(\stdClass $record): void
    {
        $index = $this->archive->locateName($record->path, \ZipArchive::FL_UNCHANGED);
        if ($index === false) {
            throw new PackageException('The Pagecraft package is missing ' . $record->path . '.');
        }
        $stream = $this->archive->getStream($record->path);
        if (!is_resource($stream)) {
            throw new PackageException('The Pagecraft package could not read ' . $record->path . '.');
        }
        $hash = hash_init('sha256');
        $bytes = 0;
        // Streaming is required here to bound memory while hashing untrusted archive entries.
        // phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fread,WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        while (!feof($stream)) {
            $chunk = fread($stream, 1048576);
            if ($chunk === false) {
                fclose($stream);
                throw new PackageException('The Pagecraft package could not verify ' . $record->path . '.');
            }
            $bytes += strlen($chunk);
            hash_update($hash, $chunk);
        }
        fclose($stream);
        // phpcs:enable
        if ($bytes !== $record->bytes || hash_final($hash) !== $record->sha256) {
            throw new PackageException('The Pagecraft package failed integrity verification for ' . $record->path . '.');
        }
    }

    private function readText(string $path, int $limit = self::MAX_FILE_BYTES): string
    {
        $index = $this->archive->locateName($path, \ZipArchive::FL_UNCHANGED);
        if ($index === false) {
            throw new PackageException('The Pagecraft package is missing ' . $path . '.');
        }
        $stat = $this->archive->statIndex($index, \ZipArchive::FL_UNCHANGED);
        if (!is_array($stat) || (int) ($stat['size'] ?? -1) > $limit) {
            throw new PackageException('The Pagecraft package file exceeds its text limit: ' . $path);
        }
        $source = $this->archive->getFromIndex($index, 0, \ZipArchive::FL_UNCHANGED);
        if (!is_string($source) || strlen($source) > $limit || preg_match('//u', $source) !== 1) {
            throw new PackageException('The Pagecraft package file is not bounded UTF-8 text: ' . $path);
        }
        return $source;
    }

    private static function assertSafePath(string $path): void
    {
        if ($path === '' || strlen($path) > self::MAX_PATH_BYTES || str_contains($path, "\0")
            || str_starts_with($path, '/') || str_ends_with($path, '/') || str_contains($path, '\\')) {
            throw new PackageException('The Pagecraft package contains an unsafe path.');
        }
        foreach (explode('/', $path) as $part) {
            if ($part === '' || $part === '.' || $part === '..') {
                throw new PackageException('The Pagecraft package contains path traversal.');
            }
        }
    }
}
