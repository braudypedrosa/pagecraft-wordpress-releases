<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Decode native raster uploads before WordPress moves files or creates attachments. */
final class MediaUpload
{
    /** @param array<string,mixed> $file */
    public static function error(array $file): ?string
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
            || !is_string($file['tmp_name'] ?? null) || !is_file($file['tmp_name'])) {
            return null; // Preserve WordPress's normal missing/failed-upload errors.
        }
        $path = $file['tmp_name'];
        $mime = wp_get_image_mime($path);
        if (!in_array($mime, ['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/avif'], true)) {
            return null; // SVG and other formats retain the host's native MIME policy.
        }
        $message = __('WordPress could not decode this image. Try exporting it again as PNG, JPEG, GIF, WebP, or AVIF.', 'pagecraft-builder');
        $size = wp_getimagesize($path);
        if (!$size || $size[0] <= 0 || $size[1] <= 0) return $message;
        $width = (int) $size[0];
        $height = (int) $size[1];
        // Even a minimal RGBA buffer must fit the existing WordPress image allowance.
        // Divide before multiplying so a corrupt header cannot overflow or allocate first.
        if ($width > intdiv(PHP_INT_MAX, 4) / $height) return $message;
        $raised = wp_raise_memory_limit('image');
        $limit = wp_convert_hr_to_bytes((string) ($raised ?: ini_get('memory_limit')));
        if ($limit > 0 && $width > max(0, $limit - memory_get_usage(true)) / 4 / $height) {
            return $message;
        }
        $editor = wp_get_image_editor($path);
        if (is_wp_error($editor)) return $message;
        return null;
    }
}
