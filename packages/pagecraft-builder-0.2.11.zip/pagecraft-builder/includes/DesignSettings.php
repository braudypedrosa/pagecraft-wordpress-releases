<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class DesignSettingsConflict extends \RuntimeException
{
    public function __construct(public readonly string $currentVersion)
    {
        parent::__construct('The Pagecraft site design changed somewhere else. Reload it before saving your changes.');
    }
}

/**
 * WordPress-owned Pagecraft design defaults.
 *
 * Site identity, URLs, language, publishing and user management deliberately stay in
 * WordPress. This record contains only the visual system shared by Pagecraft documents.
 */
final class DesignSettings
{
    public const OPTION = 'pagecraft_design_settings_v1';
    public const STYLESHEET_OPTION = 'pagecraft_design_stylesheet_v1';
    private const MAX_TOKENS_BYTES = 2097152;

    /** @return array<string,mixed> */
    public function read(): array
    {
        $stored = get_option(self::OPTION, []);
        return is_array($stored) ? $this->sanitizeDesign($stored) : [];
    }

    /** @param array<string,mixed>|null $design */
    public function version(?array $design = null): string
    {
        $stylesheet = get_option(self::STYLESHEET_OPTION, []);
        return hash('sha256', CanonicalJson::encode([
            'design' => $design ?? $this->read(),
            'stylesheet' => is_array($stylesheet) ? $stylesheet : [],
        ]));
    }

    /**
     * @param array<string,mixed> $input
     * @return array{design:array<string,mixed>,globalCss:array{path:string,hash:string,bytes:int}|null,designVersion:string}
     */
    public function save(array $input): array
    {
        return EditorWriteLock::runExclusiveSourceWrite([], fn (): array => $this->saveLocked($input));
    }

    /** @param array<string,mixed> $input @return array{design:array<string,mixed>,globalCss:array{path:string,hash:string,bytes:int}|null,designVersion:string} */
    private function saveLocked(array $input): array
    {
        if (array_key_exists('expectedVersion', $input)) {
            $expectedVersion = $input['expectedVersion'];
            if (!is_string($expectedVersion) || preg_match('/^[a-f0-9]{64}$/D', $expectedVersion) !== 1) {
                throw new PackageException('The Pagecraft design version is invalid.');
            }
            $currentVersion = $this->version();
            if (!hash_equals($currentVersion, $expectedVersion)) {
                throw new DesignSettingsConflict($currentVersion);
            }
        }
        $design = $input['design'] ?? null;
        if (!is_array($design)) {
            throw new PackageException('The Pagecraft design settings payload is missing.');
        }
        $design = $this->sanitizeDesign($design);
        $this->assertResourceRemovalsAreUnused($design);
        $globalCss = $input['globalCss'] ?? '';
        if (!is_string($globalCss) || strlen($globalCss) > GeneratedAssetStore::MAX_CSS_BYTES) {
            throw new PackageException('The Pagecraft global stylesheet exceeds the WordPress limit.');
        }
        $globalCss = FallbackCompiler::safeCssSource($globalCss);
        $asset = $globalCss !== '' ? (new GeneratedAssetStore())->writeCss('global', $globalCss) : null;

        $priorDesign = get_option(self::OPTION, null);
        $priorStylesheet = get_option(self::STYLESHEET_OPTION, null);
        try {
            $this->putOption(self::OPTION, $design, 'WordPress could not save the Pagecraft design settings.');
            // Keep the current foundation independently of page/global edit snapshots.
            $this->putOption(self::STYLESHEET_OPTION, $asset ?? [], 'WordPress could not save the Pagecraft design stylesheet.');
        } catch (\Throwable $error) {
            $this->restoreOption(self::OPTION, $priorDesign);
            $this->restoreOption(self::STYLESHEET_OPTION, $priorStylesheet);
            throw $error;
        }

        return ['design' => $design, 'globalCss' => $asset, 'designVersion' => $this->version()];
    }

    /** @return array{known:true,counts:array<string,int>} */
    public function classUsage(): array
    {
        $usage = $this->designUsage();
        return ['known' => true, 'counts' => $usage['counts']['classes']];
    }

    /**
     * Return privacy-safe resource counts without exposing post titles or document content.
     * Each count is the number of saved documents, revisions, or the current design record
     * that references the resource, rather than the number of individual occurrences.
     *
     * @return array{known:true,counts:array{classes:array<string,int>,colors:array<string,int>,textStyles:array<string,int>}}
     */
    public function designUsage(): array
    {
        $design = $this->read();
        return ['known' => true, 'counts' => $this->resourceUsageCounts($this->resourceIds($design), $design)];
    }

    /** Import only the visual system; compiled assets are managed by the project importer.
     * @param array<string,mixed> $document
     */
    public function importDocument(array $document): void
    {
        EditorWriteLock::runSourceWrite([], function () use ($document): void {
            $this->importDocumentLocked($document);
        });
    }

    /** @param array<string,mixed> $document */
    private function importDocumentLocked(array $document): void
    {
        $design = $this->preflightImportDocument($document);
        $priorDesign = get_option(self::OPTION, null);
        $priorStylesheet = get_option(self::STYLESHEET_OPTION, null);
        try {
            $this->putOption(self::OPTION, $design, 'WordPress could not import the project design settings.');
            /* Every imported page/global already owns the package's compiled foundation. A
             * stylesheet made by the previous WordPress design would load after it and win. */
            if (!delete_option(self::STYLESHEET_OPTION)
                && get_option(self::STYLESHEET_OPTION, null) !== null) {
                throw new PackageException('WordPress could not replace the project design stylesheet.');
            }
        } catch (\Throwable $error) {
            $this->restoreOption(self::OPTION, $priorDesign);
            $this->restoreOption(self::STYLESHEET_OPTION, $priorStylesheet);
            throw $error;
        }
    }

    private function putOption(string $key, mixed $value, string $error): void
    {
        if (!update_option($key, $value, false) && get_option($key, null) !== $value) {
            throw new PackageException($error);
        }
    }

    private function restoreOption(string $key, mixed $value): void
    {
        if ($value === null) delete_option($key);
        else update_option($key, $value, false);
    }

    /**
     * Validate an imported visual system without changing WordPress.
     *
     * Whole-project imports call this before creating the recovery job or changing
     * any posts. The import itself repeats the check under the same source-write
     * mutex so direct callers cannot bypass the persistent-reference guarantee.
     *
     * @param array<string,mixed> $document
     * @return array<string,mixed>
     */
    public function preflightImportDocument(array $document): array
    {
        $meta = $document['meta'] ?? [];
        if (!is_array($meta)) throw new PackageException('The project design settings are invalid.');
        return $this->keepResourcesStillInUse($this->sanitizeDesign($meta));
    }

    /**
     * An import brings another project's visual system. Colours, text styles and classes it
     * does not have, but that saved pages, templates or revisions here still use, stay beside
     * the incoming ones: a replaced page is archived, not deleted, and must still look right
     * when it is restored. Refusing instead made it impossible to replace a site with a
     * different project. Kept resources can be removed in Site Settings once nothing uses them.
     *
     * @param array<string,mixed> $design
     * @return array<string,mixed>
     */
    private function keepResourcesStillInUse(array $design): array
    {
        $stored = $this->read();
        $tokenKeys = ['classes' => 'classes', 'colors' => 'colors', 'textStyles' => 'text'];
        $storedIds = $this->resourceIds($stored);
        // A kept class or text style may itself use a colour, so repeat until nothing is added.
        for ($pass = 0; $pass < 64; $pass++) {
            $nextIds = $this->resourceIds($design);
            $removed = [];
            foreach ($storedIds as $kind => $ids) $removed[$kind] = array_values(array_diff($ids, $nextIds[$kind]));
            if (array_filter($removed) === []) return $design;
            $usage = $this->resourceUsageCounts($removed, $design);
            $kept = 0;
            foreach ($tokenKeys as $kind => $tokenKey) {
                foreach ($stored['tokens'][$tokenKey] ?? [] as $resource) {
                    if (($usage[$kind][$resource['id']] ?? 0) < 1) continue;
                    if (!isset($design['tokens']) || !is_array($design['tokens'])) $design['tokens'] = [];
                    if (!isset($design['tokens'][$tokenKey]) || !is_array($design['tokens'][$tokenKey])) $design['tokens'][$tokenKey] = [];
                    $design['tokens'][$tokenKey][] = $resource;
                    $usage[$kind][$resource['id']] = 0;
                    $kept++;
                }
            }
            if ($kept === 0) return $design;
        }
        throw $this->usageUnreadable();
    }

    /** @param array<string,mixed> $design */
    private function assertResourceRemovalsAreUnused(array $design): void
    {
        $storedIds = $this->resourceIds($this->read());
        $nextIds = $this->resourceIds($design);
        $removed = [];
        $hasRemoved = false;
        foreach (array_keys($storedIds) as $kind) {
            $removed[$kind] = array_values(array_diff($storedIds[$kind], $nextIds[$kind]));
            $hasRemoved = $hasRemoved || $removed[$kind] !== [];
        }
        if (!$hasRemoved) return;

        $usage = $this->resourceUsageCounts($removed, $design);
        $messages = [
            'classes' => 'Pagecraft cannot remove design classes while saved pages, theme templates, or revisions still use them.',
            'colors' => 'Pagecraft cannot remove design colours while saved pages, theme templates, revisions, or design styles still use them.',
            'textStyles' => 'Pagecraft cannot remove text styles while saved pages, theme templates, revisions, or custom CSS still use them.',
        ];
        foreach (array_keys($removed) as $kind) {
            if (array_sum($usage[$kind]) > 0) throw new PackageException($messages[$kind]);
        }
    }

    /** @param array<string,mixed> $design @return array<string,mixed> */
    private function sanitizeDesign(array $design): array
    {
        $result = [];
        foreach (['maxWidth', 'font', 'headFont', 'size'] as $key) {
            $value = $design[$key] ?? null;
            if ($value === null) {
                continue;
            }
            if (!is_string($value) || strlen($value) > 1024 || str_contains($value, "\0")) {
                throw new PackageException('A Pagecraft design setting is invalid.');
            }
            $result[$key] = $value;
        }

        if (array_key_exists('css', $design)) {
            if (!is_string($design['css']) || strlen($design['css']) > GeneratedAssetStore::MAX_CSS_BYTES) {
                throw new PackageException('The Pagecraft custom CSS exceeds the WordPress limit.');
            }
            $result['css'] = FallbackCompiler::safeCssSource($design['css']);
        }

        if (array_key_exists('tokens', $design)) {
            if (!is_array($design['tokens'])) {
                throw new PackageException('The Pagecraft design tokens are invalid.');
            }
            $tokens = $this->sanitizeTree($design['tokens']);
            if (!is_array($tokens) || strlen(CanonicalJson::encode($tokens)) > self::MAX_TOKENS_BYTES) {
                throw new PackageException('The Pagecraft design tokens exceed the WordPress limit.');
            }
            $result['tokens'] = $tokens;
        }
        return $result;
    }

    private function sanitizeTree(mixed $value, int $depth = 0): mixed
    {
        if ($depth > 16) {
            throw new PackageException('The Pagecraft design tokens are nested too deeply.');
        }
        if (is_array($value)) {
            $clean = [];
            foreach ($value as $key => $item) {
                if (is_string($key) && strlen($key) > 128) {
                    throw new PackageException('A Pagecraft design token key is invalid.');
                }
                $clean[$key] = $this->sanitizeTree($item, $depth + 1);
            }
            return $clean;
        }
        if (is_string($value)) {
            if (strlen($value) > 65536 || str_contains($value, "\0")) {
                throw new PackageException('A Pagecraft design token value is invalid.');
            }
            return $value;
        }
        if (is_int($value) || is_float($value) || is_bool($value) || $value === null) {
            return $value;
        }
        throw new PackageException('A Pagecraft design token value is invalid.');
    }

    /**
     * @param array<string,mixed> $design
     * @return array{classes:list<string>,colors:list<string>,textStyles:list<string>}
     */
    private function resourceIds(array $design): array
    {
        $tokens = $design['tokens'] ?? [];
        if (!is_array($tokens)) throw $this->usageUnreadable();
        $ids = ['classes' => [], 'colors' => [], 'textStyles' => []];
        foreach (['classes' => 'classes', 'colors' => 'colors', 'textStyles' => 'text'] as $kind => $tokenKey) {
            $resources = $tokens[$tokenKey] ?? [];
            if (!is_array($resources)) throw $this->usageUnreadable();
            $unique = [];
            foreach ($resources as $resource) {
                if (!is_array($resource) || !is_string($resource['id'] ?? null) || $resource['id'] === '') {
                    throw $this->usageUnreadable();
                }
                $unique[$resource['id']] = true;
            }
            $ids[$kind] = array_keys($unique);
        }
        return $ids;
    }

    /**
     * @param array{classes:list<string>,colors:list<string>,textStyles:list<string>} $resourceIds
     * @param array<string,mixed> $design
     * @return array{classes:array<string,int>,colors:array<string,int>,textStyles:array<string,int>}
     */
    private function resourceUsageCounts(array $resourceIds, array $design): array
    {
        $counts = [
            'classes' => array_fill_keys($resourceIds['classes'], 0),
            'colors' => array_fill_keys($resourceIds['colors'], 0),
            'textStyles' => array_fill_keys($resourceIds['textStyles'], 0),
        ];
        if (array_filter($counts) === []) return $counts;

        $designFound = $this->emptyFound($counts);
        $this->findDesignReferences($design, $designFound);
        $this->addFound($counts, $designFound);

        foreach ($this->persistentDocumentSources() as $source) {
            if (strlen($source) > PageEditor::MAX_DOCUMENT_BYTES) {
                throw $this->usageUnreadable();
            }
            try {
                $document = json_decode($source, true, 512, JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                throw $this->usageUnreadable();
            }
            if (!is_array($document)) {
                throw $this->usageUnreadable();
            }
            $found = $this->emptyFound($counts);
            $this->findDocumentReferences($document, $found);
            $this->addFound($counts, $found);
        }
        foreach ($counts as &$kindCounts) ksort($kindCounts, SORT_STRING);
        unset($kindCounts);
        return $counts;
    }

    /** @return \Generator<int,string> */
    private function persistentDocumentSources(): \Generator
    {
        $statuses = function_exists('get_post_stati')
            ? array_values(get_post_stati([], 'names'))
            : ['publish', 'future', 'draft', 'pending', 'private', 'trash', 'auto-draft', 'inherit'];
        if ($statuses === []) {
            throw $this->usageUnreadable();
        }

        $perPage = 200;
        $seen = [];
        for ($page = 1; ; $page++) {
            $records = get_posts([
                'post_type' => ['page', GlobalElement::POST_TYPE, 'revision'],
                'post_status' => $statuses,
                'posts_per_page' => $perPage,
                'paged' => $page,
                'fields' => 'ids',
                'orderby' => 'ID',
                'order' => 'ASC',
                'no_found_rows' => true,
                'suppress_filters' => true,
            ]);
            if (!is_array($records)) {
                throw $this->usageUnreadable();
            }
            $newRecords = 0;
            foreach ($records as $record) {
                $postId = is_object($record) ? (int) ($record->ID ?? 0) : (int) $record;
                if ($postId <= 0) {
                    throw $this->usageUnreadable();
                }
                if (isset($seen[$postId])) continue;
                $seen[$postId] = true;
                $newRecords++;
                foreach ([ManagedPage::DOCUMENT, GlobalElement::DOCUMENT] as $metaKey) {
                    $source = get_post_meta($postId, $metaKey, true);
                    if ($source === '') continue;
                    if (!is_string($source)) {
                        throw $this->usageUnreadable();
                    }
                    yield $source;
                }
            }
            if (count($records) < $perPage) return;
            if ($newRecords === 0) {
                throw $this->usageUnreadable();
            }
        }
    }

    /**
     * Raw page and global documents carry stale copies of shared design tokens. They are not
     * authoritative references. Keep blocks and components in meta, but scan the current design
     * record separately so its custom CSS and remaining style definitions still protect tokens.
     *
     * @param array<string,mixed> $document
     * @param array{classes:array<string,bool>,colors:array<string,bool>,textStyles:array<string,bool>} $found
     */
    private function findDocumentReferences(array $document, array &$found): void
    {
        if (isset($document['meta']) && is_array($document['meta'])) {
            unset($document['meta']['tokens'], $document['meta']['css']);
        }
        $this->walkDocument($document, $found);
    }

    /** @param array{classes:array<string,bool>,colors:array<string,bool>,textStyles:array<string,bool>} $found */
    private function walkDocument(mixed $value, array &$found): void
    {
        if (!is_array($value)) return;
        if (array_key_exists('cls', $value)) {
            if (!is_array($value['cls'])) throw $this->usageUnreadable();
            foreach ($value['cls'] as $classId) {
                if (!is_string($classId)) throw $this->usageUnreadable();
                if (array_key_exists($classId, $found['classes'])) $found['classes'][$classId] = true;
            }
        }
        if (array_key_exists('props', $value)) {
            if (!is_array($value['props'])) throw $this->usageUnreadable();
            $textStyle = $value['props']['ts'] ?? null;
            if ($textStyle !== null && !is_string($textStyle)) throw $this->usageUnreadable();
            if (is_string($textStyle) && array_key_exists($textStyle, $found['textStyles'])) {
                $found['textStyles'][$textStyle] = true;
            }
        }
        foreach (['css', 'st'] as $key) {
            if (array_key_exists($key, $value)) $this->findColorReferences($value[$key], $found['colors']);
        }
        if (array_key_exists('adv', $value)) {
            if (!is_array($value['adv'])) throw $this->usageUnreadable();
            if (array_key_exists('css', $value['adv'])) {
                $this->findColorReferences($value['adv']['css'], $found['colors']);
            }
        }
        foreach ($value as $key => $child) {
            if (in_array($key, ['cls', 'props', 'css', 'st', 'adv'], true)) continue;
            $this->walkDocument($child, $found);
        }
    }

    /**
     * @param array<string,mixed> $design
     * @param array{classes:array<string,bool>,colors:array<string,bool>,textStyles:array<string,bool>} $found
     */
    private function findDesignReferences(array $design, array &$found): void
    {
        $customCss = $design['css'] ?? '';
        if (!is_string($customCss)) throw $this->usageUnreadable();
        $this->findColorReferences($customCss, $found['colors']);
        $this->findTextStyleCssReferences($customCss, $found['textStyles']);

        $tokens = $design['tokens'] ?? [];
        if (!is_array($tokens)) throw $this->usageUnreadable();
        foreach (['colors', 'text', 'classes'] as $tokenKey) {
            $resources = $tokens[$tokenKey] ?? [];
            if (!is_array($resources)) throw $this->usageUnreadable();
            foreach ($resources as $resource) {
                if (!is_array($resource)) throw $this->usageUnreadable();
                if ($tokenKey === 'colors') {
                    $this->findColorReferences($resource['value'] ?? '', $found['colors']);
                    continue;
                }
                foreach (['css', 'st'] as $styleKey) {
                    if (array_key_exists($styleKey, $resource)) {
                        $this->findColorReferences($resource[$styleKey], $found['colors']);
                    }
                }
            }
        }
    }

    /** @param array<string,bool> $found */
    private function findColorReferences(mixed $value, array &$found): void
    {
        if (is_array($value)) {
            foreach ($value as $child) $this->findColorReferences($child, $found);
            return;
        }
        if (!is_string($value)) return;
        $value = $this->activeCssSource($value);
        foreach (array_keys($found) as $colorId) {
            $matched = preg_match(
                '/(?i:var)\(\s*--c-' . preg_quote($colorId, '/') . '(?![A-Za-z0-9_-])/',
                $value
            );
            if ($matched === false) throw $this->usageUnreadable();
            if ($matched === 1) {
                $found[$colorId] = true;
            }
        }
    }

    /**
     * Remove comments and quoted strings before looking for active CSS variable calls.
     * Comments inside var() become whitespace, so valid forms such as
     * VAR(/* explanation *\/ --c-brand) remain detectable.
     */
    private function activeCssSource(string $css): string
    {
        $length = strlen($css);
        $result = '';
        $activeStart = 0;
        for ($index = 0; $index < $length;) {
            $character = $css[$index];
            $isComment = $character === '/' && $index + 1 < $length && $css[$index + 1] === '*';
            $isString = $character === '"' || $character === "'";
            if (!$isComment && !$isString) {
                $index++;
                continue;
            }

            $result .= substr($css, $activeStart, $index - $activeStart) . ' ';
            if ($isComment) {
                $end = strpos($css, '*/', $index + 2);
                $index = $end === false ? $length : $end + 2;
            } else {
                $quote = $character;
                $index++;
                while ($index < $length) {
                    if ($css[$index] === '\\') {
                        $index = min($length, $index + 2);
                        continue;
                    }
                    if ($css[$index] === $quote) {
                        $index++;
                        break;
                    }
                    $index++;
                }
            }
            $activeStart = $index;
        }
        return $result . substr($css, $activeStart);
    }

    /** @param array<string,bool> $found */
    private function findTextStyleCssReferences(string $css, array &$found): void
    {
        foreach (array_keys($found) as $styleId) {
            if (preg_match('/(?:^|[^A-Za-z0-9_-])ts-' . preg_quote($styleId, '/') . '(?![A-Za-z0-9_-])/', $css) === 1) {
                $found[$styleId] = true;
            }
        }
    }

    /**
     * @param array{classes:array<string,int>,colors:array<string,int>,textStyles:array<string,int>} $counts
     * @return array{classes:array<string,bool>,colors:array<string,bool>,textStyles:array<string,bool>}
     */
    private function emptyFound(array $counts): array
    {
        $found = [];
        foreach ($counts as $kind => $kindCounts) $found[$kind] = array_fill_keys(array_keys($kindCounts), false);
        return $found;
    }

    /**
     * @param array{classes:array<string,int>,colors:array<string,int>,textStyles:array<string,int>} $counts
     * @param array{classes:array<string,bool>,colors:array<string,bool>,textStyles:array<string,bool>} $found
     */
    private function addFound(array &$counts, array $found): void
    {
        foreach ($found as $kind => $kindFound) {
            foreach ($kindFound as $id => $referenced) {
                if ($referenced) $counts[$kind][$id]++;
            }
        }
    }

    private function usageUnreadable(): PackageException
    {
        return new PackageException(
            'Pagecraft cannot verify shared design usage because a saved Pagecraft document is unreadable.'
        );
    }

}
