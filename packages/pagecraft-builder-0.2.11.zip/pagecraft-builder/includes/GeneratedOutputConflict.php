<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class GeneratedOutputConflict extends \RuntimeException
{
    public function __construct(
        public readonly int $currentVersion,
        public readonly string $currentDocumentSha256,
        public readonly ?string $currentRenderContextSha256 = null
    ) {
        parent::__construct($currentRenderContextSha256 === null
            ? 'This Pagecraft document changed before its generated output could be refreshed. Reload the maintenance batch.'
            : 'This Pagecraft render context changed before its generated output could be refreshed. Reload the maintenance batch.');
    }
}
