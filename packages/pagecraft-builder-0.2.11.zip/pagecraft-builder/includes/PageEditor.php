<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class PageEditor
{
    public const SCHEMA_VERSION = 17;
    public const MAX_DOCUMENT_BYTES = 8388608;
    public const MAX_HTML_BYTES = 12582912;

    /** @return array{document:?array<string,mixed>,version:int} */
    public function load(int $postId): array
    {
        $this->assertEditablePage($postId);
        $raw = get_post_meta($postId, ManagedPage::DOCUMENT, true);
        if (!is_string($raw) || $raw === '') {
            return ['document' => null, 'version' => 0];
        }
        try {
            $document = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new PackageException('The stored Pagecraft document is invalid: ' . $error->getMessage());
        }
        if (!is_array($document)) {
            throw new PackageException('The stored Pagecraft document is not an object.');
        }

        return [
            'document' => $document,
            'version' => max(1, (int) get_post_meta($postId, ManagedPage::DOCUMENT_VERSION, true)),
        ];
    }

    /**
     * @param array<string,mixed> $input
     * @return array{version:int,revisionId:?int}
     */
    public function save(int $postId, array $input): array
    {
        $this->assertEditablePage($postId);
        return EditorWriteLock::runExclusiveSourceWrite([$postId], function () use ($postId, $input): array {
            $this->assertSaveIdentity($postId, $input);
            $prepared = $this->prepareSave($postId, $input);
            $document = $prepared['document'];
            $save = fn (): array => $this->saveLocked($postId, $prepared);
            return (new NativeMenu())->synchronizeAndRun($document, $save);
        });
    }

    /** @param array<string,mixed> $input */
    private function assertSaveIdentity(int $postId, array $input): void
    {
        $managed = ManagedPage::isManaged($postId);
        $currentVersion = $managed
            ? max(1, (int) get_post_meta($postId, ManagedPage::DOCUMENT_VERSION, true))
            : 0;
        $clientVersion = filter_var($input['version'] ?? null, FILTER_VALIDATE_INT);
        if ($clientVersion === false || $clientVersion !== $currentVersion) {
            throw new EditorConflict($clientVersion === false ? -1 : (int) $clientVersion, $currentVersion);
        }
        $compiled = $input['compiled'] ?? null;
        if (!is_array($compiled)) {
            throw new PackageException('The compiled WordPress fallback is missing.');
        }
        if (array_key_exists('compiler', $compiled)) {
            $compiler = CompilerContract::current();
            if (!is_array($compiled['compiler']) || !$compiler->matchesSealedPayload($compiled['compiler'])) {
                throw new CompilerContractConflict($compiler->sealedPayload());
            }
        }
    }

    /**
     * @param array<string,mixed> $input
     * @return array{
     *   managed:bool,
     *   conversionRevision:int,
     *   currentVersion:int,
     *   document:array<string,mixed>,
     *   schemaVersion:int,
     *   documentJson:string,
     *   mediaAttachments:string,
     *   compiler:?CompilerContract,
     *   globalCss:string,
     *   pageCss:string,
     *   content:string
     * }
     */
    private function prepareSave(int $postId, array $input): array
    {
        $managed = ManagedPage::isManaged($postId);
        $conversionRevision = (int) get_post_meta($postId, ManagedPage::CONVERSION_REVISION, true);
        if (!$managed && $conversionRevision === 0) {
            throw new PackageException('Start the explicit Pagecraft conversion first so WordPress can back up this page.');
        }
        $currentVersion = (int) $input['version'];
        $document = $input['document'] ?? $input['doc'] ?? null;
        if (!is_array($document)) {
            throw new PackageException('The Pagecraft document payload is missing.');
        }
        $schemaVersion = filter_var($document['schemaVersion'] ?? $document['v'] ?? null, FILTER_VALIDATE_INT);
        if ($schemaVersion === false || $schemaVersion <= 0) {
            throw new PackageException('The Pagecraft document has no valid schema version.');
        }
        if ($schemaVersion > self::SCHEMA_VERSION) {
            throw new PackageException(
                'This document uses Pagecraft schema ' . $schemaVersion . ', but this plugin supports schema '
                . self::SCHEMA_VERSION . '. Upgrade Pagecraft Builder before saving.'
            );
        }
        $documentJson = DocumentJson::encode($document);
        if (strlen($documentJson) > self::MAX_DOCUMENT_BYTES) {
            throw new PackageException('The Pagecraft document exceeds the WordPress editor limit.');
        }
        $mediaAttachments = MediaLibrary::attachmentIdsJsonForDocument($document);
        $compiled = $input['compiled'] ?? null;
        if (!is_array($compiled)) {
            throw new PackageException('The compiled WordPress fallback is missing.');
        }
        $compiler = null;
        if (array_key_exists('compiler', $compiled)) {
            $compiler = CompilerContract::current();
            if ($schemaVersion > $compiler->schemaVersion) {
                throw new PackageException('The sealed Pagecraft compiler cannot compile this document schema.');
            }
        }
        $html = $this->boundedString($compiled['html'] ?? null, self::MAX_HTML_BYTES, 'compiled page');
        $globalCss = FallbackCompiler::safeCssSource(
            $this->boundedString($compiled['globalCss'] ?? '', GeneratedAssetStore::MAX_CSS_BYTES, 'global stylesheet', true)
        );
        $pageCss = FallbackCompiler::safeCssSource(
            $this->boundedString($compiled['pageCss'] ?? '', GeneratedAssetStore::MAX_CSS_BYTES, 'page stylesheet', true)
        );
        $html = FallbackCompiler::remapProjectHtmlLinks($html, CurrentPageRoute::routes($postId, $document));
        $content = FallbackCompiler::contentFromHtml($html);
        return [
            'managed' => $managed,
            'conversionRevision' => $conversionRevision,
            'currentVersion' => $currentVersion,
            'document' => $document,
            'schemaVersion' => $schemaVersion,
            'documentJson' => $documentJson,
            'mediaAttachments' => $mediaAttachments,
            'compiler' => $compiler,
            'globalCss' => $globalCss,
            'pageCss' => $pageCss,
            'content' => $content,
        ];
    }

    /**
     * @param array{
     *   managed:bool,
     *   conversionRevision:int,
     *   currentVersion:int,
     *   document:array<string,mixed>,
     *   schemaVersion:int,
     *   documentJson:string,
     *   mediaAttachments:string,
     *   compiler:?CompilerContract,
     *   globalCss:string,
     *   pageCss:string,
     *   content:string
     * } $prepared
     * @return array{version:int,revisionId:?int}
     */
    private function saveLocked(int $postId, array $prepared): array
    {
        $this->assertEditablePage($postId);
        $managed = $prepared['managed'];
        $conversionRevision = $prepared['conversionRevision'];
        $currentVersion = $prepared['currentVersion'];
        $document = $prepared['document'];
        $schemaVersion = $prepared['schemaVersion'];
        $documentJson = $prepared['documentJson'];
        $mediaAttachments = $prepared['mediaAttachments'];
        $compiler = $prepared['compiler'];
        $globalCss = $prepared['globalCss'];
        $pageCss = $prepared['pageCss'];
        $content = $prepared['content'];
        $renderContextSha256 = $compiler !== null
            ? (new RefreshGeneratedOutput($compiler))->contextSha256($postId, 'page', $document)
            : '';
        $assets = new GeneratedAssetStore();
        $globalAsset = $globalCss !== '' ? $assets->writeCss('global', $globalCss) : null;
        $pageAsset = $pageCss !== '' ? $assets->writeCss('page', $pageCss) : null;
        $runtimeAsset = FallbackCompiler::needsRuntime($content) ? $assets->writeRuntime() : null;

        $revisionId = null;
        if ($managed) {
            $savedRevision = wp_save_post_revision($postId);
            if (is_wp_error($savedRevision)) {
                throw new PackageException('WordPress could not create the safety revision: ' . $savedRevision->get_error_message());
            }
            if (is_int($savedRevision) && $savedRevision > 0) {
                $revisionId = $savedRevision;
            }
        } else {
            $revisionId = $conversionRevision > 0 ? $conversionRevision : null;
        }

        $updated = wp_update_post([
            'ID' => $postId,
            'post_content' => wp_slash($content),
        ], true);
        if (is_wp_error($updated)) {
            throw new PackageException('WordPress could not save the Pagecraft page: ' . $updated->get_error_message());
        }

        $nextVersion = $currentVersion + 1;
        $metadata = [
            ManagedPage::DOCUMENT => $documentJson,
            ManagedPage::MEDIA_ATTACHMENTS => $mediaAttachments,
            ManagedPage::DOCUMENT_VERSION => (string) $nextVersion,
            ManagedPage::SCHEMA_VERSION => (string) $schemaVersion,
            ManagedPage::RENDERER_VERSION => $compiler !== null
                ? $compiler->rendererVersion
                : PAGECRAFT_BUILDER_VERSION,
            ManagedPage::COMPILED_HASH => hash('sha256', $content),
            ManagedPage::COMPILED_CSS => implode("\n", array_filter([$globalCss, $pageCss])),
            ManagedPage::GLOBAL_CSS_PATH => $globalAsset['path'] ?? '',
            ManagedPage::GLOBAL_CSS_HASH => $globalAsset['hash'] ?? '',
            ManagedPage::PAGE_CSS_PATH => $pageAsset['path'] ?? '',
            ManagedPage::PAGE_CSS_HASH => $pageAsset['hash'] ?? '',
            ManagedPage::RUNTIME_PATH => $runtimeAsset['path'] ?? '',
            ManagedPage::RUNTIME_HASH => $runtimeAsset['hash'] ?? '',
            ManagedPage::COMPILER_EDITOR_VERSION => '',
            ManagedPage::COMPILER_RENDERER_REVISION => '',
            ManagedPage::COMPILER_DOCUMENT_SHA256 => '',
            ManagedPage::COMPILER_RENDER_CONTEXT_SHA256 => '',
            ManagedPage::COMPILED_AT => '',
        ];
        if ($compiler !== null) {
            $metadata = array_replace($metadata, $compiler->provenance($documentJson));
            $metadata[ManagedPage::COMPILER_RENDER_CONTEXT_SHA256] = $renderContextSha256;
        }
        foreach ($metadata as $key => $value) {
            update_post_meta($postId, $key, wp_slash($value));
        }

        return ['version' => $nextVersion, 'revisionId' => $revisionId];
    }

    /** @return list<array{id:string,version:int,createdAt:string,author:array{id:string,name:string},current:bool}> */
    public function revisions(int $postId): array
    {
        $loaded = $this->load($postId);
        $rows = [];
        $snapshots = new EditorRevisionSnapshots(
            ManagedPage::DOCUMENT,
            ManagedPage::DOCUMENT_VERSION,
            ManagedPage::COMPILED_HASH
        );
        $selection = $snapshots->selectForPost($postId, $loaded['version']);
        foreach ($selection['snapshots'] as $revision) {
            $id = (int) $revision->ID;
            $author = get_userdata((int) $revision->post_author);
            $rows[] = [
                'id' => (string) $id,
                'version' => max(1, (int) get_post_meta($id, ManagedPage::DOCUMENT_VERSION, true)),
                'createdAt' => get_post_time('c', true, $revision),
                'author' => [
                    'id' => (string) ($author->ID ?? ''),
                    'name' => (string) ($author->display_name ?? __('WordPress user', 'pagecraft-builder')),
                ],
                'current' => false,
            ];
        }
        array_unshift($rows, [
            'id' => 'current',
            'version' => $loaded['version'],
            'createdAt' => get_post_modified_time('c', true, $postId),
            'author' => [
                'id' => '',
                'name' => $selection['hasUnverifiedHistory']
                    ? __('Current draft · Some older versions cannot be safely restored here', 'pagecraft-builder')
                    : __('Current WordPress draft', 'pagecraft-builder'),
            ],
            'current' => true,
        ]);
        return $rows;
    }

    /** @return array{document:array<string,mixed>,version:int} */
    public function restore(int $postId, int $revisionVersion, int $currentVersion): array
    {
        $this->assertEditablePage($postId);
        return EditorWriteLock::runExclusiveSourceWrite(
            [$postId],
            fn (): array => $this->restoreLocked($postId, $revisionVersion, $currentVersion)
        );
    }

    private function restoreLocked(int $postId, int $revisionVersion, int $currentVersion): array
    {
        $loaded = $this->load($postId);
        if ($loaded['version'] !== $currentVersion) {
            throw new EditorConflict($currentVersion, $loaded['version']);
        }
        $matched = (new EditorRevisionSnapshots(
            ManagedPage::DOCUMENT,
            ManagedPage::DOCUMENT_VERSION,
            ManagedPage::COMPILED_HASH
        ))->forVersion($postId, $loaded['version'], $revisionVersion);
        if (!$matched instanceof \WP_Post) {
            throw new PackageException('That Pagecraft version has no verified WordPress revision and cannot be restored.');
        }
        $safety = wp_save_post_revision($postId);
        if (is_wp_error($safety)) {
            throw new PackageException('WordPress could not protect the current draft before restoring it.');
        }
        $updated = wp_update_post(['ID' => $postId, 'post_content' => wp_slash((string) $matched->post_content)], true);
        if (is_wp_error($updated)) {
            throw new PackageException('WordPress could not restore the selected Pagecraft revision.');
        }
        foreach (ManagedPage::keys() as $key) {
            if (in_array($key, [ManagedPage::DOCUMENT_VERSION, ManagedPage::CONVERSION_REVISION], true)) {
                continue;
            }
            $value = get_post_meta((int) $matched->ID, $key, true);
            if (is_string($value)) {
                update_post_meta($postId, $key, wp_slash($value));
            }
        }
        $nextVersion = $currentVersion + 1;
        update_post_meta($postId, ManagedPage::DOCUMENT_VERSION, (string) $nextVersion);
        $restored = $this->load($postId);
        if (!is_array($restored['document'])) {
            throw new PackageException('The selected revision has no Pagecraft document.');
        }
        update_post_meta(
            $postId,
            ManagedPage::MEDIA_ATTACHMENTS,
            wp_slash(MediaLibrary::attachmentIdsJsonForDocument($restored['document']))
        );
        return ['document' => $restored['document'], 'version' => $nextVersion];
    }

    private function assertEditablePage(int $postId): void
    {
        if ($postId <= 0 || get_post_type($postId) !== 'page' || !current_user_can('edit_post', $postId)
            || !current_user_can(Capabilities::EDIT)) {
            throw new PackageException('You are not allowed to edit this Pagecraft page.');
        }
    }

    private function boundedString(mixed $value, int $limit, string $label, bool $allowEmpty = false): string
    {
        if (!is_string($value) || (!$allowEmpty && $value === '')) {
            throw new PackageException('The ' . $label . ' payload is missing.');
        }
        if (strlen($value) > $limit) {
            throw new PackageException('The ' . $label . ' exceeds the WordPress editor limit.');
        }
        return $value;
    }
}
