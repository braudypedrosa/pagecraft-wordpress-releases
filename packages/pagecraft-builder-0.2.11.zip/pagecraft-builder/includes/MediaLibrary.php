<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Import package assets into native, content-addressed WordPress attachments. */
final class MediaLibrary
{
    public const HASH = '_pagecraft_asset_sha256';
    public const SOURCE_ID = '_pagecraft_asset_source_id';
    public const SOURCE_PATH = '_pagecraft_asset_source_path';

    public static function register(): void
    {
        add_filter('pre_delete_attachment', [self::class, 'preventReferencedDeletion'], 10, 3);
    }

    public static function preventReferencedDeletion(mixed $delete, object $post, bool $forceDelete): mixed
    {
        $attachmentId = (int) ($post->ID ?? 0);
        if ($attachmentId <= 0 || self::usage($attachmentId)['canDelete']) {
            return $delete;
        }
        return false;
    }

    public function import(PortablePagePackage $package): MediaImportResult
    {
        if (!current_user_can(Capabilities::IMPORT) || !current_user_can('upload_files')) {
            throw new PackageException('You are not allowed to import Pagecraft media.');
        }
        $usage = $this->importUsage($package->documentJson());
        $assets = [];
        $created = [];
        try {
            foreach ($package->assetRecords() as $record) {
                $metadata = $record->asset;
                $sourceId = (string) $metadata->id;
                $bytes = $package->assetBytes((string) $record->path);
                $actual = $this->inspect($bytes, (string) $record->mediaType);
                if (($metadata->width > 0 && $actual['width'] > 0 && $metadata->width !== $actual['width'])
                    || ($metadata->height > 0 && $actual['height'] > 0 && $metadata->height !== $actual['height'])) {
                    throw new PackageException('Pagecraft asset dimensions do not match the file: ' . $record->path . '.');
                }
                $attachmentId = $this->existing((string) $record->sha256);
                if ($attachmentId <= 0) {
                    $attachmentId = $this->createAttachment(
                        (string) $metadata->name,
                        (string) $record->mediaType,
                        $bytes,
                        $usage[$sourceId] ?? [],
                        (string) $record->sha256,
                        $sourceId,
                        (string) $record->path
                    );
                    $created[] = $attachmentId;
                } else {
                    $this->applyTextMetadata($attachmentId, $usage[$sourceId] ?? [], true);
                }
                $url = wp_get_attachment_url($attachmentId);
                if (!is_string($url) || $url === '') {
                    throw new PackageException('WordPress could not resolve the imported media URL.');
                }
                $assets[$sourceId] = [
                    'attachmentId' => $attachmentId,
                    'path' => (string) $record->path,
                    'url' => esc_url_raw($url),
                    'hash' => (string) $record->sha256,
                ];
            }
            return new MediaImportResult($assets, $created);
        } catch (\Throwable $error) {
            foreach ($created as $attachmentId) {
                wp_delete_attachment($attachmentId, true);
            }
            throw $error;
        }
    }

    public function preflight(PortablePagePackage $package): void
    {
        foreach ($package->assetRecords() as $record) {
            $metadata = $record->asset;
            $actual = $this->inspect(
                $package->assetBytes((string) $record->path),
                (string) $record->mediaType
            );
            if (($metadata->width > 0 && $actual['width'] > 0 && $metadata->width !== $actual['width'])
                || ($metadata->height > 0 && $actual['height'] > 0 && $metadata->height !== $actual['height'])) {
                throw new PackageException('Pagecraft asset dimensions do not match the file: ' . $record->path . '.');
            }
        }
    }

    /** @return array{width:int,height:int} */
    private function inspect(string $bytes, string $expectedType): array
    {
        $actualType = $this->sniff($bytes);
        if ($actualType !== $expectedType) {
            throw new PackageException('A Pagecraft asset does not match its declared media type.');
        }
        if ($actualType === 'image/svg+xml') {
            $root = $this->inspectSvg($bytes);
            $dimensions = ['width' => 0, 'height' => 0];
            $viewBox = preg_split('/[\s,]+/', trim($root->getAttribute('viewBox')));
            if (is_array($viewBox) && count($viewBox) === 4
                && preg_match('/^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i', $viewBox[2])
                && preg_match('/^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i', $viewBox[3])
                && is_finite((float) $viewBox[2]) && is_finite((float) $viewBox[3])
                && (float) $viewBox[2] > 0 && (float) $viewBox[3] > 0) {
                $dimensions = [
                    'width' => (int) round((float) $viewBox[2]),
                    'height' => (int) round((float) $viewBox[3]),
                ];
            }
            return $dimensions;
        }
        $image = @getimagesizefromstring($bytes);
        if (!is_array($image) || (int) $image[0] <= 0 || (int) $image[1] <= 0) {
            throw new PackageException('A Pagecraft image is corrupt or unsupported by this WordPress host.');
        }
        return ['width' => (int) $image[0], 'height' => (int) $image[1]];
    }

    private function inspectSvg(string $bytes): \DOMElement
    {
        $reject = static function (): never {
            throw new PackageException('Pagecraft SVG assets must be static and self-contained.');
        };
        if (!class_exists(\DOMDocument::class)
            || preg_match('/<!DOCTYPE\b|<!ENTITY\b/i', $bytes)) {
            $reject();
        }

        // Permit one normal XML declaration. Reject every other processing instruction.
        $withoutDeclaration = preg_replace(
            '/\A(?:\xEF\xBB\xBF)?\s*<\?xml\s+[^?]*\?>/i',
            '',
            $bytes,
            1
        );
        if (!is_string($withoutDeclaration) || str_contains($withoutDeclaration, '<?')) {
            $reject();
        }

        $document = new \DOMDocument();
        $document->resolveExternals = false;
        $document->substituteEntities = false;
        $previousErrors = libxml_use_internal_errors(true);
        libxml_clear_errors();
        $loaded = false;
        $parseErrors = [];
        try {
            $loaded = $document->loadXML($bytes, LIBXML_NONET | LIBXML_COMPACT);
            $parseErrors = libxml_get_errors();
        } catch (\Throwable) {
            // Invalid encodings and other parser failures use the same rejection contract.
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previousErrors);
        }
        $root = $document->documentElement;
        if (!$loaded || $parseErrors !== [] || !$root instanceof \DOMElement
            || $root->localName !== 'svg'
            || $root->namespaceURI !== 'http://www.w3.org/2000/svg') {
            $reject();
        }

        $allowedElements = array_fill_keys([
            'svg', 'g', 'defs', 'symbol', 'use',
            'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
            'text', 'tspan', 'textPath', 'title', 'desc',
            'linearGradient', 'radialGradient', 'stop',
            'clipPath', 'mask', 'pattern', 'marker',
        ], true);
        $allowedNamespaces = [
            '',
            'http://www.w3.org/XML/1998/namespace',
            'http://www.w3.org/1999/xlink',
            'http://www.w3.org/2000/xmlns/',
        ];
        $allowedStyleProperties = array_fill_keys([
            'color', 'display', 'visibility', 'opacity',
            'fill', 'fill-opacity', 'fill-rule',
            'stroke', 'stroke-width', 'stroke-opacity', 'stroke-linecap',
            'stroke-linejoin', 'stroke-miterlimit', 'stroke-dasharray', 'stroke-dashoffset',
            'clip-rule', 'stop-color', 'stop-opacity', 'flood-color', 'flood-opacity',
            'color-interpolation', 'color-rendering', 'shape-rendering', 'text-rendering',
            'font-family', 'font-size', 'font-style', 'font-weight',
            'letter-spacing', 'word-spacing', 'text-anchor', 'dominant-baseline',
        ], true);
        foreach ($document->getElementsByTagName('*') as $element) {
            if (!$element instanceof \DOMElement
                || $element->namespaceURI !== 'http://www.w3.org/2000/svg'
                || !isset($allowedElements[$element->localName])) {
                $reject();
            }
            foreach ($element->attributes as $attribute) {
                if (!$attribute instanceof \DOMAttr) {
                    $reject();
                }
                $namespace = (string) $attribute->namespaceURI;
                $name = $attribute->localName;
                $value = trim($attribute->value);
                if (!in_array($namespace, $allowedNamespaces, true)
                    || preg_match('/^on/i', $name)
                    || $name === 'base'
                    || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)) {
                    $reject();
                }
                if ($namespace === 'http://www.w3.org/2000/xmlns/') {
                    if (!in_array($value, [
                        'http://www.w3.org/2000/svg',
                        'http://www.w3.org/1999/xlink',
                    ], true)) {
                        $reject();
                    }
                    continue;
                }
                if (in_array(strtolower($name), ['href', 'src'], true)
                    && !preg_match('/^#[A-Za-z0-9_.:-]+$/', $value)) {
                    $reject();
                }
                if ($name === 'style') {
                    if (preg_match('/(?:@|\\\\|\/\*|\*\/|url\s*\(|expression\s*\(|(?:https?|data|file|ftp)\s*:)/i', $value)) {
                        $reject();
                    }
                    foreach (explode(';', $value) as $declaration) {
                        $declaration = trim($declaration);
                        if ($declaration === '') continue;
                        if (!preg_match('/^([a-z-]+)\s*:\s*(.+)$/i', $declaration, $style)
                            || !isset($allowedStyleProperties[strtolower($style[1])])) {
                            $reject();
                        }
                    }
                }
                if ($name !== 'style'
                    && preg_match('/(?:url|image-set)\s*\(/i', $value)
                    && !preg_match('/^url\(\s*["\']?#[A-Za-z0-9_.:-]+["\']?\s*\)$/i', $value)) {
                    $reject();
                }
            }
        }
        return $root;
    }

    private function sniff(string $bytes): string
    {
        if (str_starts_with($bytes, "\x89PNG\r\n\x1a\n")) return 'image/png';
        if (str_starts_with($bytes, "\xff\xd8\xff")) return 'image/jpeg';
        if (str_starts_with($bytes, 'GIF87a') || str_starts_with($bytes, 'GIF89a')) return 'image/gif';
        if (substr($bytes, 0, 4) === 'RIFF' && substr($bytes, 8, 4) === 'WEBP') return 'image/webp';
        if (substr($bytes, 4, 4) === 'ftyp' && preg_match('/^(?:avif|avis|mif1|msf1)$/', substr($bytes, 8, 4))) {
            return 'image/avif';
        }
        if (preg_match('/<svg[\s>]/i', substr($bytes, 0, 4096))) return 'image/svg+xml';
        return '';
    }

    private function existing(string $hash): int
    {
        $ids = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_key' => self::HASH,
            'meta_value' => $hash,
        ]);
        foreach (is_array($ids) ? $ids : [] as $id) {
            $file = get_attached_file((int) $id);
            if (is_string($file) && is_file($file) && hash_file('sha256', $file) === $hash) {
                return (int) $id;
            }
        }
        return 0;
    }

    /** @param array{alt?:string,caption?:string} $usage */
    private function createAttachment(
        string $name,
        string $mediaType,
        string $bytes,
        array $usage,
        string $hash,
        string $sourceId,
        string $sourcePath
    ): int {
        $filename = sanitize_file_name($name);
        if ($filename === '') {
            throw new PackageException('A Pagecraft asset has no safe filename.');
        }
        $this->assertFilenameMatchesType($filename, $mediaType);
        $svgMimes = static function (array $mimes): array {
            $mimes['svg'] = 'image/svg+xml';
            return $mimes;
        };
        if ($mediaType === 'image/svg+xml') add_filter('upload_mimes', $svgMimes, 10, 1);
        try {
            // SVG reaches this private path only after package integrity, byte sniffing,
            // static/self-contained markup, dimensions, filename and import capabilities
            // have all been verified. Keep the MIME exception scoped to this one write.
            $upload = wp_upload_bits($filename, null, $bytes);
        } finally {
            if ($mediaType === 'image/svg+xml') remove_filter('upload_mimes', $svgMimes, 10);
        }
        if (!is_array($upload) || !empty($upload['error']) || !is_string($upload['file'] ?? null)
            || !is_string($upload['url'] ?? null)) {
            throw new PackageException('WordPress could not store a Pagecraft asset: ' . (string) ($upload['error'] ?? 'upload failed'));
        }
        $attachmentId = wp_insert_attachment([
            'post_mime_type' => $mediaType,
            'post_title' => sanitize_text_field(pathinfo($filename, PATHINFO_FILENAME)),
            'post_excerpt' => sanitize_text_field((string) ($usage['caption'] ?? '')),
            'post_status' => 'inherit',
        ], $upload['file'], 0, true);
        if (is_wp_error($attachmentId)) {
            wp_delete_file($upload['file']);
            throw new PackageException('WordPress could not register a Pagecraft asset: ' . $attachmentId->get_error_message());
        }
        $attachmentId = (int) $attachmentId;
        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $generated = wp_generate_attachment_metadata($attachmentId, $upload['file']);
        if (is_array($generated) && $generated !== []) {
            wp_update_attachment_metadata($attachmentId, $generated);
        }
        update_post_meta($attachmentId, self::HASH, $hash);
        update_post_meta($attachmentId, self::SOURCE_ID, $sourceId);
        update_post_meta($attachmentId, self::SOURCE_PATH, $sourcePath);
        $this->applyTextMetadata($attachmentId, $usage);
        return $attachmentId;
    }

    private function assertFilenameMatchesType(string $filename, string $mediaType): void
    {
        $extension = strtolower((string) pathinfo($filename, PATHINFO_EXTENSION));
        $allowed = [
            'image/png' => ['png'],
            'image/jpeg' => ['jpg', 'jpeg'],
            'image/gif' => ['gif'],
            'image/webp' => ['webp'],
            'image/avif' => ['avif'],
            'image/svg+xml' => ['svg'],
        ];
        if (!isset($allowed[$mediaType]) || !in_array($extension, $allowed[$mediaType], true)) {
            throw new PackageException('A Pagecraft asset filename does not match its verified media type: ' . $filename . '.');
        }
    }

    /** @param array{alt?:string,caption?:string} $usage */
    private function applyTextMetadata(int $attachmentId, array $usage, bool $onlyMissing = false): void
    {
        $alt = sanitize_text_field((string) ($usage['alt'] ?? ''));
        if ($alt !== '' && (!$onlyMissing || get_post_meta($attachmentId, '_wp_attachment_image_alt', true) === '')) {
            update_post_meta($attachmentId, '_wp_attachment_image_alt', $alt);
        }
        $caption = sanitize_text_field((string) ($usage['caption'] ?? ''));
        $attachment = $onlyMissing ? get_post($attachmentId) : null;
        if ($caption !== '' && (!$onlyMissing || !is_object($attachment) || $attachment->post_excerpt === '')) {
            wp_update_post(['ID' => $attachmentId, 'post_excerpt' => $caption]);
        }
    }

    /** @return array<string,array{alt?:string,caption?:string}> */
    private function importUsage(string $documentJson): array
    {
        $document = json_decode($documentJson, true);
        $usage = [];
        $visit = function (mixed $value) use (&$visit, &$usage): void {
            if (!is_array($value)) return;
            $source = is_string($value['src'] ?? null) ? $value['src'] : '';
            if (preg_match('/^asset:([A-Za-z0-9][A-Za-z0-9._:-]*)/', $source, $match)) {
                $id = $match[1];
                $usage[$id] ??= [];
                foreach (['alt', 'caption'] as $field) {
                    $text = trim((string) ($value[$field] ?? ''));
                    if ($text !== '' && empty($usage[$id][$field])) $usage[$id][$field] = $text;
                }
            }
            foreach ($value as $child) $visit($child);
        };
        $visit($document);
        return $usage;
    }

    /**
     * Resolve exact WordPress attachments referenced by a Pagecraft document.
     * Stored import metadata is deliberately ignored because it may describe an older document.
     *
     * @param array<string,mixed> $document
     * @return list<int>
     */
    public static function attachmentIdsForDocument(array $document): array
    {
        $strings = self::strings($document);
        $ids = [];
        foreach ($strings as $value) {
            if (!preg_match_all('/(?<![A-Za-z0-9])asset:([1-9][0-9]*)(?:@[0-9]+)?(?![A-Za-z0-9])/', $value, $matches)) {
                continue;
            }
            foreach ($matches[1] as $match) {
                $attachmentId = (int) $match;
                if (get_post_type($attachmentId) === 'attachment') {
                    $ids[$attachmentId] = true;
                }
            }
        }
        $urls = self::attachmentUrls();
        $urlReferences = self::referencedIds(
            $strings,
            array_fill_keys(array_keys($urls), true),
            $urls,
            false
        );
        foreach ($urlReferences as $attachmentId) {
            $ids[$attachmentId] = true;
        }
        $result = array_map('intval', array_keys($ids));
        sort($result, SORT_NUMERIC);
        return $result;
    }

    /** @param array<string,mixed> $document */
    public static function attachmentIdsJsonForDocument(array $document): string
    {
        return CanonicalJson::encode(array_map('strval', self::attachmentIdsForDocument($document)));
    }

    /**
     * @return array{usageCount:int,canDelete:bool,usedBy:list<array{id:string,type:string,title:string,status:string,parentId:?string,references:list<string>}>}
     */
    public static function usage(int $attachmentId): array
    {
        $map = self::usageMap([$attachmentId]);
        return $map[$attachmentId] ?? ['usageCount' => 0, 'canDelete' => true, 'usedBy' => []];
    }

    /**
     * Scan current managed documents, recoverable revisions, and native WordPress content once.
     *
     * @param list<int> $attachmentIds
     * @return array<int,array{usageCount:int,canDelete:bool,usedBy:list<array{id:string,type:string,title:string,status:string,parentId:?string,references:list<string>}>}>
     */
    public static function usageMap(array $attachmentIds): array
    {
        $targets = [];
        foreach ($attachmentIds as $attachmentId) {
            $attachmentId = (int) $attachmentId;
            if ($attachmentId > 0) $targets[$attachmentId] = true;
        }
        if ($targets === []) return [];

        $urls = [];
        foreach (array_keys($targets) as $attachmentId) {
            $attachmentUrls = self::attachmentReferenceUrls($attachmentId);
            if ($attachmentUrls !== []) $urls[$attachmentId] = $attachmentUrls;
        }
        $postTypes = function_exists('get_post_types')
            ? array_values(get_post_types([], 'names'))
            : ['post', 'page', GlobalElement::POST_TYPE, 'revision'];
        if (!in_array('revision', $postTypes, true)) $postTypes[] = 'revision';
        $statuses = function_exists('get_post_stati')
            ? array_values(get_post_stati([], 'names'))
            : 'any';
        $posts = self::allPosts([
            'post_type' => $postTypes,
            'post_status' => $statuses,
            'orderby' => 'ID',
            'order' => 'ASC',
            // This is an administrative integrity scan, not a frontend display query.
            // Language and presentation filters must not hide a saved reference owner.
            'suppress_filters' => true,
        ]);

        /** @var array<int,array<int,array<string,bool>>> $references */
        $references = [];
        /** @var array<int,object> $postById */
        $postById = [];
        foreach ($posts as $record) {
            $post = self::post($record);
            if (!is_object($post) || (int) ($post->ID ?? 0) <= 0 || (string) ($post->post_type ?? '') === 'attachment') {
                continue;
            }
            $postId = (int) $post->ID;
            $postById[$postId] = $post;
            foreach ([ManagedPage::DOCUMENT, GlobalElement::DOCUMENT] as $metaKey) {
                $encoded = get_post_meta($postId, $metaKey, true);
                if (!is_string($encoded) || $encoded === '') continue;
                $document = json_decode($encoded, true);
                $documentStrings = is_array($document)
                    ? self::strings($document)
                    : [str_replace('\\/', '/', $encoded)];
                foreach (self::referencedIds($documentStrings, $targets, $urls, false) as $attachmentId) {
                    $references[$attachmentId][$postId]['managed_document'] = true;
                }
            }
            $content = (string) ($post->post_content ?? '');
            foreach (self::referencedIds([$content], $targets, $urls, true) as $attachmentId) {
                $references[$attachmentId][$postId]['native_content'] = true;
            }
            $thumbnailId = (int) get_post_meta($postId, '_thumbnail_id', true);
            if (isset($targets[$thumbnailId])) {
                $references[$thumbnailId][$postId]['featured_image'] = true;
            }
        }

        $result = [];
        foreach (array_keys($targets) as $attachmentId) {
            $usedBy = [];
            $postReferences = $references[$attachmentId] ?? [];
            ksort($postReferences, SORT_NUMERIC);
            foreach ($postReferences as $postId => $kinds) {
                $post = $postById[$postId] ?? get_post($postId);
                if (!is_object($post)) continue;
                $referenceKinds = array_keys($kinds);
                sort($referenceKinds, SORT_STRING);
                $parentId = (int) ($post->post_parent ?? 0);
                $readPostId = (string) ($post->post_type ?? '') === 'revision' && $parentId > 0
                    ? $parentId
                    : $postId;
                $canReadTitle = !function_exists('current_user_can')
                    || current_user_can('read_post', $readPostId);
                $usedBy[] = [
                    'id' => (string) $postId,
                    'type' => (string) ($post->post_type ?? ''),
                    'title' => $canReadTitle ? (string) ($post->post_title ?? '') : '',
                    'status' => (string) ($post->post_status ?? ''),
                    'parentId' => $parentId > 0 ? (string) $parentId : null,
                    'references' => $referenceKinds,
                ];
            }
            $result[$attachmentId] = [
                'usageCount' => count($usedBy),
                'canDelete' => $usedBy === [],
                'usedBy' => $usedBy,
            ];
        }
        return $result;
    }

    private static function post(mixed $record): ?object
    {
        if (is_object($record)) return $record;
        if (!is_int($record) && !is_string($record)) return null;
        $post = get_post((int) $record);
        return is_object($post) ? $post : null;
    }

    /** @return array<int,list<string>> */
    private static function attachmentUrls(): array
    {
        $ids = self::allPosts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_mime_type' => 'image',
            'fields' => 'ids',
            'orderby' => 'ID',
            'order' => 'ASC',
        ]);
        $urls = [];
        foreach ($ids as $attachmentId) {
            $attachmentId = (int) $attachmentId;
            if ($attachmentId <= 0) continue;
            $attachmentUrls = self::attachmentReferenceUrls($attachmentId);
            if ($attachmentUrls !== []) $urls[$attachmentId] = $attachmentUrls;
        }
        return $urls;
    }

    /** @return list<string> */
    private static function attachmentReferenceUrls(int $attachmentId): array
    {
        $url = wp_get_attachment_url($attachmentId);
        if (!is_string($url) || $url === '') return [];
        $url = preg_replace('/[?#].*$/', '', $url) ?? $url;
        $canonical = [$url];
        $metadata = function_exists('wp_get_attachment_metadata')
            ? wp_get_attachment_metadata($attachmentId)
            : false;
        if (is_array($metadata)) {
            $filenames = [];
            if (is_string($metadata['original_image'] ?? null)) {
                $filenames[] = $metadata['original_image'];
            }
            foreach (is_array($metadata['sizes'] ?? null) ? $metadata['sizes'] : [] as $size) {
                if (is_array($size) && is_string($size['file'] ?? null)) $filenames[] = $size['file'];
            }
            $directory = rtrim(str_replace('\\', '/', dirname($url)), '/');
            foreach ($filenames as $filename) {
                $filename = basename(str_replace('\\', '/', $filename));
                if ($filename === '' || $filename === '.' || $filename === '..') continue;
                $canonical[] = $directory . '/' . rawurlencode(rawurldecode($filename));
            }
        }
        $references = [];
        foreach (array_values(array_unique($canonical)) as $canonicalUrl) {
            foreach (self::urlVariants($canonicalUrl) as $variant) $references[$variant] = true;
        }
        return array_keys($references);
    }

    /** @return list<string> */
    private static function urlVariants(string $url): array
    {
        if (!function_exists('wp_parse_url')) return [$url];
        $parts = wp_parse_url($url);
        if (!is_array($parts) || !is_string($parts['host'] ?? null) || !is_string($parts['path'] ?? null)) {
            return [$url];
        }
        $authority = $parts['host'];
        if (isset($parts['port'])) $authority .= ':' . (int) $parts['port'];
        $path = $parts['path'];
        return array_values(array_unique([$url, '//' . $authority . $path, $path]));
    }

    /** @param array<string,mixed> $arguments @return list<mixed> */
    private static function allPosts(array $arguments): array
    {
        $batchSize = 250;
        $page = 1;
        $result = [];
        $seen = [];
        do {
            $batch = get_posts(array_replace($arguments, [
                'posts_per_page' => $batchSize,
                'paged' => $page,
            ]));
            if (!is_array($batch) || $batch === []) break;
            $added = 0;
            foreach ($batch as $record) {
                $key = is_object($record) ? (int) $record->ID : (int) $record;
                if ($key <= 0 || isset($seen[$key])) continue;
                $seen[$key] = true;
                $result[] = $record;
                $added++;
            }
            $page++;
        } while (count($batch) === $batchSize && $added > 0);
        return $result;
    }

    /** @return list<string> */
    private static function strings(mixed $value): array
    {
        if (is_string($value)) return [$value];
        if (!is_array($value)) return [];
        $strings = [];
        foreach ($value as $child) array_push($strings, ...self::strings($child));
        return $strings;
    }

    /**
     * @param list<string> $strings
     * @param array<int,bool> $targets
     * @param array<int,list<string>> $urls
     * @return list<int>
     */
    private static function referencedIds(array $strings, array $targets, array $urls, bool $native): array
    {
        $found = [];
        $urlTargets = [];
        foreach ($urls as $attachmentId => $attachmentUrls) {
            foreach ($attachmentUrls as $url) {
                if ($url !== '') $urlTargets[$url] = $attachmentId;
            }
        }
        foreach ($strings as $value) {
            if (preg_match_all('/(?<![A-Za-z0-9])asset:([1-9][0-9]*)(?:@[0-9]+)?(?![A-Za-z0-9])/', $value, $matches)) {
                foreach ($matches[1] as $match) {
                    $attachmentId = (int) $match;
                    if (isset($targets[$attachmentId])) $found[$attachmentId] = true;
                }
            }
            $normalizedValue = self::normalizeReferenceUrl($value);
            if (isset($urlTargets[$normalizedValue])) {
                $found[$urlTargets[$normalizedValue]] = true;
            }
            if (preg_match_all('~(?:https?:)?//[^\s"\'<>)]+|/[^\s"\'<>)]+~i', $value, $matches)) {
                foreach ($matches[0] as $candidate) {
                    $candidate = self::normalizeReferenceUrl($candidate);
                    if (isset($urlTargets[$candidate])) $found[$urlTargets[$candidate]] = true;
                }
            }
            if (!$native) continue;
            if (preg_match_all('/(?:wp-image-|attachment_)([1-9][0-9]*)(?![0-9])/', $value, $matches)) {
                foreach ($matches[1] as $match) {
                    $attachmentId = (int) $match;
                    if (isset($targets[$attachmentId])) $found[$attachmentId] = true;
                }
            }
            if (preg_match_all('/(?:\?|&amp;|&)attachment_id=([1-9][0-9]*)(?![0-9])/', $value, $matches)) {
                foreach ($matches[1] as $match) {
                    $attachmentId = (int) $match;
                    if (isset($targets[$attachmentId])) $found[$attachmentId] = true;
                }
            }
            if (preg_match_all('/\[gallery\b[^\]]*\bids\s*=\s*(["\'])(.*?)\1[^\]]*\]/i', $value, $galleries, PREG_SET_ORDER)) {
                foreach ($galleries as $gallery) {
                    if (!preg_match_all('/[1-9][0-9]*/', (string) $gallery[2], $matches)) continue;
                    foreach ($matches[0] as $match) {
                        $attachmentId = (int) $match;
                        if (isset($targets[$attachmentId])) $found[$attachmentId] = true;
                    }
                }
            }
            foreach (self::nativeBlockAttachmentIds($value) as $attachmentId) {
                if (isset($targets[$attachmentId])) $found[$attachmentId] = true;
            }
        }
        $ids = array_map('intval', array_keys($found));
        sort($ids, SORT_NUMERIC);
        return $ids;
    }

    private static function normalizeReferenceUrl(string $url): string
    {
        $url = html_entity_decode(trim($url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return preg_replace('/[?#].*$/', '', $url) ?? $url;
    }

    /** @return list<int> */
    private static function nativeBlockAttachmentIds(string $content): array
    {
        $ids = [];
        if (function_exists('parse_blocks')) {
            $visit = static function (array $blocks) use (&$visit, &$ids): void {
                foreach ($blocks as $block) {
                    if (!is_array($block)) continue;
                    self::collectBlockAttachmentIds(
                        (string) ($block['blockName'] ?? ''),
                        is_array($block['attrs'] ?? null) ? $block['attrs'] : [],
                        $ids
                    );
                    if (is_array($block['innerBlocks'] ?? null)) $visit($block['innerBlocks']);
                }
            };
            $blocks = parse_blocks($content);
            if (is_array($blocks)) $visit($blocks);
        } elseif (preg_match_all(
            '/<!--\s+wp:(image|cover|media-text|gallery)\s+(\{.*?\})\s*(?:\/)?-->/s',
            $content,
            $matches,
            PREG_SET_ORDER
        )) {
            foreach ($matches as $match) {
                $attributes = json_decode((string) $match[2], true);
                if (is_array($attributes)) {
                    self::collectBlockAttachmentIds('core/' . $match[1], $attributes, $ids);
                }
            }
        }
        $result = array_map('intval', array_keys($ids));
        sort($result, SORT_NUMERIC);
        return $result;
    }

    /** @param array<string,mixed> $attributes @param array<int,bool> $ids */
    private static function collectBlockAttachmentIds(string $blockName, array $attributes, array &$ids): void
    {
        $keys = match ($blockName) {
            'core/image' => ['id'],
            'core/cover' => ['id', 'mediaId'],
            'core/media-text' => ['mediaId'],
            default => [],
        };
        foreach ($keys as $key) {
            $attachmentId = (int) ($attributes[$key] ?? 0);
            if ($attachmentId > 0) $ids[$attachmentId] = true;
        }
        if ($blockName === 'core/gallery' && is_array($attributes['ids'] ?? null)) {
            foreach ($attributes['ids'] as $attachmentId) {
                $attachmentId = (int) $attachmentId;
                if ($attachmentId > 0) $ids[$attachmentId] = true;
            }
        }
    }
}
