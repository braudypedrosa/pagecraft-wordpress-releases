<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class EditorBusy extends \RuntimeException
{
    public function __construct()
    {
        parent::__construct('Another Pagecraft save is in progress. Wait for it to finish, then retry.');
    }
}
