<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Serialize version checks and writes across PHP workers sharing this WP database. */
final class EditorWriteLock
{
    /** @var array<string,int> */
    private static array $held = [];

    /** @param list<int> $postIds */
    public static function runExclusiveSourceWrite(array $postIds, callable $operation): mixed
    {
        $lockIds = array_values(array_unique(array_merge([0], array_map('intval', $postIds))));
        foreach ($lockIds as $postId) {
            if (isset(self::$held[self::key($postId)])) throw new EditorBusy();
        }
        return self::runSourceWrite($postIds, $operation);
    }

    /**
     * Serialize writes that can change a persisted Pagecraft source document or shared design.
     * Lock zero is the site-wide source boundary; known post locks always follow it numerically.
     * Already-held locks are recognized only from this request's private lock state, so callers
     * cannot bypass locking with a request parameter when an importer nests source writes.
     *
     * @param list<int> $postIds
     */
    public static function runSourceWrite(array $postIds, callable $operation): mixed
    {
        $postIds = array_values(array_unique(array_filter(
            array_map('intval', $postIds),
            static fn (int $postId): bool => $postId > 0
        )));
        sort($postIds, SORT_NUMERIC);
        $globalKey = self::key(0);
        if (!isset(self::$held[$globalKey]) && self::$held !== []) {
            // Never acquire the global lock after a post lock: another worker may hold them
            // in the required opposite order. Existing code reaching here is a lock bug.
            throw new PackageException('WordPress could not establish the safe source-write lock order. Nothing was saved.');
        }
        if (isset(self::$held[$globalKey]) && count(self::$held) > 1) {
            $heldPostIds = array_values(array_filter(
                self::$held,
                static fn (int $postId): bool => $postId > 0
            ));
            $highestHeldPostId = $heldPostIds === [] ? 0 : max($heldPostIds);
            foreach ($postIds as $postId) {
                if (isset(self::$held[self::key($postId)])) continue;
                // A whole-site import can create a new post after locking every
                // existing destination. WordPress allocates that ID above the
                // held set, so extending monotonically preserves global ->
                // ascending-post lock order. Missing lower IDs remain unsafe.
                if ($postId <= $highestHeldPostId) {
                    throw new PackageException('WordPress could not extend the safe source-write lock set. Nothing was saved.');
                }
                $highestHeldPostId = $postId;
            }
        }
        array_unshift($postIds, 0);
        $next = static function (int $index) use (&$next, $postIds, $operation): mixed {
            if (!isset($postIds[$index])) return $operation();
            $postId = $postIds[$index];
            return isset(self::$held[self::key($postId)])
                ? $next($index + 1)
                : self::run($postId, static fn (): mixed => $next($index + 1));
        };
        return $next(0);
    }

    /** @param list<int> $postIds */
    public static function runMany(array $postIds, callable $operation): mixed
    {
        $postIds = array_values(array_unique($postIds));
        sort($postIds, SORT_NUMERIC);
        $next = static function (int $index) use (&$next, $postIds, $operation): mixed {
            return isset($postIds[$index])
                ? self::run($postIds[$index], static fn (): mixed => $next($index + 1))
                : $operation();
        };
        return $next(0);
    }

    public static function run(int $postId, callable $operation): mixed
    {
        global $wpdb;
        // MySQL advisory locks are connection-owned and released if a worker dies.
        // Include the database and table prefix because one server can host many WP sites.
        $key = self::key($postId);
        if (isset(self::$held[$key])) {
            throw new EditorBusy();
        }
        $acquired = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 0)', $key));
        if ((string) $acquired !== '1') {
            if ((string) $acquired === '0') throw new EditorBusy();
            throw new PackageException('WordPress could not acquire a safe editor write lock. Nothing was saved.');
        }
        self::$held[$key] = $postId;
        try {
            // Do not compare against metadata cached before another request committed.
            wp_cache_delete($postId, 'post_meta');
            return $operation();
        } finally {
            unset(self::$held[$key]);
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $key));
        }
    }

    private static function key(int $postId): string
    {
        global $wpdb;
        return 'pc-edit-' . substr(hash(
            'sha256',
            (defined('DB_NAME') ? DB_NAME : '') . ':' . $wpdb->prefix . ':' . $postId
        ), 0, 56);
    }
}
