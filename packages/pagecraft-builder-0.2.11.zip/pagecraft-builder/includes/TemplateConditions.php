<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Normalizes and evaluates the portable display-condition contract used by
 * Theme Builder records. The matcher deliberately has no WordPress dependency
 * so the same rules can be tested and mirrored by the standalone theme.
 */
final class TemplateConditions
{
    public const META = '_pagecraft_template_conditions';
    public const PRIORITY = '_pagecraft_template_priority';

    /** @return list<string> */
    public static function types(): array
    {
        return [
            'site',
            'singular',
            'post_type',
            'post',
            'archive',
            'post_type_archive',
            'taxonomy',
            'term',
            'search',
            'not_found',
        ];
    }

    /** @return list<array{action:string,type:string,value:string}> */
    public static function defaults(string $kind): array
    {
        return match ($kind) {
            'header', 'footer' => [['action' => 'include', 'type' => 'site', 'value' => '']],
            'single_page' => [['action' => 'include', 'type' => 'post_type', 'value' => 'page']],
            'single_post' => [['action' => 'include', 'type' => 'post_type', 'value' => 'post']],
            'archive' => [['action' => 'include', 'type' => 'archive', 'value' => '']],
            'search' => [['action' => 'include', 'type' => 'search', 'value' => '']],
            'not_found' => [['action' => 'include', 'type' => 'not_found', 'value' => '']],
            default => [],
        };
    }

    /** @param mixed $rules @return list<array{action:string,type:string,value:string}> */
    public static function normalize(mixed $rules): array
    {
        if (is_string($rules) && $rules !== '') {
            try {
                $rules = json_decode($rules, true, 64, JSON_THROW_ON_ERROR);
            } catch (\JsonException) {
                return [];
            }
        }
        if (!is_array($rules)) {
            return [];
        }
        $normalized = [];
        foreach ($rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $action = strtolower(trim((string) ($rule['action'] ?? 'include')));
            $type = strtolower(trim((string) ($rule['type'] ?? '')));
            $value = trim((string) ($rule['value'] ?? ''));
            if (!in_array($action, ['include', 'exclude'], true) || !in_array($type, self::types(), true)) {
                continue;
            }
            $value = (string) preg_replace('/[^A-Za-z0-9_:\-]/', '', $value);
            if (in_array($type, ['post_type', 'post', 'post_type_archive', 'taxonomy', 'term'], true) && $value === '') {
                continue;
            }
            $key = $action . '|' . $type . '|' . $value;
            $normalized[$key] = ['action' => $action, 'type' => $type, 'value' => $value];
        }
        return array_values($normalized);
    }

    /** @param mixed $rules */
    public static function encode(mixed $rules): string
    {
        return (string) wp_json_encode(self::normalize($rules), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param array{action:string,type:string,value:string} $rule
     * @param array<string,mixed> $context
     */
    public static function matches(array $rule, array $context): bool
    {
        $value = (string) $rule['value'];
        return match ($rule['type']) {
            'site' => true,
            'singular' => (bool) ($context['is_singular'] ?? false),
            'post_type' => (bool) ($context['is_singular'] ?? false)
                && hash_equals($value, (string) ($context['post_type'] ?? '')),
            'post' => (bool) ($context['is_singular'] ?? false)
                && (int) $value === (int) ($context['post_id'] ?? 0),
            'archive' => (bool) ($context['is_archive'] ?? false),
            'post_type_archive' => (bool) ($context['is_post_type_archive'] ?? false)
                && hash_equals($value, (string) ($context['post_type'] ?? '')),
            'taxonomy' => (bool) ($context['is_taxonomy'] ?? false)
                && hash_equals($value, (string) ($context['taxonomy'] ?? '')),
            'term' => self::matchesTerm($value, $context),
            'search' => (bool) ($context['is_search'] ?? false),
            'not_found' => (bool) ($context['is_404'] ?? false),
            default => false,
        };
    }

    /**
     * A negative return value means the template is not applicable. Excludes
     * always win; otherwise the most specific matching include determines rank.
     *
     * @param mixed $rules
     * @param array<string,mixed> $context
     */
    public static function score(mixed $rules, array $context): int
    {
        $rules = self::normalize($rules);
        $best = -1;
        foreach ($rules as $rule) {
            if (!self::matches($rule, $context)) {
                continue;
            }
            if ($rule['action'] === 'exclude') {
                return -1;
            }
            $best = max($best, self::specificity($rule['type']));
        }
        return $best;
    }

    public static function specificity(string $type): int
    {
        return match ($type) {
            'post', 'term', 'search', 'not_found' => 500,
            'post_type', 'post_type_archive', 'taxonomy' => 400,
            'singular', 'archive' => 300,
            'site' => 100,
            default => 0,
        };
    }

    /** @param mixed $rules */
    public static function hasInclude(mixed $rules): bool
    {
        foreach (self::normalize($rules) as $rule) {
            if ($rule['action'] === 'include') {
                return true;
            }
        }
        return false;
    }

    /** @param mixed $rules */
    public static function summary(mixed $rules): string
    {
        $parts = [];
        foreach (self::normalize($rules) as $rule) {
            $label = self::ruleLabel($rule['type'], $rule['value']);
            $parts[] = ($rule['action'] === 'exclude' ? 'Except ' : '') . $label;
        }
        return $parts === [] ? 'No display conditions' : implode(' · ', $parts);
    }

    private static function ruleLabel(string $type, string $value): string
    {
        return match ($type) {
            'site' => 'Entire site',
            'singular' => 'All singular content',
            'post_type' => 'All ' . self::humanizeCollection($value),
            'post' => 'Content #' . $value,
            'archive' => 'All archives',
            'post_type_archive' => self::humanize($value) . ' archive',
            'taxonomy' => self::humanize($value) . ' archives',
            'term' => 'Term ' . str_replace(':', ' #', $value),
            'search' => 'Search results',
            'not_found' => '404 page',
            default => self::humanize($type),
        };
    }

    private static function humanize(string $value): string
    {
        return ucwords(str_replace(['_', '-'], ' ', $value));
    }

    private static function humanizeCollection(string $value): string
    {
        return match ($value) {
            'post' => 'Posts',
            'page' => 'Pages',
            default => self::humanize($value),
        };
    }

    /** @param array<string,mixed> $context */
    private static function matchesTerm(string $value, array $context): bool
    {
        if (!(bool) ($context['is_taxonomy'] ?? false)) {
            return false;
        }
        [$taxonomy, $termId] = array_pad(explode(':', $value, 2), 2, '');
        return $taxonomy !== ''
            && hash_equals($taxonomy, (string) ($context['taxonomy'] ?? ''))
            && (int) $termId === (int) ($context['term_id'] ?? 0);
    }
}
