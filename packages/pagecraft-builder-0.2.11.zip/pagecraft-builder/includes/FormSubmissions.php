<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Pagecraft forms on WordPress: WordPress receives, stores and emails entries itself.
 *
 * Pages keep the portable "disabled form" markup Pagecraft compiles for hosts without a form
 * service. While Builder is active, that markup is upgraded when the page is served: a small
 * hidden <form> posts to admin-post.php and the visible fields join it through the HTML form
 * attribute. Nothing is rewritten in stored content, so deactivating Builder returns forms to
 * their disabled state, and public requests never contact Pagecraft Cloud.
 */
final class FormSubmissions
{
    public const POST_TYPE = 'pagecraft_entry';
    public const ACTION = 'pagecraft_form_submit';
    public const NOTIFY_OPTION = 'pagecraft_form_notify';
    public const SOURCE = '_pagecraft_entry_source';
    public const FORM = '_pagecraft_entry_form';
    public const FORM_LABEL = '_pagecraft_entry_form_label';
    public const PAGE_URL = '_pagecraft_entry_page_url';
    public const FIELDS = '_pagecraft_entry_fields';
    public const UNREAD = '_pagecraft_entry_unread';
    public const SPAM = '_pagecraft_entry_spam';

    private const MIN_SECONDS = 3;
    private const MAX_AGE = 30 * DAY_IN_SECONDS;
    private const RATE_LIMIT = 5;
    private const RATE_WINDOW = 10 * MINUTE_IN_SECONDS;
    private const MAX_FIELD_LENGTH = 5000;

    public static function register(): void
    {
        add_action('init', [self::class, 'registerPostType']);
        add_action('admin_post_nopriv_' . self::ACTION, [self::class, 'handle']);
        add_action('admin_post_' . self::ACTION, [self::class, 'handle']);
        add_filter('the_content', [self::class, 'filterPageContent'], 20);
        add_filter('pagecraft_theme_global_content', [self::class, 'filterSourceContent'], 10, 3);
        add_filter('pagecraft_theme_template_content', [self::class, 'filterSourceContent'], 10, 3);
        add_filter('wp_privacy_personal_data_exporters', [self::class, 'registerExporter']);
        add_filter('wp_privacy_personal_data_erasers', [self::class, 'registerEraser']);
    }

    public static function registerPostType(): void
    {
        register_post_type(self::POST_TYPE, [
            'label' => __('Form entries', 'pagecraft-builder'),
            'public' => false,
            'publicly_queryable' => false,
            'exclude_from_search' => true,
            'show_ui' => false,
            'show_in_rest' => false,
            'rewrite' => false,
            'query_var' => false,
            'supports' => ['title', 'custom-fields'],
            'capability_type' => 'post',
            'capabilities' => ['create_posts' => 'do_not_allow'],
            'map_meta_cap' => true,
        ]);
    }

    public static function notifyEnabled(): bool
    {
        return get_option(self::NOTIFY_OPTION, '1') !== '0';
    }

    public static function filterPageContent(string $content): string
    {
        $postId = (int) get_the_ID();
        if ($postId <= 0 || !ManagedPage::isManaged($postId)) {
            return $content;
        }
        return self::upgrade($content, $postId, $postId);
    }

    public static function filterSourceContent(string $content, string $kind = '', int $sourceId = 0): string
    {
        return $sourceId > 0 ? self::upgrade($content, $sourceId, (int) get_queried_object_id()) : $content;
    }

    /**
     * Turn every disabled Pagecraft form in compiled markup into a working WordPress form.
     */
    public static function upgrade(string $html, int $sourceId, int $returnId = 0): string
    {
        if (!str_contains($html, 'data-disabled') || !str_contains($html, 'pagecraft-form')) {
            return $html;
        }
        $processor = new \WP_HTML_Tag_Processor($html);
        $forms = [];
        $current = null;
        while ($processor->next_tag()) {
            $tag = $processor->get_tag();
            if ($tag === 'DIV' && $processor->get_attribute('data-disabled') !== null && self::hasClass($processor, 'pagecraft-form')) {
                $id = (string) $processor->get_attribute('id');
                $current = preg_match('/^[A-Za-z0-9_-]{1,120}$/', $id) ? $id : null;
                if ($current !== null) {
                    $forms[] = $current;
                    $processor->remove_attribute('data-disabled');
                    $processor->set_attribute('data-pagecraft-form-mode', 'wordpress');
                }
                continue;
            }
            if ($current === null) {
                continue;
            }
            if (in_array($tag, ['INPUT', 'SELECT', 'TEXTAREA'], true)
                && str_starts_with((string) $processor->get_attribute('id'), $current . '-f')) {
                $processor->remove_attribute('disabled');
                $processor->set_attribute('form', 'pcf-' . $current);
            } elseif ($tag === 'BUTTON' && self::hasClass($processor, 'pagecraft-form-button')) {
                $processor->remove_attribute('disabled');
                $processor->set_attribute('type', 'submit');
                $processor->set_attribute('form', 'pcf-' . $current);
                $current = null;
            }
        }
        $html = $processor->get_updated_html();
        foreach ($forms as $formId) {
            $html = self::insertHostForm($html, $formId, $sourceId, $returnId);
            $html = self::replaceStatus($html, $formId);
        }
        return $html;
    }

    private static function hasClass(\WP_HTML_Tag_Processor $processor, string $class): bool
    {
        $classes = preg_split('/\s+/', trim((string) $processor->get_attribute('class')));
        return is_array($classes) && in_array($class, $classes, true);
    }

    private static function insertHostForm(string $html, string $formId, int $sourceId, int $returnId): string
    {
        $issued = (string) time();
        $host = '<form id="' . esc_attr('pcf-' . $formId) . '" class="pagecraft-form-host" action="'
            . esc_url(admin_url('admin-post.php')) . '" method="post" hidden>'
            . '<input type="hidden" name="action" value="' . esc_attr(self::ACTION) . '">'
            . '<input type="hidden" name="_pc_source" value="' . esc_attr((string) $sourceId) . '">'
            . '<input type="hidden" name="_pc_form" value="' . esc_attr($formId) . '">'
            . '<input type="hidden" name="_pc_return" value="' . esc_attr((string) max(0, $returnId)) . '">'
            . '<input type="hidden" name="_pc_t" value="' . esc_attr($issued . '.' . self::sign($issued, $sourceId, $formId)) . '">'
            . '<label>' . esc_html__('Leave this field empty', 'pagecraft-builder')
            . '<input type="text" name="_pc_trap" value="" tabindex="-1" autocomplete="off"></label></form>';
        $pattern = '/<div\b[^>]*\bid=(["\'])' . preg_quote($formId, '/') . '\1/';
        return (string) preg_replace_callback($pattern, static fn (array $m): string => $host . $m[0], $html, 1);
    }

    private static function replaceStatus(string $html, string $formId): string
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Display-only result after a redirect.
        $queryId = isset($_GET['pagecraft_form_id']) ? sanitize_key(wp_unslash((string) $_GET['pagecraft_form_id'])) : '';
        $result = isset($_GET['pagecraft_form']) && $queryId !== '' && hash_equals(strtolower($formId), $queryId)
            ? sanitize_key(wp_unslash((string) $_GET['pagecraft_form']))
            : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        $message = match ($result) {
            'sent' => __('Thanks. Your message was sent.', 'pagecraft-builder'),
            'invalid' => __('Some required fields were empty or not valid. Check the form and send it again.', 'pagecraft-builder'),
            'limit' => __('Too many messages were sent from here in a short time. Wait a few minutes and try again.', 'pagecraft-builder'),
            'unavailable' => __('This form can’t take messages right now. Try again later.', 'pagecraft-builder'),
            default => '',
        };
        $pattern = '/(<p\b[^>]*\bid=(["\'])' . preg_quote($formId . '-status', '/') . '\2[^>]*>)(.*?)(<\/p>)/s';
        return (string) preg_replace_callback($pattern, static function (array $m) use ($message, $result): string {
            $open = str_replace('<p', '<p role="status" data-pagecraft-form-result="' . esc_attr($result) . '"', $m[1]);
            return $open . esc_html($message) . $m[4];
        }, $html, 1);
    }

    private static function sign(string $issued, int $sourceId, string $formId): string
    {
        return substr(hash_hmac('sha256', $issued . '|' . $sourceId . '|' . $formId, wp_salt('nonce')), 0, 24);
    }

    /**
     * Read the fields of one disabled Pagecraft form from stored compiled markup.
     *
     * @return array{label:string,fields:list<array{name:string,label:string,type:string,required:bool,options:list<string>}>}|null
     */
    public static function schema(string $html, string $formId): ?array
    {
        $processor = new \WP_HTML_Tag_Processor($html);
        $inside = false;
        $label = '';
        $fields = [];
        while ($processor->next_tag()) {
            $tag = $processor->get_tag();
            if (!$inside) {
                if ($tag === 'DIV' && $processor->get_attribute('id') === $formId
                    && $processor->get_attribute('data-disabled') !== null && self::hasClass($processor, 'pagecraft-form')) {
                    $inside = true;
                    $label = trim((string) $processor->get_attribute('aria-label'));
                }
                continue;
            }
            if ($tag === 'BUTTON' && self::hasClass($processor, 'pagecraft-form-button')) {
                return ['label' => $label !== '' ? $label : __('Form', 'pagecraft-builder'), 'fields' => $fields];
            }
            if (!in_array($tag, ['INPUT', 'SELECT', 'TEXTAREA'], true)) {
                continue;
            }
            $id = (string) $processor->get_attribute('id');
            $name = (string) $processor->get_attribute('name');
            if (!str_starts_with($id, $formId . '-f') || !preg_match('/^[A-Za-z0-9_.\-\[\] ]{1,120}$/', $name)) {
                continue;
            }
            $type = $tag === 'INPUT' ? strtolower((string) ($processor->get_attribute('type') ?? 'text')) : strtolower($tag);
            $fields[] = [
                'name' => $name,
                'label' => self::labelFor($html, $id, $name),
                'type' => $type,
                'required' => $processor->get_attribute('required') !== null,
                'options' => $tag === 'SELECT' ? self::selectOptions($html, $id) : [],
            ];
        }
        return null;
    }

    private static function labelFor(string $html, string $id, string $fallback): string
    {
        if (preg_match('/<label\b[^>]*\bfor=(["\'])' . preg_quote($id, '/') . '\1[^>]*>(.*?)<\/label>/s', $html, $m)) {
            $inner = preg_replace('/<span\b[^>]*aria-hidden=(["\'])true\1[^>]*>\s*\*\s*<\/span>/', '', $m[2]) ?? $m[2];
            $text = rtrim(trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($inner)) ?? ''), " *");
            if ($text !== '') return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        return $fallback;
    }

    /** @return list<string> */
    private static function selectOptions(string $html, string $id): array
    {
        if (!preg_match('/<select\b[^>]*\bid=(["\'])' . preg_quote($id, '/') . '\1[^>]*>(.*?)<\/select>/s', $html, $m)) {
            return [];
        }
        preg_match_all('/<option\b[^>]*\bvalue=(["\'])(.*?)\1/s', $m[2], $options);
        return array_values(array_map(
            static fn (string $value): string => html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            $options[2]
        ));
    }

    /** The page or Theme Builder record that owns a form, if it may receive entries. */
    private static function source(int $sourceId): ?\WP_Post
    {
        $post = $sourceId > 0 ? get_post($sourceId) : null;
        if (!$post instanceof \WP_Post || $post->post_status !== 'publish' || post_password_required($post)) {
            return null;
        }
        if ($post->post_type === GlobalElement::POST_TYPE || ManagedPage::isManaged($post->ID)) {
            return $post;
        }
        return null;
    }

    public static function handle(): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- Public form on cacheable pages; a signed timestamp, honeypot and rate limit stand in for a nonce.
        $sourceId = absint($_POST['_pc_source'] ?? 0);
        $formId = preg_replace('/[^A-Za-z0-9_-]/', '', sanitize_text_field(wp_unslash((string) ($_POST['_pc_form'] ?? '')))) ?? '';
        $returnId = absint($_POST['_pc_return'] ?? 0);
        $token = sanitize_text_field(wp_unslash((string) ($_POST['_pc_t'] ?? '')));
        $trap = sanitize_text_field(wp_unslash((string) ($_POST['_pc_trap'] ?? '')));
        $back = static function (string $result) use ($returnId, $sourceId, $formId): never {
            $target = $returnId > 0 && get_post_status($returnId) === 'publish' ? get_permalink($returnId) : false;
            if (!is_string($target) || $target === '') {
                $target = ManagedPage::isManaged($sourceId) ? get_permalink($sourceId) : home_url('/');
            }
            $url = add_query_arg(['pagecraft_form' => $result, 'pagecraft_form_id' => strtolower($formId)], (string) $target);
            wp_safe_redirect($url . ($formId !== '' ? '#' . rawurlencode($formId) : ''), 303);
            exit;
        };

        $source = self::source($sourceId);
        $schema = $source && $formId !== '' ? self::schema((string) $source->post_content, $formId) : null;
        if (!$source || !$schema) {
            $back('unavailable');
        }

        [$issued, $signature] = array_pad(explode('.', $token, 2), 2, '');
        $age = time() - (int) $issued;
        $validToken = ctype_digit($issued) && $signature !== ''
            && hash_equals(self::sign($issued, $sourceId, $formId), $signature)
            && $age >= self::MIN_SECONDS && $age <= self::MAX_AGE;
        $spam = $trap !== '' || !$validToken;

        $rateKey = self::rateKey();
        if (!$spam && (int) get_transient($rateKey) >= self::RATE_LIMIT) {
            $back('limit');
        }

        $values = [];
        foreach ($schema['fields'] as $field) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- Unslashed and sanitized per field type just below.
            $raw = isset($_POST[$field['name']]) ? wp_unslash($_POST[$field['name']]) : null;
            if ($field['type'] === 'checkbox') {
                $value = $raw !== null && $raw !== '' ? __('Yes', 'pagecraft-builder') : __('No', 'pagecraft-builder');
                if ($field['required'] && $raw === null) $back('invalid');
            } else {
                $text = is_scalar($raw) ? (string) $raw : '';
                $value = $field['type'] === 'textarea' ? sanitize_textarea_field($text) : sanitize_text_field($text);
                $value = mb_substr($value, 0, self::MAX_FIELD_LENGTH);
                if ($field['required'] && trim($value) === '') $back('invalid');
                if ($value !== '' && $field['type'] === 'email' && !is_email($value)) $back('invalid');
                if ($value !== '' && $field['type'] === 'select' && $field['options'] && !in_array($value, $field['options'], true)) $back('invalid');
            }
            $values[] = ['name' => $field['name'], 'label' => $field['label'], 'type' => $field['type'], 'value' => $value];
        }
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        $pageUrl = $returnId > 0 ? (string) get_permalink($returnId) : (string) get_permalink($sourceId);
        $entryId = self::store($sourceId, $formId, $schema['label'], $pageUrl, $values, $spam);
        if ($entryId > 0 && !$spam) {
            // Only accepted entries count, so a visitor correcting a typo is never locked out.
            set_transient($rateKey, (int) get_transient($rateKey) + 1, self::RATE_WINDOW);
            if (self::notifyEnabled()) {
                self::notify($entryId, $schema['label'], $pageUrl, $values);
            }
        }
        $back($entryId > 0 || $spam ? 'sent' : 'unavailable');
    }

    /** Per-visitor counter key; the address is only ever kept as a keyed hash. */
    private static function rateKey(): string
    {
        $address = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : '';
        return 'pagecraft_form_rate_' . substr(hash_hmac('sha256', $address, wp_salt('nonce')), 0, 20);
    }

    /** @param list<array{name:string,label:string,type:string,value:string}> $values */
    private static function store(int $sourceId, string $formId, string $label, string $pageUrl, array $values, bool $spam): int
    {
        $summary = self::summary($values);
        $entryId = wp_insert_post([
            'post_type' => self::POST_TYPE,
            'post_status' => 'private',
            'post_title' => $label . ($summary !== '' ? ' · ' . $summary : ''),
            'post_parent' => get_post_type($sourceId) === 'page' ? $sourceId : 0,
            'post_author' => 0,
        ], true);
        if (is_wp_error($entryId) || $entryId <= 0) {
            return 0;
        }
        update_post_meta($entryId, self::SOURCE, $sourceId);
        update_post_meta($entryId, self::FORM, $formId);
        update_post_meta($entryId, self::FORM_LABEL, $label);
        update_post_meta($entryId, self::PAGE_URL, esc_url_raw($pageUrl));
        update_post_meta($entryId, self::FIELDS, wp_slash((string) wp_json_encode($values)));
        update_post_meta($entryId, self::UNREAD, '1');
        update_post_meta($entryId, self::SPAM, $spam ? '1' : '0');
        return (int) $entryId;
    }

    /** @param list<array{name:string,label:string,type:string,value:string}> $values */
    public static function summary(array $values): string
    {
        foreach (['name', 'email'] as $kind) {
            foreach ($values as $value) {
                $isMatch = $kind === 'email' ? $value['type'] === 'email' : (bool) preg_match('/name/i', $value['name'] . ' ' . $value['label']);
                if ($isMatch && trim($value['value']) !== '') return mb_substr($value['value'], 0, 80);
            }
        }
        return '';
    }

    /** @param list<array{name:string,label:string,type:string,value:string}> $values */
    private static function notify(int $entryId, string $label, string $pageUrl, array $values): void
    {
        $site = wp_specialchars_decode((string) get_option('blogname'), ENT_QUOTES);
        $lines = [];
        foreach ($values as $value) {
            $lines[] = $value['label'] . ': ' . ($value['value'] !== '' ? $value['value'] : '—');
        }
        $lines[] = '';
        $lines[] = sprintf(__('Sent from %s', 'pagecraft-builder'), $pageUrl);
        $lines[] = sprintf(__('All entries: %s', 'pagecraft-builder'), admin_url('admin.php?page=pagecraft-submissions&entry=' . $entryId));
        $headers = [];
        foreach ($values as $value) {
            if ($value['type'] === 'email' && is_email($value['value'])) {
                $headers[] = 'Reply-To: ' . sanitize_email($value['value']);
                break;
            }
        }
        wp_mail(
            (string) get_option('admin_email'),
            sprintf(__('[%1$s] New entry: %2$s', 'pagecraft-builder'), $site, $label),
            implode("\n", $lines),
            $headers
        );
    }

    /** @return list<array{name:string,label:string,type:string,value:string}> */
    public static function fields(int $entryId): array
    {
        $decoded = json_decode((string) get_post_meta($entryId, self::FIELDS, true), true);
        if (!is_array($decoded)) return [];
        $fields = [];
        foreach ($decoded as $field) {
            if (!is_array($field)) continue;
            $fields[] = [
                'name' => (string) ($field['name'] ?? ''),
                'label' => (string) ($field['label'] ?? ''),
                'type' => (string) ($field['type'] ?? 'text'),
                'value' => (string) ($field['value'] ?? ''),
            ];
        }
        return $fields;
    }

    public static function unreadCount(): int
    {
        $query = new \WP_Query([
            'post_type' => self::POST_TYPE,
            'post_status' => 'private',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'no_found_rows' => false,
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Small private inbox.
            'meta_query' => [
                ['key' => self::UNREAD, 'value' => '1'],
                ['key' => self::SPAM, 'value' => '0'],
            ],
        ]);
        return (int) $query->found_posts;
    }

    /** @param array<string, array<string, mixed>> $exporters @return array<string, array<string, mixed>> */
    public static function registerExporter(array $exporters): array
    {
        $exporters['pagecraft-form-entries'] = [
            'exporter_friendly_name' => __('Pagecraft form entries', 'pagecraft-builder'),
            'callback' => [self::class, 'exportPersonalData'],
        ];
        return $exporters;
    }

    /** @param array<string, array<string, mixed>> $erasers @return array<string, array<string, mixed>> */
    public static function registerEraser(array $erasers): array
    {
        $erasers['pagecraft-form-entries'] = [
            'eraser_friendly_name' => __('Pagecraft form entries', 'pagecraft-builder'),
            'callback' => [self::class, 'erasePersonalData'],
        ];
        return $erasers;
    }

    /** Every entry whose email field matches, scanned in batches. @return list<int> */
    private static function entriesForEmail(string $email): array
    {
        $email = strtolower(trim($email));
        if ($email === '' || !is_email($email)) return [];
        $matches = [];
        for ($page = 1; ; $page++) {
            $ids = get_posts([
                'post_type' => self::POST_TYPE,
                'post_status' => 'private',
                'posts_per_page' => 200,
                'paged' => $page,
                'fields' => 'ids',
                'orderby' => 'ID',
                'order' => 'ASC',
            ]);
            foreach ($ids as $id) {
                foreach (self::fields((int) $id) as $field) {
                    if ($field['type'] === 'email' && strtolower($field['value']) === $email) {
                        $matches[] = (int) $id;
                        break;
                    }
                }
            }
            if (count($ids) < 200) break;
        }
        return $matches;
    }

    /** @return array{data:list<array<string,mixed>>,done:bool} */
    public static function exportPersonalData(string $email, int $page = 1): array
    {
        $data = [];
        foreach (self::entriesForEmail($email) as $id) {
            $items = [['name' => __('Form', 'pagecraft-builder'), 'value' => (string) get_post_meta($id, self::FORM_LABEL, true)]];
            foreach (self::fields($id) as $field) {
                $items[] = ['name' => $field['label'], 'value' => $field['value']];
            }
            $data[] = ['group_id' => 'pagecraft-form-entries', 'group_label' => __('Pagecraft form entries', 'pagecraft-builder'),
                'item_id' => 'pagecraft-entry-' . $id, 'data' => $items];
        }
        return ['data' => $data, 'done' => true];
    }

    /** @return array{items_removed:bool,items_retained:bool,messages:list<string>,done:bool} */
    public static function erasePersonalData(string $email, int $page = 1): array
    {
        $removed = false;
        foreach (self::entriesForEmail($email) as $id) {
            $removed = (bool) wp_delete_post($id, true) || $removed;
        }
        return ['items_removed' => $removed, 'items_retained' => false, 'messages' => [], 'done' => true];
    }
}
