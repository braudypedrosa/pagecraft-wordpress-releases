<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Resolves only the current Pagecraft document page to its owning WordPress page. */
final class CurrentPageRoute
{
    /**
     * @param array<string,mixed> $document
     * @return array<string,string>
     */
    public static function routes(int $postId, array $document): array
    {
        try {
            $targetPageId = self::targetPageId($postId, 'page', $document);
        } catch (PackageException) {
            return [];
        }
        $pages = $document['pages'] ?? null;
        if (!is_array($pages)) {
            return [];
        }
        $slug = '';
        $matches = 0;
        foreach ($pages as $page) {
            if (!is_array($page) || !is_string($page['id'] ?? null) || trim($page['id']) === '') {
                return [];
            }
            if (trim($page['id']) !== $targetPageId) {
                continue;
            }
            if (!is_string($page['slug'] ?? null)) {
                return [];
            }
            $matches++;
            $slug = trim($page['slug']);
        }
        $permalink = function_exists('get_permalink') ? get_permalink($postId) : false;
        if ($matches !== 1 || $slug === '' || !is_string($permalink) || $permalink === '') {
            return [];
        }
        foreach ($pages as $page) {
            if (trim($page['id']) !== $targetPageId
                && is_string($page['slug'] ?? null) && trim($page['slug']) === $slug) {
                return [];
            }
        }
        return [$slug => $permalink];
    }

    /** @param array<string,mixed> $document */
    public static function targetPageId(int $postId, string $type, array $document): string
    {
        $pages = is_array($document['pages'] ?? null) ? $document['pages'] : [];
        $pageIds = [];
        foreach ($pages as $index => $page) {
            $pageId = is_array($page) && is_string($page['id'] ?? null) ? trim($page['id']) : '';
            if ($pageId !== '') {
                $pageIds[(int) $index] = $pageId;
            }
        }
        $sourcePageId = $type === 'page'
            ? (string) get_post_meta($postId, ManagedPage::SOURCE_PAGE_ID, true)
            : '';
        if ($sourcePageId !== '' && in_array($sourcePageId, $pageIds, true)) {
            return $sourcePageId;
        }
        $current = filter_var($document['cur'] ?? null, FILTER_VALIDATE_INT);
        if ($current !== false && isset($pageIds[$current])) {
            return $pageIds[$current];
        }
        if (count($pageIds) === 1) {
            return (string) reset($pageIds);
        }
        throw new PackageException('The Pagecraft render target page is missing or ambiguous.');
    }
}
