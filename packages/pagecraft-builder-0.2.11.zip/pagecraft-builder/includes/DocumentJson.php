<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Restore schema-defined object maps after WordPress associative JSON decoding.
 * Keep internal PHP documents as arrays; apply only at serialization boundaries.
 */
final class DocumentJson
{
    /** @param array<string,mixed> $document */
    public static function encode(array $document): string
    {
        return CanonicalJson::encode(self::document($document));
    }

    /** @param array<string,mixed> $document @return array<string,mixed> */
    public static function document(array $document): array
    {
        foreach (['header', 'footer'] as $key) {
            if (isset($document[$key]) && is_array($document[$key])) {
                $document[$key] = array_map(self::node(...), $document[$key]);
            }
        }
        foreach ($document['pages'] ?? [] as $index => $page) {
            if (isset($page['tree']) && is_array($page['tree'])) {
                $document['pages'][$index]['tree'] = array_map(self::node(...), $page['tree']);
            }
        }
        if (isset($document['meta']) && is_array($document['meta'])) {
            $document['meta'] = self::design($document['meta']);
            foreach (['blocks', 'components'] as $key) {
                foreach ($document['meta'][$key] ?? [] as $index => $entry) {
                    if (isset($entry['node']) && is_array($entry['node'])) {
                        $document['meta'][$key][$index]['node'] = self::node($entry['node']);
                    }
                    foreach ($entry['variants'] ?? [] as $variant => $value) {
                        $document['meta'][$key][$index]['variants'][$variant] = self::maps($value, ['values']);
                    }
                }
            }
            foreach ($document['meta']['collections'] ?? [] as $index => $collection) {
                foreach ($collection['items'] ?? [] as $item => $value) {
                    $document['meta']['collections'][$index]['items'][$item] = self::maps($value, ['values']);
                }
            }
        }
        return $document;
    }

    /** @param array<string,mixed> $design @return array<string,mixed> */
    public static function design(array $design): array
    {
        foreach (['text', 'classes'] as $key) {
            foreach ($design['tokens'][$key] ?? [] as $index => $style) {
                $design['tokens'][$key][$index] = self::styles($style);
            }
        }
        return $design;
    }

    /** @param array<string,mixed> $node @return array<string,mixed> */
    private static function node(array $node): array
    {
        $node = self::maps(self::styles($node), ['props', 'hide', 'adv', 'anim', 'bind', 'vals', 'showIf']);
        if (isset($node['children']) && is_array($node['children'])) {
            $node['children'] = array_map(self::node(...), $node['children']);
        }
        return $node;
    }

    /** @param array<string,mixed> $value @return array<string,mixed> */
    private static function styles(array $value): array
    {
        if (isset($value['css']) && is_array($value['css'])) {
            $value['css'] = (object) self::maps($value['css'], ['d', 't', 'm']);
        }
        if (isset($value['st']) && is_array($value['st'])) {
            foreach ($value['st'] as $state => $css) {
                if (is_array($css)) {
                    $value['st'][$state] = (object) self::maps($css, ['d', 't', 'm']);
                }
            }
            $value['st'] = (object) $value['st'];
        }
        return $value;
    }

    /** @param array<string,mixed> $value @param list<string> $keys @return array<string,mixed> */
    private static function maps(array $value, array $keys): array
    {
        foreach ($keys as $key) {
            if (isset($value[$key]) && is_array($value[$key])) {
                $value[$key] = (object) $value[$key];
            }
        }
        return $value;
    }
}
