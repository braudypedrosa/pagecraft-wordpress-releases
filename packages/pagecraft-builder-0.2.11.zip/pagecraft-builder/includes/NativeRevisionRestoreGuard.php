<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Keeps managed documents on Pagecraft's coherent, versioned restore path. */
final class NativeRevisionRestoreGuard
{
    public function register(): void
    {
        add_filter('wp_prepare_revision_for_js', [$this, 'filterRevisionData'], 10, 3);
        add_action('load-revision.php', [$this, 'guardRestoreRequest']);
    }

    /** @param array<string,mixed> $data @return array<string,mixed> */
    public function filterRevisionData(array $data, \WP_Post $revision, \WP_Post $post): array
    {
        if ($this->isManaged((int) $post->ID)) {
            $data['restoreUrl'] = false;
        }
        return $data;
    }

    public function guardRestoreRequest(): void
    {
        $action = isset($_REQUEST['action']) && is_scalar($_REQUEST['action'])
            ? sanitize_key(wp_unslash((string) $_REQUEST['action']))
            : '';
        $revisionId = isset($_REQUEST['revision']) && is_scalar($_REQUEST['revision'])
            ? absint($_REQUEST['revision'])
            : 0;
        if ($action !== 'restore' || $revisionId <= 0) {
            return;
        }
        $revision = wp_get_post_revision($revisionId);
        if (!$revision instanceof \WP_Post || !$this->isManaged((int) $revision->post_parent)) {
            return;
        }

        $postId = (int) $revision->post_parent;
        if (!current_user_can('edit_post', $postId)) {
            return;
        }
        check_admin_referer('restore-post_' . $revisionId);
        $query = get_post_type($postId) === GlobalElement::POST_TYPE
            ? 'admin.php?page=' . Admin::EDITOR_SLUG . '&global=' . $postId
            : 'admin.php?page=' . Admin::EDITOR_SLUG . '&post=' . $postId;
        $historyUrl = admin_url($query);
        wp_die(
            wp_kses_post(sprintf(
                /* translators: %s: link to the Pagecraft editor history. */
                __('Open Pagecraft, then choose Version history to restore this document safely. <a href="%s">Open Pagecraft</a>.', 'pagecraft-builder'),
                esc_url($historyUrl)
            )),
            esc_html__('Use Pagecraft History', 'pagecraft-builder'),
            ['response' => 409, 'back_link' => true]
        );
    }

    private function isManaged(int $postId): bool
    {
        if (ManagedPage::isManaged($postId)) {
            return true;
        }
        return $postId > 0
            && get_post_type($postId) === GlobalElement::POST_TYPE
            && get_post_meta($postId, GlobalElement::DOCUMENT, true) !== '';
    }
}
