<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Selects the recoverable Pagecraft snapshot for each editor version.
 *
 * WordPress may retain transition revisions whose post content was written before
 * Pagecraft updated its revisioned metadata. Those rows remain in WordPress, but
 * they are not safe Pagecraft restore targets because their document and compiled
 * HTML describe different versions.
 */
final class EditorRevisionSnapshots
{
    public const QUERY_LIMIT = 100;

    public function __construct(
        private readonly string $documentKey,
        private readonly string $versionKey,
        private readonly string $compiledHashKey
    ) {
    }

    /** @return array{snapshots:list<\WP_Post>,hasUnverifiedHistory:bool} */
    public function selectForPost(int $postId, int $currentVersion): array
    {
        $snapshots = [];
        $seen = [];
        $unverifiedVersions = [];
        foreach ($this->revisions($postId) as $revision) {
            $id = (int) $revision->ID;
            if (function_exists('wp_is_post_autosave') && wp_is_post_autosave($id) !== false) {
                continue;
            }
            $version = (int) get_post_meta($id, $this->versionKey, true);
            if ($version <= 0 || $version >= $currentVersion || isset($seen[$version])) {
                continue;
            }
            if (!$this->hasValidDocument($id)) {
                continue;
            }
            $compiledHash = get_post_meta($id, $this->compiledHashKey, true);
            if (!is_string($compiledHash) || preg_match('/^[a-f0-9]{64}$/D', $compiledHash) !== 1) {
                $unverifiedVersions[$version] = true;
                continue;
            }
            if (!hash_equals($compiledHash, hash('sha256', (string) $revision->post_content))) {
                continue;
            }
            $seen[$version] = true;
            unset($unverifiedVersions[$version]);
            $snapshots[] = $revision;
        }
        return ['snapshots' => $snapshots, 'hasUnverifiedHistory' => $unverifiedVersions !== []];
    }

    /** @return list<\WP_Post> */
    public function forPost(int $postId, int $currentVersion): array
    {
        return $this->selectForPost($postId, $currentVersion)['snapshots'];
    }

    public function forVersion(int $postId, int $currentVersion, int $version): ?\WP_Post
    {
        foreach ($this->forPost($postId, $currentVersion) as $revision) {
            if ((int) get_post_meta((int) $revision->ID, $this->versionKey, true) === $version) {
                return $revision;
            }
        }
        return null;
    }

    /** @return list<\WP_Post> */
    private function revisions(int $postId): array
    {
        $rows = wp_get_post_revisions($postId, [
            'posts_per_page' => self::QUERY_LIMIT,
            'check_enabled' => false,
        ]);
        return array_values(array_filter($rows, static fn (mixed $row): bool => $row instanceof \WP_Post));
    }

    private function hasValidDocument(int $revisionId): bool
    {
        $document = get_post_meta($revisionId, $this->documentKey, true);
        if (!is_string($document) || $document === '') {
            return false;
        }
        try {
            $decoded = json_decode($document, true, 512, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            return false;
        }
        if (!is_array($decoded)) {
            return false;
        }
        $schemaVersion = filter_var($decoded['schemaVersion'] ?? $decoded['v'] ?? null, FILTER_VALIDATE_INT);
        if ($schemaVersion === false || $schemaVersion <= 0) {
            return false;
        }
        return true;
    }
}
