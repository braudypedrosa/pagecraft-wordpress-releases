<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Pagecraft → Submissions: the WordPress inbox for Pagecraft form entries. */
final class SubmissionsScreen
{
    public const SLUG = 'pagecraft-submissions';
    private const PER_PAGE = 50;

    public static function register(): void
    {
        add_action('admin_post_pagecraft_entry_action', [self::class, 'entryAction']);
        add_action('admin_post_pagecraft_entries_export', [self::class, 'export']);
        add_action('admin_post_pagecraft_form_settings', [self::class, 'saveSettings']);
        // admin_menu runs before admin_init, so clear the flag ahead of Admin::menus() counting it.
        add_action('admin_menu', [self::class, 'markOpenedEntryRead'], 1);
    }

    /** Mark an opened entry read before the admin menu draws its unread count. */
    public static function markOpenedEntryRead(): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Viewing an entry only clears its unread flag.
        if (!isset($_GET['page'], $_GET['entry']) || sanitize_key(wp_unslash((string) $_GET['page'])) !== self::SLUG) {
            return;
        }
        $entryId = absint($_GET['entry']);
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        if ($entryId > 0 && current_user_can(Capabilities::MANAGE) && get_post_type($entryId) === FormSubmissions::POST_TYPE) {
            update_post_meta($entryId, FormSubmissions::UNREAD, '0');
        }
    }

    public static function url(array $args = []): string
    {
        return add_query_arg(array_merge(['page' => self::SLUG], $args), admin_url('admin.php'));
    }

    /** The entry being viewed, or 0 for the inbox. */
    private static function currentEntry(): int
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation.
        $entryId = absint($_GET['entry'] ?? 0);
        return $entryId > 0 && get_post_type($entryId) === FormSubmissions::POST_TYPE ? $entryId : 0;
    }

    /**
     * What the screen header shows: the inbox, or the entry that is open.
     *
     * @return array{title:string,description:string,options:array<string,mixed>}
     */
    public static function header(): array
    {
        $entryId = self::currentEntry();
        $entry = $entryId > 0 ? get_post($entryId) : null;
        if (!$entry instanceof \WP_Post) {
            return [
                'title' => __('Submissions', 'pagecraft-builder'),
                'description' => __('Entries from Pagecraft forms on this site. They are stored in WordPress and never sent to Pagecraft Cloud.', 'pagecraft-builder'),
                'options' => ['actions' => static function (): void {
                    self::notifySwitch();
                    echo '<a class="button" href="'
                        . esc_url(wp_nonce_url(admin_url('admin-post.php?action=pagecraft_entries_export'), 'pagecraft_entries_export'))
                        . '">' . esc_html__('Export CSV', 'pagecraft-builder') . '</a>';
                }],
            ];
        }
        $spam = get_post_meta($entryId, FormSubmissions::SPAM, true) === '1';
        $from = FormSubmissions::summary(FormSubmissions::fields($entryId));
        $received = sprintf(
            /* translators: %s: date and time */
            __('Received %s', 'pagecraft-builder'),
            self::date($entry)
        );
        return [
            'title' => (string) get_post_meta($entryId, FormSubmissions::FORM_LABEL, true),
            'description' => $from !== ''
                /* translators: 1: sender, 2: "Received <date>" */
                ? sprintf(__('From %1$s · %2$s', 'pagecraft-builder'), $from, $received)
                : $received,
            'options' => [
                'classes' => 'pagecraft-entry-screen',
                'badge' => $spam ? __('In Spam', 'pagecraft-builder') : '',
                'badgeState' => 'bad',
                'before' => static function () use ($spam): void {
                    echo '<p class="pagecraft-crumb"><a href="' . esc_url(self::url($spam ? ['view' => 'spam'] : [])) . '">← '
                        . esc_html($spam ? __('Back to Spam', 'pagecraft-builder') : __('Back to entries', 'pagecraft-builder')) . '</a></p>';
                },
                'actions' => static function () use ($entryId, $spam): void {
                    self::actionButton($entryId, $spam ? 'not_spam' : 'spam', $spam ? __('Not spam', 'pagecraft-builder') : __('Mark as spam', 'pagecraft-builder'), 'button');
                    self::actionButton($entryId, 'delete', __('Delete permanently', 'pagecraft-builder'), 'button button-link-delete');
                },
            ],
        ];
    }

    public static function render(): void
    {
        // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only inbox filters.
        $view = isset($_GET['view']) && sanitize_key(wp_unslash((string) $_GET['view'])) === 'spam' ? 'spam' : 'inbox';
        $form = isset($_GET['form']) ? preg_replace('/[^A-Za-z0-9_-]/', '', sanitize_text_field(wp_unslash((string) $_GET['form']))) ?? '' : '';
        $paged = max(1, absint($_GET['paged'] ?? 1));
        $message = isset($_GET['pagecraft_message']) ? sanitize_key(wp_unslash((string) $_GET['pagecraft_message'])) : '';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended
        $notice = match ($message) {
            'spam' => __('Entry moved to Spam.', 'pagecraft-builder'),
            'not_spam' => __('Entry moved to the inbox.', 'pagecraft-builder'),
            'deleted' => __('Entry deleted.', 'pagecraft-builder'),
            'settings' => __('Submission settings saved.', 'pagecraft-builder'),
            default => '',
        };
        if ($notice !== '') {
            echo '<div class="pagecraft-toast pagecraft-toast--success" role="status"><p>' . esc_html($notice) . '</p></div>';
        }
        $entryId = self::currentEntry();
        if ($entryId > 0) {
            self::detail($entryId);
            return;
        }
        self::inbox($view, $form, $paged);
    }

    private static function inbox(string $view, string $form, int $paged): void
    {
        $meta = [['key' => FormSubmissions::SPAM, 'value' => $view === 'spam' ? '1' : '0']];
        if ($form !== '') {
            $meta[] = ['key' => FormSubmissions::FORM, 'value' => $form];
        }
        $query = new \WP_Query([
            'post_type' => FormSubmissions::POST_TYPE,
            'post_status' => 'private',
            'posts_per_page' => self::PER_PAGE,
            'paged' => $paged,
            'orderby' => 'date',
            'order' => 'DESC',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Small private inbox.
            'meta_query' => $meta,
        ]);
        $spamCount = self::count(true);
        $inboxCount = self::count(false);
        $forms = self::forms();

        // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- viewLink() escapes every part.
        echo '<section class="pagecraft-entries" aria-label="' . esc_attr($view === 'spam' ? __('Spam', 'pagecraft-builder') : __('Entries', 'pagecraft-builder')) . '">'
            . '<div class="pagecraft-toolbar"><nav class="pagecraft-entries__views" aria-label="' . esc_attr__('Entry views', 'pagecraft-builder') . '">'
            . self::viewLink(__('Inbox', 'pagecraft-builder'), $inboxCount, self::url($form !== '' ? ['form' => $form] : []), $view === 'inbox')
            . self::viewLink(__('Spam', 'pagecraft-builder'), $spamCount, self::url(array_merge(['view' => 'spam'], $form !== '' ? ['form' => $form] : [])), $view === 'spam')
            . '</nav>';
        // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
        if ($forms !== []) {
            echo '<form class="pagecraft-entries__filter" method="get" action="' . esc_url(admin_url('admin.php')) . '" data-pagecraft-autosubmit>'
                . '<input type="hidden" name="page" value="' . esc_attr(self::SLUG) . '">'
                . ($view === 'spam' ? '<input type="hidden" name="view" value="spam">' : '')
                . '<label class="screen-reader-text" for="pagecraft-entries-form">' . esc_html__('Form', 'pagecraft-builder') . '</label>'
                . '<select id="pagecraft-entries-form" name="form"><option value="">' . esc_html__('All forms', 'pagecraft-builder') . '</option>';
            foreach ($forms as $formId => $label) {
                echo '<option value="' . esc_attr($formId) . '"' . selected($form, $formId, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select><noscript><button class="button">' . esc_html__('Filter', 'pagecraft-builder') . '</button></noscript></form>';
        }
        $unread = $view === 'inbox' && $form === '' ? FormSubmissions::unreadCount() : 0;
        if ($unread > 0) {
            echo '<span class="pagecraft-toolbar__facts">' . esc_html(sprintf(
                /* translators: %d: number of unread entries */
                _n('%d unread', '%d unread', $unread, 'pagecraft-builder'),
                $unread
            )) . '</span>';
        }
        echo '</div>';

        if (!$query->have_posts()) {
            echo '<div class="pagecraft-empty pagecraft-entries__empty"><strong>'
                . esc_html($view === 'spam' ? __('No spam.', 'pagecraft-builder') : __('No entries yet.', 'pagecraft-builder'))
                . '</strong>' . ($view === 'spam' ? '' : '<p>'
                . esc_html__('When someone sends a Pagecraft form on this site, their message appears here.', 'pagecraft-builder')
                . '</p>') . '</div>';
            self::deliveryNote();
            echo '</section>';
            return;
        }

        echo '<div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-entries__table"><thead><tr><th scope="col">'
            . esc_html__('From', 'pagecraft-builder') . '</th><th scope="col">' . esc_html__('Form', 'pagecraft-builder')
            . '</th><th scope="col" class="pagecraft-table__wide-only">' . esc_html__('Page', 'pagecraft-builder') . '</th><th scope="col">'
            . esc_html__('Received', 'pagecraft-builder') . '</th><th scope="col" class="pagecraft-table__end"><span class="screen-reader-text">'
            . esc_html__('Actions', 'pagecraft-builder') . '</span></th></tr></thead><tbody>';
        $lastDay = '';
        foreach ($query->posts as $entry) {
            if (!$entry instanceof \WP_Post) continue;
            $day = self::dayLabel($entry);
            if ($day !== $lastDay) {
                echo '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="5">' . esc_html($day) . '</th></tr>';
                $lastDay = $day;
            }
            self::row($entry, $view === 'spam');
        }
        echo '</tbody></table></div>';
        $pages = (int) $query->max_num_pages;
        if ($pages > 1) {
            echo '<p class="pagecraft-entries__pages">' . wp_kses_post((string) paginate_links([
                'base' => add_query_arg('paged', '%#%'),
                'format' => '',
                'current' => $paged,
                'total' => $pages,
            ])) . '</p>';
        }
        self::deliveryNote();
        echo '</section>';
    }

    private static function row(\WP_Post $entry, bool $spam): void
    {
        $fields = FormSubmissions::fields($entry->ID);
        $from = FormSubmissions::summary($fields);
        $name = $from !== '' ? $from : __('Entry', 'pagecraft-builder') . ' #' . $entry->ID;
        $excerpt = self::excerpt($fields);
        $unread = get_post_meta($entry->ID, FormSubmissions::UNREAD, true) === '1';
        $pageUrl = (string) get_post_meta($entry->ID, FormSubmissions::PAGE_URL, true);
        $path = (string) wp_parse_url($pageUrl, PHP_URL_PATH);
        $today = self::dayLabel($entry) !== __('Earlier', 'pagecraft-builder');
        echo '<tr' . ($unread ? ' class="is-unread"' : '') . '><td class="pagecraft-entries__from"><span class="pagecraft-entries__dot" aria-hidden="true"></span><a class="row-title" href="'
            . esc_url(self::url(['entry' => $entry->ID])) . '">' . esc_html($name) . '</a>'
            . ($unread ? ' <span class="pagecraft-status pagecraft-status--ready screen-reader-text">' . esc_html__('New', 'pagecraft-builder') . '</span>' : '')
            . ($excerpt !== '' ? ' <span class="pagecraft-entries__excerpt">' . esc_html($excerpt) . '</span>' : '')
            . '</td><td>' . esc_html((string) get_post_meta($entry->ID, FormSubmissions::FORM_LABEL, true))
            . '</td><td class="pagecraft-table__wide-only">' . ($pageUrl !== '' ? '<a href="' . esc_url($pageUrl) . '">' . esc_html($path !== '' ? $path : $pageUrl) . '</a>' : '—')
            . '</td><td class="pagecraft-entries__date pagecraft-table__muted">'
            . esc_html($today ? (string) get_the_date((string) get_option('time_format'), $entry) : self::date($entry))
            . '</td><td class="pagecraft-table__end"><details class="pagecraft-more"><summary aria-label="'
            /* translators: %s: who sent the entry */
            . esc_attr(sprintf(__('Actions for the entry from %s', 'pagecraft-builder'), $name)) . '"><span aria-hidden="true">⋯</span></summary><div class="pagecraft-more__menu">'
            . '<a href="' . esc_url(self::url(['entry' => $entry->ID])) . '">' . esc_html__('Open entry', 'pagecraft-builder') . '</a>';
        self::actionButton($entry->ID, $spam ? 'not_spam' : 'spam', $spam ? __('Not spam', 'pagecraft-builder') : __('Mark as spam', 'pagecraft-builder'), '');
        self::actionButton($entry->ID, 'delete', __('Delete permanently', 'pagecraft-builder'), 'pagecraft-more__danger');
        echo '</div></details></td></tr>';
    }

    /** Today, Yesterday or Earlier, in the site's own timezone. */
    private static function dayLabel(\WP_Post $entry): string
    {
        $day = (string) get_the_date('Y-m-d', $entry);
        $now = current_datetime();
        if ($day === $now->format('Y-m-d')) return __('Today', 'pagecraft-builder');
        if ($day === $now->modify('-1 day')->format('Y-m-d')) return __('Yesterday', 'pagecraft-builder');
        return __('Earlier', 'pagecraft-builder');
    }

    /** The three newest unread entries, as rows for the Overview table. */
    public static function newestUnreadRows(int $limit): void
    {
        $query = new \WP_Query([
            'post_type' => FormSubmissions::POST_TYPE,
            'post_status' => 'private',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Small private inbox.
            'meta_query' => [
                ['key' => FormSubmissions::SPAM, 'value' => '0'],
                ['key' => FormSubmissions::UNREAD, 'value' => '1'],
            ],
        ]);
        foreach ($query->posts as $entry) {
            if (!$entry instanceof \WP_Post) continue;
            $fields = FormSubmissions::fields($entry->ID);
            $from = FormSubmissions::summary($fields);
            $excerpt = self::excerpt($fields);
            echo '<tr><th scope="row" class="pagecraft-table__key"><a href="' . esc_url(self::url(['entry' => $entry->ID])) . '">'
                . esc_html($from !== '' ? $from : __('Entry', 'pagecraft-builder') . ' #' . $entry->ID) . '</a></th><td>'
                . esc_html($excerpt !== '' ? $excerpt : (string) get_post_meta($entry->ID, FormSubmissions::FORM_LABEL, true))
                . '</td><td class="pagecraft-table__end pagecraft-table__muted">' . esc_html(self::date($entry)) . '</td></tr>';
        }
    }

    private static function viewLink(string $label, ?int $count, string $url, bool $current): string
    {
        return '<a href="' . esc_url($url) . '" class="pagecraft-chip pagecraft-entries__view' . ($current ? ' is-current is-active' : '') . '"'
            . ($current ? ' aria-current="page"' : '') . '>' . esc_html($label)
            . ($count !== null ? '<span class="pagecraft-chip__count count">' . esc_html(number_format_i18n($count)) . '</span>' : '') . '</a>';
    }

    private static function detail(int $entryId): void
    {
        $entry = get_post($entryId);
        if (!$entry instanceof \WP_Post) return;
        $spam = get_post_meta($entryId, FormSubmissions::SPAM, true) === '1';
        $pageUrl = (string) get_post_meta($entryId, FormSubmissions::PAGE_URL, true);
        echo '<section class="pagecraft-entry"><div class="pagecraft-table-scroll"><table class="pagecraft-table pagecraft-table--facts pagecraft-entry__fields"><tbody>'
            . '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="2">' . esc_html__('Answers', 'pagecraft-builder') . '</th></tr>';
        foreach (FormSubmissions::fields($entryId) as $field) {
            $value = $field['value'] !== '' ? $field['value'] : '—';
            echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html($field['label']) . '</th><td>'
                . ($field['type'] === 'email' && is_email($field['value'])
                    ? '<a href="' . esc_url('mailto:' . $field['value']) . '">' . esc_html($value) . '</a>'
                    : nl2br(esc_html($value)))
                . '</td></tr>';
        }
        echo '<tr class="pagecraft-table__band"><th scope="colgroup" colspan="2">' . esc_html__('Details', 'pagecraft-builder') . '</th></tr>'
            . '<tr><th scope="row" class="pagecraft-table__key">' . esc_html__('Form', 'pagecraft-builder') . '</th><td>'
            . esc_html((string) get_post_meta($entryId, FormSubmissions::FORM_LABEL, true)) . '</td></tr>';
        if ($pageUrl !== '') {
            echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html__('Sent from', 'pagecraft-builder') . '</th><td><a href="'
                . esc_url($pageUrl) . '">' . esc_html($pageUrl) . '</a></td></tr>';
        }
        echo '<tr><th scope="row" class="pagecraft-table__key">' . esc_html__('Received', 'pagecraft-builder') . '</th><td>' . esc_html(self::date($entry)) . '</td></tr>'
            . '<tr><th scope="row" class="pagecraft-table__key">' . esc_html__('Status', 'pagecraft-builder') . '</th><td>'
            . esc_html($spam ? __('Spam', 'pagecraft-builder') : __('Inbox', 'pagecraft-builder')) . '</td></tr></tbody></table></div></section>';
    }

    private static function actionButton(int $entryId, string $operation, string $label, string $class): void
    {
        // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts plus WordPress's own nonce field.
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'
            . '<input type="hidden" name="action" value="pagecraft_entry_action">'
            . '<input type="hidden" name="entry" value="' . esc_attr((string) $entryId) . '">'
            . '<input type="hidden" name="operation" value="' . esc_attr($operation) . '">'
            . wp_nonce_field('pagecraft_entry_' . $entryId, '_wpnonce', true, false)
            . '<button type="submit"' . ($class !== '' ? ' class="' . esc_attr($class) . '"' : '')
            . ($operation === 'delete' ? ' onclick="return window.confirm(this.dataset.confirm)" data-confirm="' . esc_attr__('Delete this entry permanently? This cannot be undone.', 'pagecraft-builder') . '"' : '')
            . '>' . esc_html($label) . '</button></form>';
        // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    /** The notification setting as a switch. It saves when changed; without JavaScript it has a Save button. */
    private static function notifySwitch(): void
    {
        // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts plus WordPress's nonce field and checked().
        echo '<form class="pagecraft-entries__notify" method="post" action="' . esc_url(admin_url('admin-post.php')) . '" data-pagecraft-autosubmit>'
            . '<input type="hidden" name="action" value="pagecraft_form_settings">'
            . wp_nonce_field('pagecraft_form_settings', '_wpnonce', true, false)
            . '<label class="pagecraft-switch"><input type="checkbox" name="notify" value="1"' . checked(FormSubmissions::notifyEnabled(), true, false) . '>'
            . '<span class="pagecraft-switch__track" aria-hidden="true"></span><span>'
            . esc_html__('Email me when a new entry arrives', 'pagecraft-builder') . '</span></label>'
            . '<noscript><button type="submit" class="button">' . esc_html__('Save', 'pagecraft-builder') . '</button></noscript></form>';
        // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    private static function deliveryNote(): void
    {
        echo '<p class="pagecraft-footnote">' . esc_html(FormSubmissions::notifyEnabled()
            ? sprintf(
                /* translators: %s: email address */
                __('New entries are emailed to %s using WordPress mail. On many hosts that mail lands in spam; an SMTP plugin makes delivery reliable.', 'pagecraft-builder'),
                (string) get_option('admin_email')
            )
            : __('Email notifications are off.', 'pagecraft-builder')) . '</p>';
    }

    private static function count(bool $spam): int
    {
        $query = new \WP_Query([
            'post_type' => FormSubmissions::POST_TYPE,
            'post_status' => 'private',
            'posts_per_page' => 1,
            'fields' => 'ids',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Small private inbox.
            'meta_query' => [['key' => FormSubmissions::SPAM, 'value' => $spam ? '1' : '0']],
        ]);
        return (int) $query->found_posts;
    }

    /** @return array<string,string> form id => label, for forms that have entries */
    private static function forms(): array
    {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One grouped read of private inbox metadata.
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT f.meta_value AS form_id, MAX(l.meta_value) AS label FROM {$wpdb->postmeta} f
             JOIN {$wpdb->posts} p ON p.ID = f.post_id AND p.post_type = %s
             LEFT JOIN {$wpdb->postmeta} l ON l.post_id = f.post_id AND l.meta_key = %s
             WHERE f.meta_key = %s GROUP BY f.meta_value ORDER BY label LIMIT 20",
            FormSubmissions::POST_TYPE,
            FormSubmissions::FORM_LABEL,
            FormSubmissions::FORM
        ));
        $forms = [];
        foreach ((array) $rows as $row) {
            $forms[(string) $row->form_id] = (string) $row->label;
        }
        return count($forms) > 1 ? $forms : [];
    }

    /** @param list<array{name:string,label:string,type:string,value:string}> $fields */
    private static function excerpt(array $fields): string
    {
        foreach ($fields as $field) {
            if ($field['type'] === 'textarea' && trim($field['value']) !== '') {
                return mb_strimwidth(preg_replace('/\s+/', ' ', $field['value']) ?? '', 0, 90, '…');
            }
        }
        return '';
    }

    private static function date(\WP_Post $entry): string
    {
        return (string) get_the_date(get_option('date_format') . ' ' . get_option('time_format'), $entry);
    }

    public static function entryAction(): void
    {
        $entryId = absint($_POST['entry'] ?? 0);
        check_admin_referer('pagecraft_entry_' . $entryId);
        self::guard();
        if (get_post_type($entryId) !== FormSubmissions::POST_TYPE) {
            wp_die(esc_html__('That entry no longer exists.', 'pagecraft-builder'), '', ['response' => 404]);
        }
        $operation = sanitize_key(wp_unslash((string) ($_POST['operation'] ?? '')));
        if ($operation === 'delete') {
            wp_delete_post($entryId, true);
            wp_safe_redirect(self::url(['pagecraft_message' => 'deleted']));
            exit;
        }
        if (in_array($operation, ['spam', 'not_spam'], true)) {
            update_post_meta($entryId, FormSubmissions::SPAM, $operation === 'spam' ? '1' : '0');
            wp_safe_redirect(self::url(['pagecraft_message' => $operation]));
            exit;
        }
        wp_die(esc_html__('Unknown entry action.', 'pagecraft-builder'), '', ['response' => 400]);
    }

    public static function saveSettings(): void
    {
        check_admin_referer('pagecraft_form_settings');
        self::guard();
        update_option(FormSubmissions::NOTIFY_OPTION, isset($_POST['notify']) ? '1' : '0', false);
        wp_safe_redirect(self::url(['pagecraft_message' => 'settings']));
        exit;
    }

    public static function export(): void
    {
        check_admin_referer('pagecraft_entries_export');
        self::guard();
        $ids = get_posts([
            'post_type' => FormSubmissions::POST_TYPE,
            'post_status' => 'private',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'orderby' => 'date',
            'order' => 'ASC',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Owner-requested export.
            'meta_query' => [['key' => FormSubmissions::SPAM, 'value' => '0']],
        ]);
        $columns = [];
        $rows = [];
        foreach ($ids as $id) {
            $values = [];
            foreach (FormSubmissions::fields((int) $id) as $field) {
                $columns[$field['label']] = true;
                $values[$field['label']] = $field['value'];
            }
            $rows[] = [
                'received' => (string) get_post_time('c', true, (int) $id),
                'form' => (string) get_post_meta((int) $id, FormSubmissions::FORM_LABEL, true),
                'page' => (string) get_post_meta((int) $id, FormSubmissions::PAGE_URL, true),
                'values' => $values,
            ];
        }
        $labels = array_keys($columns);
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="pagecraft-entries-' . gmdate('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'w'); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Streaming CSV to the response.
        if ($out === false) exit;
        fputcsv($out, array_map([self::class, 'csvCell'], array_merge(
            [__('Received', 'pagecraft-builder'), __('Form', 'pagecraft-builder'), __('Page', 'pagecraft-builder')],
            $labels
        )), ',', '"', '');
        foreach ($rows as $row) {
            $line = [$row['received'], $row['form'], $row['page']];
            foreach ($labels as $label) {
                $line[] = $row['values'][$label] ?? '';
            }
            fputcsv($out, array_map([self::class, 'csvCell'], $line), ',', '"', '');
        }
        fclose($out); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming CSV to the response.
        exit;
    }

    /** Keep spreadsheet apps from running a visitor's text as a formula. */
    public static function csvCell(string $value): string
    {
        return preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value;
    }

    private static function guard(): void
    {
        if (!current_user_can(Capabilities::MANAGE)) {
            wp_die(esc_html__('You are not allowed to manage Pagecraft submissions.', 'pagecraft-builder'), '', ['response' => 403]);
        }
    }
}
