<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** Resolve active Theme Builder records against the current WordPress query. */
final class TemplateResolver
{
    /** @param list<string>|null $kinds */
    public static function current(?array $kinds = null): int
    {
        return self::resolve(self::context(), $kinds);
    }

    /** @param array<string,mixed> $context @param list<string>|null $kinds */
    public static function resolve(array $context, ?array $kinds = null): int
    {
        $kinds ??= GlobalElement::templateKinds();
        $candidates = get_posts([
            'post_type' => GlobalElement::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => 200,
            'orderby' => ['modified' => 'DESC', 'ID' => 'DESC'],
        ]);
        $winner = 0;
        $winnerScore = -1;
        $winnerPriority = PHP_INT_MIN;
        foreach ($candidates as $candidate) {
            $postId = is_object($candidate) ? (int) $candidate->ID : (int) $candidate;
            $kind = (string) get_post_meta($postId, GlobalElement::KIND, true);
            if (!in_array($kind, $kinds, true)) {
                continue;
            }
            $rules = (string) get_post_meta($postId, TemplateConditions::META, true);
            if ($rules === '') {
                if (in_array($kind, ['header', 'footer'], true)) {
                    continue;
                }
                $rules = TemplateConditions::encode(TemplateConditions::defaults($kind));
            }
            $score = TemplateConditions::score($rules, $context);
            $priority = (int) get_post_meta($postId, TemplateConditions::PRIORITY, true);
            if ($score > $winnerScore || ($score === $winnerScore && $priority > $winnerPriority)
                || ($score === $winnerScore && $priority === $winnerPriority && $postId > $winner)) {
                $winner = $postId;
                $winnerScore = $score;
                $winnerPriority = $priority;
            }
        }
        return $winnerScore >= 0 ? $winner : 0;
    }

    /** @return array<string,mixed> */
    public static function context(): array
    {
        $object = get_queried_object();
        $postType = '';
        $taxonomy = '';
        $termId = 0;
        if ($object instanceof \WP_Post) {
            $postType = (string) $object->post_type;
        } elseif ($object instanceof \WP_Term) {
            $taxonomy = (string) $object->taxonomy;
            $termId = (int) $object->term_id;
        }
        if ($postType === '' && is_post_type_archive()) {
            $queried = get_query_var('post_type');
            $postType = is_array($queried) ? (string) reset($queried) : (string) $queried;
        }
        return [
            'is_singular' => is_singular(),
            'post_id' => is_singular() ? (int) get_queried_object_id() : 0,
            'post_type' => $postType,
            'is_archive' => is_archive() || is_home(),
            'is_post_type_archive' => is_post_type_archive(),
            'is_taxonomy' => is_category() || is_tag() || is_tax(),
            'taxonomy' => $taxonomy,
            'term_id' => $termId,
            'is_search' => is_search(),
            'is_404' => is_404(),
        ];
    }
}
