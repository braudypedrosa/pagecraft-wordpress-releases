<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class CompilerContractConflict extends \RuntimeException
{
    /** @param array<string,mixed> $current */
    public function __construct(public readonly array $current)
    {
        parent::__construct('The Pagecraft compiler changed before this output was saved. Reload the editor and save again.');
    }
}
