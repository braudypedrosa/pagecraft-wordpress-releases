<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class Compatibility
{
    public static function status(): string
    {
        $theme = wp_get_theme('pagecraft');
        if (!$theme->exists() || $theme->errors()) return 'missing';
        if (!hash_equals(PAGECRAFT_BUILDER_VERSION, (string) $theme->get('Version'))) return 'version';
        if (get_stylesheet() !== 'pagecraft') return 'inactive';
        return 'ready';
    }

    public static function ready(): bool
    {
        return self::status() === 'ready';
    }

    public static function notice(): void
    {
        $status = self::status();
        if ($status === 'ready') return;
        $message = match ($status) {
            'missing' => __('Pagecraft Builder is blocked because Pagecraft Theme is not installed.', 'pagecraft-builder'),
            'version' => __('Pagecraft Builder is blocked because its Theme version is incompatible.', 'pagecraft-builder'),
            default => __('Pagecraft Builder is blocked until Pagecraft Theme is active.', 'pagecraft-builder'),
        };
        $url = admin_url('tools.php?page=pagecraft-importer');
        echo '<div class="notice notice-error"><p>' . esc_html($message) . ' '
            . wp_kses_post(sprintf(__('<a href="%s">Open Pagecraft Importer</a>.', 'pagecraft-builder'), esc_url($url)))
            . '</p></div>';
    }
}
