<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/** The sealed editor/compiler identity shipped with this Builder package. */
final class CompilerContract
{
    public const FORMAT = 'pagecraft.editor-contract.v1';

    private function __construct(
        public readonly string $editorVersion,
        public readonly int $schemaVersion,
        public readonly string $rendererVersion,
        public readonly string $rendererRevision
    ) {
    }

    public static function current(): self
    {
        $path = defined('PAGECRAFT_EDITOR_CONTRACT_FILE')
            ? (string) PAGECRAFT_EDITOR_CONTRACT_FILE
            : PAGECRAFT_BUILDER_DIR . 'assets/pagecraft-editor-contract.json';
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Trusted local bundled contract, never a remote URL.
        $source = @file_get_contents($path);
        if (!is_string($source) || $source === '') {
            throw new PackageException('The sealed Pagecraft editor/compiler contract is missing.');
        }
        try {
            $value = json_decode($source, true, 32, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new PackageException('The sealed Pagecraft editor/compiler contract is invalid: ' . $error->getMessage());
        }
        if (!is_array($value)) {
            throw new PackageException('The sealed Pagecraft editor/compiler contract is invalid.');
        }
        return self::fromArray($value);
    }

    /** @param array<string,mixed> $value */
    public static function fromArray(array $value): self
    {
        $keys = array_keys($value);
        sort($keys);
        $expected = ['editorVersion', 'format', 'rendererRevision', 'rendererVersion', 'schemaVersion'];
        sort($expected);
        if ($keys !== $expected || ($value['format'] ?? null) !== self::FORMAT) {
            throw new PackageException('The sealed Pagecraft editor/compiler contract has an unsupported shape.');
        }
        $schemaVersion = $value['schemaVersion'] ?? null;
        if (!is_int($schemaVersion) || $schemaVersion <= 0 || $schemaVersion > PageEditor::SCHEMA_VERSION) {
            throw new PackageException('The sealed Pagecraft editor/compiler schema version is unsupported.');
        }
        foreach (['editorVersion', 'rendererVersion', 'rendererRevision'] as $key) {
            if (!is_string($value[$key]) || $value[$key] === '' || strlen($value[$key]) > 191
                || preg_match('/[^A-Za-z0-9._+:-]/', $value[$key])) {
                throw new PackageException('The sealed Pagecraft editor/compiler identity is invalid.');
            }
        }
        return new self(
            $value['editorVersion'],
            $schemaVersion,
            $value['rendererVersion'],
            $value['rendererRevision']
        );
    }

    /** @return array{editorVersion:string,schemaVersion:int,rendererVersion:string,rendererRevision:string} */
    public function payload(): array
    {
        return [
            'editorVersion' => $this->editorVersion,
            'schemaVersion' => $this->schemaVersion,
            'rendererVersion' => $this->rendererVersion,
            'rendererRevision' => $this->rendererRevision,
        ];
    }

    /** @return array{format:string,editorVersion:string,schemaVersion:int,rendererVersion:string,rendererRevision:string} */
    public function sealedPayload(): array
    {
        return ['format' => self::FORMAT] + $this->payload();
    }

    /** @param array<string,mixed> $value */
    public function matchesSealedPayload(array $value): bool
    {
        try {
            $candidate = self::fromArray($value);
        } catch (PackageException) {
            return false;
        }
        return $candidate->payload() === $this->payload();
    }

    /** @return array<string,string> */
    public function provenance(string $documentJson): array
    {
        return [
            ManagedPage::COMPILER_EDITOR_VERSION => $this->editorVersion,
            ManagedPage::COMPILER_RENDERER_REVISION => $this->rendererRevision,
            ManagedPage::COMPILER_DOCUMENT_SHA256 => hash('sha256', $documentJson),
            ManagedPage::COMPILED_AT => gmdate('c'),
        ];
    }
}
