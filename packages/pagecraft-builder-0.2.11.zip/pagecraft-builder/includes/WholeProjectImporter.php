<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class WholeProjectImporter
{
    public const JOB_POST_TYPE = 'pagecraft_import_job';
    public const LINKED_PROJECT = 'pagecraft_linked_cloud_project_v1';

    public static function register(): void
    {
        register_post_status('pc_archived', [
            'label' => __('Archived by Pagecraft', 'pagecraft-builder'),
            'public' => false, 'internal' => false, 'protected' => true,
            'exclude_from_search' => true, 'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
        ]);
        register_post_type(self::JOB_POST_TYPE, [
            'public' => false,
            'show_ui' => false,
            'show_in_rest' => false,
            'rewrite' => false,
            'query_var' => false,
            'supports' => ['title', 'custom-fields'],
            'capability_type' => ['page', 'pages'],
            'map_meta_cap' => true,
        ]);
    }

    /** @return array{jobId:int,created:int,updated:int,absent:int,projectId:string,sourceVersion:int,homepageId:int} */
    public function import(PortablePagePackage $package, array $options = []): array
    {
        return EditorWriteLock::runSourceWrite(
            [],
            fn (): array => $this->importLocked($package, $options)
        );
    }

    /** @param array<string,mixed> $options @return array{jobId:int,created:int,updated:int,absent:int,projectId:string,sourceVersion:int,homepageId:int} */
    private function importLocked(PortablePagePackage $package, array $options): array
    {
        if (!current_user_can(Capabilities::IMPORT) || !current_user_can(Capabilities::MANAGE)
            || !current_user_can('upload_files') || !current_user_can('edit_theme_options')) {
            throw new PackageException('You are not allowed to import a complete Pagecraft project.');
        }
        if (!$package->isSite()) throw new PackageException('Whole-project import requires a Pagecraft site package.');
        $status = (string) ($options['status'] ?? 'draft');
        if (!in_array($status, ['draft', 'publish'], true)) throw new PackageException('Choose draft or published import status.');
        if ($status === 'publish' && !current_user_can('publish_pages')) {
            throw new PackageException('You are not allowed to publish imported pages.');
        }
        $projectId = (string) $package->provenance()->sourceId;
        $sourceVersion = (int) $package->provenance()->sourceVersion;
        $linked = get_option(self::LINKED_PROJECT, []);
        if (empty($options['replace_site']) && is_array($linked) && !empty($linked['project_id']) && !hash_equals((string) $linked['project_id'], $projectId)) {
            throw new PackageException('This WordPress installation is already linked to another Pagecraft project. Disconnect it before importing a different project.');
        }
        $pages = $package->pages();
        if ($pages === []) throw new PackageException('The Pagecraft project contains no pages.');
        $incomingIds = [];
        foreach ($pages as $page) {
            $id = (string) ($page->id ?? '');
            if ($id === '' || isset($incomingIds[$id])) throw new PackageException('The Pagecraft project contains duplicate page identities.');
            $incomingIds[$id] = true;
        }

        $fullDocument = json_decode($package->fullDocumentJson(), true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($fullDocument)) throw new PackageException('The Pagecraft project document is invalid.');
        (new MediaLibrary())->preflight($package);
        FallbackCompiler::globalContent($package, 'header');
        FallbackCompiler::globalContent($package, 'footer');
        FallbackCompiler::safeCssSource($package->globalCss());
        $preflightPageMap = [];
        foreach (array_keys($incomingIds) as $index => $sourcePageId) {
            $package->selectPage($sourcePageId);
            FallbackCompiler::content($package);
            FallbackCompiler::safeCssSource($package->pageCss());
            $preflightPageMap[$sourcePageId] = $index + 1;
        }
        (new NativeMenu())->preflightImportDocument($fullDocument, $preflightPageMap);
        (new DesignSettings())->preflightImportDocument($fullDocument);

        /* Every package and cross-object compatibility check above completes before this first write. */
        $jobId = wp_insert_post([
            'post_type' => self::JOB_POST_TYPE,
            'post_status' => 'private',
            'post_title' => 'Pagecraft import ' . gmdate('Y-m-d H:i:s') . ' UTC',
            'post_content' => '',
        ], true);
        if (is_wp_error($jobId)) throw new PackageException('WordPress could not create the import job.');
        $jobId = (int) $jobId;
        $createdPosts = [];
        $updatedRevisions = [];
        $attachmentsBefore = $this->pagecraftAttachments();
        $attachmentState = $this->attachmentState($attachmentsBefore);
        $defaultState = [
            'header' => get_option(GlobalElement::DEFAULT_HEADER, 0),
            'footer' => get_option(GlobalElement::DEFAULT_FOOTER, 0),
        ];
        $frontState = [
            'show_on_front' => get_option('show_on_front', 'posts'),
            'page_on_front' => get_option('page_on_front', 0),
        ];
        $designState = get_option(DesignSettings::OPTION, null);
        $designStylesheetState = get_option(DesignSettings::STYLESHEET_OPTION, null);
        $linkedState = get_option(self::LINKED_PROJECT, null);
        $pageMap = [];
        $created = 0;
        $updated = 0;
        $absent = 0;
        $homepageId = 0;
        $wasBlank = $this->isBlankSite();

        try {
            foreach ($pages as $page) {
                $sourcePageId = (string) $page->id;
                $package->selectPage($sourcePageId);
                $existing = $this->findPage($projectId, $sourcePageId, !empty($options['replace_site']));
                $result = (new PageImporter())->import($package, $existing > 0 ? [
                    'replace_post_id' => $existing,
                    'confirm_replace' => true,
                    'replace_title' => !empty($options['replace_site']) ? (string) ($page->name ?? $page->title ?? '') : '',
                ] : ['status' => $status]);
                $pageMap[$sourcePageId] = $result->postId;
                update_post_meta($result->postId, ManagedPage::IMPORT_JOB_ID, (string) $jobId);
                delete_post_meta($result->postId, ManagedPage::ABSENT_FROM_IMPORT);
                if ($result->replaced) {
                    $updated++;
                    if (!$result->revisionId) throw new PackageException('An updated page has no recoverable revision.');
                    $updatedRevisions[$result->postId] = $result->revisionId;
                } else {
                    $created++;
                    $createdPosts[] = $result->postId;
                }
                if ((string) ($page->slug ?? '') === 'index') $homepageId = $result->postId;
            }

            // WordPress may allocate a different slug when an unrelated page already owns
            // the Pagecraft route. Rebind both fallback HTML and the native editable document
            // after every destination ID is known, so buttons follow the imported pages just
            // like the native menu does.
            $willSetHomepage = $homepageId > 0 && ($wasBlank || !empty($options['set_homepage']));
            $internalRoutes = $this->internalRoutes($pages, $pageMap, $willSetHomepage ? $homepageId : 0);
            $this->remapImportedPageLinks($pageMap, $internalRoutes);

            foreach (['header', 'footer'] as $kind) {
                $existing = GlobalElement::findForSource($projectId, $kind, !empty($options['replace_site']));
                $beforeVersion = $existing > 0
                    ? (int) get_post_meta($existing, GlobalElement::DOCUMENT_VERSION, true)
                    : 0;
                $id = (new GlobalElement())->import($package, $kind, 0, $internalRoutes);
                $changed = $existing <= 0
                    || (int) get_post_meta($id, GlobalElement::DOCUMENT_VERSION, true) !== $beforeVersion;
                if ($changed) update_post_meta($id, ManagedPage::IMPORT_JOB_ID, (string) $jobId);
                if ($existing > 0) {
                    if (!$changed) continue;
                    $revision = $this->latestRevisionId($id);
                    if (!$revision) throw new PackageException('An updated global element has no recoverable revision.');
                    $updatedRevisions[$id] = $revision;
                } else {
                    $createdPosts[] = $id;
                }
            }

            (new DesignSettings())->importDocument($fullDocument);

            /* documentJson selects one page for PageImporter; menus need the full source document. */
            (new NativeMenu())->importDocument($fullDocument, $pageMap, true);

            foreach ($this->linkedPages($projectId) as $postId) {
                $sourcePageId = (string) get_post_meta($postId, ManagedPage::SOURCE_PAGE_ID, true);
                if (!isset($incomingIds[$sourcePageId])) {
                    update_post_meta($postId, ManagedPage::ABSENT_FROM_IMPORT, (string) $jobId);
                    $absent++;
                }
            }
            $setHomepage = $willSetHomepage;
            if ($setHomepage) {
                update_option('show_on_front', 'page', false);
                update_option('page_on_front', $homepageId, false);
            }
            update_option(self::LINKED_PROJECT, [
                'project_id' => $projectId,
                'source_version' => $sourceVersion,
                'last_job_id' => $jobId,
                'imported_at' => gmdate('c'),
            ], false);
            $result = compact('jobId', 'created', 'updated', 'absent', 'projectId', 'sourceVersion', 'homepageId');
            wp_update_post(['ID' => $jobId, 'post_content' => wp_slash(wp_json_encode(['status' => 'complete'] + $result))]);
            return $result;
        } catch (\Throwable $error) {
            $rollbackErrors = [];
            if ($designState === null) delete_option(DesignSettings::OPTION);
            else update_option(DesignSettings::OPTION, $designState, false);
            if ($designStylesheetState === null) delete_option(DesignSettings::STYLESHEET_OPTION);
            else update_option(DesignSettings::STYLESHEET_OPTION, $designStylesheetState, false);
            foreach (array_reverse($createdPosts) as $postId) {
                if (!wp_delete_post($postId, true)) {
                    $rollbackErrors[] = 'created post ' . $postId;
                }
            }
            foreach (array_reverse($updatedRevisions, true) as $postId => $revisionId) {
                if (!wp_restore_post_revision($revisionId)) {
                    $rollbackErrors[] = 'revision ' . $revisionId . ' for post ' . $postId;
                }
            }
            update_option(GlobalElement::DEFAULT_HEADER, $defaultState['header'], false);
            update_option(GlobalElement::DEFAULT_FOOTER, $defaultState['footer'], false);
            update_option('show_on_front', $frontState['show_on_front'], false);
            update_option('page_on_front', $frontState['page_on_front'], false);
            if ($linkedState === null) {
                delete_option(self::LINKED_PROJECT);
            } else {
                update_option(self::LINKED_PROJECT, $linkedState, false);
            }
            $this->restoreAttachmentState($attachmentState);
            foreach (array_diff($this->pagecraftAttachments(), $attachmentsBefore) as $attachmentId) {
                if (!wp_delete_attachment($attachmentId, true)) {
                    $rollbackErrors[] = 'attachment ' . $attachmentId;
                }
            }
            wp_update_post(['ID' => $jobId, 'post_content' => wp_slash(wp_json_encode([
                'status' => $rollbackErrors === [] ? 'failed' : 'rollback_failed',
                'error' => $error->getMessage(),
                'rollback_errors' => $rollbackErrors,
                'rolled_back_at' => gmdate('c'),
            ]))]);
            if ($rollbackErrors !== []) {
                throw new PackageException(
                    $error->getMessage() . ' WordPress could not fully restore: ' . implode(', ', $rollbackErrors) . '.',
                    0,
                    $error
                );
            }
            throw $error;
        }
    }

    private function findPage(string $projectId, string $pageId, bool $includeArchived = false): int
    {
        $ids = get_posts([
            'post_type' => 'page',
            'post_status' => $includeArchived
                ? ['publish', 'draft', 'pending', 'private', 'future', CloudReplacement::ARCHIVE_STATUS]
                : 'any',
            'posts_per_page' => 2, 'fields' => 'ids',
            'meta_query' => ['relation' => 'AND',
                ['key' => ManagedPage::SOURCE_PROJECT_ID, 'value' => $projectId, 'compare' => '='],
                ['key' => ManagedPage::SOURCE_PAGE_ID, 'value' => $pageId, 'compare' => '='],
            ],
        ]);
        if (count($ids) > 1) throw new PackageException('Multiple WordPress pages claim one Pagecraft source identity.');
        return isset($ids[0]) ? (int) $ids[0] : 0;
    }

    /**
     * @param list<object> $pages
     * @param array<string,int> $pageMap
     * @return array<string,string>
     */
    private function internalRoutes(array $pages, array $pageMap, int $homepageId = 0): array
    {
        $routes = [];
        foreach ($pages as $page) {
            $sourceId = (string) ($page->id ?? '');
            $slug = (string) ($page->slug ?? '');
            $postId = (int) ($pageMap[$sourceId] ?? 0);
            if ($sourceId === '' || $slug === '' || $postId <= 0) continue;
            $permalink = $postId === $homepageId ? home_url('/') : get_permalink($postId);
            if (is_string($permalink) && $permalink !== '') $routes[$slug] = $permalink;
        }
        return $routes;
    }

    /** @param array<string,int> $pageMap @param array<string,string> $routes */
    private function remapImportedPageLinks(array $pageMap, array $routes): void
    {
        foreach ($pageMap as $postId) {
            EditorWriteLock::runSourceWrite([$postId], function () use ($postId, $routes): void {
                $post = get_post($postId);
                if (!is_object($post)) throw new PackageException('An imported Pagecraft page could not be reloaded.');
                $content = FallbackCompiler::remapProjectHtmlLinks((string) $post->post_content, $routes);
                if ($content !== (string) $post->post_content) {
                    $saved = wp_update_post(['ID' => $postId, 'post_content' => wp_slash($content)], true);
                    if (is_wp_error($saved)) {
                        throw new PackageException('WordPress could not map the imported Pagecraft page links: ' . $saved->get_error_message());
                    }
                    update_post_meta($postId, ManagedPage::COMPILED_HASH, hash('sha256', $content));
                }
                $encoded = (string) get_post_meta($postId, ManagedPage::DOCUMENT, true);
                $document = json_decode($encoded, true, 512, JSON_THROW_ON_ERROR);
                if (!is_array($document)) throw new PackageException('An imported Pagecraft document could not be reloaded.');
                $mapped = DocumentJson::encode(FallbackCompiler::remapProjectDocumentLinks($document, $routes));
                if ($mapped !== $encoded) update_post_meta($postId, ManagedPage::DOCUMENT, wp_slash($mapped));
            });
        }
    }

    /** @return list<int> */
    private function linkedPages(string $projectId): array
    {
        return array_map('intval', get_posts([
            'post_type' => 'page', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids',
            'meta_key' => ManagedPage::SOURCE_PROJECT_ID, 'meta_value' => $projectId,
        ]));
    }

    /** @return list<int> */
    private function pagecraftAttachments(): array
    {
        return array_map('intval', get_posts([
            'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => -1, 'fields' => 'ids',
            'meta_key' => MediaLibrary::HASH, 'compare' => 'EXISTS',
        ]));
    }

    private function latestRevisionId(int $postId): ?int
    {
        $revisions = wp_get_post_revisions($postId, ['posts_per_page' => 1, 'order' => 'DESC', 'orderby' => 'date ID', 'check_enabled' => false]);
        $latest = reset($revisions);
        return is_object($latest) ? (int) $latest->ID : null;
    }

    private function isBlankSite(): bool
    {
        $counts = wp_count_posts('page');
        return ((int) ($counts->publish ?? 0) + (int) ($counts->draft ?? 0) + (int) ($counts->private ?? 0)) === 0;
    }

    /** @param list<int> $ids @return array<int,array{alt:string,caption:string}> */
    private function attachmentState(array $ids): array
    {
        $state = [];
        foreach ($ids as $id) {
            $post = get_post($id);
            if (!is_object($post)) continue;
            $state[$id] = [
                'alt' => (string) get_post_meta($id, '_wp_attachment_image_alt', true),
                'caption' => $post->post_excerpt,
            ];
        }
        return $state;
    }

    /** @param array<int,array{alt:string,caption:string}> $state */
    private function restoreAttachmentState(array $state): void
    {
        foreach ($state as $id => $record) {
            if (get_post_type($id) !== 'attachment') continue;
            if ($record['alt'] === '') delete_post_meta($id, '_wp_attachment_image_alt');
            else update_post_meta($id, '_wp_attachment_image_alt', $record['alt']);
            wp_update_post(['ID' => $id, 'post_excerpt' => $record['caption']]);
        }
    }
}
