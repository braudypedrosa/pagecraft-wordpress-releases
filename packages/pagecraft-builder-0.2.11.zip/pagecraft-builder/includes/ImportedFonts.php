<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

/**
 * Web fonts for imported pages.
 *
 * A package carries the names of its fonts and, in each compiled page, the one Google Fonts
 * stylesheet that serves them. WordPress keeps only the page body and the Pagecraft styles, so
 * without this an imported page asks for fonts that nothing loads and shows fallbacks until
 * somebody saves it in the editor. The editor writes `@font-face` rules into the global
 * stylesheet when it saves; an import now writes the same rules.
 *
 * Nothing here can stop an import. If the stylesheet cannot be fetched or read, the page is
 * imported without the rules and `missed()` says so, so the screen that ran the import can
 * tell the person their pages are showing fallback fonts.
 */
final class ImportedFonts
{
    private const MAX_STYLESHEET_BYTES = 524288;
    private const SUBSETS = ['latin', 'latin-ext'];
    /* Google answers an unknown client with one TrueType file per weight and no subsets. */
    private const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

    /** @var array<string,string> */
    private static array $fetched = [];
    private static bool $missed = false;

    /** Whether a page since the last `reset()` needed web fonts that could not be fetched. */
    public static function missed(): bool
    {
        return self::$missed;
    }

    public static function reset(): void
    {
        self::$missed = false;
    }

    public static function prepend(PortablePagePackage $package, string $globalCss): string
    {
        try {
            return self::prependFor($package->compiledHtml(), $globalCss);
        } catch (\Throwable) {
            return $globalCss;
        }
    }

    /** The global stylesheet, led by the font rules the compiled page's fonts need. */
    public static function prependFor(string $compiledHtml, string $globalCss): string
    {
        if (stripos($globalCss, '@font-face') !== false) return $globalCss;
        try {
            $href = self::stylesheetUrl($compiledHtml);
            if ($href === '') return $globalCss;
            if (!isset(self::$fetched[$href])) {
                $faces = self::faceCss(self::fetch($href));
                // A failed fetch is not remembered: the next page of the same import tries again.
                if ($faces === '') {
                    self::$missed = true;
                    return $globalCss;
                }
                self::$fetched[$href] = $faces;
            }
            return self::$fetched[$href] . "\n" . $globalCss;
        } catch (\Throwable) {
            return $globalCss;
        }
    }

    /** The Google Fonts stylesheet a compiled page links, or '' when it links none. */
    public static function stylesheetUrl(string $html): string
    {
        if (!preg_match_all('/<link\b[^>]*>/i', $html, $links)) return '';
        foreach ($links[0] as $link) {
            if (!preg_match('/\bhref\s*=\s*(["\'])(https:\/\/fonts\.googleapis\.com\/css2\?[^"\']*)\1/i', $link, $match)) {
                continue;
            }
            $href = html_entity_decode($match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            // Family names, weights and the display mode only: nothing else belongs in this address.
            if (strlen($href) <= 2048
                && preg_match('/^https:\/\/fonts\.googleapis\.com\/css2\?[A-Za-z0-9+:;,@&=._-]+$/', $href) === 1) {
                return $href;
            }
        }
        return '';
    }

    /** `@font-face` rules for the Latin subsets of a Google Fonts stylesheet. */
    public static function faceCss(string $stylesheet): string
    {
        // Each subset's rules follow a comment naming it.
        $parts = preg_split('/\/\*\s*([a-z0-9-]+)\s*\*\//i', $stylesheet, -1, PREG_SPLIT_DELIM_CAPTURE);
        if (!is_array($parts)) return '';
        $rules = [];
        for ($index = 1; $index + 1 < count($parts); $index += 2) {
            if (!in_array(strtolower($parts[$index]), self::SUBSETS, true)) continue;
            if (!preg_match_all('/@font-face\s*\{([^}]*)\}/', $parts[$index + 1], $blocks)) continue;
            foreach ($blocks[1] as $block) {
                $rule = self::rule($block);
                if ($rule !== '') $rules[$rule] = true;
            }
        }
        return implode("\n", array_keys($rules));
    }

    private static function rule(string $block): string
    {
        $pick = static function (string $name) use ($block): string {
            return preg_match('/(?:^|;)\s*' . $name . '\s*:\s*([^;]+)/', $block, $match) === 1 ? trim($match[1]) : '';
        };
        $family = trim($pick('font-family'), "\"' ");
        $weight = $pick('font-weight') ?: '400';
        $style = $pick('font-style') ?: 'normal';
        $range = $pick('unicode-range');
        $url = preg_match('/url\(\s*["\']?([^"\')\s]+)["\']?\s*\)/', $block, $match) === 1 ? $match[1] : '';
        // Every value is written into a stylesheet visitors load, so each must be exactly its kind.
        if (preg_match('/^[A-Za-z0-9][A-Za-z0-9 ]{0,63}$/', $family) !== 1
            || preg_match('/^\d{1,4}(?: \d{1,4})?$/', $weight) !== 1
            || !in_array($style, ['normal', 'italic'], true)
            || preg_match('/^https:\/\/fonts\.gstatic\.com\/[A-Za-z0-9\/_.-]+\.woff2$/', $url) !== 1
            || ($range !== '' && preg_match('/^[Uu+0-9A-Fa-f?, -]{1,600}$/', $range) !== 1)) {
            return '';
        }
        return "@font-face{font-family:'" . $family . "';font-style:" . $style . ';font-weight:' . $weight
            . ";font-display:swap;src:url('" . $url . "') format('woff2')"
            . ($range !== '' ? ';unicode-range:' . $range : '') . '}';
    }

    private static function fetch(string $href): string
    {
        if (!function_exists('wp_safe_remote_get')) return '';
        $response = wp_safe_remote_get($href, [
            'timeout' => 8, 'redirection' => 0, 'user-agent' => self::USER_AGENT,
            'limit_response_size' => self::MAX_STYLESHEET_BYTES,
        ]);
        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) return '';
        return (string) wp_remote_retrieve_body($response);
    }
}
