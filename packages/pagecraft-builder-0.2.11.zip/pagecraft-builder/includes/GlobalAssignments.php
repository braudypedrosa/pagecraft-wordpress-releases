<?php

declare(strict_types=1);

namespace Pagecraft\Builder;

final class GlobalAssignments
{
    public function register(): void
    {
        add_action('add_meta_boxes_page', [$this, 'box']);
        add_action('save_post_page', [$this, 'save'], 10, 2);
        add_action('add_meta_boxes_' . GlobalElement::POST_TYPE, [$this, 'globalBox']);
        add_action('save_post_' . GlobalElement::POST_TYPE, [$this, 'saveGlobal'], 10, 2);
        add_action('admin_post_pagecraft_global_defaults', [$this, 'saveDefaults']);
    }

    public function globalBox(): void
    {
        add_meta_box(
            'pagecraft-global-kind',
            __('Pagecraft template type', 'pagecraft-builder'),
            [$this, 'renderGlobal'],
            GlobalElement::POST_TYPE,
            'side',
            'high'
        );
    }

    public function renderGlobal(\WP_Post $post): void
    {
        wp_nonce_field('pagecraft_global_kind_' . $post->ID, 'pagecraft_global_kind_nonce');
        $kind = (string) get_post_meta($post->ID, GlobalElement::KIND, true);
        if (!in_array($kind, GlobalElement::kinds(), true)) $kind = 'header';
        echo '<p><label for="pagecraft-global-kind-select">' . esc_html__('Template type', 'pagecraft-builder')
            . '</label></p><select id="pagecraft-global-kind-select" name="pagecraft_global_kind">';
        foreach (GlobalElement::kinds() as $value) {
            echo '<option value="' . esc_attr($value) . '"' . selected($kind, $value, false) . '>'
                . esc_html(GlobalElement::label($value)) . '</option>';
        }
        echo '</select><p class="description">' . esc_html__('Display conditions and activation are managed in Pagecraft Theme Builder.', 'pagecraft-builder') . '</p>'
            . '<p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=' . Admin::EDITOR_SLUG . '&global=' . $post->ID)) . '">'
            . esc_html__('Edit with Pagecraft', 'pagecraft-builder') . '</a>';
        if ((string) get_post_meta($post->ID, GlobalElement::DOCUMENT, true) !== '') {
            echo ' <a class="button" target="_blank" rel="noopener" href="' . esc_url(wp_nonce_url(
                admin_url('admin-post.php?action=pagecraft_preview_global&global=' . $post->ID),
                'pagecraft_preview_global_' . $post->ID
            )) . '">' . esc_html__('Preview element', 'pagecraft-builder') . '</a>';
        }
        echo '</p>';
    }

    public function saveGlobal(int $postId, \WP_Post $post): void
    {
        if (wp_is_post_autosave($postId) || wp_is_post_revision($postId)
            || !current_user_can('edit_post', $postId)
            || !isset($_POST['pagecraft_global_kind_nonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash((string) $_POST['pagecraft_global_kind_nonce'])), 'pagecraft_global_kind_' . $postId)) return;
        $kind = sanitize_key((string) ($_POST['pagecraft_global_kind'] ?? ''));
        if (!in_array($kind, GlobalElement::kinds(), true)) return;
        update_post_meta($postId, GlobalElement::KIND, $kind);
        update_post_meta($postId, GlobalElement::UPDATED_AT, gmdate('c'));
    }

    public function box(): void
    {
        add_meta_box(
            'pagecraft-global-assignments',
            __('Pagecraft header and footer', 'pagecraft-builder'),
            [$this, 'render'],
            'page',
            'side',
            'default'
        );
    }

    public function render(\WP_Post $post): void
    {
        wp_nonce_field('pagecraft_global_assignments_' . $post->ID, 'pagecraft_global_assignments_nonce');
        foreach (['header', 'footer'] as $kind) {
            $modeKey = $kind === 'header' ? GlobalElement::PAGE_HEADER_MODE : GlobalElement::PAGE_FOOTER_MODE;
            $idKey = $kind === 'header' ? GlobalElement::PAGE_HEADER_ID : GlobalElement::PAGE_FOOTER_ID;
            $mode = (string) get_post_meta($post->ID, $modeKey, true);
            if (!in_array($mode, ['inherit', 'selected', 'none'], true)) $mode = 'inherit';
            $selected = (int) get_post_meta($post->ID, $idKey, true);
            echo '<p><strong>' . esc_html(ucfirst($kind)) . '</strong></p><label class="screen-reader-text" for="pagecraft-'
                . esc_attr($kind) . '-mode">' . esc_html(ucfirst($kind) . ' mode') . '</label><select id="pagecraft-'
                . esc_attr($kind) . '-mode" name="pagecraft_' . esc_attr($kind) . '_mode">';
            foreach (['inherit' => __('Use site default', 'pagecraft-builder'), 'selected' => __('Use selected element', 'pagecraft-builder'), 'none' => __('Display none', 'pagecraft-builder')] as $value => $label) {
                echo '<option value="' . esc_attr($value) . '"' . selected($mode, $value, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select><label class="screen-reader-text" for="pagecraft-' . esc_attr($kind) . '-id">'
                . esc_html('Selected ' . $kind) . '</label><select id="pagecraft-' . esc_attr($kind) . '-id" name="pagecraft_'
                . esc_attr($kind) . '_id"><option value="0">' . esc_html__('Select an element', 'pagecraft-builder') . '</option>';
            foreach (GlobalElement::all($kind) as $global) {
                echo '<option value="' . esc_attr((string) $global->ID) . '"' . selected($selected, (int) $global->ID, false) . '>'
                    . esc_html(get_the_title($global)) . '</option>';
            }
            echo '</select>';
        }
    }

    public function save(int $postId, \WP_Post $post): void
    {
        if (wp_is_post_autosave($postId) || wp_is_post_revision($postId)
            || !current_user_can('edit_post', $postId)
            || !isset($_POST['pagecraft_global_assignments_nonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash((string) $_POST['pagecraft_global_assignments_nonce'])), 'pagecraft_global_assignments_' . $postId)) return;
        foreach (['header', 'footer'] as $kind) {
            $mode = sanitize_key((string) ($_POST['pagecraft_' . $kind . '_mode'] ?? 'inherit'));
            if (!in_array($mode, ['inherit', 'selected', 'none'], true)) $mode = 'inherit';
            $id = absint($_POST['pagecraft_' . $kind . '_id'] ?? 0);
            if ($mode === 'selected' && !GlobalElement::valid($id, $kind)) $mode = 'inherit';
            update_post_meta($postId, $kind === 'header' ? GlobalElement::PAGE_HEADER_MODE : GlobalElement::PAGE_FOOTER_MODE, $mode);
            update_post_meta($postId, $kind === 'header' ? GlobalElement::PAGE_HEADER_ID : GlobalElement::PAGE_FOOTER_ID, $mode === 'selected' ? (string) $id : '');
        }
    }

    public function saveDefaults(): void
    {
        if (!current_user_can(Capabilities::MANAGE) || !current_user_can('edit_theme_options')) {
            wp_die(esc_html__('You cannot assign Pagecraft global elements.', 'pagecraft-builder'), '', ['response' => 403]);
        }
        check_admin_referer('pagecraft_global_defaults');
        foreach (['header', 'footer'] as $kind) {
            $id = absint($_POST['pagecraft_default_' . $kind] ?? 0);
            if ($id > 0 && !GlobalElement::valid($id, $kind)) {
                wp_die(esc_html__('A selected global element is invalid.', 'pagecraft-builder'), '', ['response' => 400]);
            }
            update_option(GlobalElement::defaultOption($kind), $id, false);
        }
        wp_safe_redirect(admin_url('admin.php?page=pagecraft-globals&pagecraft_message=defaults'));
        exit;
    }
}
