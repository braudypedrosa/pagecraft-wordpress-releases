(() => {
  'use strict';

  const config = window.PAGECRAFT_BLOCK_EDITOR;
  if (!config || !config.labels || !config.prepareUrl || !config.prepareNonce) return;

  const labels = config.labels;
  const templates = Array.isArray(config.templates) ? config.templates : [];
  const buttonId = 'pagecraft-edit-with-pagecraft';
  const dialogId = 'pagecraft-block-editor-dialog';
  let opener = null;
  let openedFromUrl = false;
  let returnToCloud = Boolean(config.openCloudOnLoad);

  const mark = () => '<svg class="pagecraft-block-editor-button__mark" width="12" height="16" viewBox="0 0 73 95" aria-hidden="true" focusable="false"><path d="M0 0H73V71H52L46 65L40 71H18V77H40V95H0Z M18 18V77H40V53H55V18Z" fill="currentColor" fill-rule="evenodd"/></svg>';
  const closeIcon = () => '<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M3 3l10 10M13 3 3 13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>';
  const arrowIcon = () => '<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M3 8h9M9 4l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const backIcon = () => '<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M13 8H4M7 4 3 8l4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  const makeChoice = (action, label, description, badge = '') => {
    const choice = document.createElement('button');
    choice.type = 'button';
    choice.className = 'pagecraft-block-editor-choice';
    if (action) choice.dataset.pagecraftChoice = action;
    if (!action) {
      choice.disabled = true;
      choice.setAttribute('aria-disabled', 'true');
    }

    const copy = document.createElement('span');
    copy.className = 'pagecraft-block-editor-choice__copy';
    const title = document.createElement('strong');
    title.textContent = label;
    const detail = document.createElement('span');
    detail.textContent = description;
    copy.append(title, detail);

    const end = document.createElement('span');
    end.className = 'pagecraft-block-editor-choice__end';
    if (badge) {
      end.classList.add('pagecraft-block-editor-choice__badge');
      end.textContent = badge;
    } else {
      end.innerHTML = arrowIcon();
    }
    choice.append(copy, end);
    return choice;
  };

  const makeTemplateCard = (template) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'pagecraft-block-editor-template';
    button.dataset.pagecraftTemplate = String(template.id || '');
    button.dataset.pagecraftTemplateCategory = String(template.category || '');
    button.dataset.pagecraftTemplateSearch = [template.name, template.description, template.category]
      .concat(Array.isArray(template.keywords) ? template.keywords : []).join(' ').toLowerCase();

    const preview = document.createElement('span');
    preview.className = 'pagecraft-block-editor-template__preview';
    preview.innerHTML = String(template.preview || '');
    const copy = document.createElement('span');
    copy.className = 'pagecraft-block-editor-template__copy';
    const title = document.createElement('strong');
    title.textContent = String(template.name || '');
    const detail = document.createElement('span');
    detail.textContent = String(template.description || '');
    const category = document.createElement('small');
    category.textContent = String(template.category || '');
    copy.append(title, detail, category);
    button.append(preview, copy);
    return button;
  };

  const createDialog = () => {
    const existing = document.getElementById(dialogId);
    if (existing) return existing;

    const dialog = document.createElement('dialog');
    dialog.id = dialogId;
    dialog.className = 'pagecraft-block-editor-dialog';
    dialog.setAttribute('aria-labelledby', `${dialogId}-title`);

    const panel = document.createElement('div');
    panel.className = 'pagecraft-block-editor-dialog__panel';
    const header = document.createElement('header');
    header.className = 'pagecraft-block-editor-dialog__header';
    const heading = document.createElement('div');
    heading.className = 'pagecraft-block-editor-dialog__heading';
    const brand = document.createElement('span');
    brand.className = 'pagecraft-block-editor-dialog__brand';
    brand.innerHTML = mark();
    const title = document.createElement('h2');
    title.id = `${dialogId}-title`;
    title.textContent = labels.title;
    const headingCopy = document.createElement('div');
    headingCopy.className = 'pagecraft-block-editor-dialog__heading-copy';
    const templateIntro = document.createElement('p');
    templateIntro.className = 'pagecraft-block-editor-dialog__description';
    templateIntro.textContent = labels.templateIntro;
    headingCopy.append(title, templateIntro);
    heading.append(brand, headingCopy);

    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'pagecraft-block-editor-dialog__close';
    close.setAttribute('aria-label', labels.close);
    close.dataset.pagecraftDialogClose = '';
    close.innerHTML = closeIcon();
    header.append(heading, close);

    const body = document.createElement('div');
    body.className = 'pagecraft-block-editor-dialog__body';

    const startView = document.createElement('section');
    startView.className = 'pagecraft-block-editor-dialog__view';
    startView.dataset.pagecraftView = 'start';
    const intro = document.createElement('p');
    intro.className = 'pagecraft-block-editor-dialog__intro';
    intro.textContent = labels.intro;
    const choices = document.createElement('div');
    choices.className = 'pagecraft-block-editor-choices';
    choices.append(
      makeChoice('blank', labels.blank, labels.blankDescription),
      makeChoice('template', labels.template, labels.templateDescription),
      makeChoice('cloud', labels.cloud, labels.cloudDescription)
    );
    startView.append(intro, choices);

    const templateView = document.createElement('section');
    templateView.className = 'pagecraft-block-editor-dialog__view';
    templateView.dataset.pagecraftView = 'template';
    templateView.hidden = true;
    const templateBack = document.createElement('button');
    templateBack.type = 'button';
    templateBack.className = 'pagecraft-block-editor-dialog__back';
    templateBack.dataset.pagecraftTemplateBack = '';
    templateBack.innerHTML = `${backIcon()}<span></span>`;
    templateBack.querySelector('span').textContent = labels.templateBack;
    const templateTools = document.createElement('div');
    templateTools.className = 'pagecraft-block-editor-template-tools';
    const templateSearch = document.createElement('input');
    templateSearch.type = 'search';
    templateSearch.className = 'pagecraft-block-editor-template-search';
    templateSearch.placeholder = labels.templateSearch;
    templateSearch.setAttribute('aria-label', labels.templateSearch);
    const templateFilters = document.createElement('div');
    templateFilters.className = 'pagecraft-block-editor-template-filters';
    templateFilters.setAttribute('role', 'toolbar');
    templateFilters.setAttribute('aria-label', labels.templateFilter);
    [labels.templateAll, ...new Set(templates.map(template => String(template.category || '')).filter(Boolean))].forEach((category, index) => {
      const filter = document.createElement('button');
      filter.type = 'button';
      filter.className = 'pagecraft-block-editor-template-filter';
      filter.dataset.pagecraftTemplateFilter = category;
      filter.setAttribute('aria-pressed', index === 0 ? 'true' : 'false');
      filter.textContent = category;
      templateFilters.append(filter);
    });
    templateTools.append(templateBack, templateSearch, templateFilters);
    const templateList = document.createElement('div');
    templateList.className = 'pagecraft-block-editor-template-list';
    templateList.dataset.pagecraftTemplateList = '';
    templates.forEach(template => templateList.append(makeTemplateCard(template)));
    const templateEmpty = document.createElement('p');
    templateEmpty.className = 'pagecraft-block-editor-template-empty';
    templateEmpty.dataset.pagecraftTemplateEmpty = '';
    templateEmpty.hidden = true;
    templateEmpty.textContent = labels.templateEmpty;
    templateView.append(templateTools, templateList, templateEmpty);

    const cloudView = document.createElement('section');
    cloudView.className = 'pagecraft-block-editor-dialog__view';
    cloudView.dataset.pagecraftView = 'cloud';
    cloudView.hidden = true;
    const back = document.createElement('button');
    back.type = 'button';
    back.className = 'pagecraft-block-editor-dialog__back';
    back.dataset.pagecraftCloudBack = '';
    back.innerHTML = `${backIcon()}<span></span>`;
    back.querySelector('span').textContent = labels.cloudBack;
    const cloudIntro = document.createElement('p');
    cloudIntro.className = 'pagecraft-block-editor-dialog__intro';
    cloudIntro.textContent = labels.cloudIntro;
    const cloudContent = document.createElement('div');
    cloudContent.className = 'pagecraft-block-editor-cloud';
    cloudContent.dataset.pagecraftCloudContent = '';
    cloudView.append(back, cloudIntro, cloudContent);

    const status = document.createElement('p');
    status.className = 'pagecraft-block-editor-dialog__status';
    status.hidden = true;
    status.setAttribute('role', 'status');
    body.append(startView, templateView, cloudView, status);
    panel.append(header, body);
    dialog.append(panel);
    document.body.append(dialog);

    close.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => {
      if (event.target === dialog) dialog.close();
    });
    dialog.addEventListener('close', () => {
      showStartView(dialog);
      if (opener instanceof HTMLElement) opener.focus();
    });
    choices.addEventListener('click', (event) => {
      const choice = event.target.closest('[data-pagecraft-choice]');
      if (!(choice instanceof HTMLButtonElement) || choice.disabled) return;
      void handleChoice(choice.dataset.pagecraftChoice || '', dialog);
    });
    templateView.addEventListener('click', (event) => {
      const backButton = event.target.closest('[data-pagecraft-template-back]');
      if (backButton instanceof HTMLButtonElement) {
        showStartView(dialog);
        return;
      }
      const filter = event.target.closest('[data-pagecraft-template-filter]');
      if (filter instanceof HTMLButtonElement) {
        templateView.querySelectorAll('[data-pagecraft-template-filter]').forEach((item) => {
          item.setAttribute('aria-pressed', item === filter ? 'true' : 'false');
        });
        filterTemplatePages(templateView);
        return;
      }
      const template = event.target.closest('[data-pagecraft-template]');
      if (template instanceof HTMLButtonElement && !template.disabled) {
        preparePage(Number(dialog.dataset.pagecraftPost || 0), template.dataset.pagecraftTemplate || 'blank', dialog);
      }
    });
    templateView.addEventListener('input', (event) => {
      if (event.target instanceof HTMLInputElement && event.target.matches('.pagecraft-block-editor-template-search')) {
        filterTemplatePages(templateView);
      }
    });
    cloudView.addEventListener('click', (event) => {
      const backButton = event.target.closest('[data-pagecraft-cloud-back]');
      if (backButton instanceof HTMLButtonElement) {
        showStartView(dialog);
        return;
      }
      const connect = event.target.closest('[data-pagecraft-cloud-connect]');
      if (connect instanceof HTMLButtonElement) {
        startCloudConnection(dialog);
        return;
      }
      const retry = event.target.closest('[data-pagecraft-cloud-retry]');
      if (retry instanceof HTMLButtonElement) {
        void loadCloudPages(dialog, Number(dialog.dataset.pagecraftPost || 0));
        return;
      }
      const page = event.target.closest('[data-pagecraft-cloud-page]');
      if (page instanceof HTMLButtonElement && !page.disabled) {
        void importCloudPage(dialog, page);
      }
    });
    cloudView.addEventListener('input', (event) => {
      if (!(event.target instanceof HTMLInputElement) || !event.target.matches('[data-pagecraft-cloud-search]')) return;
      filterCloudPages(cloudView, event.target.value);
    });
    return dialog;
  };

  const setStatus = (dialog, message = '', error = false) => {
    const status = dialog.querySelector('.pagecraft-block-editor-dialog__status');
    status.hidden = message === '';
    status.textContent = message;
    status.classList.toggle('is-error', error);
  };

  const setBusy = (dialog, busy, message = '', error = false) => {
    dialog.setAttribute('aria-busy', busy ? 'true' : 'false');
    dialog.querySelectorAll('[data-pagecraft-choice]:not([aria-disabled="true"]), [data-pagecraft-template-back], [data-pagecraft-template-filter], [data-pagecraft-template], [data-pagecraft-cloud-back], [data-pagecraft-cloud-connect], [data-pagecraft-cloud-retry], [data-pagecraft-cloud-page]').forEach((button) => {
      button.disabled = busy;
    });
    setStatus(dialog, message, error);
  };

  const showStartView = (dialog) => {
    dialog.querySelector(`#${dialogId}-title`).textContent = labels.title;
    dialog.classList.remove('is-templates');
    dialog.querySelector('[data-pagecraft-view="start"]').hidden = false;
    dialog.querySelector('[data-pagecraft-view="template"]').hidden = true;
    dialog.querySelector('[data-pagecraft-view="cloud"]').hidden = true;
    setBusy(dialog, false);
  };

  const filterTemplatePages = (templateView) => {
    const search = templateView.querySelector('.pagecraft-block-editor-template-search');
    const active = templateView.querySelector('[data-pagecraft-template-filter][aria-pressed="true"]');
    const query = search instanceof HTMLInputElement ? search.value.trim().toLowerCase() : '';
    const category = active instanceof HTMLButtonElement ? active.dataset.pagecraftTemplateFilter || labels.templateAll : labels.templateAll;
    let shown = 0;
    templateView.querySelectorAll('[data-pagecraft-template]').forEach((button) => {
      const visible = (category === labels.templateAll || button.dataset.pagecraftTemplateCategory === category)
        && (!query || String(button.dataset.pagecraftTemplateSearch || '').includes(query));
      button.hidden = !visible;
      if (visible) shown++;
    });
    const empty = templateView.querySelector('[data-pagecraft-template-empty]');
    if (empty instanceof HTMLElement) empty.hidden = shown !== 0;
  };

  const showTemplateView = (dialog, postId) => {
    dialog.dataset.pagecraftPost = String(postId);
    dialog.classList.add('is-templates');
    dialog.querySelector(`#${dialogId}-title`).textContent = labels.templateTitle;
    dialog.querySelector('[data-pagecraft-view="start"]').hidden = true;
    dialog.querySelector('[data-pagecraft-view="template"]').hidden = false;
    dialog.querySelector('[data-pagecraft-view="cloud"]').hidden = true;
    setBusy(dialog, false);
    const search = dialog.querySelector('.pagecraft-block-editor-template-search');
    if (search instanceof HTMLInputElement) search.focus();
  };

  const showCloudView = (dialog, postId) => {
    dialog.dataset.pagecraftPost = String(postId);
    dialog.classList.remove('is-templates');
    dialog.querySelector(`#${dialogId}-title`).textContent = labels.cloudTitle;
    dialog.querySelector('[data-pagecraft-view="start"]').hidden = true;
    dialog.querySelector('[data-pagecraft-view="cloud"]').hidden = false;
  };

  const saveCurrentPage = async () => {
    const editorSelect = window.wp && window.wp.data ? window.wp.data.select('core/editor') : null;
    const editorDispatch = window.wp && window.wp.data ? window.wp.data.dispatch('core/editor') : null;
    if (!editorSelect || !editorDispatch) throw new Error('The WordPress editor is not ready.');

    const status = editorSelect.getCurrentPostAttribute('status');
    if (status === 'auto-draft') {
      const currentTitle = String(editorSelect.getEditedPostAttribute('title') || '').trim();
      editorDispatch.editPost({
        status: 'draft',
        ...(currentTitle === '' ? { title: labels.untitled } : {})
      });
    }
    if (status === 'auto-draft' || editorSelect.isEditedPostDirty()) {
      await editorDispatch.savePost();
    }
    const postId = Number(editorSelect.getCurrentPostId() || config.postId || 0);
    if (!Number.isInteger(postId) || postId < 1) throw new Error('The page has not been saved.');
    return postId;
  };

  const preparePage = (postId, template = 'blank', dialog = null) => {
    if (dialog) setBusy(dialog, true, labels.templatePreparing);
    const form = document.createElement('form');
    form.method = 'post';
    form.action = config.prepareUrl;
    form.hidden = true;
    [['action', 'pagecraft_prepare_page'], ['post', String(postId)], ['template', template], ['_wpnonce', config.prepareNonce]].forEach(([name, value]) => {
      const field = document.createElement('input');
      field.type = 'hidden';
      field.name = name;
      field.value = value;
      form.append(field);
    });
    document.body.append(form);
    form.submit();
  };

  const responseJson = async (response) => {
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload || payload.success !== true) {
      const error = new Error(payload && payload.data && payload.data.message ? payload.data.message : labels.cloudLoadError);
      error.connected = payload && payload.data ? payload.data.connected : undefined;
      throw error;
    }
    return payload.data || {};
  };

  const cloudPageRows = (projects) => projects.flatMap((project) => {
    const projectName = String(project.name || '');
    const projectId = String(project.id || '');
    return Array.isArray(project.pages) ? project.pages.map((page) => ({
      projectId,
      projectName,
      id: String(page.id || ''),
      name: String(page.name || labels.untitled),
      slug: String(page.slug || '')
    })) : [];
  }).filter((page) => page.projectId && page.id);

  const renderCloudConnect = (dialog) => {
    const content = dialog.querySelector('[data-pagecraft-cloud-content]');
    const state = document.createElement('div');
    state.className = 'pagecraft-block-editor-cloud__state';
    const title = document.createElement('strong');
    title.textContent = labels.cloudConnectTitle;
    const description = document.createElement('p');
    description.textContent = labels.cloudConnectDescription;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'pagecraft-block-editor-cloud__primary';
    button.dataset.pagecraftCloudConnect = '';
    button.textContent = labels.cloudConnectAction;
    state.append(title, description, button);
    content.replaceChildren(state);
  };

  const renderCloudEmpty = (dialog) => {
    const content = dialog.querySelector('[data-pagecraft-cloud-content]');
    const state = document.createElement('div');
    state.className = 'pagecraft-block-editor-cloud__state';
    const title = document.createElement('strong');
    title.textContent = labels.cloudEmpty;
    const description = document.createElement('p');
    description.textContent = labels.cloudEmptyDescription;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'pagecraft-block-editor-cloud__secondary';
    button.dataset.pagecraftCloudRetry = '';
    button.textContent = labels.cloudRetry;
    state.append(title, description, button);
    content.replaceChildren(state);
  };

  const renderCloudError = (dialog, message, canConnect) => {
    if (canConnect) {
      renderCloudConnect(dialog);
      setStatus(dialog, message, true);
      return;
    }
    const content = dialog.querySelector('[data-pagecraft-cloud-content]');
    const state = document.createElement('div');
    state.className = 'pagecraft-block-editor-cloud__state';
    const description = document.createElement('p');
    description.textContent = message || labels.cloudLoadError;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'pagecraft-block-editor-cloud__secondary';
    button.dataset.pagecraftCloudRetry = '';
    button.textContent = labels.cloudRetry;
    state.append(description, button);
    content.replaceChildren(state);
  };

  const renderCloudPages = (dialog, pages) => {
    if (!pages.length) {
      renderCloudEmpty(dialog);
      return;
    }
    const content = dialog.querySelector('[data-pagecraft-cloud-content]');
    const fragment = document.createDocumentFragment();
    if (pages.length > 8) {
      const search = document.createElement('input');
      search.type = 'search';
      search.className = 'pagecraft-block-editor-cloud__search';
      search.placeholder = labels.cloudSearch;
      search.setAttribute('aria-label', labels.cloudSearch);
      search.dataset.pagecraftCloudSearch = '';
      fragment.append(search);
    }
    const list = document.createElement('div');
    list.className = 'pagecraft-block-editor-cloud__list';
    pages.forEach((page) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'pagecraft-block-editor-cloud__page';
      button.dataset.pagecraftCloudPage = page.id;
      button.dataset.pagecraftCloudProject = page.projectId;
      button.dataset.pagecraftCloudSearchText = `${page.name} ${page.projectName} ${page.slug}`.toLocaleLowerCase();
      const copy = document.createElement('span');
      copy.className = 'pagecraft-block-editor-choice__copy';
      const title = document.createElement('strong');
      title.textContent = page.name;
      const detail = document.createElement('span');
      const path = page.slug ? ` · /${page.slug.replace(/^\/+/, '')}` : '';
      detail.textContent = `${page.projectName}${path}`;
      copy.append(title, detail);
      const arrow = document.createElement('span');
      arrow.className = 'pagecraft-block-editor-choice__end';
      arrow.innerHTML = arrowIcon();
      button.append(copy, arrow);
      list.append(button);
    });
    const noResults = document.createElement('p');
    noResults.className = 'pagecraft-block-editor-cloud__no-results';
    noResults.hidden = true;
    noResults.textContent = labels.cloudNoResults;
    fragment.append(list, noResults);
    content.replaceChildren(fragment);
  };

  const filterCloudPages = (cloudView, value) => {
    const query = value.trim().toLocaleLowerCase();
    let visible = 0;
    cloudView.querySelectorAll('[data-pagecraft-cloud-page]').forEach((page) => {
      page.hidden = query !== '' && !String(page.dataset.pagecraftCloudSearchText || '').includes(query);
      if (!page.hidden) visible += 1;
    });
    const noResults = cloudView.querySelector('.pagecraft-block-editor-cloud__no-results');
    if (noResults) noResults.hidden = visible !== 0;
  };

  const loadCloudPages = async (dialog, postId) => {
    showCloudView(dialog, postId);
    const content = dialog.querySelector('[data-pagecraft-cloud-content]');
    content.replaceChildren();
    setBusy(dialog, true, labels.cloudLoading);
    try {
      const url = new URL(config.cloudPagesUrl, window.location.href);
      url.searchParams.set('nonce', config.cloudNonce);
      const data = await responseJson(await fetch(url.toString(), { credentials: 'same-origin' }));
      if (!data.connected) {
        renderCloudConnect(dialog);
      } else {
        renderCloudPages(dialog, cloudPageRows(Array.isArray(data.projects) ? data.projects : []));
      }
      setBusy(dialog, false);
      const first = dialog.querySelector('[data-pagecraft-cloud-page], [data-pagecraft-cloud-connect], [data-pagecraft-cloud-retry]');
      if (first instanceof HTMLElement) first.focus();
    } catch (error) {
      renderCloudError(dialog, error instanceof Error ? error.message : labels.cloudLoadError, error && error.connected === false);
      setBusy(dialog, false, error instanceof Error ? error.message : labels.cloudLoadError, true);
    }
  };

  const startCloudConnection = (dialog) => {
    const postId = Number(dialog.dataset.pagecraftPost || 0);
    if (!Number.isInteger(postId) || postId < 1) return;
    setBusy(dialog, true, labels.cloudLoading);
    const form = document.createElement('form');
    form.method = 'post';
    form.action = config.cloudStartUrl;
    form.hidden = true;
    [['action', 'pagecraft_cloud_start'], ['post', String(postId)], ['_wpnonce', config.cloudStartNonce]].forEach(([name, value]) => {
      const field = document.createElement('input');
      field.type = 'hidden';
      field.name = name;
      field.value = value;
      form.append(field);
    });
    document.body.append(form);
    form.submit();
  };

  const importCloudPage = async (dialog, button) => {
    const postId = Number(dialog.dataset.pagecraftPost || 0);
    setBusy(dialog, true, labels.cloudImporting);
    try {
      const body = new URLSearchParams({
        nonce: config.cloudNonce,
        post: String(postId),
        project: String(button.dataset.pagecraftCloudProject || ''),
        cloud_page: String(button.dataset.pagecraftCloudPage || '')
      });
      const data = await responseJson(await fetch(config.cloudImportUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body.toString()
      }));
      if (!data.editorUrl) throw new Error(labels.cloudImportError);
      window.location.assign(data.editorUrl);
    } catch (error) {
      setBusy(dialog, false, error instanceof Error ? error.message : labels.cloudImportError, true);
    }
  };

  const handleChoice = async (action, dialog) => {
    setBusy(dialog, true, labels.saving);
    try {
      const postId = await saveCurrentPage();
      if (action === 'blank') {
        preparePage(postId);
        return;
      }
      if (action === 'template') {
        showTemplateView(dialog, postId);
        return;
      }
      if (action === 'cloud') await loadCloudPages(dialog, postId);
    } catch (error) {
      setBusy(dialog, false, labels.error, true);
    }
  };

  const openDialog = (source) => {
    if (config.editorUrl) {
      window.location.assign(config.editorUrl);
      return;
    }
    const dialog = createDialog();
    opener = source instanceof HTMLElement ? source : null;
    showStartView(dialog);
    if (!dialog.open) dialog.showModal();
    if (returnToCloud) {
      returnToCloud = false;
      const postId = Number(config.postId || 0);
      if (Number.isInteger(postId) && postId > 0) {
        void loadCloudPages(dialog, postId);
        return;
      }
    }
    const firstChoice = dialog.querySelector('[data-pagecraft-choice="blank"]');
    if (firstChoice instanceof HTMLElement) firstChoice.focus();
  };

  const clearOpenFlag = () => {
    const url = new URL(window.location.href);
    if (!url.searchParams.has('pagecraft_choose') && !url.searchParams.has('pagecraft_cloud')) return;
    url.searchParams.delete('pagecraft_choose');
    url.searchParams.delete('pagecraft_cloud');
    window.history.replaceState({}, '', url.toString());
  };

  const mount = () => {
    let button = document.getElementById(buttonId);
    if (!button) {
      const toolbar = document.querySelector('.editor-document-tools, .edit-post-header-toolbar');
      if (!toolbar) return false;
      button = document.createElement('button');
      button.id = buttonId;
      button.type = 'button';
      button.className = 'components-button pagecraft-block-editor-button';
      button.innerHTML = `${mark()}<span></span>`;
      button.querySelector('span').textContent = labels.button;
      button.setAttribute('aria-label', labels.button);
      button.addEventListener('click', () => {
        if (config.editorUrl) window.location.assign(config.editorUrl);
        else openDialog(button);
      });
      toolbar.append(button);
    }

    if (config.openOnLoad && !openedFromUrl) {
      openedFromUrl = true;
      clearOpenFlag();
      openDialog(button);
    }
    return true;
  };

  mount();
  let scheduled = false;
  const observer = new MutationObserver(() => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      mount();
    });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
