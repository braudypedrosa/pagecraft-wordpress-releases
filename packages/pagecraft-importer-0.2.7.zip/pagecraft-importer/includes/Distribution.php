<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use RuntimeException;

final class Distribution
{
    private const PREFIX = "pagecraft-wordpress-distribution-v1\0";
    private const CACHE_KEY = 'pagecraft_importer_stable_distribution';
    private const ACCEPTED_KEY = 'pagecraft_importer_accepted_distribution_v1';

    /** @return array<string,mixed> */
    public function stable(bool $refresh = false): array
    {
        if (!$refresh) {
            $cached = get_transient(self::CACHE_KEY);
            if (is_array($cached)) return $cached;
        }
        $origin = Support::apiOrigin();
        $response = wp_safe_remote_get($origin . Support::feedPath(), [
            'timeout' => 20, 'redirection' => 0,
            'headers' => ['Accept' => 'application/json'],
            'user-agent' => 'Pagecraft-Importer/' . PAGECRAFT_IMPORTER_VERSION,
            'limit_response_size' => 512 * 1024,
        ]);
        if (is_wp_error($response)) {
            throw new RuntimeException('Pagecraft distribution could not be reached: ' . $response->get_error_message());
        }
        if (wp_remote_retrieve_response_code($response) !== 200) {
            throw new RuntimeException('Pagecraft distribution is not currently available.');
        }
        $payload = json_decode(wp_remote_retrieve_body($response), true, 128, JSON_THROW_ON_ERROR);
        if (!is_array($payload)) throw new RuntimeException('Pagecraft distribution response is invalid.');
        $keyset = RootTrust::verify((array) ($payload['keysetEnvelope'] ?? []));
        $encoded = (string) ($payload['manifest'] ?? '');
        $bytes = Support::base64UrlDecode($encoded);
        CanonicalJson::decode($bytes);
        $signature = Support::base64UrlDecode((string) ($payload['signature'] ?? ''));
        $publicKey = $this->releaseKey($keyset, (string) ($payload['keyId'] ?? ''));
        if (strlen($signature) !== 64 || !Support::verifyEd25519($signature, self::PREFIX . $bytes, $publicKey)) {
            throw new RuntimeException('The Pagecraft distribution signature is invalid.');
        }
        $manifest = Support::decodeObject($bytes);
        $this->validate($manifest, $payload, $origin);
        $manifest['_downloads'] = array_map(
            static fn (array $product): string => (string) $product['downloadUrl'],
            (array) $payload['products']
        );
        update_option(self::ACCEPTED_KEY, [
            'generated_at' => (string) $manifest['generatedAt'],
            'versions' => array_map(static fn (array $product): string => (string) $product['version'], $manifest['products']),
        ], false);
        set_transient(self::CACHE_KEY, $manifest, 5 * MINUTE_IN_SECONDS);
        return $manifest;
    }

    /** @param array<string,mixed> $keyset */
    private function releaseKey(array $keyset, string $id): string
    {
        foreach ((array) ($keyset['keys'] ?? []) as $key) {
            if (!is_array($key) || !hash_equals($id, (string) ($key['id'] ?? ''))) continue;
            $now = time();
            $before = strtotime((string) ($key['notBefore'] ?? ''));
            $after = strtotime((string) ($key['notAfter'] ?? ''));
            if (($key['algorithm'] ?? '') !== 'Ed25519' || !$before || !$after || $before > $now || $after <= $now) break;
            $decoded = Support::base64UrlDecode((string) ($key['publicKey'] ?? ''));
            if (strlen($decoded) === 32) return $decoded;
        }
        throw new RuntimeException('The Pagecraft distribution signing key is unknown or inactive.');
    }

    /** @param array<string,mixed> $manifest @param array<string,mixed> $payload */
    private function validate(array $manifest, array $payload, string $origin): void
    {
        if (($manifest['format'] ?? '') !== 'pagecraft.wordpress-distribution.v1'
            || ($manifest['channel'] ?? '') !== 'stable'
            || !is_array($manifest['products'] ?? null)
            || !is_array($manifest['compatibility']['builderTheme'] ?? null)
            || !is_array($payload['products'] ?? null)) {
            throw new RuntimeException('The Pagecraft distribution manifest is unsupported.');
        }
        $generated = strtotime((string) ($manifest['generatedAt'] ?? ''));
        if (!$generated || $generated > time() + 300) {
            throw new RuntimeException('The Pagecraft distribution timestamp is invalid.');
        }
        $accepted = get_option(self::ACCEPTED_KEY, []);
        if (is_array($accepted) && !empty($accepted['generated_at'])) {
            $previous = strtotime((string) $accepted['generated_at']);
            if ($previous && $generated < $previous) {
                throw new RuntimeException('The Pagecraft distribution is older than one this site already accepted.');
            }
        }
        $expected = ['importer' => 'pagecraft-importer', 'builder' => 'pagecraft-builder', 'theme' => 'pagecraft-theme'];
        foreach ($expected as $name => $slug) {
            $product = $manifest['products'][$name] ?? null;
            $response = $payload['products'][$name] ?? null;
            if (!is_array($product) || !is_array($response)
                || ($product['slug'] ?? '') !== $slug
                || !preg_match('/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/', (string) ($product['version'] ?? ''))
                || !preg_match('/^[a-f0-9]{64}$/', (string) ($product['sha256'] ?? ''))
                || !is_int($product['size'] ?? null) || $product['size'] < 1 || $product['size'] > 64 * MB_IN_BYTES
                || !is_array($product['requirements'] ?? null)
                || !is_string($product['requirements']['wordpress'] ?? null)
                || !is_string($product['requirements']['php'] ?? null)
                || !is_string($product['downloadPath'] ?? null)
                || !hash_equals((string) $product['downloadPath'], (string) ($response['downloadPath'] ?? ''))
                || !hash_equals((string) $product['sha256'], (string) ($response['sha256'] ?? ''))) {
                throw new RuntimeException(sprintf('The signed %s package record is invalid.', $name));
            }
            $previousVersion = is_array($accepted) ? (string) ($accepted['versions'][$name] ?? '') : '';
            if ($previousVersion !== '' && version_compare((string) $product['version'], $previousVersion, '<')) {
                throw new RuntimeException(sprintf('The signed %s package attempts a version rollback.', $name));
            }
            $download = (string) ($response['downloadUrl'] ?? '');
            $parts = wp_parse_url($download);
            if ($download === '' || !hash_equals(strtolower($origin), Support::originFromUrl($download))
                || !hash_equals((string) $product['downloadPath'], (string) ($parts['path'] ?? ''))
                || !empty($parts['query']) || !empty($parts['fragment'])) {
                throw new RuntimeException(sprintf('The %s package URL is not bound to its signed record.', $name));
            }
            if (!hash_equals((string) $product['size'], (string) ($response['size'] ?? ''))
                || !hash_equals((string) $product['slug'], (string) ($response['slug'] ?? ''))
                || !hash_equals((string) $product['version'], (string) ($response['version'] ?? ''))) {
                throw new RuntimeException(sprintf('The %s package response does not match its signed record.', $name));
            }
        }
        $builder = (string) $manifest['products']['builder']['version'];
        $theme = (string) $manifest['products']['theme']['version'];
        $compatible = array_filter(
            $manifest['compatibility']['builderTheme'],
            static fn (mixed $row): bool => is_array($row)
                && hash_equals($builder, (string) ($row['builder'] ?? ''))
                && hash_equals($theme, (string) ($row['theme'] ?? ''))
        );
        if ($compatible === []) throw new RuntimeException('Builder and Theme are not a tested compatibility pair.');
    }
}
