<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use Throwable;

final class Admin
{
    public function __construct(
        private readonly Distribution $distribution,
        private readonly Preflight $preflight,
        private readonly Installer $installer
    ) {
    }

    public function hooks(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_post_pagecraft_importer_apply', [$this, 'apply']);
        add_action('admin_post_pagecraft_importer_rollback_theme', [$this, 'rollback']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
    }

    public function menu(): void
    {
        add_management_page(
            __('Pagecraft Importer', 'pagecraft-importer'),
            __('Pagecraft Importer', 'pagecraft-importer'),
            Capabilities::MANAGE,
            'pagecraft-importer',
            [$this, 'render']
        );
    }

    public function assets(string $hook): void
    {
        if ($hook === 'tools_page_pagecraft-importer') {
            wp_enqueue_style('pagecraft-importer', PAGECRAFT_IMPORTER_URL . 'assets/admin.css', [], PAGECRAFT_IMPORTER_VERSION);
        }
    }

    public function render(): void
    {
        if (!Capabilities::allowed()) wp_die(esc_html__('You cannot manage Pagecraft packages.', 'pagecraft-importer'));
        $checks = $this->preflight->report();
        $error = '';
        try {
            $manifest = $this->distribution->stable();
        } catch (Throwable $caught) {
            $manifest = [];
            $error = $caught->getMessage();
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Cosmetic message from a safe admin redirect.
        $message = sanitize_text_field(wp_unslash((string) ($_GET['pagecraft_message'] ?? '')));
        ?>
        <div class="wrap pc-importer">
            <h1><?php esc_html_e('Pagecraft Importer', 'pagecraft-importer'); ?></h1>
            <p class="description"><?php esc_html_e('Verified setup and compatibility management for Pagecraft Builder and Theme.', 'pagecraft-importer'); ?></p>
            <?php if ($message !== '') : ?><div class="notice notice-success inline"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
            <?php if ($error !== '') : ?><div class="notice notice-error inline"><p><?php echo esc_html($error); ?></p></div><?php endif; ?>
            <section class="pc-importer-card">
                <h2><?php esc_html_e('Preflight', 'pagecraft-importer'); ?></h2>
                <ul class="pc-checks">
                    <?php foreach ($checks as $check) : ?>
                        <li class="<?php echo $check['ok'] ? 'is-ok' : ($check['blocking'] ? 'is-error' : 'is-warning'); ?>">
                            <span aria-hidden="true"></span><?php echo esc_html($check['message']); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <?php if (!$checks['existing_content']['ok']) : ?>
                    <div class="notice notice-warning inline"><p><?php esc_html_e('This site already has pages. Back up the site and review theme impact before continuing. Existing content is not deleted.', 'pagecraft-importer'); ?></p></div>
                <?php endif; ?>
            </section>
            <?php if ($manifest !== []) : ?>
                <section class="pc-importer-card">
                    <h2><?php esc_html_e('Signed stable release', 'pagecraft-importer'); ?></h2>
                    <table class="widefat striped"><thead><tr><th><?php esc_html_e('Product', 'pagecraft-importer'); ?></th><th><?php esc_html_e('Version', 'pagecraft-importer'); ?></th><th><?php esc_html_e('SHA-256', 'pagecraft-importer'); ?></th></tr></thead><tbody>
                    <?php foreach (['importer', 'builder', 'theme'] as $name) : $product = $manifest['products'][$name]; ?>
                        <tr><td><?php echo esc_html(ucfirst($name)); ?></td><td><?php echo esc_html((string) $product['version']); ?></td><td><code><?php echo esc_html((string) $product['sha256']); ?></code></td></tr>
                    <?php endforeach; ?>
                    </tbody></table>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="pc-importer-actions">
                        <input type="hidden" name="action" value="pagecraft_importer_apply">
                        <?php wp_nonce_field('pagecraft_importer_apply'); ?>
                        <label><input type="checkbox" name="actions[]" value="install_theme"> <?php esc_html_e('Install or update Pagecraft Theme', 'pagecraft-importer'); ?></label>
                        <label><input type="checkbox" name="actions[]" value="install_builder"> <?php esc_html_e('Install or update Pagecraft Builder', 'pagecraft-importer'); ?></label>
                        <label><input type="checkbox" name="actions[]" value="activate_builder"> <?php esc_html_e('Activate Pagecraft Builder', 'pagecraft-importer'); ?></label>
                        <label><input type="checkbox" name="actions[]" value="switch_theme"> <?php esc_html_e('Switch this site to Pagecraft Theme', 'pagecraft-importer'); ?></label>
                        <p class="description"><?php esc_html_e('Only checked changes will run. Theme switching changes the public appearance of existing content.', 'pagecraft-importer'); ?></p>
                        <?php submit_button(
                            __('Confirm selected changes', 'pagecraft-importer'),
                            'primary',
                            'submit',
                            false,
                            $this->preflight->passes($checks) ? [] : ['disabled' => 'disabled']
                        ); ?>
                    </form>
                </section>
            <?php endif; ?>
            <?php if (is_array(get_option('pagecraft_importer_previous_theme', null))) : ?>
                <section class="pc-importer-card"><h2><?php esc_html_e('Theme rollback', 'pagecraft-importer'); ?></h2>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="pagecraft_importer_rollback_theme">
                        <?php wp_nonce_field('pagecraft_importer_rollback_theme'); ?>
                        <?php submit_button(__('Restore previous theme', 'pagecraft-importer'), 'secondary', 'submit', false); ?>
                    </form>
                </section>
            <?php endif; ?>
        </div>
        <?php
    }

    public function apply(): void
    {
        if (!Capabilities::allowed()) {
            wp_die(esc_html__('You cannot manage Pagecraft packages.', 'pagecraft-importer'), '', ['response' => 403]);
        }
        check_admin_referer('pagecraft_importer_apply');
        $actions = array_values(array_filter(array_map(
            'sanitize_key',
            (array) wp_unslash($_POST['actions'] ?? [])
        )));
        try {
            $messages = $this->installer->apply($actions);
            $this->redirect($messages === [] ? 'No changes were selected.' : implode(' ', $messages));
        } catch (Throwable $error) {
            wp_die(esc_html($error->getMessage()), esc_html__('Pagecraft installation failed', 'pagecraft-importer'), ['response' => 400]);
        }
    }

    public function rollback(): void
    {
        $this->guard('pagecraft_importer_rollback_theme');
        try { $this->redirect($this->installer->rollbackTheme()); }
        catch (Throwable $error) {
            wp_die(esc_html($error->getMessage()), esc_html__('Pagecraft rollback failed', 'pagecraft-importer'), ['response' => 400]);
        }
    }

    private function guard(string $nonce): void
    {
        if (!Capabilities::allowed()) wp_die(esc_html__('You cannot manage Pagecraft packages.', 'pagecraft-importer'), '', ['response' => 403]);
        check_admin_referer($nonce);
    }

    private function redirect(string $message): never
    {
        wp_safe_redirect(add_query_arg([
            'page' => 'pagecraft-importer', 'pagecraft_message' => $message
        ], admin_url('tools.php')));
        exit;
    }
}
