<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use JsonException;
use RuntimeException;
use stdClass;

final class CanonicalJson
{
    public static function encode(mixed $value): string
    {
        if ($value === null) return 'null';
        if ($value === true) return 'true';
        if ($value === false) return 'false';
        if (is_int($value)) return (string) $value;
        if (is_float($value)) throw new RuntimeException('Floating-point values are not allowed in signed manifests.');
        if (is_string($value)) return self::encodeString($value);
        if ($value instanceof stdClass) return self::encodeObject(get_object_vars($value));
        if (is_array($value)) {
            return array_is_list($value)
                ? '[' . implode(',', array_map([self::class, 'encode'], $value)) . ']'
                : self::encodeObject($value);
        }
        throw new RuntimeException('Unsupported canonical JSON value.');
    }

    public static function decode(string $json): stdClass
    {
        try {
            $decoded = json_decode($json, false, 128, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new RuntimeException('Manifest JSON is invalid.', 0, $error);
        }
        if (!$decoded instanceof stdClass || !hash_equals(self::encode($decoded), $json)) {
            throw new RuntimeException('Manifest JSON is not canonical.');
        }
        return $decoded;
    }

    /** @param array<string,mixed> $value */
    private static function encodeObject(array $value): string
    {
        uksort($value, static function (string $left, string $right): int {
            if (function_exists('mb_convert_encoding')) {
                return strcmp(
                    (string) mb_convert_encoding($left, 'UTF-16BE', 'UTF-8'),
                    (string) mb_convert_encoding($right, 'UTF-16BE', 'UTF-8')
                );
            }
            if (function_exists('iconv')) {
                return strcmp((string) iconv('UTF-8', 'UTF-16BE', $left), (string) iconv('UTF-8', 'UTF-16BE', $right));
            }
            return strcmp($left, $right);
        });
        $pairs = [];
        foreach ($value as $key => $item) {
            $pairs[] = self::encodeString((string) $key) . ':' . self::encode($item);
        }
        return '{' . implode(',', $pairs) . '}';
    }

    private static function encodeString(string $value): string
    {
        // phpcs:ignore WordPress.WP.AlternativeFunctions.json_encode_json_encode -- Signed canonical JSON must preserve exact bytes and is verified in standalone release tests.
        return json_encode(
            $value,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_LINE_TERMINATORS | JSON_THROW_ON_ERROR
        );
    }
}
