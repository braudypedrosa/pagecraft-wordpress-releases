<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

final class Capabilities
{
    public const MANAGE = 'manage_pagecraft_distribution';

    public static function activate(): void
    {
        if (is_multisite()) {
            deactivate_plugins(plugin_basename(PAGECRAFT_IMPORTER_FILE));
            wp_die(esc_html__('Pagecraft Importer v1 does not support WordPress multisite.', 'pagecraft-importer'));
        }
        $role = get_role('administrator');
        if ($role) {
            $role->add_cap(self::MANAGE);
        }
    }

    public static function allowed(): bool
    {
        return current_user_can(self::MANAGE)
            && current_user_can('install_plugins')
            && current_user_can('activate_plugins')
            && current_user_can('install_themes')
            && current_user_can('switch_themes');
    }
}
