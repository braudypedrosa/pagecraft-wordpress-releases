<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use RuntimeException;
use ZipArchive;

final class ArchiveValidator
{
    private const MAX_FILES = 5000;
    private const MAX_UNCOMPRESSED = 256 * MB_IN_BYTES;
    private const MAX_FILE = 64 * MB_IN_BYTES;
    private const MAX_RATIO = 100;
    private const MAX_PATH_BYTES = 1024;

    public function validate(string $file, string $slug): void
    {
        if (!class_exists(ZipArchive::class)) throw new RuntimeException('ZIP support is required.');
        $zip = new ZipArchive();
        if ($zip->open($file) !== true) throw new RuntimeException('The package is not a readable ZIP archive.');
        try {
            if ($zip->numFiles < 1 || $zip->numFiles > self::MAX_FILES) {
                throw new RuntimeException('The package contains an unsafe number of files.');
            }
            $expectedRoot = $slug === 'pagecraft-theme' ? 'pagecraft' : $slug;
            $required = $slug === 'pagecraft-theme' ? 'pagecraft/style.css' : $slug . '/' . $slug . '.php';
            $found = false;
            $total = 0;
            for ($index = 0; $index < $zip->numFiles; $index++) {
                $stat = $zip->statIndex($index);
                if (!is_array($stat)) {
                    throw new RuntimeException('The package contains an unreadable ZIP record.');
                }
                $name = (string) $stat['name'];
                $size = (int) $stat['size'];
                $compressed = (int) $stat['comp_size'];
                if (!$this->safePath($name) || !str_starts_with($name, $expectedRoot . '/')) {
                    throw new RuntimeException('The package contains an unsafe or unexpected path.');
                }
                if (str_ends_with($name, '/')) continue;
                if (!in_array((int) $stat['comp_method'], [ZipArchive::CM_STORE, ZipArchive::CM_DEFLATE], true)
                    || (int) $stat['encryption_method'] !== ZipArchive::EM_NONE) {
                    throw new RuntimeException('The package uses unsupported ZIP compression or encryption.');
                }
                $operations = 0;
                $attributes = 0;
                if ($zip->getExternalAttributesIndex($index, $operations, $attributes)
                    && $operations === ZipArchive::OPSYS_UNIX
                    && (($attributes >> 16) & 0170000) === 0120000) {
                    throw new RuntimeException('The package cannot contain symbolic links.');
                }
                if ($size < 0 || $size > self::MAX_FILE || $compressed < 0
                    || ($compressed === 0 && $size > 0)
                    || ($compressed > 0 && $size / $compressed > self::MAX_RATIO)) {
                    throw new RuntimeException('The package contains an unsafe compressed file.');
                }
                $total += $size;
                if ($total > self::MAX_UNCOMPRESSED) throw new RuntimeException('The package is too large after extraction.');
                if ($name === $required) $found = true;
            }
            if (!$found) throw new RuntimeException(sprintf('The package is missing %s.', $required));
        } finally {
            $zip->close();
        }
    }

    private function safePath(string $path): bool
    {
        if ($path === '' || strlen($path) > self::MAX_PATH_BYTES || str_starts_with($path, '/')
            || str_contains($path, "\0") || str_contains($path, '\\')) return false;
        foreach (explode('/', rtrim($path, '/')) as $part) {
            if ($part === '' || $part === '.' || $part === '..') return false;
        }
        return true;
    }
}
