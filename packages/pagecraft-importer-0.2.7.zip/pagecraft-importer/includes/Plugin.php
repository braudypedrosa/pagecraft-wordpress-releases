<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

final class Plugin
{
    private static ?self $instance = null;

    public static function instance(): self
    {
        return self::$instance ??= new self();
    }

    public function boot(): void
    {
        if (is_multisite() || version_compare(PHP_VERSION, '8.1', '<')) {
            add_action('admin_notices', [$this, 'requirementsNotice']);
            return;
        }
        $distribution = new Distribution();
        $installer = new Installer($distribution, new ArchiveValidator());
        (new Admin(
            $distribution,
            new Preflight(),
            $installer
        ))->hooks();
        (new Updates($distribution, $installer))->hooks();
        add_action('admin_notices', [$this, 'compatibilityNotice']);
    }

    public function requirementsNotice(): void
    {
        echo '<div class="notice notice-error"><p>'
            . esc_html__('Pagecraft Importer requires PHP 8.1+ and a single-site WordPress installation.', 'pagecraft-importer')
            . '</p></div>';
    }

    public function compatibilityNotice(): void
    {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        if (!is_plugin_active('pagecraft-builder/pagecraft-builder.php')) return;
        $theme = wp_get_theme('pagecraft');
        if ($theme->exists() && defined('PAGECRAFT_BUILDER_VERSION')
            && version_compare((string) $theme->get('Version'), PAGECRAFT_BUILDER_VERSION, '==')) return;
        echo '<div class="notice notice-error"><p>'
            . wp_kses_post(sprintf(
                __('Pagecraft Builder is blocked until the matching Pagecraft Theme is installed. <a href="%s">Open Pagecraft Importer</a>.', 'pagecraft-importer'),
                esc_url(admin_url('tools.php?page=pagecraft-importer'))
            )) . '</p></div>';
    }
}
