<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use RuntimeException;

final class Support
{
    public static function base64UrlDecode(string $value): string
    {
        if ($value === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $value)) {
            throw new RuntimeException('Signed Pagecraft data is not valid base64url.');
        }
        $decoded = base64_decode(strtr($value, '-_', '+/') . str_repeat('=', (4 - strlen($value) % 4) % 4), true);
        if (!is_string($decoded)) {
            throw new RuntimeException('Signed Pagecraft data could not be decoded.');
        }
        return $decoded;
    }

    /** @return array<string,mixed> */
    public static function decodeObject(string $json): array
    {
        $value = json_decode($json, true, 128, JSON_THROW_ON_ERROR);
        if (!is_array($value) || array_is_list($value)) {
            throw new RuntimeException('Signed Pagecraft data must be an object.');
        }
        return $value;
    }

    /** Releases are published to a public GitHub repository and read as plain files. */
    public const RELEASES_ORIGIN = 'https://raw.githubusercontent.com';
    public const RELEASES_FEED_PATH = '/braudypedrosa/pagecraft-wordpress-releases/main/stable.json';

    /**
     * Where the signed feed lives under the origin. The feed is trusted for its signature, not its
     * address, so this only decides where to look.
     */
    public static function feedPath(): string
    {
        $path = (string) apply_filters('pagecraft_importer_feed_path', self::RELEASES_FEED_PATH);
        if (preg_match('#^(/[A-Za-z0-9._-]+)+$#', $path) !== 1 || str_contains($path, '..')) {
            throw new RuntimeException('The Pagecraft distribution feed path is invalid.');
        }
        return $path;
    }

    public static function apiOrigin(): string
    {
        $origin = untrailingslashit((string) apply_filters(
            'pagecraft_importer_api_origin',
            self::RELEASES_ORIGIN
        ));
        $parts = wp_parse_url($origin);
        $local = in_array(strtolower((string) ($parts['host'] ?? '')), ['localhost', '127.0.0.1', '::1'], true)
            && defined('PAGECRAFT_IMPORTER_ALLOW_LOCAL_HTTP')
            && PAGECRAFT_IMPORTER_ALLOW_LOCAL_HTTP === true;
        if (($parts['scheme'] ?? '') !== 'https' && !$local) {
            throw new RuntimeException('The Pagecraft distribution origin must use HTTPS.');
        }
        if (empty($parts['host']) || !empty($parts['user']) || !empty($parts['pass'])
            || !empty($parts['query']) || !empty($parts['fragment'])
            || (isset($parts['path']) && !in_array($parts['path'], ['', '/'], true))) {
            throw new RuntimeException('The Pagecraft distribution origin is invalid.');
        }
        return $origin;
    }

    public static function isLoopbackOrigin(string $origin): bool
    {
        $parts = wp_parse_url($origin);
        return in_array(strtolower((string) ($parts['host'] ?? '')), ['localhost', '127.0.0.1', '::1'], true);
    }

    public static function originFromUrl(string $url): string
    {
        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return '';
        }
        $host = str_contains((string) $parts['host'], ':')
            ? '[' . (string) $parts['host'] . ']'
            : (string) $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
        return strtolower((string) $parts['scheme']) . '://' . strtolower($host) . $port;
    }

    public static function verifyEd25519(string $signature, string $message, string $publicKey): bool
    {
        if (function_exists('sodium_crypto_sign_verify_detached')) {
            return sodium_crypto_sign_verify_detached($signature, $message, $publicKey);
        }
        if (class_exists('ParagonIE_Sodium_Compat')) {
            return \ParagonIE_Sodium_Compat::crypto_sign_verify_detached($signature, $message, $publicKey);
        }
        throw new RuntimeException('Pagecraft requires Sodium or sodium_compat to verify signed packages.');
    }
}
