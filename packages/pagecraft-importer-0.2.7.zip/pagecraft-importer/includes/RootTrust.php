<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use RuntimeException;

final class RootTrust
{
    public const ROOT_KEY_ID = 'pagecraft-root-v1';
    private const BUNDLED_ROOT_PUBLIC_KEY = 'jzDL0y4ABGOUnECJhP-Kd5mJgngSBqA7432DPyt0i80';
    private const PREFIX = "pagecraft-keyset-v1\0";

    /** @param array<string,mixed> $envelope @return array<string,mixed> */
    public static function verify(array $envelope): array
    {
        $encoded = (string) ($envelope['keyset'] ?? '');
        $bytes = Support::base64UrlDecode($encoded);
        $signature = Support::base64UrlDecode((string) ($envelope['signature'] ?? ''));
        if (!hash_equals(self::ROOT_KEY_ID, (string) ($envelope['rootKeyId'] ?? ''))
            || strlen($signature) !== 64) {
            throw new RuntimeException('The Pagecraft signing-key envelope is invalid.');
        }
        CanonicalJson::decode($bytes);
        if (!Support::verifyEd25519($signature, self::PREFIX . $bytes, self::publicKey())) {
            throw new RuntimeException('The Pagecraft signing-key set is not signed by the pinned root key.');
        }
        $keyset = Support::decodeObject($bytes);
        $now = time();
        if (($keyset['format'] ?? '') !== 'pagecraft.keyset.v1'
            || !is_array($keyset['keys'] ?? null)
            || ($generated = strtotime((string) ($keyset['generatedAt'] ?? ''))) === false
            || ($expires = strtotime((string) ($keyset['expiresAt'] ?? ''))) === false
            || $generated > $now + 300 || $expires <= $now) {
            throw new RuntimeException('The Pagecraft signing-key set is not currently valid.');
        }
        return $keyset;
    }

    private static function publicKey(): string
    {
        $encoded = self::BUNDLED_ROOT_PUBLIC_KEY;
        if (str_starts_with($encoded, '@@')
            && defined('PAGECRAFT_IMPORTER_LOCAL_ROOT_PUBLIC_KEY')
            && defined('PAGECRAFT_IMPORTER_ALLOW_LOCAL_ROOT_OVERRIDE')
            && PAGECRAFT_IMPORTER_ALLOW_LOCAL_ROOT_OVERRIDE === true
            && Support::isLoopbackOrigin(Support::apiOrigin())) {
            $encoded = (string) PAGECRAFT_IMPORTER_LOCAL_ROOT_PUBLIC_KEY;
        }
        $key = Support::base64UrlDecode($encoded);
        if (strlen($key) !== 32) {
            throw new RuntimeException('This Pagecraft Importer has no valid pinned root public key.');
        }
        return $key;
    }
}
