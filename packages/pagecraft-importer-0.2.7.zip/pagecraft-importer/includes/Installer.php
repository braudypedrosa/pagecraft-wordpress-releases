<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use RuntimeException;

final class Installer
{
    public function __construct(
        private readonly Distribution $distribution,
        private readonly ArchiveValidator $archives
    ) {
    }

    /** @param list<string> $actions @return list<string> */
    public function apply(array $actions): array
    {
        if (!Capabilities::allowed()) throw new RuntimeException('Your account cannot install and activate Pagecraft products.');
        $allowed = ['install_builder', 'install_theme', 'activate_builder', 'switch_theme'];
        foreach ($actions as $action) if (!in_array($action, $allowed, true)) throw new RuntimeException('Unknown Pagecraft installation action.');
        $manifest = $this->distribution->stable(true);
        $messages = [];
        if (in_array('install_theme', $actions, true)) {
            $this->install('theme', $manifest);
            $messages[] = 'Pagecraft Theme installed or updated.';
        }
        if (in_array('install_builder', $actions, true)) {
            $this->install('builder', $manifest);
            $messages[] = 'Pagecraft Builder installed or updated.';
        }
        if (in_array('switch_theme', $actions, true)) {
            $theme = wp_get_theme('pagecraft');
            if (!$theme->exists() || $theme->errors()) throw new RuntimeException('Install Pagecraft Theme before activating it.');
            if (get_stylesheet() !== 'pagecraft') {
                update_option('pagecraft_importer_previous_theme', [
                    'stylesheet' => get_stylesheet(), 'template' => get_template(), 'recorded_at' => time()
                ], false);
                switch_theme('pagecraft');
            }
            if (get_stylesheet() !== 'pagecraft') throw new RuntimeException('WordPress did not activate Pagecraft Theme.');
            $messages[] = 'Pagecraft Theme activated. The previous theme is available for rollback.';
        }
        if (in_array('activate_builder', $actions, true)) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            $theme = wp_get_theme('pagecraft');
            if (!$theme->exists() || $theme->errors()
                || !hash_equals((string) $manifest['products']['theme']['version'], (string) $theme->get('Version'))
                || get_stylesheet() !== 'pagecraft') {
                throw new RuntimeException('Install and activate the matching Pagecraft Theme before activating Builder.');
            }
            $result = activate_plugin('pagecraft-builder/pagecraft-builder.php', '', false, false);
            if (is_wp_error($result)) throw new RuntimeException($result->get_error_message());
            $messages[] = 'Pagecraft Builder activated.';
        }
        return $messages;
    }

    /** @param array<string,mixed> $manifest */
    public function verifiedDownload(string $name, array $manifest): string
    {
        $product = $manifest['products'][$name] ?? null;
        $url = $manifest['_downloads'][$name] ?? null;
        if (!is_array($product) || !is_string($url)) throw new RuntimeException('The signed package record is missing.');
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url($url, 300, false);
        if (is_wp_error($file)) throw new RuntimeException($file->get_error_message());
        try {
            $size = filesize($file);
            if (!is_int($size) || $size !== (int) $product['size']
                || !hash_equals((string) $product['sha256'], (string) hash_file('sha256', $file))) {
                throw new RuntimeException('The downloaded package does not match its signed size and SHA-256 hash.');
            }
            $this->archives->validate($file, (string) $product['slug']);
            return $file;
        } catch (\Throwable $error) {
            wp_delete_file($file);
            throw $error;
        }
    }

    public function rollbackTheme(): string
    {
        if (!Capabilities::allowed()) throw new RuntimeException('Your account cannot switch themes.');
        $previous = get_option('pagecraft_importer_previous_theme', []);
        $stylesheet = is_array($previous) ? sanitize_key((string) ($previous['stylesheet'] ?? '')) : '';
        $theme = $stylesheet !== '' ? wp_get_theme($stylesheet) : null;
        if (!$theme || !$theme->exists() || $theme->errors()) throw new RuntimeException('The previous theme is no longer installed.');
        switch_theme($stylesheet);
        if (get_stylesheet() !== $stylesheet) throw new RuntimeException('WordPress did not restore the previous theme.');
        delete_option('pagecraft_importer_previous_theme');
        return 'The previous theme was restored.';
    }

    /** @param array<string,mixed> $manifest */
    private function install(string $name, array $manifest): void
    {
        $product = $manifest['products'][$name] ?? null;
        if (!is_array($product)) throw new RuntimeException('The signed package record is missing.');
        $slug = (string) $product['slug'];
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        $file = $this->verifiedDownload($name, $manifest);
        try {
            $skin = new \Automatic_Upgrader_Skin();
            $upgrader = $name === 'theme' ? new \Theme_Upgrader($skin) : new \Plugin_Upgrader($skin);
            $result = $upgrader->install($file, ['overwrite_package' => true]);
            if (is_wp_error($result)) throw new RuntimeException($result->get_error_message());
            if ($result !== true) throw new RuntimeException(sprintf('WordPress could not install %s.', $slug));
        } finally {
            wp_delete_file($file);
        }
    }
}
