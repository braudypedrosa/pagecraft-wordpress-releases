<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

use Throwable;

/**
 * Offers Pagecraft releases on WordPress's own Updates screen.
 *
 * WordPress only learns that a newer version exists and where the file is. The file it then
 * downloads is the one named in the signed feed, checked against the signed size and hash before
 * WordPress is allowed to install it.
 */
final class Updates
{
    /** Feed product => the plugin file WordPress knows it by. */
    private const PLUGINS = [
        'importer' => 'pagecraft-importer/pagecraft-importer.php',
        'builder' => 'pagecraft-builder/pagecraft-builder.php',
    ];
    private const THEME = 'pagecraft';
    private const HOME = 'https://itspagecraft.com/';

    public function __construct(
        private readonly Distribution $distribution,
        private readonly Installer $installer
    ) {
    }

    public function hooks(): void
    {
        add_filter('pre_set_site_transient_update_plugins', [$this, 'offer']);
        add_filter('pre_set_site_transient_update_themes', [$this, 'offerTheme']);
        add_filter('upgrader_pre_download', [$this, 'verifyDownload'], 10, 4);
        add_filter('plugins_api', [$this, 'details'], 10, 3);
    }

    /**
     * What "View version details" shows on the Updates and Plugins screens. Everything comes from
     * the signed feed; the release notes are a link, never fetched into wp-admin.
     */
    public function details(mixed $result, mixed $action, mixed $args): mixed
    {
        $slug = is_object($args) ? (string) ($args->slug ?? '') : '';
        if ($action !== 'plugin_information' || $slug === '') return $result;
        try {
            $manifest = $this->distribution->stable();
            foreach (array_keys(self::PLUGINS) as $name) {
                $product = $manifest['products'][$name] ?? null;
                $url = $manifest['_downloads'][$name] ?? null;
                if (!is_array($product) || !is_string($url) || (string) ($product['slug'] ?? '') !== $slug) continue;
                $sections = ['description' => '<p>' . esc_html($name === 'builder'
                    ? __('Imports and edits Pagecraft content as native WordPress pages.', 'pagecraft-importer')
                    : __('Installs and updates Pagecraft Builder and Pagecraft Theme from signed releases.', 'pagecraft-importer')) . '</p>'];
                if (preg_match('#^/([^/]+/[^/]+)/(v[0-9][^/]*)/packages/#', (string) ($product['downloadPath'] ?? ''), $match)) {
                    $sections['changelog'] = '<p><a href="' . esc_url('https://github.com/' . $match[1] . '/blob/' . $match[2] . '/RELEASE-NOTES.md')
                        . '" target="_blank" rel="noopener noreferrer">' . esc_html(sprintf(
                            /* translators: %s: version number */
                            __('Read the release notes for %s', 'pagecraft-importer'),
                            (string) $product['version']
                        )) . '</a></p>';
                }
                return (object) [
                    'name' => $name === 'builder' ? 'Pagecraft Builder' : 'Pagecraft Importer',
                    'slug' => $slug,
                    'version' => (string) $product['version'],
                    'author' => '<a href="' . esc_url(self::HOME) . '">Pagecraft</a>',
                    'homepage' => self::HOME,
                    'requires' => ltrim((string) ($product['requirements']['wordpress'] ?? ''), '>= '),
                    'tested' => self::tested((string) ($product['requirements']['testedWordPress'] ?? '')),
                    'requires_php' => ltrim((string) ($product['requirements']['php'] ?? '8.1'), '>= '),
                    'download_link' => $url,
                    'sections' => $sections,
                ];
            }
        } catch (Throwable) {
            // A failed feed read must not break the details window of any plugin.
        }
        return $result;
    }

    /**
     * A release is tested against a WordPress branch such as "7.1". WordPress compares that with
     * its full version, so "7.1" would read as untested on 7.1.5: report the running version
     * whenever it belongs to the tested branch.
     */
    private static function tested(string $tested): string
    {
        $running = (string) preg_replace('/-.*$/', '', (string) get_bloginfo('version'));
        return preg_match('/^\d+\.\d+$/D', $tested) === 1 && str_starts_with($running . '.', $tested . '.') ? $running : $tested;
    }

    public function offer(mixed $transient): mixed
    {
        if (!is_object($transient) || empty($transient->checked)) return $transient;
        try {
            $manifest = $this->distribution->stable();
            foreach (self::PLUGINS as $name => $plugin) {
                $installed = (string) ($transient->checked[$plugin] ?? '');
                $product = $manifest['products'][$name] ?? null;
                $url = $manifest['_downloads'][$name] ?? null;
                if ($installed === '' || !is_array($product) || !is_string($url)
                    || version_compare((string) $product['version'], $installed, '<=')) {
                    continue;
                }
                $transient->response[$plugin] = (object) [
                    'id' => (string) $product['slug'],
                    'slug' => (string) $product['slug'],
                    'plugin' => $plugin,
                    'new_version' => (string) $product['version'],
                    'url' => self::HOME,
                    'package' => $url,
                    'tested' => self::tested((string) ($product['requirements']['testedWordPress'] ?? '')),
                    'requires_php' => ltrim((string) ($product['requirements']['php'] ?? '8.1'), '>= '),
                ];
            }
        } catch (Throwable) {
            // A failed update check must not interfere with the rest of wp-admin.
        }
        return $transient;
    }

    public function offerTheme(mixed $transient): mixed
    {
        if (!is_object($transient) || empty($transient->checked[self::THEME])) return $transient;
        try {
            $manifest = $this->distribution->stable();
            $product = $manifest['products']['theme'] ?? null;
            $url = $manifest['_downloads']['theme'] ?? null;
            if (!is_array($product) || !is_string($url)
                || version_compare((string) $product['version'], (string) $transient->checked[self::THEME], '<=')) {
                return $transient;
            }
            $transient->response[self::THEME] = [
                'theme' => self::THEME,
                'new_version' => (string) $product['version'],
                'url' => self::HOME,
                'package' => $url,
                'requires' => ltrim((string) ($product['requirements']['wordpress'] ?? ''), '>= '),
                'requires_php' => ltrim((string) ($product['requirements']['php'] ?? '8.1'), '>= '),
            ];
        } catch (Throwable) {
            // A failed update check must not interfere with the rest of wp-admin.
        }
        return $transient;
    }

    public function verifyDownload(mixed $reply, string $package, mixed $upgrader, array $hookExtra): mixed
    {
        if ($reply !== false) return $reply;
        $name = array_search((string) ($hookExtra['plugin'] ?? ''), self::PLUGINS, true);
        if ($name === false && ($hookExtra['theme'] ?? '') === self::THEME) $name = 'theme';
        if (!is_string($name)) return $reply;
        try {
            $manifest = $this->distribution->stable(true);
            $expected = (string) ($manifest['_downloads'][$name] ?? '');
            if ($expected === '' || !hash_equals($expected, $package)) {
                return new \WP_Error('pagecraft_importer_unsigned_update', __('This update is not the one in the signed Pagecraft release feed.', 'pagecraft-importer'));
            }
            return $this->installer->verifiedDownload($name, $manifest);
        } catch (Throwable $error) {
            return new \WP_Error('pagecraft_importer_update_failed', $error->getMessage());
        }
    }
}
