<?php

declare(strict_types=1);

namespace Pagecraft\Importer;

final class Preflight
{
    /** @return array<string,array{ok:bool,blocking:bool,message:string}> */
    public function report(): array
    {
        global $wp_filesystem;
        require_once ABSPATH . 'wp-admin/includes/file.php';
        if (!$wp_filesystem) WP_Filesystem();
        $uploads = wp_upload_dir();
        $pages = wp_count_posts('page');
        return [
            'wordpress' => ['ok' => version_compare((string) get_bloginfo('version'), '6.6', '>='), 'blocking' => true, 'message' => 'WordPress 6.6 or later'],
            'php' => ['ok' => version_compare(PHP_VERSION, '8.1', '>='), 'blocking' => true, 'message' => 'PHP 8.1 or later'],
            'single_site' => ['ok' => !is_multisite(), 'blocking' => true, 'message' => 'Single-site WordPress only'],
            'https' => ['ok' => is_ssl() || wp_get_environment_type() === 'local', 'blocking' => true, 'message' => 'HTTPS (local development excepted)'],
            'permalinks' => ['ok' => (string) get_option('permalink_structure', '') !== '', 'blocking' => true, 'message' => 'Pretty permalinks enabled'],
            'crypto' => ['ok' => function_exists('sodium_crypto_sign_verify_detached') || class_exists('ParagonIE_Sodium_Compat'), 'blocking' => true, 'message' => 'Ed25519 signature verification'],
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Read-only preflight; no filesystem abstraction writes here.
            'uploads' => ['ok' => empty($uploads['error']) && is_writable((string) ($uploads['basedir'] ?? '')), 'blocking' => true, 'message' => 'Writable uploads directory'],
            'filesystem' => ['ok' => is_object($wp_filesystem), 'blocking' => true, 'message' => 'WordPress filesystem access'],
            'existing_content' => ['ok' => ((int) ($pages->publish ?? 0) + (int) ($pages->draft ?? 0)) === 0, 'blocking' => false, 'message' => 'No existing pages'],
            'theme_impact' => ['ok' => get_stylesheet() === 'pagecraft', 'blocking' => false, 'message' => 'Pagecraft Theme already active'],
        ];
    }

    public function passes(array $report): bool
    {
        foreach ($report as $check) if ($check['blocking'] && !$check['ok']) return false;
        return true;
    }
}
