=== Pagecraft Importer ===
Contributors: pagecraft
Requires at least: 6.6
Requires PHP: 8.1
Stable tag: 0.2.0
License: GPLv3 or later

Verifies, installs, updates, and maintains compatibility between Pagecraft Builder and Pagecraft Theme.

== Security ==

Every distribution manifest is verified against the public root key embedded in this plugin.
Every archive is checked for its signed SHA-256 hash, exact size, expected package root, unsafe paths,
file count, expanded size, per-file size, and compression ratio before WordPress Upgrader APIs install it.
